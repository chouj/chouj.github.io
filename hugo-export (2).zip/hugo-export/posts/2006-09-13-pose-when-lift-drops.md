---
title: 电梯下坠时保护自己的最佳动作
author: Chouj
type: post
date: 2006-09-13T04:40:00+00:00
url: /2006/09/13/pose-when-lift-drops/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post_13.html
views:
  - 1508
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969806
categories:
  - 我记录
tags:
  - 保护
  - 电梯

---
<span style="font-size:180%;"><strong>首</strong></span>先在<a href="http://www.awflasher.com/blog/article.asp?id=663" target="_blank">aw</a>那里看到的，确实有用，值得转载。

**『电梯下坠时保护自己的最佳动作』**
  
****
  
**第一、(不论有几层楼) 赶快把每一层楼的按键都按下。**
  
****
  
**第二、如果电梯里有手把，一只手紧握手把。**
  
****
  
**第三、整个背部跟头部紧贴电梯内墙，呈一直线。**
  
****
  
**第四、膝盖呈弯曲姿势。**

说明：因为电梯下坠时，你不会知道它会何时着地，且坠落时很可能会全身骨折而死。所以：第一点是当紧急电源启动时，电梯可以马上停止继续下坠 .

第二点是为了要固定你人所在的位子，以致于你不会因为重心不稳而摔伤

第三点是为了要运用电梯墙壁作为脊椎的防护 .

第四点是最重要的是因为韧带是唯一人体富含弹性的一个组织，所以借用膝盖弯曲来承受重击压力，比骨头来承受压力来的大。

这个信息绝不虚构，只是我觉得很重要想让大家都知道，而且以后高楼会越来越多，以防万一 .

为了自己，为了朋友，为了亲人……看完之后请广为转寄…功德无量花5分钟转寄一下吧。