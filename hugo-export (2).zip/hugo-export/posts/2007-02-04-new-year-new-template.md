---
title: New Year New Template
author: Chouj
type: post
date: 2007-02-03T16:04:00+00:00
url: /2007/02/04/new-year-new-template/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/new-year-new-template.html
views:
  - 1562
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969845
categories:
  - 我记录
tags:
  - blog

---
<span style="font-size:180%;"><span style="font-weight: bold;">其</span></span>实之前的模版挺好的，但为了能适合发一些白底的图，一心想换成白色背景的板子。在家有时间有条件捣腾，就迫不及待的实现了。

<span style="font-size:180%;"><span style="font-weight: bold;">先</span></span>搜了半天，适合新版blogger的模版还真是不多，给出模版的出处（HUST校园网内估计访问不了）：<a href="http://www.geckoandfly.com/blogger-templates-beta/" target="_blank">Blogger Templates (Beta)</a>。里面的5个模版都很不错，经测试都可用。

<span style="font-size:180%;"><span style="font-weight: bold;">为</span></span>了调这些板子代码，测试显示效果，特意弄了个<a href="http://chris-chou.blogspot.com/" target="_blank">test blog</a>。最喜欢的要数K2，最先换上的，但在ie下显示不佳，调试失败，只好作罢。Andreas02也很棒，我唯独不喜欢这个板子的侧栏，链接一多就显得乱了。现在的这款Kubrick，和我<a href="http://xcchris.52blog.net/" target="_blank">第一个blog</a>的板子几乎是一样的，我废了点劲PS了一张header banner。担心的就是一旦<a href="http://pages.google.com/" target="_blank">googlepages</a>服务失效，这里就会面目全非了。

<span style="font-size:180%;"><span style="font-weight: bold;">在</span></span>学校，每天同学热情的拉人DotA，面子上磨不开，自由失去了纯色般，境地尴尬。住家几天，在时间的支配上就简单了许多。新年新模版，之后就是要好好想想，写点东西了。