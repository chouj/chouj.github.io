---
title: Feeds的翻译 正太们的照片
author: Chouj
type: post
date: 2007-04-22T08:45:00+00:00
url: /2007/04/22/translate-of-feed-pictures-of-boys/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/feeds.html
views:
  - 1874
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969877
categories:
  - 我记录
tags:
  - blog
  - Feed
  - 图片
  - 网络

---
<span style="font-size:180%;">译</span>文网是个好去处，blog上没话题可写了，就可以上去淘两篇文章翻译翻译，还可以练练英语。前些天在那里看到<a href="http://www.yeeyan.com/groups/topic/web20/118" target="_blank">一个帖</a>，问Feeds如何翻译比较好，有说翻译为飞子的，有逗乐说翻译为痱子的。我感觉呢，不翻为妙。九几年时，书店里还能见到一个词：“视窗操作系统”,现在你还见的到么？这种势必会变得众人皆知的词，保留原样最好。

写<a href="http://www.xuchi.name/blog/2007/04/20/%e6%94%be%e7%89%9b%e7%8f%ad%e7%9a%84%e6%98%a5%e5%a4%a9/" target="_blank">童声伴我心</a>的时候转了两张图，觉得不大过瘾，还真让我撞见过瘾的啦，<a href="http://blog.sina.com.cn/u/1274782263" target="_blank">放牛班的春天广州音乐会官方博客</a>，放出了一堆小孩儿照片，想看照片的筒子们有福了！！

给<a href="http://Technorati.com" target="_blank">Technorati.com</a>的论坛留了言，原因是搜索能搜出本blog有45个反向链接，但Links Counts中总是显示“0 links from 0 sites”,让我很郁闷，参见侧栏中那个大大的零。要说的是，那个faq论坛里，留言的大部分都是这个问题，唉，Technorati.com也不靠谱啊。