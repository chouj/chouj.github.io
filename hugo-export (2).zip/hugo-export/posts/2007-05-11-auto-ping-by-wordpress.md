---
title: 嗨!我更新了，你要抓取哟！
author: Chouj
type: post
date: 2007-05-11T00:51:45+00:00
url: /2007/05/11/auto-ping-by-wordpress/
views:
  - 2107
  - 2107
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969951
categories:
  - WordPress
  - 教程
tags:
  - Feedburner
  - feedsky
  - ping

---
<font color="#0000ff">本文写给以<strong><a href="http://wordpress.org/" target="_blank">WordPress</a>搭建blog</strong>的bloggers</font>

当您更新了blog，一定希望订阅您blog的读者能第一时间看到您的文字。但一次次前去<a href="http://www.feedsky.com/ping.html" target="_blank">通知页面</a>手动更新是非常麻烦的事情，那么怎么样能让Feed服务商的爬虫自动前来抓取您更新了的内容呢？借用WP后台的“更新服务”，我们就可以做到。

<img src="http://photo7.yupoo.com/20070508/202834_1113329269_abjehcja.jpg" title="WP更新服务-RSS相关" alt="WP更新服务-RSS相关" height="207" width="378" />

上图即为WP**后台**&#8211;**选项**&#8211;**撰写**标签下的“更新服务”，可自动通知的站点包括各大搜索引擎，RSS聚合站和Feed服务商。Wordpress.org官方站提供了一个可选的<a href="http://codex.wordpress.org/Update_Services" target="_blank">网址列表</a>，如下：

> http://rpc.blogrolling.com/pinger/
  
> http://www.blogdigger.com/RPC2
  
> http://www.bitacoles.net/ping.php
  
> http://rpc.wpkeys.com
  
>  <font color="#3366ff">http://rpc.technorati.com/rpc/ping</font>
  
> http://rpc.britblog.com
  
> http://pingoat.com/goat/RPC2
  
> http://bulkfeeds.net/rpc
  
> http://rpc.weblogs.com/RPC2
  
>  <font color="#3366ff">http://api.my.yahoo.com/RPC2</font>
  
> http://services.newsgator.com/ngws/xmlrpcping.aspx
  
> http://api.moreover.com/ping
  
> http://api.moreover.com/RPC2
  
> http://www.blogpeople.net/servlet/weblogUpdates
  
> http://ping.fakapster.com/rpc
  
> http://www.blogoon.net/ping/
  
> http://ping.bloggers.jp/rpc/
  
> http://bblog.com/ping.php
  
> http://rpc.tailrank.com/feedburner/RPC2
  
> http://ping.bitacoras.com
  
> <font color="#ff0000"><strong> http://ping.feedburner.com</strong></font>
  
> http://ping.myblog.jp
  
> http://ping.syndic8.com/xmlrpc.php
  
> http://ping.weblogalot.com/rpc.php
  
> http://pinger.blogflux.com/rpc
  
>  <font color="#3366ff">http://blogsearch.google.com/ping/RPC2</font>
  
> http://blog.goo.ne.jp/XMLRPC
  
> http://rpc.icerocket.com:10080
  
> http://rpc.pingomatic.com
  
> http://api.feedster.com/ping.php

注意其上的标注：蓝色部分为三个主要的搜索引擎站的ping地址，分别为<a href="http://Technorati.com" target="_blank">Techonrati</a>、<a href="http://www.yahoo.com" target="_blank">Yahoo!</a>和<a href="http://blogsearch.google.com" target="_blank">Google的blogsearch</a>；红色粗体即为<a href="http://www.feedburner.com" target="_blank">Feedburner</a>服务的ping地址。

这些ping地址都是国外的各大站点，如果您选用了国内<a href="http://www.feedsky.com" target="_blank">Feedsky</a>的Feed烧制服务，那么务必再**添加**如下地址进去：

**<font color="#ff0000">http://www.feedsky.com/api/RPC2</font>**

这样即可在您发文的同时，第一时间自动向Feed服务商喊出：“<font color="#ff0000">嗨!我更新了，你要抓取哟！</font>”

PS. [RSS相关][1]<font color="#3366ff"><strong>不推荐</strong></font>您将以上所有地址全部添加进去，一是<font color="#3366ff">有很多用不到</font>，二是<font color="#3366ff">会延缓文章发布的速度</font>。 [RSS相关][1]发布一个推荐列表，您直接复制进去即可：

> http://rpc.pingomatic.com/
  
> http://api.my.yahoo.com/RPC2
  
> http://blogsearch.google.com/ping/RPC2
  
> http://rpc.newsgator.com/
  
> http://rpc.weblogs.com/RPC2
  
> http://www.feedsky.com/api/RPC2
  
> http://ping.feedburner.com

 [1]: http://aboutrss.cn