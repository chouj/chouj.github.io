---
title: 摆摆书架:让闲置书有用武之地
author: Chouj
type: post
date: 2010-12-01T09:41:40+00:00
excerpt: 处置闲书的好地方啊，新加入的用户还可以免费借一本书。之后有闲书，不留的书，就放到摆摆书架来。每借出一本，就再可以免费借入一本。
url: /2010/12/01/bookforus/
views:
  - 2839
duoshuo_thread_id:
  - 1279764464521970061
categories:
  - 我尝试
  - 我表达
tags:
  - 网站
  - 读书

---
<a title="摆摆书架" target="_blank"><img src="http://bookfor.us/include/style/img/logo.png" alt="摆摆书架" /></a>

处置闲书的好地方啊，新加入的用户还可以免费借一本书。

之后有闲书，不留的书，就放到摆摆书架来。每借出一本，就再可以免费借入一本。

我放上去两本，借出了一本《名博是怎样炼成的》，借入了一本《长尾理论》。操作流程顺畅，UI很漂亮，每本书都有豆瓣链接可以看详细信息。我的id：<a title="抽筋儿@摆摆书架" href="http://bookfor.us/user/102/ " target="_blank">抽筋儿</a>

大家都来补充书，构造超全流动书库，就不愁没书看了。“书非借不能读也”，哈哈。

目前摆摆书架在内测中，可以来以下地址索取邀请码：

  * <a href="http://lightory.net/baibai-bookshelf-alpha-invitation/628/" target="_blank">开发者博客</a>
  * <a href="http://www.douban.com/group/topic/15827241/" target="_blank">豆瓣小组</a>
  * <a href="http://www.v2ex.com/t/4383" target="_blank">v2ex</a>

摆摆书架规则：<a title="摆摆书架规则" href="http://bookfor.us/about/" target="_blank">http://bookfor.us/about/ </a>

其他介绍：<a title="摆摆书架：社会化图书馆" href="http://www.web20share.com/2010/11/bookforus.html" target="_blank">摆摆书架：社会化图书馆</a>

[ 点此进入：**<a title="摆摆书架" href="http://bookfor.us/" target="_blank">摆摆书架</a>** ]