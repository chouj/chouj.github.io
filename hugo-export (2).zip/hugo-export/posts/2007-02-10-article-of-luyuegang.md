---
title: 卢跃刚：禁书、禁人、禁……
author: Chouj
type: post
date: 2007-02-10T08:15:00+00:00
url: /2007/02/10/article-of-luyuegang/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/blog-post_10.html
views:
  - 1631
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969850
categories:
  - 我记录
tags:
  - 卢跃刚

---
给出三个不同的网上来源：

<a href="http://bbs.bullog.cn/forums/bullog/4305.aspx" target="_blank">牛博论坛一贴</a>
  
<a href="http://wlc001.id666.com/mod/5/show_article.asp?id=559986" target="_blank">五柳百草园一文</a> <span style="color: #666666;">这站首页上有首散曲，写的很是“嚣张”。</span>
  
<a href="http://www.360doc.com/showWeb/0/0/361339.aspx" target="_blank">360DOC收藏文章</a> <span style="color: #6f6f6f;">from </span><a href="http://www.360doc.com/UserHome/16239.aspx" target="_blank">真积力久</a> <a href="http://www.360doc.com/showRelevantArt.aspx?ArticleID=361339&ArticleNum=18" target="_blank">相关文章(18)</a>

该文有关章诒和新书《<a href="http://www.douban.com/subject/1903968/" target="_blank">伶人往事</a>》被禁一事，也许教育网用户看不到以上链接，请点<a href="http://docs.google.com/View?docid=dgn53rq3_14gnhwcc" target="_blank">这里。</a>

附一帖：<a href="http://www.360doc.com/showWeb/0/0/338864.aspx" target="_blank"><span style="font-size: 100%; font-family: Helvetica; color: #f70909;">沙叶新支持章诒和抗议禁书 2007年1月20日</span></a>

我也是在《<a href="http://www.douban.com/subject/1437900/" target="_blank">冰点故事</a>》、《<a href="http://www.douban.com/subject/1831600/" target="_blank">用新闻影响今天</a>》这两本书里认识卢跃刚这人的，李大同手下大记者。自中青报冰点被解散之后，终于又见到这个人名了，该文2月2日发于《亚洲周刊》。