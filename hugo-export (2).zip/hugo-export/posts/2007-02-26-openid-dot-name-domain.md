---
title: 'OpenID & .name 试用报告（续前篇）'
author: Chouj
type: post
date: 2007-02-26T07:54:00+00:00
url: /2007/02/26/openid-dot-name-domain/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/openid-name.html
views:
  - 3680
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969857
categories:
  - 我尝试
tags:
  - .name
  - OpenID

---
<span style="font-size:180%;"><span style="font-weight: bold;">伴</span></span>随网络上一大票儿标榜2.0网站的兴起，咱要是像<a href="http://daodao.org/" target="_blank">Daodao</a>一样挨个尝鲜的话，估计光注册填表格就得耗去大把的时间，而OpenID就是为了解决这种“超负荷注册”现象应运而生的。虽然目前支持OpenID的站点还不多，但随着<a href="http://news.mydrivers.com/pages/20070207102608_53905.htm" target="_blank">巨人微软开始一点点支持OpenID</a>，OpenID也许将成为潮流趋势。我也是听着这个词儿挺新鲜的，就去弄了个ID玩玩，顺便抢个好记的用户名，:-P

<span style="font-weight: bold;"><span style="font-size:180%;">到</span>底OpenID怎么作用？</span>上段那链接的新闻里写的好：

> 一旦你建立起你的用户信息后，当你需要登陆一个新的站点时，它能将其指向你存放信息的站点。这个存放注册信息站点将会把你的用户资料发送给你要注册的新站点，从而使其知道你是谁并让你顺利登陆。

打个比方，如果说Internet是个游乐场，一个一个的站点就是这游乐场里的景区。有了OpenID，就像有了通票，一张票，您可以逛遍各个景区；没有的话，您就只有挨个景区买通行证了。其实只要您是Google的用户，应该对这个方法并不陌生。Google这个大景区里，有Reader、Pages、Picasa、Docs、Orkut等等诸多小游戏，只要您是Google的注册用户，凭借Gmail地址，您就可以玩遍小游戏，这其实跟OpenID的用途是一样的。

<span style="font-size:180%;"><span style="font-weight: bold;">您</span></span>要是还不懂OpenID，可以参看<a href="http://xcchris.blogspot.com/2007/02/translation-freeyourid.html" target="_blank">前文</a>和<a href="http://en.wikipedia.org/wiki/Openid" target="_blank">这张wiki页</a>。

<span style="font-size:180%;"><span style="font-weight: bold;">那</span></span><span style="font-weight: bold;">到哪里弄个OpenID呢？</span>给出以下两个发布站点：<span id="logotext"><a href="https://www.myopenid.com/" target="_blank">MyOpenID</a></span> 、<a href="http://getopenid.com/" target="_blank"><img style="width: 102px; height: 23px;" src="http://getopenid.com/images/logo.gif" border="0" alt="Logo" /></a>。前者注册到的OpenID形式为username.myopenid.com，后者则为getopenid.com/username。

<span style="font-size:180%;"><span style="font-weight: bold;">另</span></span>外，<a href="http://claimid.com/" target="_blank">ClaimID.com<img style="width: 66px; height: 24px;" src="http://claimid.com/images/logo_front.jpg" border="0" alt="claimID" /></a>，也提供OpenID申请，只要普通申请的用户，即给出一个claimid.com/username的url，这个url可作为您的OpenID。但该站主要功能是，其给出的url页面是个可编辑页面，在这个页面里，您可以加载一切与您有关的链接，比方blog、QQzone、digg之类。并可生成一个链接logo添加到您的博客中去，比如我的<a href="http://claimid.com/xcchris" target="_blank"><img title="Chris Xu" src="http://claimid.com/images/claimid_badge.gif" border="0" alt="Chris Xu" /></a>。<a href="http://xcchris.blogspot.com/2007/02/translation-freeyourid.html" target="_blank">前文</a>提到的[FreeYourID.com][1]不是专门发放OpenID的站点，而且配送的ID只能3个月试用，其给出的OpenID形式则为firstname.lastname.name。

<span style="font-weight: bold;"><span style="font-size:180%;">有</span>了OpenID，到哪里去试试呢？</span>这里有个<a href="https://www.myopenid.com/directory" target="_blank">OpenID Site Directory</a>，但平常可用的，支持OpenID的站点不多（YY下，要是Yahoo和Google也开始支持OpenID就爽歪歪了），第一次试用，就用OpenID登录<a href="http://claimid.com/" target="_blank">ClaimID.com</a>好了。奇怪的是，<a href="https://www.myopenid.com/directory" target="_blank">Directory</a>里有<a href="http://technorati.com/" target="_blank"><img style="width: 84px; height: 11px;" src="http://static.technorati.com/static/img/logo/masthead.png" border="0" alt="" /></a>,但在该站的Claim Blog服务里，只见到了Quick Claim、Post Claim 、Embedded Claim ，却没有OpenID Claim（见其<a href="http://technorati.com/weblog/2006/10/144.html" target="_blank">blog post：Blog Claiming with OpenId</a>）。还是不过分纠缠了，如此伟大的站点已经被<a href="http://zh.wikipedia.org/w/index.php?title=GFW&variant=zh-cn" target="_blank">GFW</a>挡在外面，顺带宣传下<a href="http://blog.donews.com/keso" target="_blank">keso</a>的广告语：操<a href="http://zh.wikipedia.org/w/index.php?title=GFW&variant=zh-cn" target="_blank">GFW</a>记得带<a href="http://zh.wikipedia.org/w/index.php?title=Tor&variant=zh-cn" target="_blank">Tor</a>。

<span style="font-size:180%;"><span style="font-weight: bold;">O</span></span>K，关于OpenID的科普普及完毕，换<span style="font-weight: bold;">点name域名</span>上场。

<a href="http://en.wikipedia.org/wiki/Dot-name" target="_blank"><span style="font-size:180%;"><span style="font-weight: bold;">.</span></span>name</a>可是目前18个<a href="http://en.wikipedia.org/wiki/Generic_top-level_domain" target="_blank">顶级域名</a>之一，wiki上写的是“<a title=".name" href="http://www2.blogger.com/wiki/.name" target="_blank">.name</a> &#8211; for families and individuals”，是架设个人博客的首选域名啊。不过，世界上同名同姓之人如此之多，想抢得一个如意的个人域名，必将又是一场腥风血雨，动心的赶紧动手吧。

<a href="http://freeyourid.com/" target="_blank"><span style="font-size:180%;"><span style="font-weight: bold;">F</span></span>reeYourID.com</a>就给了大家一个享用.name域名的机会，虽然只有90天免费期，但我还是申请了一个尝尝鲜。大家输入这个地址<a href="http://www.xu.chi.name/" target="_blank">http://www.xu.chi.name</a>，现在它指向本博客；大家发邮件到xu在chi.name，就将转交到我的Gmail邮箱。90天内，这两个地址就属于我了，您要是也叫Xu Chi，就只能屈就www.x.chi.name或www.xu.c.name之类的域名了。

<span style="font-size:180%;"><span style="font-weight: bold;">偷</span></span>偷告诉您，没准儿90天后，我再把这个域名注回来，:-P

<span style="color: #ff0000;">Update:</span>刚收到一封自动email，来自freeyourid.com,署名Hakon Haugnes，Global Name Registry，部分内容如下：

> If you are unsure about how OpenID works, Simon Willison has a great introductory video on OpenID on his blog <a onclick="return top.js.OpenExtLink(window,event,this)" href="http://simonwillison.net/2006/openid-screencast/" target="_blank">http://simonwillison.net/2006/openid-screencast/</a>

这个链接里的视频相当的赞，非常详细的讲解了OpenID的使用方法，相信看过都能懂！

 [1]: http://freeyourid.com/