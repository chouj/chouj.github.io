---
title: “枪版”全文RSS Feed的是与非
author: Chouj
type: post
date: 2009-08-18T16:56:04+00:00
url: /2009/08/19/about-fullview-feed-diy/
views:
  - 3761
duoshuo_thread_id:
  - 1279764464521970046
categories:
  - 相关
tags:
  - Feed
  - 全文
  - 枪版

---
<img title="“枪版”全文RSS Feed的是与非" src="http://pic.yupoo.com/xcchris/188367ee3952/am5ayc5h.jpg" alt="“枪版”全文RSS Feed的是与非" width="630" />

欣欣然想在这里发布一些推友制作的全文RSS Feeds的时候，我想到了版权问题，于是有了这个名字：**“枪版”全文RSS Feed**。

**什么是“枪版”全文RSS Feed？**

利用一些网络应用将门户或纸媒网络版的摘要型Feed全文化所得到的全文RSS Feed，就被我起名为**“枪版”RSS Feed**。这跟“枪版”电影的道理是一样的：“枪版”电影虽然也算推广了作品，但毕竟影响票房，侵犯版权；私制的全文RSS Feed传递了信息，方便了订阅者，但损害了门户和纸媒网站的利益，一样侵权。

<!--more-->

**矛盾在哪里？**

全文输出的RSS Feed一直为读者们所追求，心里默认的都是：“不输出全文的Feed，不是好Feed”。早前关于全文输出与否还引发了诸多bloggers的讨论，当然那时的讨论大多针对blog的RSS输出。不过，若干门户和纸媒网络版并不遵循blog的游戏规则，为了守住网站自己的访问量，守住纸媒的销量，他们的RSS Feed多是摘要型。要让他们折腾成全文型Feed，可是需要莫大的勇气。很欣慰，世界上还是有这样的好媒体的：参看曹增辉的《<a title="RSS输出全文：为卫报喝个彩——一言谈" href="http://www.caozenghui.cn/archives/342.html" target="_blank">RSS输出全文：为卫报喝个彩</a>》。

利益决定行为，你可守，我可攻，发布方的限制刺激了网驻民的能动性。全文RSS Feeds免费量大质优，折腾出个全文Feed也并不是什么难事。随便翻下我的网摘，就有两枚：

  * <a title="fisio@twitter" href="https://twitter.com/fisio" target="_blank">@fisio</a>的<a href="http://fisio.cn/google-reader-full-feed-changer.html" target="_blank">RSS feed不输出全文，一样搞定你</a>
  * <a title="sfufoet@twitter" href="https://twitter.com/sfufoet" target="_blank">@sfufoet</a>的<a href="http://www.appinn.com/full-rss-feed/" target="_blank">RSS feed摘要输出轻松全文</a>（话说这个题目怎么这么纠结）。

再搭上无比强大的<a title="Yahoo Pipes" href="http://pipes.yahoo.com/pipes/" target="_blank">Yahoo Pipes</a>以及<a title="HTML/PAGE2RSS线上工具收集" href="http://aboutrss.cn/2007/09/html2rss-online-tools/" target="_self">HTML2RSS</a>的若干，于是“枪版”RSS Feed华丽诞生了。盗版商和片方，错了，是RSS读者和门户、纸媒的梁子也就这么结下了。

**“枪版”全文RSS Feed的“非”**

很显然，“非”在信息的非官方传播，侵犯门户、纸媒的利益。其实关于“利益”和“侵权”二字，还是很值得深入讨论的，比方，“流量”算不算利益？比方，本身可在网络上免费看到的全文搬到了Feed里，可见于阅读器，算不算侵权。我在Twitter上征询此类全文Feed是否归属于侵权的范畴，多数说算，但<a href="https://twitter.com/NetPuter/status/3363140762" target="_blank">@NetPuter提到</a>：<span><span>标明版权，无广告等盈利点，应该不算侵权。我不是法律界人士，无法解答这些问题，这也超出了本文的范畴。但类似“侵到何程度算情节严重”这种法律细节，想必还是为众人所关心的。</span></span>

**“枪版”全文RSS Feed的“是”**

你情我不愿，如若版权法有规范这类细节，那“枪版”Feed的主刀手被请上公堂也不是不可能了。但问题在于，中国是个神奇的国度，试问，“<span onmouseover="_tipon(this)" onmouseout="_tipoff()">下载后请于24小时内删除”、“如果满意请购买正版”的字幕翻飞于大大小小的液晶之上，“枪版”RSS Feed是不是有了些许存在的底气？</span>

<span onmouseover="_tipon(this)" onmouseout="_tipoff()">撇开冷血的法律条文不谈，在国内这种信息不对称，信息墙化的环境中，我们是不是打心眼里期盼信息的有效迅捷的传播？兼听则明，偏听则暗，我们是不是需要一条通往墙外信息的途径？媒体公信力、舆论监督力，我们是不是又希望它们能挺直腰杆吆喝呐喊？</span>

<span onmouseover="_tipon(this)" onmouseout="_tipoff()">一不小心扯偏了题。阅读器搭载RSS Feed来穿墙获取信息本就是贵国特色，这也让我们针对“枪版”RSS Feed的态度变得暧昧和无奈。</span>

**<span onmouseover="_tipon(this)" onmouseout="_tipoff()">让我们用善意来保有商量的余地</span>**

<span onmouseover="_tipon(this)" onmouseout="_tipoff()">在“枪版”全文RSS Feed的制作中，表示友好和善意是必须的：</span>

  1. <span onmouseover="_tipon(this)" onmouseout="_tipoff()">制作前，试着联络对方，如果能说服官方放出全文Feed，那皆大欢喜，或者申请许可；</span>
  2. <span onmouseover="_tipon(this)" onmouseout="_tipoff()">在feed烧制中，添加版权声明信息，声明版权归原媒体所有；</span>
  3. <span onmouseover="_tipon(this)" onmouseout="_tipoff()">Feed中不能嵌入诸如Adsense for Feed的广告，要表明只是善意的传播，而非营利性目的；<br /> </span>
  4. <span onmouseover="_tipon(this)" onmouseout="_tipoff()">尽量不公开传播Feed；</span>
  5. <span onmouseover="_tipon(this)" onmouseout="_tipoff()">制作或改进不会侵权的RSS Feed，像<a title="est@twitter" href="https://twitter.com/est" target="_blank">@est</a>那样，改进<a title="微软搜索引擎Bing每日图片RSS" href="http://initiative.yo2.cn/archives/641978" target="_blank">微软搜索引擎Bing每日图片RSS</a>。<br /> </span>

**<span onmouseover="_tipon(this)" onmouseout="_tipoff()">讨论和小结</span>**

 <span onmouseover="_tipon(this)" onmouseout="_tipoff()"></span>

在米国或香港，房东都无权赶走没打算搬家的房客，而在中国，却不尽然。所以，我很好奇在法制比较健全的国家，是否有“枪版”RSS Feed这种类似的东东。如若没有，那“枪版”全文RSS Feed就可以打上“中国特色”的标签了。

我不会在这里发布推友们的全文RSS Feed，但我会收藏到我<a title="xcchris's rss Bookmarks " href="http://delicious.com/xcchris/rss" target="_blank">网摘的rss标签</a>里，欢迎订阅。