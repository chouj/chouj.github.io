---
title: 圣火传递广州站照片幻灯展示
author: Chouj
type: post
date: 2008-05-07T17:23:24+00:00
url: /2008/05/08/sacred-flame-in-guangzhou/
views:
  - 2311
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969734
categories:
  - 我记录
tags:
  - 图片
  - 圣火
  - 奥运
  - 广州

---
广州 海珠区 滨江东路 新珠江大酒店 2008.05.07
  
幻灯播放，RSS阅读器里怕是看不到
  
同学拍摄，已获授权，谢绝商业性转载

<EMBED src="http://www.yupoo.com/images/slideshow.swf?api_key=4a0dfd625c8ad19b1e2105ff44dc962b&#038;album_id=ff80808119c2d3cd0119c44e441415fe&#038;minH=350&#038;minW=762" quality="high" bgcolor="#000000" WIDTH="500" HEIGHT="500" id="slideShowMovie" name="slideShowMovie" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer">
</EMBED>