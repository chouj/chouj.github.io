---
title: 领导归来（续）
author: Chouj
type: post
date: 2008-08-21T09:10:26+00:00
url: /2008/08/21/girlfriend-comes-back-2/
views:
  - 2104
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969906
categories:
  - 我记录
tags:
  - 感情

---
<img class="aligncenter size-full wp-image-302" title="luxian" src="http://www.xuchi.name/blog/wp-content/uploads/2008/08/luxian.jpg" alt="" width="500" height="414" />

<p style="text-align: center;">
  今日凌晨4时单车骑行接人路线，时速9.6Km/h
</p>