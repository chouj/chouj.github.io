---
title: Feedburner订阅数归零了？
author: Chouj
type: post
date: 2007-05-17T12:27:03+00:00
url: /2007/05/17/zero-feedburner/
views:
  - 1039
  - 1039
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969953
categories:
  - 新闻
tags:
  - Feedburner

---
<img src="http://www.feedburner.com/fb/i/logo_150w.gif" title="feedburner-aboutrss" alt="feedburner-aboutrss" height="27" width="150" />

<big><big>由</big></big><a href="http://www.feedburner.com/" target="_blank">Feedburner</a> Feed烧制服务商所统计的订阅数，貌似都归零了，<a href="http://www.awflasher.com/blog/archives/890" target="_blank">这里也有汇报</a>，表明不止一家。

拭目以待吧，不知道出了什么差错。

最近论文ing，疏于更新一下下。

**<font color="#ff0000">Update</font>**:经<a href="http://www.penglei.name" target="_blank">PengLei</a>友情指示，<a href="http://forums.feedburner.com/" target="_blank">Feedburner官方论坛</a>有关于此事件的<a href="http://forums.feedburner.com/viewtopic.php?p=44084" target="_blank"><strong>解释</strong></a>:

> Our nightly rollup process is running late, so you may see &#8220;0&#8221; subscribers for your May 16, 2007 number.

貌似像是维护或者升级造成的。且此次事件后，订阅数有所增多，以下**不负责任猜测**：Feedburner又添加了新的阅读器的数据，嘿嘿，我遁。