---
title: 消逝
author: Chouj
type: post
date: 2006-11-16T14:38:00+00:00
url: /2006/11/16/killing-time/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/11/blog-post_16.html
views:
  - 1558
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969829
categories:
  - 我记录
tags:
  - 生活
  - 读书

---
**<span style="font-size:180%;">在</span>**学校图书馆翻到《[老徐的博客][1]》，崭新的，刨了回来。没精神到网上翻丫的博客，但闲的时候翻翻纸质的东西却别有韵味，同时伴随着些许惊异，因为这么一本没什么学术与收藏价值，全是琐碎日记的书，丫图书馆居然购置了。

**<span style="font-size:180%;">现</span>**在，每每到图书馆都会激起读书的兴奋感，会有窥视封皮之下文字的冲动，宛如诸多免费书籍摆在我面前，不读不是亏大了的奇怪感觉。说到底是意识到，图书馆也许是个离我远去的事物了，即便有，也别想找到《[老徐的博客][1]》这样的书。记得在广州，问师兄能否到中山大学的图书馆里借书看，答曰：除非你有同学在里面。看来，浩瀚的资源果真在离我远去，以后想摩挲下纸制品都要自己掏腰包了。

**<span style="font-size:180%;">攥</span>**着大把的时间，无度得挥霍。妈的，什么时候改变哈子，挥霍始终是个贬义词。

 [1]: http://www.douban.com/subject/1758872/