---
title: 08下半年deviantART RSS设计精选
author: Chouj
type: post
date: 2009-01-22T14:31:36+00:00
url: /2009/01/22/rss-design-2008-second-half/
views:
  - 1729
  - 1729
duoshuo_thread_id:
  - 1279764464521970035
categories:
  - 标志
tags:
  - Graph
  - Icon
  - Subscribe
  - Symbol

---
[<img title="08下半年deviantART RSS设计精选" src="http://pic.yupoo.com/xcchris/372476dbe193/qmft38cp.jpg" alt="08下半年deviantART RSS设计精选" width="468" />][1]

鼠年年末，本命年将终，精选deviantART 08年下半年RSS设计，以迎牛年，Feed YOU！（点击图片即可跳转到deviantART页面）：

<!--more--><figure style="width: 250px" class="wp-caption aligncenter">

[<img title="RSS 2.4 by ~Kijm" src="http://pic.yupoo.com/xcchris/191716dbe18f/grppjjoc.jpg" alt="RSS 2.4 by ~Kijm" width="250" height="250" />][2]<figcaption class="wp-caption-text">RSS 2.4 by ~Kijm：仅仅是一个png，但我觉得很精致，所以入选</figcaption></figure> <figure style="width: 460px" class="wp-caption aligncenter">[<img title="RSS by ~BlueMalboro" src="http://pic.yupoo.com/xcchris/963086dbe18b/1alx4beh.jpg" alt="RSS by ~BlueMalboro 立体RSS 256px PNG 适用于win mac系统 可选" width="460" height="270" />][3]<figcaption class="wp-caption-text">RSS by ~BlueMalboro：立体RSS 256px PNG 适用于win mac系统 可选</figcaption></figure> <figure style="width: 350px" class="wp-caption aligncenter">[<img title="RSS Feeds Icons - Paper by ~neoworxspace" src="http://pic.yupoo.com/xcchris/879226dbe18c/puzf4x3n.jpg" alt="RSS Feeds Icons - Paper by ~neoworxspace 纸片系～" width="350" height="250" />][4]<figcaption class="wp-caption-text">RSS Feeds Icons - Paper by ~neoworxspace：纸片系～</figcaption></figure> <figure style="width: 468px" class="wp-caption alignnone">[<img title="Mac Style RSS Feed Icons by ~NightTremble" src="http://pic.yupoo.com/xcchris/616976dbe189/eflli4t3.jpg" alt="Mac Style RSS Feed Icons by ~NightTremble：仅仅是该图的一个PSD" width="468" />][5]<figcaption class="wp-caption-text">Mac Style RSS Feed Icons by ~NightTremble：仅仅是该图的一个PSD</figcaption></figure> <figure style="width: 350px" class="wp-caption aligncenter">[<img title="RSS Feeds Icons - Bottle Caps by ~neoworxspace" src="http://pic.yupoo.com/xcchris/825476dbe183/tqdlm9fz.jpg" alt="RSS Feeds Icons - Bottle Caps by ~neoworxspace：瓶盖版RSS图标" width="350" height="250" />][6]<figcaption class="wp-caption-text">RSS Feeds Icons - Bottle Caps by ~neoworxspace：瓶盖版RSS图标</figcaption></figure> <figure style="width: 468px" class="wp-caption aligncenter">[<img title="Blokt Icon Set 01 by =furryyx" src="http://pic.yupoo.com/xcchris/240496dbe183/ry1hnvat.jpg" alt="Blokt Icon Set 01 by =furryyx：124×124 PNG 很精致的图标哦～" width="468" />][7]<figcaption class="wp-caption-text">Blokt Icon Set 01 by =furryyx：124×124 PNG 很精致的图标哦～</figcaption></figure> <figure style="width: 400px" class="wp-caption aligncenter">[<img title="devi.RSS by ~devi-cry" src="http://pic.yupoo.com/xcchris/129486dbe17d/gw8uj7td.jpg" alt="devi.RSS by ~devi-cry：平躺立体系RSS标志" width="400" height="300" />][8]<figcaption class="wp-caption-text">devi.RSS by ~devi-cry：平躺立体系RSS标志</figcaption></figure> <figure style="width: 400px" class="wp-caption aligncenter">[<img title="Square Black RSS Icon by ~imarqui" src="http://pic.yupoo.com/xcchris/601876dbe1ac/ybnc90om.jpg" alt="Square Black RSS Icon by ~imarqui：虽然不那么好看，但设计还是比较特别的" width="400" height="200" />][9]<figcaption class="wp-caption-text">Square Black RSS Icon by ~imarqui：虽然不那么好看，但设计还是比较特别的</figcaption></figure> <figure style="width: 320px" class="wp-caption aligncenter">[<img title="RSS Feed Icons by =Oliuss" src="http://pic.yupoo.com/xcchris/252266dbe1a9/6brytc0k.jpg" alt="RSS Feed Icons by =Oliuss：华丽系的图标，尺寸繁多" width="320" height="470" />][10]<figcaption class="wp-caption-text">RSS Feed Icons by =Oliuss：华丽系的图标，尺寸繁多</figcaption></figure> <figure style="width: 468px" class="wp-caption aligncenter">[<img title="Lopagofs preview sheet. by =lopagof" src="http://pic.yupoo.com/xcchris/078556dbe1a1/8b54ab2a.jpg" alt="Lopagofs preview sheet. by =lopagof：预览图很漂亮，图标也挺别致" width="468" />][11]<figcaption class="wp-caption-text">Lopagof's preview sheet. by =lopagof：预览图很漂亮，图标也挺别致</figcaption></figure> <figure style="width: 300px" class="wp-caption aligncenter">[<img title="new rss feed icons set by ~joyologo" src="http://pic.yupoo.com/xcchris/688146dbe199/09eislmt.jpg" alt="new rss feed icons set by ~joyologo：比较粗糙，但是很好玩，hoho" width="300" height="660" />][12]<figcaption class="wp-caption-text">new rss feed icons set by ~joyologo：比较粗糙，但是很好玩，hoho</figcaption></figure> <figure style="width: 388px" class="wp-caption aligncenter">[<img title="RSS Christmas Icon PNG PSD by ~GiZZiStar" src="http://pic.yupoo.com/xcchris/299326dbe193/enng7n0u.jpg" alt="RSS Christmas Icon PNG PSD by ~GiZZiStar：虽然过了圣诞，但不妨碍我们欣赏戴圣诞帽的RSS标志" width="388" height="140" />][13]<figcaption class="wp-caption-text">RSS Christmas Icon PNG PSD by ~GiZZiStar：虽然过了圣诞，但不妨碍我们欣赏戴圣诞帽的RSS标志</figcaption></figure> <figure style="width: 468px" class="wp-caption aligncenter">[<img title="Neat Subscribe Area PSD by =eliburford" src="http://pic.yupoo.com/xcchris/459586dbe18f/9c4bhiyh.jpg" alt="Neat Subscribe Area PSD by =eliburford：这个就不是标志设计啦～而是blog订阅区的设计，很精彩" width="468" />][14]<figcaption class="wp-caption-text">Neat Subscribe Area PSD by =eliburford：这个就不是标志设计啦～而是blog订阅区的设计，很精彩</figcaption></figure> <figure style="width: 450px" class="wp-caption aligncenter">[<img title="Grunge RSS Banners by ~GraphicIdentity" src="http://pic.yupoo.com/xcchris/559376dbe18e/uu8pr154.jpg" alt="Grunge RSS Banners by ~GraphicIdentity：这是一个Banner设计，记得看Artists Comments" width="450" height="610" />][15]<figcaption class="wp-caption-text">Grunge RSS Banners by ~GraphicIdentity：这是一个Banner设计，记得看Artist's Comments</figcaption></figure> 

恭祝：牛年大吉！

 [1]: http://easetock.deviantart.com/art/Feed-me-106617561
 [2]: http://kijm.deviantart.com/art/RSS-2-4-92667934
 [3]: http://bluemalboro.deviantart.com/art/RSS-93447114
 [4]: http://neoworxspace.deviantart.com/art/RSS-Feeds-Icons-Paper-97582125
 [5]: http://nighttremble.deviantart.com/art/Mac-Style-RSS-Feed-Icons-97984342
 [6]: http://neoworxspace.deviantart.com/art/RSS-Feeds-Icons-Bottle-Caps-99577029
 [7]: http://furryyx.deviantart.com/art/Blokt-Icon-Set-01-102666711
 [8]: http://devi-cry.deviantart.com/art/devi-RSS-103128975
 [9]: http://imarqui.deviantart.com/art/Square-Black-RSS-Icon-103373108
 [10]: http://oliuss.deviantart.com/art/RSS-Feed-Icons-103352370
 [11]: http://lopagof.deviantart.com/art/Lopagof-s-preview-sheet-104517313
 [12]: http://joyologo.deviantart.com/art/new-rss-feed-icons-set-105722140
 [13]: http://gizzistar.deviantart.com/art/RSS-Christmas-Icon-PNG-PSD-106397938
 [14]: http://eliburford.deviantart.com/art/Neat-Subscribe-Area-PSD-107350265
 [15]: http://graphicidentity.deviantart.com/art/Grunge-RSS-Banners-90628414