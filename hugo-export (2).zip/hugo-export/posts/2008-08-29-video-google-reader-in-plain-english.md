---
title: '[视频]Google Reader in plain English'
author: Chouj
type: post
date: 2008-08-29T01:43:34+00:00
url: /2008/08/29/video-google-reader-in-plain-english/
views:
  - 1691
  - 1691
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970018
categories:
  - 教程
  - 知识
tags:
  - Google Reader
  - Video

---
我在侧栏顶部放置的一个视频叫“**RSS in plain English**”，形象介绍RSS功用的，不知道在我这里收视率如何。

26日，<a title="Google Reader in plain English by commoncraft" href="http://commoncraft.com/reader" target="_blank">CommonCraft又推出了一个新的视频</a>：**Google Reader in plain English**，顾名思义，就是讲Google Reader能帮助用户做什么，非常棒，非常易懂（会英语的话）。一睹为快吧：



这里有一个英文字幕版的：

[http://dotsub.com/media/f79f1b5e-bea1-43ab-97fb-666544aaf0bf/e/m]