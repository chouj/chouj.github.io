---
title: 点名游戏
author: Chouj
type: post
date: 2007-03-14T12:03:00+00:00
url: /2007/03/14/call-roll-game/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/blog-post_14.html
views:
  - 1738
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969862
categories:
  - 我表达
tags:
  - 点名游戏

---
点名链接：
  
<a href="http://huiranfu.blogspot.com/" target="_blank">http://huiranfu.blogspot.com/</a>

点名规则：
  
1. 被点到名字的人要在自己的博客里写下自己的答案，然后去掉第一个问题再在后面加上一个问题，仍然组成4个问题，传给其他8个人，列出其他8个需要回答问题 的人的名字，还要到这8个人的博客里留言通知对方——你被点名了，被点名者不得拒绝回答问题，完成游戏的人将会永远得到大家的祝福。
  
2.这8个人要在自己的博客里注明是从哪里接到的，并且再想一个问题传给其他8个人，让游戏继续下去，不得回传。被点到名字的人将会得到大家的祝福，并且所有美好的愿望都会在不久的将来实现。

小然的问题：
  
1.你最邪恶的念头是什么?
  
不说为妙。

2.你觉得橙子最大的缺点是什么？
  
会酸掉牙。

3.你最害怕失去的是什么?
  
自由。

4.你的薪水是多少？嘻嘻。（不得拒绝回答哦:)）
  
俺是学生！

我的问题：
  
1.你觉得橙子最大的缺点是什么？
  
2.你最害怕失去的是什么？
  
3.你的薪水是多少？嘻嘻。（不得拒绝回答哦:)）
  
4.不想让你们答题了，有人反对么？

以下8人要回答我的问题：
  
<a class="STYLE3" href="http://manonfire.yculblog.com/" target="_blank">射手麦子</a>
  
<a class="STYLE3" href="http://masafly.yculblog.com/" target="_blank">马萨</a>
  
<a class="STYLE3" href="http://blog.sina.com.cn/u/1280475545" target="_blank">flyhan</a>
  
<a class="STYLE3" href="http://blog.sina.com.cn/u/1213481881" target="_blank">蓝日</a>
  
<a class="STYLE3" href="http://songpeng-cronaldo.blogspot.com/" target="_blank">Cronaldo</a>
  
<a class="STYLE3" href="http://marsyan.yculblog.com/" target="_blank">Mars</a>
  
<a class="STYLE3" href="http://blog.mop.com/dicpxkk" target="_blank">来杯咖啡</a>
  
<a class="STYLE3" href="http://happy-star.blog.sohu.com/" target="_blank">angeline</a>

<span style="font-size:180%;"><span style="font-weight: bold;">以</span></span>上是按美女<a class="STYLE3" href="http://huiranfu.blogspot.com/" target="_blank">小然</a>的意愿例行其事，重色轻友让我挺过意不去。所以点几个基本敢不给我面子的，或者没机会给我面子的，从我这里减少对大众时间的浪费。

<span style="font-weight: bold;font-size:180%;">update</span>:
  
被禾草唐楷又点上了，顺带回答下他的问题：
  
<span id="fullpost">途锐，卡宴，Q7，揽胜，X5，谁最能让你芳心摇曳？<br /> 答：一个都没见过。。。如果非要答，allover好了。<br /> </span>