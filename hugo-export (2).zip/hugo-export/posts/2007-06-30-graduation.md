---
title: 毕业了（一）
author: Chouj
type: post
date: 2007-06-30T05:49:33+00:00
url: /2007/06/30/graduation/
views:
  - 2841
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969686
categories:
  - 我思考
  - 我记录
tags:
  - 学位
  - 毕业
  - 游行

---
<p align="center">
  <font color="#660000"><span class="content">黄鹤楼</span><br /> <span class="content">(唐) 崔颢</span></font>
</p>

<p align="center">
  <font color="#660000"><span class="content"> </span><span class="content">昔人已乘黄鹤去，此地空余黄鹤楼。</span><br /> <span class="content">黄鹤一去不复返，白云千载空悠悠。</span><br /> <span class="content">晴川历历汉阳树，芳草萋萋鹦鹉洲。</span><br /> <span class="content">日暮乡关何处是？烟波江上使人愁。</span></font>
</p>

<span class="content"><big><big>以</big></big>这首诗形容HUST每届毕业生的离愁，怕是再合适不过了。</span>这些天在家里，有学妹在Q上说，时间过的好快，师兄们一个一个的都走了，言语中露出哀伤，很是契合<span class="content">崔颢这首诗中的调调。回想这毕业的几天，离愁之于我，仿佛只是一刹那一恍惚。那还是25日晚，和通讯部的朋友们K歌之后，第二天就要离开的我，坐在taxi上，望着一路闪过的街景，怆然得泪眼迷离，要不是有04级的天翼在，我也许就泪流满面了，他应该没有看见我的泪花。</span>

<big><big>我</big></big>是班上第一个离开的，[饭否][1]上留下了我这样的一段自我鉴定：“<span class="content">毕业时，应该最后走的。可以从容的和每个人说再见，可以见证寝室的空荡，可以拥有诸多次离别。而这诸多次，没准儿可以将离愁稀释到无足轻重。</span><span class="content">”最后一句，是传说中的自欺欺人，因为早走很像是一种逃，逃避、逃脱、逃难的逃。逃，兴许会是一种遗憾。<br /> <big><big><br /> 在</big></big>此前，倒是有许多疯狂的有趣的记忆。</span>

<p align="center">
  <span class="content"><a href="http://www.yupoo.com/photos/view?id=ff8080811374561f011376a3878817ef" title="来YUPOO看我的照片"><img src="http://photo8.yupoo.com/20070629/164034_2136795012.jpg" alt="学位授予仪式" border="0" height="360" width="480" /></a><br /> <small><font color="#666666">没照单人的学士服照片，因为个人感觉实在太矬了</font></small><br /> </span><span class="content"></span>
</p>

<span class="content"><br /> <big><big>二</big></big>十号领学位证，一个个套着学士服，恭听最后的教诲。完事后有人语：学位授予仪式，一个字：假；大学四年，一个字：混！也有人语：四年大学就是把流苏从右边折腾到左边尔。晚上的班撮，自是觥筹交错。</span>

<p align="center">
  <span class="content"><img src="http://images.hustnews.com/Science/2007-6-22/17973.jpg" width="480" /><br /> <font color="#666666"><small>照片转载于<a href="http://www.hustonline.net">华中大在线</a></small></font><br /> </span><span class="content"></span>
</p>

<span class="content"><br /> <big><big>二</big></big>十一号毕业生晚会“同歌同行”,毕业生激情释放的官方版。总是觉得当一群人拥有共同的头衔时，共同利益的超距作用就会立马把他们笼络到一块儿，做一些外人看起来挺矬，自己却快感于其中的事情。这晚会上，我如此，甘愿如此，大家也如此。为旗帜欢呼，为口号呐喊，甚至全力打造“荧光棒雨”送给光电，只因他们那欠揍的口号：“我们来的时候最强，走的时候也要最强”。</span>

<font color="#666666">待续&#8230;</font><span class="content"><br /> </span>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://fanfou.com/Chris