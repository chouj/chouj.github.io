---
title: 看了本新闻业内的书
author: Chouj
type: post
date: 2006-09-15T00:51:00+00:00
url: /2006/09/15/read-a-book-focus-on-news/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post_15.html
views:
  - 1695
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969808
categories:
  - 我思考
tags:
  - 读书

---
<div>
  <a href="http://www.douban.com/subject/1400428/" target="_blank"><img src="http://www.douban.com/lpic/s1607480.jpg" border="0" alt="" /></a></p> 
  
  <p>
    <strong><span style="font-size:180%;">当</span></strong>然，我不是从新闻业内的视角来看这本书的，我没有兴趣研究新闻行业在网络上的发展壮大，而之所以把它从图书馆刨回来是基于这些时日在网络上的个人阅历：我可以从网络历史和网络舆论的方向看这本书，在这个方向，这本书记载和评述的比较详细客观。
  </p>
  
  <p>
    <strong><span style="font-size:180%;">这</span></strong>些年来泡在网上，零零落落的接触到了一些网上的事，网络的作用和影响对我的生活侵入之深我很有体会。而看过这本书，网络上这几年来发生了些什么事，也就是网络上的历史，就更加明晰了。网络搭建了平台，网民在这个平台上活动，相当多的事件被网络放大传播了，这本书里提及了许多，给个罗列（无时间顺序）：
  </p>
</div>

<div>
  <span style="color: #999999;">中美撞击问题</span>
</div>

<div>
  <span style="color: #999999;">9.11事件</span>
</div>

<div>
  <span style="color: #999999;">我南斯×拉夫大使馆被炸事件</span>
</div>

<div>
  <span style="color: #999999;">非×典事件</span>
</div>

<div>
  <span style="color: #999999;">广西南×丹矿×难</span>
</div>

<div>
  <span style="color: #999999;">伊战</span>
</div>

<div>
  <span style="color: #999999;">03年罗×刚事件</span>
</div>

<div>
  <span style="color: #999999;">清华大学硫×酸泼熊事件</span>
</div>

<div>
  <span style="color: #999999;">孙志×刚案</span>
</div>

<div>
  <span style="color: #999999;">黄×静事件</span>
</div>

<div>
  <span style="color: #999999;">黑社会头目刘*涌案</span>
</div>

<div>
  <span style="color: #999999;">孙*大午案</span>
</div>

<div>
  <span style="color: #999999;">李*思怡案</span>
</div>

<div>
  <span style="color: #999999;">哈尔宾宝马案</span>
</div>

<div>
  <span style="color: #999999;">赵薇军*旗装事件</span>
</div>

<div>
  <span style="color: #999999;">珠海日本人买*春事件</span>
</div>

<div>
  <span style="color: #999999;">西北大学日本留学生下流表演事件</span>
</div>

<div>
  <span style="color: #999999;">侵华日军遗留毒气弹伤人事件</span>
</div>

<div>
</div>

<div>
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">是</span></strong>不是有些相当的熟悉？当然，不见得非要上网才知道这些事情，传统媒体也有报道，只是网络在这些事件的传播上是一个很高效重要的途径。而且这样的案例如今仍在上演着，网络上依旧风风雨雨，比如高×莺莺事件（<a href="http://xcchris.blogspot.com/2006/07/blog-post.html" target="_blank">1</a>、<a href="http://xcchris.blogspot.com/2006/08/blog-post_19.html" target="_blank">2</a>），比如最近刚刚发生的 <a href="http://dhj2006.blogspot.com/" target="_blank">浙 江 瑞 安 警 民 冲 突</a>(已被封掉了，唉)。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">本</span></strong>书还提及了博客在网络上对网络媒体的影响，只是那时博客现象尚没有大热，所以篇幅较小，只提及了木子美的遗情书。而现今博客对新闻媒介的冲击早不能同日而语，个人搭建的信息汇总和新闻发布博客比比皆是，有些个人博客俨然已是另类门户。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">而</span></strong>本书没有提及的，就是网络消息的信息封锁和管制，不过这属于新闻自由范畴，而不属于网络媒体范畴，姑且算不在本书的讨论范围之内。这个方面偏离正统，消息的传播与封锁涉及钱权利益，在网络上也相当敏感，总体来说，这发展的十年内，网络自然功不可没。“下情上达、上情下达、去塞求通、彰显民意”，网络已经成为了民众发声，表达意愿的阵地，在这一点上，本书也有相当细致的评述。书中还提出了两个对我而言相当专业的词汇：“网络民族主义”、“集体无意识”，抽象出了网民普遍的潜思维，而这些潜在的意识成为了网络上言论极端和泛滥的发动机。
</div>

<div>
</div>

<div>
  <span style="color: #999999;">……网络舆论是一桶解渴的马尿。企图借助网上民意来实现司法公正和社会公正，不好说是饮鸩止渴，也不好说是饮死海里的咸水止渴；对于焦渴于司法和社会公正而难得的人们，姑且饮下这桶马尿，虽有一股令人不爽的骚味，毕竟聊胜于无。</span>
</div>

<div>
  <span style="color: #999999;">&#8212;-《</span><a href="http://www.douban.com/lpic/s1607480.jpg" target="_blank"><span style="color: #999999;">中国网络媒体的第一个十年</span></a><span style="color: #999999;">》P308</span>
</div>

<div>
  书中转引时评家鄢烈山关于网络舆论的评论，一针见血。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">比</span></strong>较有趣的是，书中有一个01－03年的每年十大假新闻，有些新闻标题很是搞笑，而且不乏很有分量的媒体所发布的新闻：
</div>

<div>
</div>

<div>
  <span style="color: #999999;">中国少女改写牛津大学800年校史 01年</span>
</div>

<div>
  <span style="color: #999999;">一男子游悉尼因好色两肾被偷 01.10.2 《南方都市报》</span>
</div>

<div>
  <span style="color: #999999;">千年木乃伊出土后怀孕 02.11.7 新浪网</span>
</div>

<div>
  <span style="color: #999999;">比尔·盖茨遇刺 03.3.29 《中国日报》网站</span>
</div>

<div>
</div>

<div>
  <span style="color: #999999;">《背景》落选新教材 03.9.11 武汉的媒体哦《武汉晨报》</p> 
  
  <div>
    <span style="font-size:85%;">以上信息来源于书中记载 P232－233，绝无诋毁媒体之意，特声明之。</span>
  </div>
  
  <p>
    </span></div> 
    
    <p>
      <span style="font-size:180%;"><strong>温</strong></span>故而知新，从历史的角度看这本书，相信每个网民都会深有感触，并和自己的所知相得益彰。
    </p>