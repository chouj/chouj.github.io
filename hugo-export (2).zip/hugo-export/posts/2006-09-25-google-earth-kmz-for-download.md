---
title: 我收藏的 google earth 地标文件 提供下载
author: Chouj
type: post
date: 2006-09-25T05:41:00+00:00
url: /2006/09/25/google-earth-kmz-for-download/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/google-earth.html
views:
  - 3974
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969814
categories:
  - 我表达
tags:
  - Google Earth
  - kmz
  - 下载
  - 图片
  - 网络

---
**<span style="font-size:180%;">最</span>**近在玩<a href="http://www.williamlong.info/google/archives/4.html" target="_blank">google earth</a>,辛辛苦苦从<a href="http://www.williamlong.info/google/" target="_blank">google earth 观察</a>下载了一大堆地标文件，存到我的地标库里，满世界乱转。实在要拜一下开发这一软件的兄弟姐妹男女老少，太赞了，鼠标一划不是出国就是出洲，比坐飞机还快，还不需要护照。愿其继续更新完善无极限吧，直到能看清我寝室厕所窗户为止。。哈哈。。

**<span style="font-size:180%;">继</span>**续发扬贴图作风！

<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_1.gif" border="0" alt="" />

**<span style="font-size:180%;">武</span>**汉的截图，曾和武大的小草同学异常Crazy的到过图中标记的那个点，下公汽的地方貌似叫船厂村……武汉本地的估计都不会去那里。。除非是live there。。

**<span style="font-size:180%;">言</span>**归正传，从<a href="http://www.williamlong.info/google/" target="_blank">google earth 观察</a>搜集了一大堆地标后，我把它另存为了一个kmz文件，这里借用google pages的空间放出下载。这个适合那种懒人，因为合集不用一个一个的添加到地标库。喜欢自己分类的，或者只想要其中一部分的，只有自己去<a href="http://www.williamlong.info/google/" target="_blank">google earth 观察</a>里一个一个下了。先介绍哈都有哪些地标，看能否勾起丫们的兴趣。

  * <div>
      <span style="color: #3333ff;">中国各省市地标</span>
    </div>

  * <div>
      <span style="color: #ff6600;">卫星可见的大字标语地标，就是什么“为人民服务”、“毛主席万岁”之类</span>
    </div>

  * <div>
      <span style="color: #ff6600;">中国各省市大学地标</span>
    </div>

  * <div>
      <span style="color: #3333ff;">全球10大航天发射基地地标</span>
    </div>

  * <div>
      <span style="color: #ff6600;">二战中著名战役及历史事件地标，包括诸多集中营</span>
    </div>

  * <div>
      <span style="color: #ff6600;">全球核设施地标</span>
    </div>

  * <div>
      <span style="color: #3333ff;">可见航天器地标</span>
    </div>

  * <div>
      <span style="color: #3333ff;">联合国教科文组织世界遗产地标</span>
    </div>

  * <div>
      <span style="color: #ff6600;">2008北京奥运会场馆地标</span>
    </div>

  * <div>
      <span style="color: #3333ff;">非洲可见动物地标</span>
    </div>

  * <div>
      <span style="color: #3333ff;">美国51区——著名军事区</span>
    </div>

  * <div>
      <span style="color: #3333ff;">美国10家最昂贵的Hotel</span>
    </div>

  * <div>
      <span style="color: #3333ff;">世界500强饭店</span>
    </div>

  * <div>
      <span style="color: #3333ff;">Discovery频道提供的美国国家公园地标和美国一览</span>
    </div>

  * <div>
      <span style="color: #3333ff;">拉斯维加斯赌场地标</span>
    </div>

  * <div>
      <span style="color: #3333ff;">世界历史、人文、自然名胜地标（有珠穆朗玛、科罗加多峡谷之类，但不全）</span>
    </div>

  * <div>
      <span style="color: #3333ff;">世界各时期七大奇迹地标</span>
    </div>

  * <div>
      <span style="color: #ff6600;">世贸中心遗址地标</span>
    </div>

[ **[点此下载][1] <span style="font-weight: normal;">] [ </span>****备用下载:**[download id=&#8221;4&#8243;] ]

 [1]: http://www.box.net/shared/pz370qq8e6 "点此下载我收藏的Google Earth地标文件"