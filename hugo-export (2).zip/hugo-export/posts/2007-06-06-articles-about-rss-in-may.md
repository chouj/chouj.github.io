---
title: 五月RSS相关文章汇集
author: Chouj
type: post
date: 2007-06-06T13:46:27+00:00
url: /2007/06/06/articles-about-rss-in-may/
views:
  - 1988
  - 1988
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969957
categories:
  - 相关
tags:
  - button
  - Email
  - Feedburner
  - feedsky
  - FeedTea
  - firefox
  - Google
  - RSS Marketing
  - Zhuaxia
  - 话题广告

---
<big><big>火</big></big>热五月，RSS界也是热闹非凡，<a href="http://www.web2week.com/archives/2007/06/googlefeedburner_1.html" target="_blank">Feedburner改姓为G</a>，及其<a href="http://www.caobian.info/?p=2158" title="我承认：Feedburner是我翻译的" target="_blank">中文版风波</a>，<a href="http://blog.donews.com/keso/archive/2007/05/24/1168174.aspx" target="_blank" title="三言二拍：收钱的话题">Feedsky话题广告的bloggers大讨论</a>，皆为业界大事件。我很欣喜能看到RSS应用的这些发展历程，很多是必须要经历的，You是最大的受益者。

  * **<a href="http://webleon.org/2007/06/googlefeedburnerfeed.html" target="_blank">Google收购Feedburner将如何影响Feed营销市场——WebLeOn</a>**
  * **<a href="http://glif.cn/2007/05/feedburnergoogle.html" target="_blank">写在FeedBurner被Google收购之后——SRC</a>**

Google收购Feedburner，必然带来Feed发展的突飞猛进和巨大变革。游戏规则的制定，再次落入Google手中。

  * **<a href="http://www.qianblogger.com/2007/05/30/huatiguangao-zhenglun/" target="_blank">关于话题广告的争论——前博客</a>**

老前整理出了相关争论文章的列表，我就不一一列出了。不管怎么说，话题广告肯定要经历这种发展和讨论的，始终是一种进步。

  * **<a href="http://blogunion.org/blogs/top-100-english-blogs-with-most-feed-subscribers.html" target="_blank">国外RSS订阅数最多的100个博客</a>**
  * **<a href="http://blogunion.org/blogs/rss-subcribers-more-than-10000.html" target="_blank">RSS 订阅数超过10000的中文博客</a>**
  * **<a href="http://blogunion.org/blogs/taiwan-blog-rss-subcribers-top-21.html" target="_blank">Feedburner订阅数最多的21个台湾博客</a>**

[博客联盟的曾英杰][1]做了一些伟大的统计工作，他还打算做出<a href="http://blogunion.org/log/the-most-subcribered-hongkong-blogs.html" target="_blank">香港博客RSS订阅数top100</a>，数据和排名摆在那里，非常直观，好奇的话不妨去看看。

  * **<a href="http://www.williamlong.info/archives/893.html" target="_blank">Feed托管服务FeedTea试用——月光博客</a>**
  * **<a href="http://www.iyee.cn/post/feedtea-intorduction.html" class="entry-title-link" target="_blank">Feed托管服务商-FeedTea——Yee</a>**

<a href="http://www.feedtea.com" target="_blank">FeedTea</a>，国内第二家Feed烧制服务提供商，Feedsky一枝独秀的局面被打破，虽然FeedTea还有一些bug。

  * **<a href="http://www.caobian.info/?p=2171" target="_blank" title="Permanent Link to ">RSS，Feed和抓虾——和菜头</a>**
  * **<a href="http://hi.baidu.com/binbinmath/blog/item/c6685aafa639fefafbed50c5.html" target="_blank">抓虾：算是半个Start-up Review ——花花</a>**

和菜头同学的blog订阅数已经突破10K，受益于RSS和抓虾的和菜头借此大力推广RSS和抓虾的应用。花花的分析很深刻，很技术，很全面，都用这么多“很”了，还不值得一看么？

  * **<a href="http://www.qianblogger.com/2007/05/21/7rss-zhuanqian/" target="_blank">7个用Rss Feed赚钱的办法——前博客</a>**
  * **<a href="http://www.qianblogger.com/2007/05/31/2rss-tubiaodidian/" target="_blank">两个被忽视的订阅按钮放置地点——前博客</a>**
  * <a href="http://e-spacy.com/blog/1714.html" title="Permanent Link to " target="_blank">DiggReSS:定制digg的Feed(强烈推荐)</a>——E-Space
  * **<a href="http://www.williamlong.info/archives/905.html" target="_blank">RSS Feed邮件评测——月光博客</a>**
  * **<a href="http://www.pengbone.com/?p=224" target="_blank">FireFox浏览器上RSS订阅插件——PengBone</a>**
  * <a href="http://www.pengbone.com/?p=223" target="_blank">lllumio：基于RSS-Feed社会化新运用——PengBone</a>
  * <a href="http://e-spacy.com/blog/1787.html" title="Permanent Link to " target="_blank">Orkut加入Feed订阅功能</a>——E-Space
  * <a href="http://gezhi.org/node/591" target="_blank">订阅文献搜索结果——格志</a>
  * <a href="http://www.caobian.info/?p=2174" title="Permanent Link to " target="_blank">比特海日志14月22日，天气预报RSS订阅</a>——和菜头
  * <a href="http://blog.donews.com/laobai/archive/2007/05/27/1169421.aspx" target="_blank">Nokia把Rss Feed叫做精灵——老白</a>
  * <a href="http://www.showeb20.com/?p=478" title="Article-Link (Permalink)" target="_blank">Funp(推推王)—来自的宝岛台湾的抓虾?</a>——盗盗

RSS的应用依旧层出不穷，高人写过的，我收集下子，就不再写了，免得话题重复，有兴趣的顺着链接过去就行。我自己其实也收集了些，无奈学校网络差，等我回到家里再整理发布吧。毕业倒计时，我也不想让电脑过多的侵占最后一月的时光，所以更新放慢下。自己的blog，自己作主，嘿嘿。

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://blogunion.org