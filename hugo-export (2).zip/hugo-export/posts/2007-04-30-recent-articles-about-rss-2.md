---
title: 最近关于RSS的文章集锦
author: Chouj
type: post
date: 2007-04-30T14:22:38+00:00
url: /2007/04/30/recent-articles-about-rss-2/
views:
  - 1332
  - 1332
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969946
categories:
  - 相关
tags:
  - Blogger
  - Google
  - Reader

---
  * <a href="http://www.qiexing.com/post/159.html" target="_blank">什么是RSS，一个经典的比喻</a>

通过自己的心身经历，把自己运用RSS的过程写的淋漓尽致，通俗易懂。怎么感觉我在总结中心思想？反正很值得看看啦。

  * <a href="http://webleon.org/2007/04/feed.html" target="_blank">为什么要输出全文Feed？</a>

Webleon告诉您为什么要全文输出FEED，但这是一家之言。出于商业化考虑，拥护摘要输出的朋友也正在增多中。

  * <a href="http://http://www.yeeyan.com/articles/view/huahua/699" target="_blank">RSS的未来</a>

译言网上一篇关于RSS的探讨性文章，由花花翻译，高度概括，推荐！

  * <a href="http://www.yangyc.com/?p=244" target="_blank">让博客的RSS订阅用户数量最大化</a>

杨远聘的力作，关于利用RSS对Blog的优化，推荐！

  *  <a href="http://tiaozaoshichang.blogspot.com/2007/03/klipfoliorss.html" target="_blank">Klipfolio：RSS播放器</a>

一款新颖的RSS播放器，是不是会吸引您的眼球呢？

  *  <a href="http://www.showeb20.com/?cat=7" target="_blank">[汇]Showeb2.0中以RSS为标签的文章</a>

盗盗关于RSS和Feed的相关文章，集成了目前最新鲜的RSS运用！

  *  <a href="http://iwfwcf.blogspot.com/2006/12/web-2022-feed.html" target="_blank">[Web 2.0]特色服务&#8211;Feed阅读器</a>

一篇介绍性的科普，来自<span style="color: #666666"></span><span class="post-author"><a href="http://iwfwcf.blogspot.com/" style="color: #666666" target="_blank">IwfWc</a>，也是Blogger圈的名人了。</span>

  *  <a href="http://ggpi.blogspot.com/2007/02/bloggerblogger.html" target="_blank">blogger:我的blogger深度友链方案</a>

GG派关于RSS应用的深度探讨，值得参详。不见得仅仅局限于Blogger呢。

  *  <a href="http://sunr.blogspot.com/2006/09/rss.html" target="_blank">普及篇——RSS和阅读器</a>

又一个有名的blogger hacker 咖啡鱼的教程，通俗讲解RSS和阅读器。

  *  <a href="http://bloooooooogger-beta.blogspot.com/2006/12/blogger_07.html" target="_blank">通过RSS给Blogger添加评论和最新文章(续)</a>

八个圈的教程，通过RSS和Google Reader给Blogger添加评论和最新文章的方法。

  *  <a href="http://bloooooooogger-beta.blogspot.com/2006/12/blogger.html" target="_blank">通过RSS给Blogger添加侧边栏评论和最新文章</a>

一样是八个圈的教程，告诉您如何通过最简单的方法，给Blogger添加侧栏评论和最新文章。

  *  <a href="http://ggpi.blogspot.com/2006/12/bloggerjsrss20.html" target="_blank">Blogger:不通过外部JS文件使RSS供稿超过20的方法</a>

Blogspot上专注Blogger Hack的GG派出品，告诉您如何使Blogger的RSS供稿超过20条。

  *  <a href="http://http://ggpi.blogspot.com/2006/12/bloggerrss.html" target="_blank">Blogger:准确的标签项目RSS地址</a>

GGpi出品，告知您Blogger上各个标签tag的RSS地址。

  *  <a href="http://http://ggpi.blogspot.com/2007/02/bloggergoogle-readerrss.html" target="_blank">如何通过google reader分享RSS聚合</a>

还是GGpi出品，讲述利用RSS和Google Reader打造个人媒体的方法。

  *  <a href="http://www.donews.net/sogoo/archive/2005/03/16/303272.aspx" target="_blank">各站点RSS新闻聚合服务</a>

收集了大量门户、站点的RSS供稿地址，极具资料收集价值。