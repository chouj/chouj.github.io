---
title: feeds.Feedburner.com二级域名访问失效？
author: Chouj
type: post
date: 2007-08-29T14:48:42+00:00
url: /2007/08/29/is-feeds-dot-feedburner-gfwed/
views:
  - 2533
  - 2533
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969976
categories:
  - 新闻
tags:
  - Feedburner

---
[<img src="http://photo11.yupoo.com/20070829/225411_1166580857_m.jpg" alt="ping feedburner" border="0" height="138" width="240" />][1]

29日晚，各地<a href="http://fanfou.com/statuses/N_A-Z4S4eS0" target="_blank">报</a>feeds.Feedburner.com二级域名访问失效，但<a href="http://fanfou.com/statuses/faYNMXoh6ms" target="_blank">可通过代理访问</a>，疑似被墙。

也有<a href="http://fanfou.com/statuses/6MWgkClxp8U" target="_blank">称</a>电信线路无法访，网通线路正常。

事情原委待查，发文测试。

本站Feedsky Feed ：[http://feed.feedsky.com/aboutrss][2]

 [1]: http://photo11.yupoo.com/20070829/225411_1166580857_hwinzrjk.jpg
 [2]: http://feed.feedsky.com/aboutrss "feed"