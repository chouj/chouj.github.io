---
title: 这俩Idea如何？
author: Chouj
type: post
date: 2007-04-13T14:06:00+00:00
url: /2007/04/13/two-great-ideas/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/idea.html
views:
  - 2399
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969874
categories:
  - 我表达
tags:
  - blog
  - Google
  - 网络

---
**你恨他吗？就送他GFW工作人员专用T恤!** 

**“想说上你不容易……”——Google Blogger 中国官方T恤衫标语**

不能不说，人的创造力是无穷的，以上采自qq群32269107，本人是辉常佩服这俩idea滴。

其实这两个idea挺有商业价值的，穿出来特个性。说不准能火，嘿嘿。