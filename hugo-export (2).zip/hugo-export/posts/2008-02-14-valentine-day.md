---
title: 鼠年的情人节
author: Chouj
type: post
date: 2008-02-14T11:00:02+00:00
url: /2008/02/14/valentine-day/
enclosure:
  - |
    |
        http://feelyoung.xmu.edu.cn/home/chem0202/blog/showblog/attachments/month_0510/peini.mp3
        4259840
        audio/mpeg
        
views:
  - 2248
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969723
categories:
  - 我表达
tags:
  - 情人节
  - 鼠年

---
<p align="center">
  <img src="http://pic.yupoo.com/xcchris/363925178911/lm1vfqqn.jpg" alt="鼠年的情人节" border="0" height="500" width="500" />
</p> [audio:http://feelyoung.xmu.edu.cn/home/chem0202/blog/showblog/attachments/month_0510/peini.mp3] 

<big><big>好</big></big>不容易有资格过Valentine&#8217;s Day了，可惜Honey不在身边，送歌一首，<a href="http://mp3.baidu.com/singerlist/%C5%ED%BE%B8%BB%DD.html" target="_blank"><font color="#0033cc">彭靖惠</font></a>的《<a href="http://feelyoung.xmu.edu.cn/home/chem0202/blog/showblog/attachments/month_0510/peini.mp3" target="_blank" title="陪你.mp3">陪你</a>》，愿Honey无论我在不在身边，无论是否是情人节，都要开心；愿所有听歌的朋友都能情人节快乐。

<big><big>其</big></big>实我觉得鼠年情人节最该配的图是<a href="http://pic.yupoo.com/kunshou/55863516b798/medium.jpg" target="_blank" title="献花的艺术">这张</a>，嘿嘿。