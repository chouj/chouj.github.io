---
title: 襄樊也出“钉子户”
author: Chouj
type: post
date: 2008-04-26T19:00:14+00:00
url: /2008/04/27/the-mayor-of-xiangfan/
views:
  - 2574
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969729
categories:
  - 我表达
tags:
  - 史上最牛
  - 图片
  - 新闻
  - 襄樊
  - 钉子户

---
家里又出事情被曝光了，**史上最牛悬赏广告**，**史上最牛的市长**（天涯社区<a href="http://cache.tianya.cn/pub/c/no04/1/696030.205.shtml" title="[新闻]襄樊的天，黑帮的地，老百姓的血，开发商的利" target="_blank">1</a>／<a href="http://cache.tianya.cn/pub/c/no04/1/696216.107.shtml" title="[新闻]史上最牛的市长(襄樊)" target="_blank">2</a>／<a href="http://cache.tianya.cn/pub/c/no04/1/695775.10.shtml" title="[新闻]史上最牛的市长(襄樊)" target="_blank">3</a>／<a href="http://cache.tianya.cn/pub/c/no04/1/696010.93.shtml" title="[新闻]史上最牛的市长;襄樊." target="_blank">4</a>）（照片转自<a href="http://pic.tianya.cn/myalbum/ShowPersonPic.asp?idWriter=0&Key=0&UserID=15745549" title="证据" target="_blank">天涯相册</a>）横空出世：

<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648865_15745549.jpg" alt="点击放大" border="0" width="500" />

<!--more-->

价码加了：

[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648864_15745549.jpg" alt="点击放大" border="0" width="500" />][1]

地点该是在原来劳动街的位置，现在要开发为拉美一条街：

[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7633547_15745549.jpg" alt="史上最牛悬赏广告" border="0" />][2]

[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7633541_15745549.jpg" alt="史上最牛悬赏广告" border="0" />][3]

稍近点儿：

[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648845_15745549.jpg" alt="史上最牛悬赏广告" border="0" />][4]

这样的场面，我在广州科技图书馆对面（黄花岗附近）见过。当地政府修路损毁大楼地基，楼内居民挂出“不顾居民生命”的横幅，可惜当时没有照相器材，也不知现在如何。[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648921_15745549.jpg" alt="点击放大" border="0" width="500" />][5]

横幅们：

[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648907_15745549.jpg" alt="点击放大" border="0" width="500" />][6]

[<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648917_15745549.jpg" alt="点击放大" border="0" width="500" />][7]

有网友评论：

是谁坐镇襄樊市,当初老妈被狗日.
  
生出人模狗样来.黑帮势力助它志.

我觉得：

相比之下，这种社会不合理不合法现象才该抵制，把家乐福好好的经营秩序给抵制乱了有啥意义。

 [1]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648864_15745549.jpg "史上最牛悬赏广告"
 [2]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7633547_15745549.jpg "史上最牛悬赏广告"
 [3]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7633541_15745549.jpg "史上最牛悬赏广告"
 [4]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648845_15745549.jpg "史上最牛悬赏广告"
 [5]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648921_15745549.jpg "史上最牛悬赏广告"
 [6]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648907_15745549.jpg "史上最牛悬赏广告"
 [7]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/7648917_15745549.jpg "史上最牛悬赏广告"