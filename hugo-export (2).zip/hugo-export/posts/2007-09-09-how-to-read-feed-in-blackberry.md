---
title: 如何使用BlackBerry阅读RSS Feeds
author: Chouj
type: post
date: 2007-09-09T12:22:38+00:00
url: /2007/09/09/how-to-read-feed-in-blackberry/
views:
  - 2072
  - 2072
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969980
categories:
  - 工具
tags:
  - Reader
  - 黑莓

---
<img src="http://blogs.feedburner.com/feedburner/archives/handango_r2_c1.gif" title="rss reader for blackberry" alt="rss reader for blackberry" height="169" width="259" />

最近在<a href="http://www.xuchi.name/blog/2007/09/08/blackberry7230/" title="“计算器”入手" target="_blank">把玩黑莓7230</a>，听说可以拿黑莓读RSS，于是找了些资源，共享出来，但**我并没有试过**，仅供参考。

1、<a href="http://www.piconews.com/" title="Piconews" target="_blank"><strong>Piconews</strong></a>——News in your pocket !

各论坛里极力推崇的黑莓用RSS reader，使用心得和截图见<a href="http://www.52blackberry.com/thread-7151-1-1.html" title="介绍一个好的RSS阅读软件 For Blackberry" target="_blank">这里</a>和<a href="http://www.52blackberry.com/thread-5152-1-1.html" title="BB上最方便、最实用的RSS免费新闻阅读软件" target="_blank">这里</a>。

2、<a href="http://www.litefeeds.com/" title="LiteFeeds" target="_blank"><strong>LiteFeeds</strong></a>——移动工具的RSS阅读

<img src="http://litefeeds.com/myfeeds/images/v3images/skins/general/lflogo.gif" title="LiteFeeds" alt="LiteFeeds" height="26" width="219" />

<a href="http://litefeeds.com/install/#bby" target="_blank">说是</a>手机上网浏览http://litefeeds.com/m之后，即可按步骤下载手机端软件并安装。不知道有没有BBers用这种。

3、<a href="http://www.mobipocket.com/en/DownloadSoft/ProductDetailsReader.asp" title=" Mobipocket Reader Desktop 6.0" target="_blank"><strong>MobiPocket Reader</strong></a>——电子书+RSS新闻阅读的强大软件

其实这只是个PC端的软件，支持把文本和RSS以.prc文件导入黑莓。当黑莓和电脑连接时，该软件会自动将手机里的RSS信息和PC端软件里的RSS信息同步，以此成为RSS阅读的一种方式。用户需要主动接入，而不是被动得等待手机网络把新内容推送过来，如果你的黑莓没有上网的话，可以尝试一下这样一种方式。

这里有PC端软件界面的<a href="http://photo11.yupoo.com/20070909/195629_1968417969_igfxckxb.jpg" title="截图 of mobipocket" target="_blank">截图</a>，可以看到添加RSS的按钮，和阅读器的基本布局。<!--more-->

对黑莓7230感兴趣的朋友，可以看看以下两篇文章：

<a href="http://www.xuchi.name/blog/2007/09/08/blackberry7230/" title="“计算器”入手" target="_blank">“计算器”入手</a>

<a href="http://tech.idv2.com/2007/09/08/blackberry-7230-tips/" title="永久链接: BlackBerry 7230一周使用体验" target="_blank">BlackBerry 7230一周使用体验</a>

<font color="#808080"><small>另，这几天RSS相关的Feedburner Feed订阅量一直是0，源于Feed报错。不过，诡异的是，原始feed正常，Feedsky方面的抓取也正常，但Feedburner方面似乎对aboutrss.cn的域名有意见。无论原始feed为http://aboutrss.cn/feed/还是http://aboutrss.cn/?feed=rss2，全部connect timed out，并且也不能另外烧制，但aboutrss.cn可以ping通。迫不得已把原始feed改为http://feed.feedsky.com/aboutrss，却顺畅无比，更改成功。只好先这么烧着了。不解啊不解。</small></font>