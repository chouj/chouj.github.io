---
title: 文艺正反馈
author: Chouj
type: post
date: 2007-10-02T16:06:56+00:00
url: /2007/10/03/positive-regeneration-of-literature/
enclosure:
  - |
    http://tifei.com/ds/xiankainidehouchexiang.mp3
    5275563
    audio/mpeg
views:
  - 2567
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969711
categories:
  - 我思考
tags:
  - 便利店
  - 地铁
  - 广州
  - 文艺
  - 红绿灯

---
（一）<img src="http://www.douban.com/mpic/s1394499.jpg" title="大事件" alt="大事件" align="right" />

杜琪峰的《<a href="http://www.douban.com/subject/1308855/" title="大事件" target="_blank">大事件</a>》里有这么一个情节：陈慧琳根据手机里传来的**“嗒嗒”声**，判断任贤齐在**红绿灯**附近，并与之相遇，对视。最后，锲而不舍的张家辉一枪了断了任贤齐要帮尤勇完成任务的英雄主义，却似乎也催化出了陈任二人经历贼与兵、追与逃之后的惺惺相惜之情。

（二）
  
[audio:http://tifei.com/ds/xiankainidehouchexiang.mp3]

少了娃娃的<span class="pl2"></span>[自然卷][1]，奇哥唱着平凡普通的《<a href="http://www.douban.com/subject/2124428/" title="掀开后车厢" target="_blank">掀开后车厢</a>》：<img src="http://www.douban.com/mpic/s2543721.jpg" title="掀开后车厢 自然卷" alt="掀开后车厢 自然卷" align="right" />

……
  
bobby醉倒在路边
  
卡住**seven-eleven的自动门**
  
**叮咚叮咚叮咚**
  
好似在催眠
  
……

<p style="text-align: center">
  <img src="http://photo11.yupoo.com/20071002/235352_1676802099.jpg" alt="便利店 seven eleven" border="0" height="375" width="500" />
</p>

<p align="center">
  照片转载于<a href="http://loreley666.yculblog.com/post.1425468.html" target="_blank">这里</a>
</p>

（三）

<p style="text-align: center">
  <img src="http://photo11.yupoo.com/20071002/231546_520949947_aekmwaul.jpg" title="广州 书法 地铁" alt="广州 书法 地铁" />
</p>

<p align="center">
  <strong>广州地铁书法站名</strong>，想看更多？<a href="http://blog.163.com/fs_0757/blog/static/2551201200774519968/" title="广州地铁书法站名" target="_blank">点这里</a>。
</p>

（四）

每当我过马路，站在红绿灯旁，听着那“嗒嗒”的声音，经常会想起（一）；

每当大晚上我进seven-eleven买宵夜，开门“叮咚”那一下，就会想起（二）；

每当我搭地铁， 去这儿去那儿，都会留意（三）。

**生活融入到作品之中，再回过头来影响生活，这是不是（城市）文艺的正反馈？**

 [1]: http://www.douban.com/subject_search?search_text=%E8%87%AA%E7%84%B6%E5%8D%B7&cat=1003