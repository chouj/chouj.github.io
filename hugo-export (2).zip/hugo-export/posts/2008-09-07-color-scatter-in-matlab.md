---
title: Matlab：如何以线上点的颜色表示强度
author: Chouj
type: post
date: 2008-09-07T09:03:45+00:00
url: /2008/09/07/color-scatter-in-matlab/
views:
  - 9765
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969908
categories:
  - 我尝试
  - 我表达
tags:
  - matlab
  - 图片
  - 教程

---
Matlab是一款极其好用的数学计算绘图软件。在科研用图绘制功能中，最常见的即为绘制等值线图，这也是一般同学们都掌握的。大家都知道，二维填充等值线图的coutourf(X,Y,Z,n)中，Z=f(X,Y)是一个矩阵，代表X,Y平面上的每一个点对应的值，颜色则表示该值的高低。也就是说，用这个画出来的是一个彩色的面，比如：

<img class="alignnone size-full wp-image-308" title="coutourf" src="http://www.xuchi.name/blog/wp-content/uploads/2008/09/coutourf.jpg" alt="coutourf" width="500" height="374" />

但是，**如果Z是一维向量呢**？如果我们手上就只有某些X,Y对应的Z值，也不能虚构其他的点值来添进，这时候我们想表示强度怎么办呢？用Plot3吗？没错Plot3确实可以，但3维图并不是很容易识别的。如果想以颜色表示该点某物理量的强度，那又怎么画呢？

**本文就来告诉你，怎么实现点线中用点的颜色表示强度。**科研中是会出现这种需要的，比方画卫星轨道、走航轨迹上一些诸如海表面高度、气溶胶浓度之类参量的时候。.

比方我们有三个一维向量：lon,lat,ssha,分别代表卫星高度计数据中的经度(microdegree)、纬度(microdegree)、海表面高度距平(cm)。用matlab散点图命令scatter即可达到我们的目的。命令格式是：

> scatter(X,Y,<S>,<C>,'<type>&#8217;);
  
> <S> &#8211; 点的大小控制，设为和X，Y同长度一维向量，则值决定点的大小；设为常数或缺省，则所有点大小统一。
  
> <C> &#8211; 点的颜色控制，设为和X，Y同长度一维向量，则色彩由值大小线性分布；设为和X，Y同长度三维向量，则按colormap RGB值定义每点颜色，[0,0,0]是黑色，[1,1,1]是白色。缺省则颜色统一。
  
> <type> &#8211; 点型：可选filled指代填充，缺省则画出的是空心圈。

这样，我们就可以得到以经纬度点的颜色表示海表面高度距平的图，使用命令：

> >>scatter(lon,lat,3,ssha);

得到图如下：

<img class="alignnone size-full wp-image-309" title="ssha-scs-topex/poseidon" src="http://www.xuchi.name/blog/wp-content/uploads/2008/09/ssha-scs.jpg" alt="ssha-scs-topex/poseidon" width="500" height="362" />

似乎不是特别直观，那么我们再利用<a title="m_map matlab toolbox" href="http://www2.ocgy.ubc.ca/~rich/map.html" target="_blank">m_map地图工具</a>，将陆地绘制上。此时要注意以下几点：

  1. m_map中经纬以十进制数目表示，不是度分秒形式，且东经为正，西经为负。数据的经纬度一定要符合此形式。
  2. m\_map中投影地图的坐标并不是实际经纬，需要以m\_ll2xy.m（就是longitude & latitude to x-y coordinates）将数据中的经纬转化为投影地图中可用的坐标。例如：>>[X,Y]=m_ll2xy(lon,lat);

命令实例：

> >>hold on
  
> >>m_proj(&#8216;miller&#8217;,&#8217;lon&#8217;,[0 250],&#8217;lat&#8217;,[-80 80]);          % 设置投影、经纬
  
> >>m_coast(&#8216;patch&#8217;,[.7 .7 .7],&#8217;edgecolor&#8217;,&#8217;none&#8217;);     % 画岸界，填充大陆
  
> >>m_grid(&#8216;xlabeldir&#8217;,&#8217;end&#8217;,&#8217;fontsize&#8217;,10);              % 显示网格，并显示label
  
> >>scatter(lon,lat,3,ssha);

得图：

<img class="alignnone size-full wp-image-310" title="ssha-with-map" src="http://www.xuchi.name/blog/wp-content/uploads/2008/09/ssha-with-map.jpg" alt="ssha-with-map" width="500" height="362" />

[教程完]其实很简单，但网络上关于这类画法的指导基本没有，所以稍稍写下，望能帮助到需要的人。