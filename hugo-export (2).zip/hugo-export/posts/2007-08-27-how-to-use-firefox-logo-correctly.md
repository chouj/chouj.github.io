---
title: Firefox logo的讲究
author: Chouj
type: post
date: 2007-08-27T12:05:01+00:00
url: /2007/08/27/how-to-use-firefox-logo-correctly/
views:
  - 2643
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969704
categories:
  - 我表达
tags:
  - firefox
  - logo

---
<img width="192" src="http://photo5.yupoo.com/20070827/192727_1313790192_yccimytj.jpg" alt="Firefox 192" height="192" title="Firefox 192" />

**Firefox** 是大家常用的一款浏览器，但不知道各位有没有研究过它的logo，最近[Asa Dotzler][1] (mozilla.organ/mozilla.org Staff Member/Driver)在其blog里强调<a target="_blank" href="http://weblogs.mozillazine.org/asa/archives/2007/08/responsible_log.html" title="responsible logo usage">Firefox logo的合法合理</a>使用，要求大家对Firefox logo的正确使用进行推广，我就来参与下，转几张他的图：

<p style="text-align: left">
  <img width="580" src="http://photo5.yupoo.com/20070827/192729_643473205_obukdxqu.jpg" alt="difference of the new logo and the old logo" height="310" title="difference of the new logo and the old logo" />
</p>

从图中可以看出，Firefox新旧logo还是有几处细微差别的，新logo更亮一些。而Firefox logo和“Mozilla”、“Firefox”两个单词的**摆放**和**比例**，也是有<a target="_blank" href="http://www.mozilla.org/foundation/identity-guidelines/firefox.html" title="Visual Identity Guidelines: Firefox">严格规定</a>的：

<p style="text-align: center">
  <img width="416" src="http://photo11.yupoo.com/20070827/192727_397573529_yghqnvxx.jpg" alt="横版" height="369" title="横版" />
</p>

<p style="text-align: center">
  横式摆放
</p>

<p style="text-align: center">
  &nbsp;
</p>

<p style="text-align: center">
  <img width="440" src="http://photo5.yupoo.com/20070827/192728_957551715_xtzkcyxv.jpg" alt="竖式" height="255" title="竖式" />
</p>

<p style="text-align: center">
  竖式摆放
</p>

下面是一些常见的**错误**：

<p style="text-align: center">
  <img width="506" src="http://photo11.yupoo.com/20070827/194528_1600802716_vaqkkhza.jpg" alt="firefox-logo-bad-examples" height="110" title="firefox-logo-bad-examples" />
</p>

从左至右错误分别是：缺投影、色彩不正确、不完整、艳丽的背景色、有图案的背景。

<p style="text-align: center">
  <img width="450" src="http://photo5.yupoo.com/20070827/194529_661460292_wkrstnoe.jpg" alt="firefox-wordmark-bad-examples" height="200" title="firefox-wordmark-bad-examples" />
</p>

顺时针方向错误分别是：字体不正确、字体颜色不正确、字体和标志的比例不正确、字体和标志的位置不正确。

**正版Firefox logo下载**（请[正确][2]并[合法][3]的使用）：

<table>
  <tr>
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-big.png">large alpha png</a> (100KB)
    </td>
    
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-medium.png">medium alpha png</a> (60KB)
    </td>
    
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-small.png">small alpha png</a> (20KB)
    </td>
  </tr>
  
  <tr>
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-big.gif">large gif (on white)</a> (64KB)
    </td>
    
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-medium.gif">medium gif (on white)</a> (32KB)
    </td>
    
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-small.gif">small gif (on white)</a> (12KB)
    </td>
  </tr>
  
  <tr>
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-big.jpg">large jpg (on white)</a> (112KB)
    </td>
    
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-medium.jpg">medium jpg (on white)</a> (68KB)
    </td>
    
    <td>
      <a href="http://weblogs.mozillazine.org/asa/ff-logo-small.jpg">small jpg (on white)</a> (20KB
    </td>
  </tr>
</table>

 [1]: http://weblogs.mozillazine.org/asa/
 [2]: http://www.mozilla.org/foundation/identity-guidelines/firefox.html
 [3]: http://www.mozilla.org/foundation/trademarks/policy.html