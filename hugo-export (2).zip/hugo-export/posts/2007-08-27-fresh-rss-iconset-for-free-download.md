---
title: 最新RSS图标免费下载
author: Chouj
type: post
date: 2007-08-27T09:45:18+00:00
url: /2007/08/27/fresh-rss-iconset-for-free-download/
views:
  - 1489
  - 1489
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969975
categories:
  - 标志
tags:
  - Icon
  - Symbol

---
**<a href="http://fasticon.com/freeware/?p=57" target="_blank">圆形Feed图标</a>**：4种色彩，适用于Windows、Linux、苹果。

<img src="http://photo5.yupoo.com/20070827/171313_1421444210_shzdbiuf.jpg" title="圆形Feed图标" alt="圆形Feed图标" height="285" width="425" />

<!--more-->

<a href="http://fasticon.com/freeware/?p=60" target="_blank"><strong>Web 2.0 社会性书签图标</strong></a>：iPhone样式，包括Blinklist, BlogMarks, Delicious, Digg, Feeds, Flickr, Furl, Magnolia, Newsvine, Reddit, Stumbleupon, Technorati。适用于Windows、Linux、苹果。

<img src="http://photo11.yupoo.com/20070827/171312_1002216945_iqkkqtee.jpg" title="社会性书签图标" alt="社会性书签图标" height="285" width="425" />

**[Feedicons][1]**：由Zeus Box Studio制作的34个Feed小图。 你可以用它让“subscribe to RSS-feed”按钮焕然一新。这些图标（不是feed的除外）都是根据<a href="http://www.feedicons.com/" title="FeedIcons" target="_blank">Feed原始图标</a>变化而来。共有32\*32和16\*16两种规格以png格式在<a href="http://creativecommons.org/licenses/by-nd/3.0/" target="_blank">Creative Commons协议</a>下发布。

<img src="http://photo11.yupoo.com/20070827/171314_1416054949_vtmlssyi.jpg" title="Feedicons" alt="Feedicons" height="204" width="248" />

**[RSS Feed][2]** : 三维Feed方块

<img src="http://photo5.yupoo.com/20070827/171313_1149766637_ytnzxnfk.jpg" title="Feed方块" alt="Feed方块" height="135" width="264" />

**[Social Bookmark Iconset][3] ：**又一社会性书签图标

![社会性书签图标][4]

[ <a href="http://www.smashingmagazine.com/2007/08/25/20-free-and-fresh-icon-sets/" title="20+ Free And Fresh Icon Sets" target="_blank">via</a> ]

 [1]: http://www.zeusbox.org/blog/feedicons
 [2]: http://fasticon.com/freeware/?p=40
 [3]: http://www.vikiworks.com/2007/06/15/social-bookmark-iconset/
 [4]: http://photo5.yupoo.com/20070827/171314_2001805654_nrvcedgb.jpg "社会性书签图标"