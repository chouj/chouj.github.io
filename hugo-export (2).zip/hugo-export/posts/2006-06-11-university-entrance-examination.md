---
title: “高考”割草机
author: Chouj
type: post
date: 2006-06-11T04:26:00+00:00
url: /2006/06/11/university-entrance-examination/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/06/blog-post_11.html
views:
  - 1651
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969782
categories:
  - 我思考
  - 我表达
tags:
  - 大学
  - 高考

---
“高考”仿佛割草机一样，碾过一茬又一茬的高三学子，随后，他们将去到不同的地方，肆意的生长。。。
  
7号， <a href="http://manonfire.yculblog.com/" target="_blank">manonfire</a> 告诉我有一个关于高考的纪录片，央视拍的，名为《高三》，记录福建省武平县第一中学2005届高三（7）班里的高考故事，后来获第23届香港国际电影节最佳纪录片人道奖。2005年12月8日，《高三》在央视播出，呵呵，还是我生日那天放的。正值高考结束，又一心念旧，遂down下来看。
  
<a href="http://www.southcn.com/weekend/" target="_blank">南方周末</a> 上也有相关的文章：
  
<a href="http://www.southcn.com/weekend/commend/200606010006.htm" target="_blank">高三非常生活［特别报道］</a>
  
<a href="http://www.southcn.com/weekend/top/200606010008.htm" target="_blank">《高三》之后的高三［特别报道］</a>
  
还有些其他相关文章：
  
<a href="http://www.southcn.com/weekend/commend/200606010002.htm" target="_blank">中国最好的学生上哪所大学</a>
  
<a href="http://www5.blog.163.com/article/--fsw-pqYbfn.html" target="_blank">热爱它，就离开它</a>——<a href="http://www5.blog.163.com/--fsw.html" target="_blank">方三文</a>

<a href="http://www5.blog.163.com/--fsw.html" target="_blank"></a>
  
虽然是小县城里的中学，虽然和我的高三经历有稍许的差别，但无疑的是，片子里的高中、教室、高三师生和高三的感觉，都无比的真实。想来，大学和高中都是轨道旁边的树，区别在于，“大学”这棵树，尚可从列车的窗口中瞥见其退去的身影，而“高中”，早已在记忆中远去。。。曾经以为不可磨灭的感觉，还是在无言的褪去。。。

当眼前飘过“大学”这棵树的时候，再去想之前飘过的那棵叫“高中”的树，忽然有种沧桑的感觉，现在的认知变的不一样了，只是心底又不甘于用“长大了”这三个无力的，能搪塞一切的字来搪塞。那天和 <a title="manonfire" href="http://manonfire.yculblog.com/" target="_blank">manonfire</a> 聊起这个话题时，一古脑的感慨和见解喷涌而出，看穿一切般的果决。。。

(2006-06-07 22:08:26) 麦片
  
进大学大家的压力是不一样的，小县城的学生们（即使如我们）背负着改造命运的使命感，真的很累，而那种青春的激情，令人感动
  
(2006-06-07 22:08:43) Chris抽儿
  
改造命运的使命在那时看来也许上大学是唯一出路，只是真正到了大学中，也许会改变这种看法吧。。在中国。。。

(2006-06-07 22:12:19) 麦片
  
呵呵，那是，但感觉大学确真的是封官加爵进入正史的唯一途径啊， 

(2006-06-07 22:12:25) Chris抽儿
  
途径唯一，机会看不看的见，抓不抓的住，在大学里照样是未知数。。 

(2006-06-07 22:16:04) 麦片
  
所以真进入大学，反而迷失了，大学的神话再进入大学拿一刻反而破灭了，对高三的人而言，像个残酷的童话

(2006-06-07 22:16:40) Chris抽儿
  
嗯，瞬间丢失目标般的，这两天又一批人，要被志愿分数这类虚无浮云般的目标所魅惑了。。。 

(2006-06-07 22:21:18) 麦片
  
去年迎新，在汉口火车站，看扑面而来的几千几千满脸意气的学生，感慨啊，中国最大的浪费不是什么电啊，水啊，饭盒什么的浪费，是激情的浪费啊

(2006-06-07 22:27:51) Chris抽儿
  
现在想想，学校里出现一批新的面孔，对我们即将大四的而言，意义仅仅类似于看见了新鲜的叶芽或活蹦乱跳的虾子般，感到一点生气罢了 

若干年后，当我们眼前飘着其他千奇百怪的花草树木时，我们又怎么想我们的大学呢？“高中”这个词是不是已经模糊的只剩一个躯壳了呢？现在，还是只能用“长大了”这三个字来无限憧憬和逃避搪塞了。。。