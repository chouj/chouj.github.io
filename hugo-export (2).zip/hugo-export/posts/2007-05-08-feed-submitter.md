---
title: Feed Submitter:向搜索引擎提交您的Feed
author: Chouj
type: post
date: 2007-05-08T02:14:34+00:00
url: /2007/05/08/feed-submitter/
views:
  - 1229
  - 1229
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969950
categories:
  - 工具
tags:
  - feed提交
  - sumbitter

---
![][1]

**<a href="http://www.feedsubmitter.com" target="_blank"><big><big>F</big></big>eed Submitter</a>**，英文意思就是提交Feed。顾名思义，该站提供的服务即为**向各大搜索引擎提交您的Feed地址**，以供搜索，免费的哦。

<big><big>目</big></big>前该站将把Feed地址提交到如下站点：

> Google Blog Search
> 
> Google Ping
> 
> Technorati
> 
> Technorati Ping
> 
> Blogdigger
> 
> BloogZ
> 
> BlogStreet

<big><big>提</big></big>交方法很简单，只需在该站首页填入RSS Feed地址和您的Email邮箱，点击“OK”即可。之后反馈页如下：

![][2]

<a href="http://www.feedsubmitter.com" target="_blank">点此进入该站 </a>

 [1]: http://photo8.yupoo.com/20070507/161803_1314524628_yaisjgzr.jpg
 [2]: http://photo6.yupoo.com/20070507/162725_126805739_jxdodjhj.jpg