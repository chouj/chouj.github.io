---
title: 08上半年出炉的RSS图标精选（一）
author: Chouj
type: post
date: 2008-06-17T05:15:20+00:00
url: /2008/06/17/rss-icons-2008-first-half-1/
views:
  - 1365
  - 1365
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970007
categories:
  - 标志
tags:
  - Download
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
_精选deviantART.com中08年新出炉的RSS Feed图标设计，陆续发布到这里。_

  * 2008.06.06 <a title="RSS feed button pack by ~deviantdark" href="http://deviantdark.deviantart.com/art/RSS-feed-button-pack-87852077" target="_blank"><strong>RSS feed button pack by ~deviantdark</strong></a>

<img src="http://pic.yupoo.com/xcchris/207305babcf6/kptyjh9y.jpg" alt="Aboutrss RSS 图标展示" width="300" height="237" />

18 个白色背景 PNGs 190&#215;190 pixels <!--more-->

  * 2008.01.03 <a title="褶皱风格RSS图标" href="http://customize.org/icons/55872" target="_blank"><strong>Grunge Style Rss Feed Icons 褶皱风格RSS图标</strong></a>

<img src="http://pic.yupoo.com/xcchris/320925967240/uim82953.jpg" alt="Grunge Style Rss Feed Icons" width="400" height="160" />

颜色：红、蓝、绿 大小：128、64、32 pix

  * 2008.02.26 <a title="Minty RSS Icon" href="http://mintyferret.com/free/free-rss-icons/" target="_blank"><strong>Minty RSS Icon</strong></a>

<img src="http://pic.yupoo.com/xcchris/481625967240/esd429ee.jpg" alt="Minty RSS Icon" width="391" height="307" />

格式：PNG、PSD

  * 2008.03.26 <a title="glossy RSS icons" href="http://sniffels.deviantart.com/art/RSS-icons-81087537" target="_blank"><strong>glossy RSS icons</strong></a>

<img src="http://pic.yupoo.com/xcchris/050355967240/51qgchp4.jpg" alt="glossy RSS icons" width="174" height="133" />

格式：PNG、PSD

  * 2008.03.30 <a title="心型RSS图标" href="http://vikiworks.com/2008/03/30/heart-rss-icon/" target="_blank"><strong>Heart RSS Icon 心型RSS图标</strong></a>

<img src="http://pic.yupoo.com/xcchris/275645962f3f/a6goaql1.jpg" alt="Heart Shape RSS Icon" width="336" height="400" /><a title="vikiworks studio" href="http://vikiworks.com/" target="_blank"></a>

格式：PNG 颜色：红、橙、紫 大小：16、32、64 pix <a title="Heart RSS Icon | Vikiworks Studio" href="http://vikiworks.com/2008/03/30/heart-rss-icon/" target="_blank"></a>

  * 2008.04.04 <a title="Wegmann RSS Icons" href="http://sniffels.deviantart.com/art/RSS-81858462" target="_blank"><strong>Wegmann RSS Icons</strong></a>

<img src="http://pic.yupoo.com/xcchris/871065967240/m93ia26u.jpg" alt="Wegmann RSS Icons" width="257" height="127" />

  * 2008.06.14 <a title="RSS Feed icons by ~Yanu23" href="http://yanu23.deviantart.com/art/RSS-Feed-Icon-88634187" target="_blank"><strong>RSS Feed Icon by ~Yanu23</strong></a>

<img src="http://pic.yupoo.com/xcchris/917175bab7ab/0tu06zqt.jpg" alt="Aboutrss RSS 图标展示" width="256" height="256" />

  * 2008.06.11 <a title="RSS icon homework1 by ~hexybaby" href="http://hexybaby.deviantart.com/art/RSS-ICON-homework1-88352355" target="_blank"><strong>RSS ICON homework1 by ~hexybaby</strong></a>

<img src="http://pic.yupoo.com/xcchris/824575bab7ab/0du7ppje.jpg" alt="Aboutrss RSS 图标展示" width="200" height="200" />

  * 2008.6.10 <a title="RSS Feed animated icon" href="http://aztecwickedsun.deviantart.com/art/rss-animated-icon-88273792" target="_blank"><strong>rss animated icon</strong></a>

<img src="http://fc01.deviantart.com/fs25/f/2008/162/8/4/rss_animated_icon_by_aztecwickedsun.gif" alt="Aboutrss RSS 动态图标展示" width="23" height="22" />

  * 2008.06.08 <a title="RSS Feed icons by ~blogeeks" href="http://blogeeks.deviantart.com/art/RSS-ICON-88028830" target="_blank"><strong>RSS ICON by ~blogeeks</strong></a>

<img src="http://pic.yupoo.com/xcchris/946155babcf6/dq5sl279.jpg" alt="Aboutrss RSS 图标展示" width="300" height="300" />
  
格式：PNG JPG 大小：250×50 pix

积极参与，慎重选择，共同期待08上半年最受欢迎RSS标志十强的出炉！
  
[poll id=&#8221;2&#8243;]