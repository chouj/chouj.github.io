---
title: 欠揍的广告
author: Chouj
type: post
date: 2007-05-13T03:41:54+00:00
url: /2007/05/13/ad-of-xiaonei-im/
views:
  - 1983
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969681
categories:
  - 我记录
tags:
  - 人人
  - 广告
  - 校内

---
![抢沙发！][1]

<big><big>个</big></big>人认为这个广告非常欠揍，不知道<a href="http://www.wangxiaofeng.net" target="_blank">三表同志</a>看了会有什么样的反应。

广告词是：用校内通，抢沙发更轻松！

 [1]: http://photo1.yupoo.com/20070808/142226_1494654951_uwfezmdy.jpg