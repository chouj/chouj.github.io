---
title: 在Blog上贴个PageRank Button
author: Chouj
type: post
date: 2007-05-02T15:38:27+00:00
url: /2007/05/02/pagerank-button/
views:
  - 2808
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969677
categories:
  - 我表达
tags:
  - button
  - pagerank
  - pr

---
<big><big>最</big></big>近查到一个提供**PageRank**查询和贴纸订做的站，感觉不错。结合我所知，这里介绍三个提供PR按钮定制服务的网站，按我喜欢的程度来排序，^_^

![][1]

**<a href="http://www.pagerankp.com/" target="_blank">点此进入</a>**

<big><big>前</big></big>些天我才看到这个站，应该有朋友介绍过。全蓝色的界面设计，很舒服。页面简单，只有一个域名提交框。提交后，即显示出PR值贴纸，三种规格如下：

[<img src="http://www.pagerankp.com/allofrss.blogspot.com/80x15.gif" alt="PageRank Plus - Google PageRank checking, with a twist." title="PageRank Plus - Google PageRank checking, with a twist." border="0" height="15" width="80" />][2] 80&#215;15 Google PageRank Button

 ![][3]88&#215;31 Google PageRank Logo

 ![][4]Signature Report

<p align="center">
  ===============================
</p>

![][5]
  
**<a href="http://www.thinkpage.cn/pagerank/" target="_blank">点此进入</a>**

<big><big>一</big></big>个中文站，一直处于Beta阶段，提供PR查询和贴纸订做服务。样式有六种：

![][6]

<big><big>支</big></big>持跟踪显示当前页面PR或显示固定页面PR，支持生成JS代码和图片代码。问题就是有些时候载入会有点慢。

<p align="center">
  ===============================
</p>

![][7]

**<a href="http://www.mypagerank.net/" target="_blank">点此进入</a>**

<big><big>老</big></big>牌PR查询站点了，但这也仅仅是其众多免费服务中的一项！点击侧栏的[Google Pagerank Button][8]即进入订做界面，只需输入您Blog的地址。样式有7种：

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009534d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009504d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009514d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009564d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009574d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009544d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<a href="http://www.mypagerank.net" target="_blank"><img src="http://www.mypagerank.net/services/pagerankbutton/pagerankbutton.php?aut=de510918b7fa779c0bcff09a5c2009554d175b64f5" alt="Powered by MyPagerank.Net" border="0" /></a>

<big><big>如</big></big>果您想显示得更加详细，可以选用侧栏Free Services的第一项[SEO Stats][9]，输出样式如下：

[<img src="http://www.mypagerank.net/services/seostats/seostats.php?s=de510918b7fa779c0bcff09a5c205a005d4a0d&bg=FFFFFF&textcolor=000000&bordercolor=999999&indicatorcolor=5EAA5E&ugo=1&uho=1&umo=1&amo=1&upr=1&tuv=1&tpv=1&yuv=1&ypv=1&ttuv=1&ttpv=1&uonline=1&f=37004" title="SEO Stats powered by MyPagerank.Net" border="0" />][10]

<big><big>该</big></big>站输出的贴纸，有时候在FF或IE下会出现点问题而显示不出来。

<p align="center">
  =============================
</p>

<big><big>介</big></big>绍完毕，朋友们可以自己挑选喜欢的Pagerank Button定制服务，生成自己的PR贴纸啦。

Technorati Tags: <a href="http://technorati.com/tag/pagerank" class="performancingtags" rel="tag">pagerank</a>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://photo8.yupoo.com/20070502/230128_1744168408.jpg
 [2]: http://www.pagerankp.com/
 [3]: http://www.pagerankp.com/allofrss.blogspot.com/88x31.gif
 [4]: http://www.pagerankp.com/allofrss.blogspot.com/sig.gif
 [5]: http://www.thinkpage.cn/images/logo.gif
 [6]: http://photo7.yupoo.com/20070502/231856_340229075.jpg
 [7]: http://www.mypagerank.net/images/29d5ad2ea506ed624d359d6ca71f245f.gif
 [8]: http://www.mypagerank.net/service_pagerankbutton_index
 [9]: http://www.mypagerank.net/service_seostats_index
 [10]: http://www.mypagerank.net