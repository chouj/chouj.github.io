---
title: 华中科技大学物理系04级毕业衫
author: Chouj
type: post
date: 2008-04-30T05:48:48+00:00
url: /2008/04/30/tshirts-of-hust-phy-04/
views:
  - 3782
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969732
categories:
  - 我记录
tags:
  - 华中科技大学
  - 毕业衫
  - 物理系

---
华中科技大学物理系04级毕业衫火热出炉，04级同学自行设计的哦：
  
[
  
][1] <img class="alignnone size-full wp-image-84" title="华中科技大学物理系04级毕业衫设计图" src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/tshirt04a.jpg" alt="华中科技大学物理系04级毕业衫设计图" width="500" height="913" />

<!--more-->

真人秀，感谢模特<a title="walkever" href="http://www.byhh.net/cgi-bin/bbsqry?userid=walkever" target="_blank">Walkever</a>同学：

<img class="aligncenter size-full wp-image-85" title="华中科技大学物理系04级毕业衫真人秀正面" src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/zheng.jpg" alt="华中科技大学物理系04级毕业衫真人秀正面" width="350" height="320" />

<img class="aligncenter size-full wp-image-86" title="华中科技大学物理系04级毕业衫真人秀背面" src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/bei.jpg" alt="华中科技大学物理系04级毕业衫真人秀背面" width="350" height="467" />
  
回味下[03级毕业衫的设计图][2]，我还是喜欢自己这级的，哇咔咔。

###### <span style="color: #888888;">for zhuaxia : {ZHUAXIA24f94cc751fc7da77e7637ea720f992bUnion}</span>

 [1]: http://www.xuchi.name/blog/wp-content/uploads/2008/04/large_14687m172.jpg "点击放大"
 [2]: http://bp2.blogger.com/_2MqU1LfBbeM/RjHiyjZlN3I/AAAAAAAAAH4/nmP1NcL_xWE/s1600/T%E6%81%A4.jpg "华中科技大学物理系03级毕业衫"