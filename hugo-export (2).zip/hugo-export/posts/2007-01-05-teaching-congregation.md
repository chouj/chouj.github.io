---
title: 狼来了
author: Chouj
type: post
date: 2007-01-05T11:04:00+00:00
url: /2007/01/05/teaching-congregation/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/01/blog-post.html
views:
  - 1827
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969839
categories:
  - 我表达
  - 我记录
tags:
  - 华中科技大学
  - 物理系

---
<img id="BLOGGER_PHOTO_ID_5017090250178550962" src="http://bp1.blogger.com/_2MqU1LfBbeM/RaBJADf33LI/AAAAAAAAAAM/7psOwT6tZCQ/s320/11k.JPG" border="0" alt="" width="400" />

<span style="font-size:180%;"><span style="font-weight: bold;">教</span></span>学预评估来了，人人自危，校主页都紧张到把日期弄错的地步（已改正）。

> 标 题: 为学校本科教育评估做贡献～大家帮顶啊
  
> 发信站: 武汉白云黄鹤站 (2007年01月04日23:43:26 星期四)
> 
> 为了迎接本科教育评估，兄弟们把压箱底的东西都搬出来了，大家帮顶啊～～
> 
> <img id="BLOGGER_PHOTO_ID_5017096293197536466" src="http://bp0.blogger.com/_2MqU1LfBbeM/RaBOfzf33NI/AAAAAAAAAAk/bPI3vrwDaJw/s320/2%25B8%25B1%25B1%25BE.jpg" border="0" alt="" width="300" />
> 
> <img id="BLOGGER_PHOTO_ID_5017093282425461954" src="http://bp3.blogger.com/_2MqU1LfBbeM/RaBLwjf33MI/AAAAAAAAAAY/idNg80a-an8/s320/1%25B8%25B1%25B1%25BE.jpg" border="0" alt="" width="300" />

<span style="font-size:180%;"><span style="font-weight: bold;">白</span></span>云上4号十大第一帖，我住这栋当然也和照片似的，一样壮观。寝室里是能扔了，不能扔的也扔了，本以为这样的场景仅有毕业方可见到，没想提前了，无端辛苦了做清洁的阿姨们。以上两张是学校东区拍的，我住西区，本科生全体动员，不是围狼，是为狼。

> 发信人: lyphhust (疯狂的猪头), 信区: Physics
  
> 标 题: 还叫人活吗？
  
> 发信站: 武汉白云黄鹤站 (2007年01月04日22:30:34 星期四)
> 
> 相信大家都接到通知了吧，我觉得那些条款不是苛刻，是搞笑啊！！

<span style="font-size:180%;"><span style="font-weight: bold;">物</span></span>理版某人一贴，庆幸BBS还未及时管制起来。所谓“条款”诸多，仅凭记忆，备案如下：

> ……
  
> 打开电脑的，任何时候不许游戏，不许QQ，不许看影视作品，不许做与学习无关的事……
  
> 举凡课堂正常上课期间，不要在教学楼内走动，窥探，尽量不要在校园内肆意走动……
  
> 我所接到的是：晚间时段，尽量不要4人全在寝室；低年级一些同学接到的是：晚间时段，寝室仅可留一人……
  
> 早8点前必须起床，晚10点前，不许呆在床上……
  
> 凡有课，必须于课前提前5分钟到教室，有班主任核查，落实到人，而非人头数目……
  
> ……

<span style="font-size:180%;"><span style="font-weight: bold;">此</span></span>事全系上下极为重视，特召开年级大会一次。楞没想到，大四了，居然召开年级大会的次数最多。稍加记录几点：

> 辅导员：如果谁有任何违纪、出错，有免推资格的，我们会考虑在给你保研单位的院系意见上提一笔；要就业的，我们会考虑在就业推荐书上，告知你要应聘的单位；考研的，我们也会考虑在院系建议上或档案里提及到……
  
> 某男接：打DotA的，我们会考虑让你的英雄每秒掉100滴血……

> 辅导员：……你们谁私下谈恋爱的，在校园里也要收敛一点……
  
> 众男议：……这年头谈恋爱，还有私下的啊？

> 辅导员：我们和各班主任都写了军令状，系里也向学校保证过……
  
> 木然想起麦子提到过的“对上负责制”一词……

[<span style="font-size:180%;"><span style="font-weight: bold;">豆</span></span>瓣][1]上有一贴：[武汉，你最想访问谁？][2]有人回复：<span style="color: #999999;">大学校长，今年的本科评估你们花了多少钱？</span>虽然即便问了，相信也套不出任何有价值的信息，但这本意良好的教学评估，无疑已经被贴上“劳民伤财”的标签了。

 [1]: http://www.douban.com/
 [2]: http://www.douban.com/group/topic/1368254/