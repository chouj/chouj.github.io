---
title: 创意表白 雪之缘
author: Chouj
type: post
date: 2007-01-16T05:55:00+00:00
url: /2007/01/16/say-love-by-footprint-in-snowfield/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/01/blog-post_16.html
views:
  - 2485
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969842
categories:
  - 我表达
tags:
  - 图片
  - 恶搞

---
时遇大雪，本少教宁丫一表白高招。

大雪天，银妆素裹，白雪似鹅毛。两人同行，最好周围人烟稀少，还有，不要撑伞。
  
宁丫先问MM：

“想和雪更近吗？”

“想”，或者“怎么更近？”

直接拦腰抱起，记住要从胯部抱或者腿抱，抱起来让MM比你高，然后转个三五圈，同时说：

“这样就和天上的雪更近啦，好玩不？”

无视MM这时说什么，应该会比较high。把MM放下来，手揽其腰，或搭其肩，切莫松手，为后续动作做准备哈。含情脉脉，深情款款的看着MM的眼睛（有眼镜的宁丫的目光就要透过镜片！）说：

“那……想和我更近吗？”

聪明的MM肯定明白宁丫在说什么，没准儿一个“想”就答应了，吻之，顺理成章。雪中浪漫，即可打造，之后的浓情蜜意待续。

不过有个词说的好，物极必反。越聪明的人往往越傻，当然，傻是装的。如此关键时刻，紧要关头，更聪明的女孩子怎能不装下傻？

“嗯？什么意思啊？不明白耶？”或“怎么个近法？”或……傻人各有傻相。

没关系，拿出男子气概，直接躬亲示范，趁着MM在怀（之前叫宁丫别松手啦撒），吻之。记住，要温柔的吻，嘴唇对嘴唇那种，宁丫别想蛇吻那旮旯去了哈。然后，深情款款，含情脉脉的看着MM的眼睛，继续问：

“现在呢？想和我更近吗？”

这句已经没有必要问了，答案了然于胸，如果人家已经让你kiss的话。但还是要说的哈，再之后可以说：

“本来想说‘想和我更亲近吗？’为了示范‘亲’这个动作，就给省掉啦哈，呵呵” 云云，随后的浓情蜜意再次待续。

另外要说的是，本想写“版权所有，D版必究”的，考虑到当今社会D版有理，“二手”精神无限传扬，本少这金牌创意从此文字化，公开化后，自然会贬值沦为糟粕，不禁扼腕哀叹。但宁丫在加速其糟粕化庸俗化的进程中，要是D版成功了，咋说也得给点版权费吧？本少好歹也算半个红娘不是？话说回来，宁丫要是不幸在D版过程中出了意外，比方说，小姑娘放不开，在被抱起的一刹那，把宁丫的意思揣测成了要非礼丫，不幸激发出了狂暴状态，对宁丫一阵拳打脚踢牙啃外带拔头发，以此带来的人身安全损失、财产损失、精神损失，概因宁丫主动D版本少创意而起，本少概不负责！

最后奉劝各位一句：情网有风险，入网先交钱。

<a href="http://bp3.blogger.com/_2MqU1LfBbeM/RaxuD8o2PcI/AAAAAAAAABo/LGCkxlcGIJs/s1600-h/r.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5020508698707377602" style="cursor: pointer;" src="http://bp3.blogger.com/_2MqU1LfBbeM/RaxuD8o2PcI/AAAAAAAAABo/LGCkxlcGIJs/s400/r.jpg" border="0" alt="" /></a>

<span style="color: #999999;">仅一本文反击那些说本少或者私下认为本少不懂浪漫，不解风情的男人女人！</span>