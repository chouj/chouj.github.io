---
title: 三款基于Adobe AIR的RSS阅读器
author: Chouj
type: post
date: 2008-08-18T16:47:19+00:00
url: /2008/08/19/3-adobe-air-rss-reader/
views:
  - 1986
  - 1986
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970017
categories:
  - 工具
tags:
  - Adobe AIR
  - AppriseReader
  - Google Reader
  - ReadAir
  - Snackr

---
_以下软件均基于Adobe AIR技术，请确保已安装<a title="Get Adobe AIR" href="http://www.adobe.com/products/air/" target="_blank">AIR支持</a>。_

  * <a title="Snackr.net" href="http://www.snackr.net/" target="_blank"><img src="http://pic.yupoo.com/daodao/6867158d2684/5ehp4it7.jpg" alt="Snackr" width="32" /><strong>Snackr</strong></a>

![Snackr截图][1]

Snackr当之无愧是最炫的AIR RSS阅读器，看截图便知。她可以附在桌面一端，滚动播放最新的条目标题，点击条目浏览也是动态展开，非常cool。当然，和正统阅读器相比，其文字排版功夫不到位，且无法标记和区分已读未读。适合追踪新闻时效性的用户使用。喜欢Snackr的朋友，可以在twitter追踪官方消息：<a title="Snackr@twitter.com" href="http://twitter.com/snackr" target="_blank">Snackr@twitter.com</a>

<!--more-->

[ <a title="Snackr主页" href="http://www.snackr.net/" target="_blank"><strong>点此进入Snackr主页</strong></a> ]

  * <a title="Apprise主页" href="http://www.apprisereader.com/" target="_blank"><img src="http://www.apprisereader.com/images/apprise.png" alt="Apprise Logo" /></a>

<img title="Apprise截图" src="http://pic.yupoo.com/xcchris/32076603e2e8/7soopzq0.jpg" alt="Apprise截图" width="468" height="353" />

中规中矩的Apprise是最阅读器的阅读器，长得和一般离线RSS阅读器差不多，差别就是她是Adobe喂大的。功能齐全，支持Feed内容浏览的同时，内含浏览器，可载入Feed对应页面。另一个特色在于，集成了twitter和AOL服务。

[ <a title="Apprise主页" href="http://www.apprisereader.com/" target="_blank"><strong>点此进入Apprise主页</strong></a> ]

  * <a title="ReadAir主页" target="_blank"><img src="http://readair.adammcgrath.com/img/logo.gif" alt="ReadAir Logo" /></a>

<img src="http://pic.yupoo.com/xcchris/34231603e2e8/cnxhxcds.jpg" alt="ReadAir截图" width="468" height="353" />

严格来说，该软件只能算是Google Reader基于Adobe AIR的桌面版，要想使用该软件首先需要Google Reader帐号，也就是说，这是一款线上阅读器软件。基本在Google Reader里能进行的操作，在ReadAir里都可以进行。界面上来看，ReadAir却带着浓厚的Mac风格，非常漂亮。

[ <a title="ReadAir项目首页" href="http://code.google.com/p/readair/" target="_blank"><strong>点此进入ReadAir主页</strong></a> ]

 [1]: http://pic.yupoo.com/xcchris/89759603e2ea/c69p7zf2.jpg "Snackr截图"