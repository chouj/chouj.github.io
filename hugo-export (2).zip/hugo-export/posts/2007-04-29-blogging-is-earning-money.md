---
title: Blogging is Earning money
author: Chouj
type: post
date: 2007-04-29T09:00:00+00:00
url: /2007/04/29/blogging-is-earning-money/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/blogging-is-earning-money.html
views:
  - 1855
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969881
categories:
  - 我尝试
tags:
  - blog

---
> 尊敬的Feedsky用户您好：
> 
> 您的广告收入已经支付到您的相应帐户，请注意查收。
> 
> 如在使用过程中碰到问题或有意见建议，欢迎您随时与我们的<a onclick="return top.js.OpenExtLink(window,event,this)" href="http://faq.feedsky.com/" target="_blank">客服联系</a>。
> 
> Feedsky广告团队祝您使用愉快
> 
> Feedsky团队敬上
> 
> <p style="margin: 5px 25px 0px 30px; font-size: 11px;">
>   <a onclick="return top.js.OpenExtLink(window,event,this)" href="http://www.feedsky.com/" target="_blank">Feedsky.com</a> ©2007 All Rights Reserved
> </p>

<span style="font-size:180%;">不</span>是我不明白，是时代变化快！写几百个字就能拿到相当一件廉价T恤的收入，看来我可以充分实现T恤的自给自足：线上收钱，线上订货，线上付账。这玩意儿要是告诉我妈，不知道她是该把我当疯子呢，还是会眼冒绿光杀进Blog圈？唉，其实，估计我告诉我身边的同学，都会有人把我当疯子呢。

<span style="font-size:180%;">P</span>agerank最近又有所调整，我那没怎么打理的[<span style="font-weight: bold;">RSS相关</span>][1]居然从0窜到了3，着实让人匪夷所思，是不是说明主题Blog更有生命力？该有所侧重？

<span style="font-size:180%;">D</span>onews Blog的后台还是进不去，真是服了[千橡门下这个超级2的站][2]。

<span style="font-size:180%;">帮</span>导师改他们写的英语论文，头大，终于知道看不地道的英语是多么痛苦，估计积累下的语感怕是在这几天之内玩儿完了。残念～～

[<span style="font-size:180%;">C</span>BN Forum][3]上在讨论[合租意向][4]，如果成行的话，服务器是世纪互联的，和抓虾的服务器摆一个机房里，大概300米一年，凑不凑这个热闹呢？

 [1]: http://allofrss.blogspot.com
 [2]: http://www.xuchi.name/blog/2007/04/29/the-most-2-internet-company/
 [3]: http://forum.chinabloggernetwork.com/?fromuid=35
 [4]: http://forum.chinabloggernetwork.com/viewthread.php?tid=367&extra=page%3D1