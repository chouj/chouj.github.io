---
title: '[图文教程]给目录页或标签页添个Feed'
author: Chouj
type: post
date: 2007-09-22T12:35:50+00:00
url: /2007/09/22/add-feed-to-category-or-tags/
views:
  - 1664
  - 1664
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969985
categories:
  - WordPress
  - 教程
tags:
  - html
  - Tutorial
  - WordPress

---
<span style="text-decoration: line-through;">WordPress架构下的目录页和标签页不支持Feed输出。</span>当我们想**让自己的目录也支持Feed输出**，或者，当我们只对blog某目录下的文章感兴趣的时候，**想订阅这个目录**，该怎么办呢？我们可以借助<a title="HTML2RSS线上工具收集" href="http://aboutrss.cn/2007/09/05/html2rss-online-tools/" target="_blank">HTML2RSS工具</a>来实现！

以**Feed43.com**为例，<a title="抽筋儿" href="http://www.xuchi.name/blog/" target="_blank">抽儿</a>PS了个教程， 由于图片硕大，就不贴在这里了，只放出LINK。依照教程思路，其他<a title="HTML2RSS线上工具收集" href="http://aboutrss.cn/2007/09/05/html2rss-online-tools/" target="_blank">HTML2RSS工具</a>同样能帮你给目录页或标签页添个Feed。

[ <a title="给目录页或标签页添个Feed" href="http://aboutrss.cn/wp-content/uploads/2008/05/feed43-tutorial.jpg" target="_blank"><strong>点此进入图文教程</strong></a> ]

<span style="color: #ff0000;"><strong>Update:</strong></span>

其实，在目录链接和标签链接后面加上/feed/就是目录页feed和标签页feed了。。。。我真傻，真的。
  
比如：http://aboutrss.cn/category/wordpress/<span style="color: #ff0000;">feed/</span>