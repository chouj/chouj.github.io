---
title: All in ONE订阅按钮免费制作站点收集
author: Chouj
type: post
date: 2007-05-23T12:32:46+00:00
url: /2007/05/23/all-in-one-feed-button/
views:
  - 2228
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969956
categories:
  - 工具
tags:
  - button

---
<big><big>B</big></big>logosphere中，经常可以见到**All in ONE**类型的订阅按钮，说白了就是用一个按钮代替众多阅读器的订阅按钮，其类型目前主要有两种，一种是鼠标移动到按钮上或点击按钮，随即触发下拉菜单，菜单中有适合各种阅读器的按钮；另一种是点击按钮后转到拥有一堆按钮的界面供选择。[RSS相关][1]特收集了一些常用的All in ONE按钮制作站点，免费无需注册：

## <span style="color: #ff0000;"><strong>菜单式：</strong></span>

<a style="text-decoration: none" href="http://www.feedbutton.com/" target="_blank"><span style="border-style: solid; border-color: #ffcc99 #ffcc99 #ff9966 #ff9966; border-width: 0px; margin: 0pt; padding: 0pt 3px; background: #ffffff none repeat scroll 0% 50%; font-family: verdana,sans-serif; font-style: normal; font-variant: normal; font-weight: bold; font-size: 22px; line-height: normal; font-size-adjust: none; font-stretch: normal; color: #3399ff; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; text-decoration: none">FEED</span><span style="border-style: solid; border-color: #ffcc99 #663300 #333300 #ff9966; border-width: 1px; margin: 0pt; padding: 0pt 0px; background: #ff6600 none repeat scroll 0% 50%; font-family: verdana,sans-serif; font-style: normal; font-variant: normal; font-weight: bold; font-size: 20px; line-height: normal; font-size-adjust: none; font-stretch: normal; color: #ffffff; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; text-decoration: none">BUTTON</span></a>

该站很早就出现了，提供的菜单有两列式(normal)和一列式(long)，但按钮只有一种。两列式菜单如下：

![][2]

**<a href="http://www.feedbutton.com/" target="_blank">点此进入按钮生成页面</a>**

<p align="center">
  <span style="color: #ff9900;">=====================================</span>
</p>

<span style="color: #ff0000;"><del datetime="2010-07-28T11:50:58+00:00">Buttonr</del></span>

[RSS相关][1]对该站做过[介绍][3]，截图如下

![][4]

同时提供不同的按钮式样供用户选择：

![][5]

该站同时可制作Bookmark按钮。

**<a href="http://buttonr.com/widget-rss.php" target="_blank">点此进入按钮生成页面</a>**

<p align="center">
  <span style="color: #ff9900;">=====================================</span>
</p>

[<img style="border: 0px none; width: 226px; height: 46px;" src="http://feedbuddy.net/img/logo.png" alt="FeedBuddy" />][6]

该站提供一大一小两个按钮，式样为：

![][7]

![][8]

点击按钮会弹出菜单，截图为：

![][9]

**<a href="http://feedbuddy.net/" target="_blank">点此进入按钮生成页面</a>**

<p align="center">
  <span style="color: #ff9900;">=====================================</span>
</p>

## **<span style="color: #ff0000;">页面式：</span>**

<img src="http://www.addthis.com/images/addthis-logo.gif" alt="" width="260" height="32" />

该站同时提供**Feed订阅按钮**和**Bookmark按钮**的定制。按钮形式多样，Feed按钮共有**六种样式**，例如

 ![][10]![][11]

而点击按钮后转入的<a href="http://www.addthis.com/bookmark.php" target="_blank">页面见此</a>。如果您是**注册用户**，您还可以订制该页面，去掉您不乐意显示的按钮；另外，您还能享受到[统计（trends）服务][12]，实时查知自己blog的**订阅趋势**和**网摘收录**情况。

**<a href="http://www.addthis.com/web-button-select.html" target="_blank">点此进入按钮生成页面</a>**

<p align="center">
  <span style="color: #ff9900;">=====================================</span>
</p>

<a href="http://www.addtofeed.com/" target="_blank"><img src="http://www.addtofeed.com/images/logoplus.gif" border="0" alt="" width="300" height="39" /></a>

该站服务很多，其一就是提供**Feed订阅按钮**和**Bookmark按钮**的定制，共有五种样式，给出一例：

![][13]

<a href="http://www.addtofeed.com/add.php?feed=http%3A%2F%2Fwww.addtofeed.com%2Fbuttons.php&title=Blogers%20and%20Webmaster.%20Promote%20your%20content%20and%20RSS%20Feed%20with%20these%20Social%20Network%20buttons" target="_blank">点击按钮后转入页面见此</a>。

**<a href="http://www.addtofeed.com/buttons.php" target="_blank">点此进入按钮生成页面</a>**

<p align="center">
  <span style="color: #ff9900;">=====================================</span>
</p>

![][14]

这个站严格来讲不算这个类别，因为它可以自动识别您默认的Feed阅读器，然后转到相应页面。按钮样式有7种，比较典型的是下面这个：

![][15]

**<a href="http://www.addtoany.com/webmasters/" target="_blank">点此进入按钮生成页面</a>**

<p align="center">
  <span style="color: #ff9900;">=====================================</span>
</p>

<span style="color: #c0c0c0;"><big><big>个</big></big>人认为还是不要选页面式的好，谁知道转入的页面在读者的网络环境下是否打的开呢，囧。</span>

 [1]: http://www.xuchi.name/blog/category/aboutrss/
 [2]: http://photo6.yupoo.com/20070523/193724_1031717747_qanvvltj.jpg
 [3]: http://www.xuchi.name/blog/2007/04/25/buttonr/
 [4]: http://photo8.yupoo.com/20070523/193723_1339527914_vpyucbxd.jpg
 [5]: http://photo6.yupoo.com/20070523/193724_259136989_jjlpqlrc.jpg
 [6]: http://feedbuddy.net/
 [7]: http://feedbuddy.net/img/feed-icon-40x28.png
 [8]: http://feedbuddy.net/img/feed-icon-25x14.png
 [9]: http://photo7.yupoo.com/20070523/194604_1608635845_qlsqedct.jpg
 [10]: http://s9.addthis.com/button1-rss.gif
 [11]: http://s9.addthis.com/button2-fd.png
 [12]: http://blog.addthis.com/?p=28
 [13]: http://www.addtofeed.com/images/icons/addtofeedmix.gif
 [14]: http://photo6.yupoo.com/20070523/201515_1863156645_cvipgstb.jpg
 [15]: http://www.addtoany.com/addfr-b.gif