---
title: '[翻译]如何让WP一分类下的文章不在Feed输出'
author: Chouj
type: post
date: 2008-06-10T16:11:49+00:00
url: /2008/06/11/translation-how-to-exclude-categories-from-main-feed/
views:
  - 5150
  - 5150
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970006
categories:
  - WordPress
  - 教程
  - 翻译
tags:
  - WordPress

---
<a rel="attachment wp-att-94" href="http://aboutrss.cn/2008/06/translation-how-to-exclude-categories-from-main-feed/wordpressfeed/"><img class="alignleft size-medium wp-image-94" title="wordpressfeed" src="http://pic.yupoo.com/xcchris/309805b2a084/qye3bzys.jpg" alt="wordpressfeed" width="100" height="100" /></a>原文：<a title="How to modify your WordPress RSS Feed - Kriesi" href="http://www.kriesi.at/archives/how-to-modify-your-wordpress-rss-feed" target="_blank">How to modify your WordPress RSS Feed</a>
  
作者：Kriesi
  
译者：<a href="http://www.xuchi.name/blog" target="_blank">抽筋儿</a>

WordPress自动生成的RSS Feed是默认输出每个目录分类下的每一篇日志的，但有时，**我们想唠叨下又不想打扰到关注有意义信息的订阅者**，怎么办呢？只需要把唠叨的日志归类到一个分类，然后在Feed里让该分类下日志不显示就OK咯！

如何实现呢？方法有二：

  1. 通过URL除掉分类下日志的Feed显示；
  2. 通过一个小函数除掉分类下日志的Feed显示。

<!--more-->

两种方法都很简单，**首先要知道分类的ID**。WP 2.5版以前，在控制面板“管理”->“分类”下面即可见分类ID；在WP 2.5之后，这些分类ID不直接显示出来了，但可以通过分类链接来判断：控制面板“管理”->“分类”下，各分类对应的链接即包含分类ID，如下图所示：

<a rel="attachment wp-att-95" href="http://aboutrss.cn/2008/06/translation-how-to-exclude-categories-from-main-feed/cat-id/"><img class="alignnone size-full wp-image-95" title="cat-id" src="http://pic.yupoo.com/xcchris/027365b2a0d4/nyg5bvdr.jpg" alt="cat-id" width="424" height="324" /></a>

所以，如果你想把ID为20的分类在Feed中除掉，就**在Feed地址后面加上&#8221;?cat=-20&#8243;(不要引号)**就好了。

例如：

  * 正常Feed：http://www.kriesi.at/feed
  * 调整后的Feed：http://www.kriesi.at/feed?cat=-20
  * 要是想灭掉更多目录：http://www.kriesi.at/feed?cat=-20&cat=-21&cat=-22

可惜，这种Feed地址挺不好看的，所以我们可以借助Feedburner之类的烧制服务来美化。但要注意的是，Feedburner所接纳的句法有点小差异，我们不能用“与”符号“＆”，需要改用逗号：

  * http://www.kriesi.at/feed?cat=-20,-21,-22

方法一介绍完咯，下面介绍方法二。不想用如上方法的话，可以看看用小函数滴方法。只要在functions.php里加入如下code就好：

<coolcode linenum="off">function my\_cat\_exclude($query) {
  
if ($query->is_feed) {
  
$query->set(&#8216;cat&#8217;,&#8217;-20,-21,-22&#8242;);
  
}
  
return $query;
  
}

add\_filter(&#8216;pre\_get\_posts&#8217;,&#8217;my\_cat_exclude&#8217;);</coolcode>

这样就可以在不调整feed url的情况下，在feed里除去选定分类下的日志了！真是简单整洁的方法，只是没法输出多个feed，没方法一灵活。

Hope this HELPFUL !

**Update**：fcicq在留言里提到，已经有这种WP插件的存在了哦，见以下：
  
<a title="Advanced category excluder wordpress plugin" href="http://wordpress.org/extend/plugins/advanced-category-excluder/" target="_blank">http://wordpress.org/extend/plugins/advanced-category-excluder/</a>