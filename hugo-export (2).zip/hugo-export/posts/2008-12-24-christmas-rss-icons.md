---
title: 增添节日氛围的RSS图标
author: Chouj
type: post
date: 2008-12-24T09:27:23+00:00
url: /2008/12/24/christmas-rss-icons/
views:
  - 1798
  - 1798
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970032
categories:
  - 标志
tags:
  - Christmas
  - Graph
  - Icon
  - RSS设计
  - Subscribe

---
<span style="color: #ff0000;"><strong>不说啥了，生蛋快乐！</strong></span>

  * <a href="http://xiao-xiao.yo2.cn/2008/12/santarssicon.html" target="_blank">Santa RSS icon</a>

<img src="http://pic.yupoo.com/xcchris/712956b573ab/1qin9k8n.jpg" alt="圣诞RSS图标" width="249" height="268" />

  * <a href="http://www.ajaxpath.com/christmas-rss-icons" target="_blank">Christmas Rss Icons</a>

<img src="http://pic.yupoo.com/xcchris/984026b57084/2yx79bz7.jpg" alt="" width="364" height="424" />

<!--more-->

  * [Drink RSS][1]（需要翻墙）

<img src="http://pic.yupoo.com/xcchris/699046b57086/ritmmwl3.jpg" alt="" width="468" height="378" />

<img src="http://pic.yupoo.com/xcchris/731036b57085/gtfvtfx4.jpg" alt="" width="468" height="378" />

 [1]: http://www.l2design.be/drinkrss/