---
title: 笑傲学府：大学排名引发的浩劫
author: Chouj
type: post
date: 2006-09-11T00:05:00+00:00
url: /2006/09/11/rank-of-universities/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post_11.html
views:
  - 1710
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969805
categories:
  - 我表达
tags:
  - 大学排名

---
<div>
  XX年间全国各国立大学排名
</div>

<div>
  少林大学
</div>

<div>
  武当大学
</div>

<div>
  昆仑大学
</div>

<div>
  峨嵋大学
</div>

<div>
  崆峒大学
</div>

<div>
  嵩山大学
</div>

<div>
  恒山大学
</div>

<div>
  华山大学
</div>

<div>
  泰山大学
</div>

<div>
  衡山大学
</div>

<div>
  XX年间全国各民办大学排名
</div>

<div>
  日月神教大学
</div>

<div>
  青城大学
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">少</span></strong>林、武当大学：生源滚滚、科研力量雄厚，方证校长、冲虚校长乃教育界泰山北斗，国内一流大学交椅非其莫属。只是身居高位，觊觎诽谤两所高校的不在少数。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">峨</span></strong>嵋、昆仑、崆峒大学：地处偏远，不懈与中原五岳学府为伍。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">恒</span></strong>山大学：女学生的勤学安分，可惜惨遭嵩山大学排挤，最后被迫由华山大学开除的三好学生令狐冲接任校长之位。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">嵩</span></strong>山大学：校长左冷禅看排名不爽，苦于五岳学府无法撼动其上诸所大学，但又眼馋教育界可怜的生源资源，一心想提升排名，分一杯羹，遂提出高校合并的政策，图谋拉拢中原各大学成立国立五岳大学，并一举谋得校长之位，以此与少林、武当大学形成鼎足之势。教育界浩劫因此而起。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">华</span></strong>山大学：校长夫妇合心治理，也算前途无量，岂料与校长千金岳灵珊研发出冲灵剑法的三好学生令狐冲触犯校规，又莫名的接受退休教师风清扬的指点，学会独孤九剑，加权平均分超过了校长岳不群，被开除出校，从此和差等生桃谷、蓝凤凰之类同流合污，并被民办大学日月神教校长之女任盈盈相中，此乃后话。学生林平之为安心学习，抛开杂念不惜自宫，研发出辟邪剑谱，在日后与青城大学的较量中占得上风，相传养猪养鸡要腌之，师从于此。校长岳不群为挽回丢掉的脸面，机缘巧合得到罕见实验器材，一面苦心钻研，一面假装同意大学合并，暗中发力。PS.校长发现自宫果然适合科研，遂毅然决然的为科学事业献身。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">泰</span></strong>山大学：不思进取，排名已无法触动其校长的神经，校长被嵩山大学拉拢，加入并校风波。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">衡</span></strong>山大学：人去楼空，校长莫大常年旅居在外，校内学生全无，破产指日可待。莫大校长高风傲骨，不同意并校。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">民</span></strong>办大学日月神教：异军突起，前校长任我行失踪期间虽一度分裂，教务主任向问天、副校长东方不败分道扬镳，好在瘦死的骆驼比马大，学子依然众多，纪律谨严。后原校长被三好学生令狐冲所救，图谋重掌大权，并看重令狐冲巨高的加权平均分，力邀其入校。只可惜令狐冲母校情结深重，虽与任我行校长千金任盈盈交好，但仍未转校。副校长东方不败贪恋年级主任杨连亭，不问校务，虽学历暴高，无奈被以上几人合力PK掉。
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">青</span></strong>城大学：当年为争得秘密实验仪器，种下祸端，校长余沧海也未能幸免，日后林平之研发出辟邪剑法，一举端了这个民办大学，从此日月神教大学少了一个敌人，得以一枝独秀。</p> 
  
  <p>
    <span style="color: #333333;"> <strong><span style="font-size:180%;">寝</span></strong>室里有人在看巨老版的笑傲江湖，围观者众，一起调侃时，有此一说，特完善之，本文原创，如有雷同纯属巧合。大学排名见《笑傲江湖》第30回 密议 方证之说辞。</span>
  </p>
</div>