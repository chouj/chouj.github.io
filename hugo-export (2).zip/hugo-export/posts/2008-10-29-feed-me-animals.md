---
title: 可爱动物RSS图标：Feed me!
author: Chouj
type: post
date: 2008-10-29T12:13:35+00:00
url: /2008/10/29/feed-me-animals/
views:
  - 7057
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969759
categories:
  - 标志
tags:
  - Download
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
<a title="点击看大图！" href="http://pic.yupoo.com/xcchris/3262266bc2d7/a0vaw40y.jpg" target="_blank"><img src="http://pic.yupoo.com/xcchris/3262266bc2d7/custom.jpg" alt="feed me animals rss icon set" width="468" height="703" /></a>

<a href="http://www.smashingmagazine.com/2008/10/28/feed-me-animals-a-free-rss-feed-icon-set/" target="_blank">SmashingMagazine</a>发布了一套动物版RSS图标，由[Mirjami Manninen][1]设计。

<!--more-->

作者：[Mirjami Manninen][1]
  
格式：png、psd、eps
  
大小：64、128、256
  
描述：蛋糕、狐狸、熊猫、斑马和大象形象的RSS feed图标，动物们都饿了，在大叫：“Feed me！(喂我!)”
  
说明：可免费用于私人和商业用途，包括软件、在线服务、模板和主题。禁止篡改、转卖、出租等等侵犯版权的行为。

[ **<a title="点此进入动物形象RSS图标下载页面" href="http://www.smashingmagazine.com/2008/10/28/feed-me-animals-a-free-rss-feed-icon-set/" target="_blank">点此进入下载页面</a>** ]

附送小猪形象RSS图片一枚 [via here][2]

<img src="http://pic.yupoo.com/xcchris/4639766bc2d5/ows3k83u.jpg" alt="小猪RSS图片" width="234" height="198" />

再附送RSS能量块一坨，藏有变形金刚的标志哦！ [via here][3]

 [1]: http://www.mirkku.com/
 [2]: http://www.design-freak.com/besplatnoe/swine-rss-icon/
 [3]: http://www.design-freak.com/design/dyou-feel-lucky-punk-rss-icon/