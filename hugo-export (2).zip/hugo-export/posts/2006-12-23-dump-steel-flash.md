---
title: '[转]废铁是怎样炼成的'
author: Chouj
type: post
date: 2006-12-23T09:55:00+00:00
url: /2006/12/23/dump-steel-flash/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/12/blog-post_23.html
views:
  - 1586
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969837
categories:
  - 我表达
tags:
  - flash

---
