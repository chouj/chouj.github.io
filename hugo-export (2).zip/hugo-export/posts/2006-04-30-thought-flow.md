---
title: 思绪之乱
author: Chouj
type: post
date: 2006-04-30T03:12:00+00:00
url: /2006/04/30/thought-flow/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/04/blog-post_8263.html
views:
  - 1534
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969773
categories:
  - 我记录
tags:
  - 生活

---
在家，思绪乱的一如既往。

先唾骂一下华工的校园网，在家里才发现公网的便利。<a href="http://newsvote.bbc.co.uk/chinese/simp/hi/china_news/default.stm" target="_blank">BBC中文网</a>、<a href="http://www.alemania-online.com/dw/0,1595,293,00.html" target="_blank">德国之声</a>、<a href="http://www.fawjournal.com/" target="_blank">纵横周刊</a>、<a href="http://www.msn.com/" target="_blank">msn</a>等等等等那些学校里全要代理才可以窥得的网站，家里全部打开的刷刷的。。。开<a href="http://www.mozilla.org.cn/" target="_blank">mozilla主站</a>下火狐插件真是爽快无比。。。想想在学校加代理加的真是苦不堪言。。。甚至还真有窥视非法站点的负罪之感。。。可是找刺激也不是这样找的啊！

最近才发现在ie下偶blog的主要文字部分居然在左边侧栏的下面，尝试整顿正常，但是失败了，于是乎推荐大家用firefox浏览，在firefox下不会出现酱紫的问题，要不然我也不会过了这么长时间才发现。

<a href="http://www.chinaui.com/news/detail/20060427181601.html" target="_blank">中国商业插画培训班开始招生</a>

培训目标：通过专业理论知识学习和实用技法训练，使学员掌握作为“职业插画师”基本职业常识、理论以及概念；认识插画创意行为的基本要素；掌握插画创作的基本技能。最终具备商业数码插画创作的工作能力。

证书：学员在规定的时间内学完教学计划规定的全部课程，达到要求，可获得由中国插画网(插画中国论坛)颁发的商业数码插画培训结业证书。

看好插画师这个行业，同时也有点小心动，只是不知道为期一个月的培训后，学员们出来都能达到一个什么样的水平。。。

最后转几篇不错的文章，由简到难。

<a href="http://www.blogcn.com/user43/xieshoujun/blog/32025424.html##" target="_blank">已然大三下</a> 写大三人心境的，颇为真切。

<a class="post_title" rel="follow" href="http://manonfire.yculblog.com/post.1251602.html">是什么冷却了我对远方的遐想</a> 将赴远方的一位友人，思考自己对远方失去好奇遐想的心路里程。兴许是长大了的我们，无意识得把那一份好奇埋藏的过为深远了，其实并未失去。。。

<a href="http://www.nanfangdaily.com.cn/zm/20060420/wh/ydws/200604200119.asp" target="_blank">古典今情中的施琅</a> 很推荐的一篇，分析施琅在历史中的定位，文笔大气，看完了有一种“会当凌绝顶，一览众山小”的感觉，拜<a href="http://manonfire.yculblog.com/" target="_blank">manonfire</a>推荐给我的，谢。