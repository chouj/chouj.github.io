---
title: Blogsticker新增数款贴纸
author: Chouj
type: post
date: 2007-05-04T10:11:33+00:00
url: /2007/05/04/blogsticker/
views:
  - 4314
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969679
categories:
  - 我表达
tags:
  - Blogsticker
  - 贴纸

---
<big><big><img src="http://photo6.yupoo.com/20070504/175825_2095251123_ivpiqbsm.jpg" alt="blogsticker" /></big></big>

<big><big>看</big></big>到本站右上方斜挂出的贴纸了吗？如果感兴趣的话，一定不要错过这个站——**<a href="http://www.blogsticker.net" target="_blank">blogsticker.net</a>**。最近该站又推出了数款stickers，特挑选几款推荐下。

1、**捍衛樂生** 稍微關注下臺灣部落客圈的朋友都應該知道樂生<a href="http://savelosheng.googlepages.com/home" target="_blank">療養院事件</a>，正義的臺灣部落客選擇在部落客上添加這兩款掛飾以示支持，該掛飾于5月1日剛剛上線。

![blogsticker-lo-sheng 樂生][1]![blogsticker-lo-sheng 樂生][2]

2、<a href="http://www.douban.com/subject/1837856/" target="_blank"><strong>群英荟萃 / 变种群英 / 英雄 / Heroes</strong></a> 这部美国剧集，最近风头正盛，有盖过越狱之势，我也相当喜欢，特别推荐！

![blogsticker 群英荟萃 / 变种群英 / 英雄 / Heroes][3]

3、**2008北京奥运** 专为2008 Beijing Olympic量身打造！

![blogsticker 2008 Beijing Olympic 北京奥运][4]

4、<a href="http://www.operachina.com/" target="_blank"><strong>Opera</strong></a> 一款操作操作系统，而下面的贴图，就是为Opera死忠用户打造的，我还是忠于我的火狐，哈哈。

![blogsticker Opera][5]

5、**AC milan / AC米兰** 红黑军团的粉丝加Blogger有福了，在blog上挂出这款球队的旗帜吧！

![blogsticker AC milan / AC米兰][6]

6、**Manchester United / 曼联** 红魔曼联，也是拥有大批死忠粉丝的球队啊，最近败在了AC脚下，止步欧冠半决赛。挂出这款旗帜来表示你的曼联的热爱吧！

![blogsticker Manchester United / 曼联][7]

<big><big>4</big></big>月份维吉尼亚理工大学枪击事件过后，<a href="http://www.blogsticker.net" target="_blank">blogsticker.net</a>曾推出一款贴纸，以表示对死难者的哀悼。

![blogsticker virginia-tech-massacre][8]

<big><big>如</big></big>若您有所心动，想在自己的blog上挂出贴纸的话，步骤是：<font color="#3366ff">在该站注册；在blog上发布blogsticker提供的代码以认领blog为您的blog；在blog的head属性内，添加代码以调用js；选择stickers，每个blog可随机显示5款stickers</font>。然后就可以肆意悬挂stickers啦！目前该站拥有208款stickers，涵盖国别、游戏、音乐、影视、科技、体育、名牌几个大类，其下分类更细，绝对能找到您喜欢的sticker！

Technorati Tags: <a href="http://technorati.com/tag/blogsticker" class="performancingtags" rel="tag">blogsticker</a>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://www.blogsticker.net/ui/stickers/l/save-lo-sheng.gif
 [2]: http://www.blogsticker.net/ui/stickers/l/lo-sheng-sanatorium.gif
 [3]: http://www.blogsticker.net/ui/stickers/l/heroes.gif
 [4]: http://www.blogsticker.net/ui/stickers/l/olympics-beijing-2008.gif
 [5]: http://www.blogsticker.net/ui/stickers/l/opera.gif
 [6]: http://www.blogsticker.net/ui/stickers/l/ac-milan.gif
 [7]: http://www.blogsticker.net/ui/stickers/l/manchester-united.gif
 [8]: http://www.blogsticker.net/ui/stickers/l/virginia-tech-massacre.gif