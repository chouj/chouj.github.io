---
title: Targets Locked
author: Chouj
type: post
date: 2007-03-12T08:44:00+00:00
url: /2007/03/12/targets-locked/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/targets-locked.html
views:
  - 1876
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969860
categories:
  - 我记录
tags:
  - 广州
  - 生活
  - 网络

---
<span style="font-weight: bold;">借由</span>

  * 和菜头同学的<a href="http://www.douban.com/group/topic/1026747/" target="_blank">广州买碟地点一览</a>
  * <a href="http://news.xinhuanet.com/book/2005-04/27/content_2882833.htm" target="_blank">广州特色书店地图</a>
  * [学而优追随者联合会][1]
  * <a href="http://www.douban.com/group/borgeslibreria/" target="_blank">博尔赫斯书店小组</a>
  * <a href="http://www.borgeslibreria.com/shumu/zn.htm" target="_blank">如何找到博尔赫斯书店？</a>
  * <a href="http://www.borgeslibreria.com/shumu/zn.htm" target="_blank"></a><a href="http://www.douban.com/group/GZshow/" target="_blank">放牛班的春天广州音乐会小组</a>
  * <a href="http://blog.sina.com.cn/u/1274782263" target="_blank">放牛班的春天广州音乐会博客</a>

<span style="font-weight: bold;">锁定</span>

  * <a href="http://www.xooyo.com/" target="_blank">学而优书店</a> 海珠区新港西路93号 面向中大西门左手边

  * <a href="http://http//www.borgeslibreria.com" target="_blank">博尔赫斯书店</a> 广州市海珠区怡乐路95号二层

  * <span>法国圣马可童生合唱团“放牛班的春天”广州音乐会售票总部 广州东风东路艺苑大厦 东峻广场旁边</span>

<span style="font-weight: bold;">有互联网真好！</span>

<div style="text-align: center;">
  <span><a href="http://blog.sina.com.cn/main/html/showpic.html#url=http://album.sina.com.cn/pic/4bfba23702000n8b" target="_blank"><span style="font-size: 12px;"><img src="http://album.sina.com.cn/pic/4bfba23702000n8b" border="0" alt="" /></span></a></p> 
  
  <p>
    </span></div>

 [1]: http://www.douban.com/group/xooyo/