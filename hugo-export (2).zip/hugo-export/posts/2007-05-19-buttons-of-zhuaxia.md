---
title: 抓虾：免费订阅按钮大放送
author: Chouj
type: post
date: 2007-05-18T17:31:46+00:00
url: /2007/05/19/buttons-of-zhuaxia/
views:
  - 1875
  - 1875
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969954
categories:
  - 工具
  - 新闻
  - 标志
tags:
  - button
  - Graph
  - Zhuaxia

---
<img src="http://www.zhuaxia.com/images/welcome_logo.gif" title="抓虾-aboutrss" alt="抓虾-aboutrss" height="63" width="290" />

<big><big><a href="http://www.zhuaxia.com" target="_blank">抓</a></big><a href="http://www.zhuaxia.com" target="_blank"></a></big><a href="http://www.zhuaxia.com" target="_blank">虾</a>日前推出了<a href="http://www.zhuaxia.com/help_sub_1.php" target="_blank"><strong>博客订阅按钮大放送</strong></a>服务 ，在抓虾首页的左侧即有其悬挂的服务广告：

<img src="http://www.zhuaxia.com/images/dafangsong_index.jpg" title="博客按钮大放送" alt="博客按钮大放送" height="221" width="150" />

<big><big>在</big></big>该服务页面中，抓虾一改绿色清新的界面，选择了热情似火的红色，可见其推广力度。

<img src="http://www.zhuaxia.com/images/subscribe/subscribe_01_1.gif" height="233" width="439" />

<big><big>服</big></big>务中，抓虾保留了原有**经典**的订阅按钮样式的同时，增加了4个类别的订阅按钮，分别为**卡通**、**星座**、**性感**、**清爽**，各有特色。按钮的**定制过程**简单：选择自己喜欢的按钮图案；填入自己的blog地址，点击生成代码，将代码放进blog的合适位置即可。我感觉，抓虾此举大有普及RSS订阅应用的意味在其中，想以个性鲜明的图片换取网友对RSS订阅的学习动力，实属可贵，赞个！

**<a href="http://www.zhuaxia.com/help_sub_1.php" target="_blank"><big>点此进入抓虾订阅按钮生成页面</big></a>**

<font color="#c0c0c0"><big><big>这</big></big>个消息发布的晚了点儿，而且我还不是从抓虾看到的，而是从<a href="http://520blogger.blogspot.com/2007/05/blog-post_18.html" target="_blank">这里</a>，囧。谁让我不是抓虾用户呢，我还是对我的Google Reader更痴情～～XD，但是如果你喜欢这里的话，也可以点下面的按钮用抓虾订阅我哦！:)</font>

[
  
<img src="http://www.zhuaxia.com/images/subscribe_16.gif" alt="订阅到抓虾" border="0" />][1]

 [1]: http://www.zhuaxia.com/add_channel.php?sourceid=102&url=http%3A%2F%2Ffeeds.feedburner.com%2Faboutrss