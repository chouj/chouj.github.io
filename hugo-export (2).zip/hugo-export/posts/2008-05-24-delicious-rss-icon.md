---
title: 秀色可餐的RSS标志
author: Chouj
type: post
date: 2008-05-24T08:02:44+00:00
url: /2008/05/24/delicious-rss-icon/
views:
  - 1760
  - 1760
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970004
categories:
  - 标志
tags:
  - Download
  - RSS设计

---
<img src="http://pic.yupoo.com/xcchris/4897759b3e47/pzs06bgw.jpg" alt="by Design Freak" width="486" height="364" />

看到一些异常精致的RSS标志，不忍独享，立马发布出来以飨群众。

<!--more-->

<img src="http://pic.yupoo.com/xcchris/9573659b33ff/y2umqw3i.jpg" alt="by Design Freak" width="483" height="193" />

<img src="http://pic.yupoo.com/xcchris/5580559b33ff/940atrgy.jpg" alt="by Design Freak" width="480" height="197" />

<img src="http://pic.yupoo.com/xcchris/0705759b33ff/bxggxy55.jpg" alt="by Design Freak" width="473" height="189" />

<img src="http://pic.yupoo.com/xcchris/3790759b3400/pykub2oj.jpg" alt="by Design Freak" width="473" height="189" />

<img src="http://pic.yupoo.com/xcchris/0700059b3400/5qcaa8vi.jpg" alt="by Design Freak" width="475" height="190" />

<img src="http://pic.yupoo.com/xcchris/3538359b3850/t5vfmi5j.jpg" alt="by Design Freak" width="473" height="189" />

<img src="http://pic.yupoo.com/xcchris/8989659b3850/igfky580.jpg" alt="by Design Freak" width="471" height="188" />

<img src="http://pic.yupoo.com/xcchris/4834559b3850/8057tdgi.jpg" alt="by Design Freak" width="473" height="189" />

<img src="http://pic.yupoo.com/xcchris/1670859b3851/7cq40ylp.jpg" alt="by Design Freak" width="468" height="187" />

<img src="http://pic.yupoo.com/xcchris/6075159b3850/eflz6mat.jpg" alt="by Design Freak" width="470" height="188" />

<img src="http://pic.yupoo.com/xcchris/4158159b3b1d/bzwgqrer.jpg" alt="by Design Freak" width="466" height="349" />

<img src="http://pic.yupoo.com/xcchris/3803159b3b1d/3s0aw7r9.jpg" alt="by Design Freak" width="468" height="351" />

<img src="http://pic.yupoo.com/xcchris/5753859b3b1d/7poznip1.jpg" alt="by Design Freak" width="476" height="357" />

<img src="http://pic.yupoo.com/xcchris/0148159b3b1c/tf70waoj.jpg" alt="by Design Freak" width="470" height="352" />

![by Design Freak][1]

via  <a title="Iconos RSS para tus feeds" href="http://www.inkilino.com/2008/05/22/iconos-rss-para-tus-feeds/" target="_blank">Iconos RSS para tus feeds</a>

![RSS icons together][2]

via  <a title="Iconos RSS para tu feed" href="http://www.inkilino.com/2008/04/08/iconos-rss-para-tu-feed/" target="_blank">Iconos RSS para tu feed</a> **该页面提供一包含116个RSS图标的rar包下载**

<a class="abp-objtab-03450741770099769 visible ontop" style="left: 500px ! important; top: 0px ! important;" href="http://aboutrss.cn/wp-content/uploads/2008/05/Rss.swf"></a>

这是个flash，点击的话，会导向作者blog的feed地址

via <a href="http://www.design-freak.com/2008/02/13/musornik-s-sjurprizom/" target="_blank">Мусорник с сюрпризом</a>

 [1]: http://pic.yupoo.com/xcchris/3356759b3b1c/brj4l8u1.jpg
 [2]: http://pic.yupoo.com/xcchris/9086059b3e48/86hnz5xr.jpg