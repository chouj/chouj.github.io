---
title: Diablo 符文RSS FEED图标
author: Chouj
type: post
date: 2008-08-13T02:31:09+00:00
url: /2008/08/13/diablo-rune-rss-feed-icon/
views:
  - 1609
  - 1609
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970016
categories:
  - 标志
tags:
  - Download
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
 <img src="http://aboutrss.cn/wp-content/uploads/2008/08/rune-rss.gif" alt="符文feed by Chris@aboutrss.cn" width="28" height="28" />我给zEUS.和DogorGod.的新主题——<a title="大菠萝3 Diablo III WordPress 主题公开测试" href="http://zeuscn.net/archives/2008/08/12/beta-diablo-iii-theme/" target="_blank">Diablo III</a>——PS的**大菠萝符文型RSS Feed标志**，200×200pix，红黄蓝三色png，技术粗糙，欢迎拍砖：

![符文feed by Chris@aboutrss.cn][1]

[ [RUNE RSS Feed download][2] | <a title="大菠萝3 Diablo III WordPress 主题公开测试" href="http://zeuscn.net/archives/2008/08/12/beta-diablo-iii-theme/" target="_blank">Diablo III WordPress Theme</a> ]

 [1]: http://fc04.deviantart.com/fs32/i/2008/225/1/5/RUNE_RSS_Feed_ICON_by_xcchris.png
 [2]: http://aboutrss.cn/wp-content/uploads/2008/08/rune-rss-feed-icons.rar "符文RSS FEED ICON点此下载"