---
title: 珍爱生命，远离网络？？
author: Chouj
type: post
date: 2007-05-15T12:01:00+00:00
url: /2007/05/15/stay-away-from-blog/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/05/blog-post_15.html
views:
  - 2893
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969884
categories:
  - 我表达
tags:
  - blog
  - 生活
  - 网络

---
没有单向收费，我就没有取消来电显示的冲动

没有能整合MSN的[PSI][1]，我就没有挂Gtalk的冲动

没有[译言][2]，我就没有翻译的冲动

没有bbs，我就没有发帖赚积分的冲动

没有blog，我就没有写点儿什么的冲动

没有GFW和Blogspot的纠结，我就没有独立blogging的冲动

没有[Twitter][3]，我就没有随时随地找点儿茬发布的冲动

没有[和菜头][4]和[Zola][5]，我就没有想整个BlackBerry玩玩的冲动

到底是<span style="font-weight: bold;">没有冲动就没有魔鬼</span>？

还是<span style="font-weight: bold;">没有网络就没有生活</span>？

 [1]: http://www.newchen.cn/2006/09/psiicqmsnqqyahoo-all-in-gtalk.html
 [2]: http://www.yeeyan.com/
 [3]: http://twitter.com/xcchris
 [4]: http://www.hecaitou.com/?p=1781
 [5]: http://zola.bullog.cn/blogs/zola/Default.aspx