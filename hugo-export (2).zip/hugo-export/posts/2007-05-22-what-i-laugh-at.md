---
title: 看到这个，我笑了
author: Chouj
type: post
date: 2007-05-22T15:27:00+00:00
url: /2007/05/22/what-i-laugh-at/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/05/blog-post_22.html
views:
  - 1925
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969886
categories:
  - 我记录
tags:
  - 指导工作

---
> ……
  
> 第二，指导教师应以对学生高度负责的态度写好评语。学生读了三年书，花了大量心血写出了数千字的处女作，不能三言两语就把学生“应付过去”了。应给学生的科研写作练习予以中肯的评价，使学生知道自己的优点与不足，为其今后的努力指明方向，这也是学生在校期间接受的最后一次学习指导。它将给学生留下终生难忘的教益。
  
> ……

指导工作都“人性化”到这地步了，世界一流大学不远矣。见于[此页][1]附件3

 [1]: http://219.140.59.210/ReadNews.asp?NewsID=726