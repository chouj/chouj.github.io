---
title: 倒戈
author: Chouj
type: post
date: 2007-03-26T02:01:00+00:00
url: /2007/03/26/change-sides/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/blog-post_26.html
views:
  - 1982
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969867
categories:
  - 我表达
tags:
  - blog
  - feedsky

---
<span style="text-decoration: line-through;"><span style="color: #ff0000;">即日起，</span><span style="font-weight: bold;"><span style="color: #ff0000;">放弃</span><a href="http://www.feedksy.com/" target="_blank">feedsky</a><span style="color: #ff0000;">烧制的</span><a href="http://feed.feedsky.com/chrischou" target="_blank">feed</a></span><span style="color: #ff0000;">，进入30天feed删除日程。开始启用</span><a href="http://www.feedburner.com/" target="_blank">feedburner</a><span style="color: #ff0000;">提供的服务，新Feed地址，即转向地址为： </span><a href="http://feeds.feedburner.com/chrischou" target="_blank">http://feeds.feedburner.com/chrischou</a> <span style="color: #ff0000;">。<a href="http://allofrss.blogspot.com/" target="_blank">RSS相关</a>的feed地址也开始转向<a href="http://feeds.feedburner.com/aboutrss" target="_blank">http://feeds.feedburner.com/aboutrss</a></span><span style="font-weight: bold; color: #ff0000;">，请重新订阅</span><span style="color: #ff0000;">。</span></span>

“<span style="font-size:180%;"><span style="font-weight: bold;">怀</span></span>疑GFW在rss上开了盾”，朋友的一句话，更是加重了我的怀疑。

<span style="font-size:180%;"><span style="font-weight: bold;">B</span></span>logspot再度被封以后，G Reader和抓虾都仅仅在输出书签的“昨日关注”，没有新日志；打开<a href="http://www.feedsky.com/" target="_blank">feedsky</a>的<a href="http://feed.feedsky.com/chrischou" target="_blank">feed</a>，也没有新日志；再打开<a href="http://xcchris.blogspot.com/feeds/posts/default" target="_blank">原始供稿</a>，却是有最新日志的。疑惑啊疑惑。再比照其他blogspot，feedsky提供的feed也没有输出新日志。结论只可能是，<a style="font-weight: bold;" href="http://www.feedsky.com/" target="_blank">feedsky</a><span style="font-weight: bold;">的rss输出在某种程度上被蔽掉了</span>,而不是订阅工具的问题。

<img src="http://www.feedsky.com/images/feedsky_logo.gif" border="0" alt="" />

<span style="font-size:180%;"><span style="font-weight: bold;">实</span></span>在抱歉，在blogspot的国度里，我要抛弃<a href="http://www.feedsky.com/" target="_blank">feedsky</a>了。我还记得当初，毅然选择了国内的这款服务作为主打，因为那亲切的界面和便捷的服务，也因为中文的Feed烧制服务更需要国人的支持。我也记得现在，依然对<a href="http://www.feedsky.com/" target="_blank">feedsky</a>倾心不已，关注<a href="http://beta.feedsky.com/fn_class.html" target="_blank">博客圈</a>的试探，关注<a href="http://blogs.feedsky.com/?p=125" target="_blank">话题广告</a>的开拓。在如此情形之下，我更希望是<a href="http://www.feedsky.com/" target="_blank">feedsky</a>单方面出了差错，而不是和GFW有半点瓜葛。

<span style="font-size:180%;"><span style="font-weight: bold;">无</span></span>论<a href="http://www.feedsky.com/" target="_blank">feedsky</a>是遭GFW毒手还是事先屈服于GFW淫威，也无论<a href="http://blogs.feedsky.com/" target="_blank">805大字报</a>是否有所解释，我都更希望能在<a href="http://www.lvxinxin.com/" target="_blank">吕欣欣的日志</a>里看到这么一句话：

<span style="font-weight: bold;">操他妈的GFW！</span>