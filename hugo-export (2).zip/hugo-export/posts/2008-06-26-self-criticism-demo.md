---
title: 旷工检查范本
author: Chouj
type: post
date: 2008-06-26T05:22:05+00:00
url: /2008/06/26/self-criticism-demo/
views:
  - 7158
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969898
categories:
  - 我表达
  - 我记录
tags:
  - 旷工
  - 检查

---
[<img class="alignnone size-full wp-image-281" title="旷工后无敌愧疚的猫猫～它装死呢～～" src="http://www.xuchi.name/blog/wp-content/uploads/2008/06/da0900f3e4cb0a5c352acc07.jpg" alt="旷工后无敌愧疚的猫猫～它装死呢～～" width="500" height="375" />][1]

霉男甲乙丙丁：

你们俩离开××室一天,为什么不请假?
  
每人写一份检查,给我.
  
下次再这样,将在Group meeting 上念检查.

<p style="text-align: center;">
  <strong>检   查</strong>
</p>

尊敬的×X×：

由于我无视组织纪律，外出活动未事先请假，特愧疚得向您检讨。

事情经过如下：单位×××组织职工××及×××××、×××和××××于×月×日参观××，学习××××发展历程，我和××同志报名参加了该活动，但出发前，仅仅告诉了×××，没有知会您，造成在您不知情的情况下我们私自离开×××整整一个白天。

事实证明我们不请假而擅自离岗是极端错误和不负责任的行为，我们错误得忽视了我所、我×××的规章制度，乐观得认为不会带来恶劣影响，虽说是参加组织活动，但已经偏离了组织成员的行为准则，且造成老师不必要的担心。在此，我承诺绝不允许这种散漫的行径再次在自己身上发生，坚决遵守纪律章程，听从××的指挥调度。

<p style="text-align: right;">
  霉男甲<br /> 20××.×.××
</p>

 [1]: http://www.xuchi.name/blog/wp-content/uploads/2008/06/da0900f3e4cb0a5c352acc07.jpg "点我点我～"