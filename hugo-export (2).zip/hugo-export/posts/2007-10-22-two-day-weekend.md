---
title: 双休
author: Chouj
type: post
date: 2007-10-22T05:00:00+00:00
url: /2007/10/22/two-day-weekend/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/10/blog-post_22.html
views:
  - 1783
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969888
categories:
  - 我记录
tags:
  - 广州
  - 生活

---
双休上课有个好处：休息眼睛啊，尽量坐后面，盯着远远的黑板，相比天天盯着显示屏而言，是种享受，具有保护视力的功效～

前天早上6：35起来赶bus，欲以晨练身份冲进黄花岗公园被拦～
  
昨天早上6：45起来赶bus，踢毽子踢到8：40～
  
前天中午，在科技图书馆看杂志看到迟到～
  
昨天中午，踢坏两只毽子，转而奋战拱猪～
  
前天回来，篮球打到黑～
  
昨天回来，足球踢到黑～

某银语录：

足球场上，球被我断掉，嚎：
  
日啊，你怎么总是东升西落？

球场上，某带球：
  
某曰：我顶你个肺～我穿你个裆～

某：本科有那么多作业，研究生还有那么多作业！
  
我：不就一门有点儿作业嘛
  
某：日啊，你怎么总是东升西落？
  
甲：老说这句什么意思啊？
  
某：我只是想说头俩字啦，一想到都研究生了要有点儿修养，就补充点儿东西在后面撒～