---
title: '[翻译]为什么我的FeedBurner订阅数会上下振荡呢？'
author: Chouj
type: post
date: 2007-08-17T16:54:16+00:00
url: /2007/08/18/translation-why-feedburner-subscriber-count-fluctuate/
views:
  - 4936
  - 4936
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969973
categories:
  - 知识
  - 翻译
tags:
  - Feedburner

---
原文：<a href="http://www.problogger.net/archives/2007/08/16/why-does-my-feedburner-subscriber-count-fluctuate/" target="_blank">Why does my Feedburner Subscriber Count Fluctuate?</a>——08.16 <a href="http://www.problogger.net/archives/2007/08/16/why-does-my-feedburner-subscriber-count-fluctuate/" target="_blank"></a>

作者：<a href="http://www.problogger.net/archives/2005/01/06/about-darren/" title="Visit Darren Rowse's website" rel="external">Darren Rowse</a>

翻译：<a href="http://www.xuchi.name/blog" target="_blank">抽筋儿</a><span style="color: #cc0000"></span>

<img src="http://photo8.yupoo.com/20070817/214130_343783371_oeqqxalx.jpg" alt="Feedburner Subscribe number" align="left" />

  * 为什么我的订阅量老蹦上蹦下的呢？
  * Feedburner的订阅量统计告诉我的订阅数增减确实是由读者订阅造成的吗？
  * 我注意到一天当中我的订阅数都会有上下波动，为什么？
  * 每周末我的订阅数都会下降，怎么回事啊？

在上一周，如上这些或类似的关于FeedBurner订阅数统计的问题，我总共被问到了七次！每次我都要找个答案应付下提问的朋友，我一度以为我知道真相，可事实并不是这样。

所以今天一早，当我又有两次从邮箱里看到类似的问题，我觉得我该直接去找Feedburner的智慧之源——主管Feedburner信息发布服务的副主席Rick Klau先生——来问个清楚，他也许会给出订阅数波动的官方解释。

## <span style="color: #cc0000">Rick是这么回答我的：</span>

当我们公布一个feed的订阅量时，它代表着一个总人数，当天所有请求获得feed信息的个体的总数。

绝大部分订阅者都来自以下两个方面：

  1. 使用离线单机阅读器的订阅者
  2. 使用浏览器端的线上阅读器的订阅者

就离线阅读来说，订阅者的阅读器基于他们自己的电脑，且一天中重复地抓取feed中的信息。我们可以思考一下这类feed信息请求的特性，区分一下同一个 人的多次请求（指规律性的定期探测，固定的ip地址和统一的客户端环境）和不同请求（指与之前所述一处或多处不同）间的差别。

就线上阅读来说，比如My Yahoo, Google Reader, Bloglines, Pageflakes, 等等，这些服务也是全天都在读取feed信息，但却是多用户同时进行的。几乎所有的这些服务都会向我们报告他们有多少用户订阅了某个feed。到了一天末 尾，我们结算有多少订阅数来自离线阅读器，然后把这个数目加到来自线上阅读器的订阅数上，这样，最后的数目就是我们对外发布的feed订阅总数。（我抛开 了一些细节，下面是更细致的解答）

而订阅数的波动几乎所有都是因为使用离线阅读器软件的订阅者在统计的那天没有打开电脑，或者没有启动他们的阅读器。如果他们的阅读器并不要求读取feed 的信息，那么我们就不知道它们的存在，结果就是并不把这些算在订阅数之内。（Darren注，这就是为什么在周末那个数字会掉下来，因为周末还开阅读器的人少嘛。）

还有个解释就是，当站点的流量陡变之时，至少当一部分访客使用的浏览器版本过低时，我们无法区分到底是浏览器访问feed还是基于浏览器的feed阅读器在读取feed。关于这种情况的细致解释可以看<a href="http://nottoogeeky.com/words/ntg/feedburner_rick_klau_interview_part_2/" target="_blank">这里</a>——从我对关于站点流量大幅波动问题的解答中可以找到有用的信息。

最后，为了全面把握订阅量统计数目的各个组成部分，去年我们<a href="http://blogs.feedburner.com/feedburner/archives/2006/09/a_peek_inside_techcrunchs_100k.php" target="_blank">在TechCrunch上做了一个研究</a>。 这项研究应该能够深层次的说明订阅量是如何计算（且为什么会波动）的。同时，这项研究也着重评论了下“订阅实效量”（译者注：原文此处为Reach，意为真正通过feed在内容上进行了阅读动作或点击动作的数量，译者不才，权且这么丑陋的译一下）。订阅量可能包括了曾对你的内容感兴趣但并没有进行实际阅读 的订阅者数目，而“订阅实效量”与此不同，它统计的对象则是在阅读器中实际被阅读的条目数和将流量带回到发布者的站点的点击量。所以，订阅量单纯的代表所 有对feed内容感兴趣的读者的数目，而订阅实效量则更准确的勾画出了订阅者与feed内容交互的程度。

<small><span style="color: #cc0000">【译者按】</span> 博客圈内的总统博客和前博客都有解释订阅数变化的文章，作为本文的补充链接，值得一看：</small>
  
<small><a href="http://jiangzhanyong.com/2007/07/feedburner-dancing-429.html" title="Permanent Link to Feedburner 跳舞">Feedburner 跳舞</a>——总而言之，统而言之<br /> <a href="http://www.qianblogger.com/2007/06/25/feedburner-tongji/" title="Permanent Link: 理解Feedburner订阅统计的变化">理解Feedburner订阅统计的变化</a>——前～博客</small>