---
title: 音乐一隅 2006世界杯专题
author: Chouj
type: post
date: 2006-05-20T03:53:00+00:00
url: /2006/05/20/music-corner-4/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/05/2006.html
views:
  - 1923
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969777
categories:
  - 我表达
tags:
  - 音乐

---
<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://happy.hustonline.net/music/CDImages/2249.jpg" border="0" alt="" />

<span style="color: #333333;"><span style="color: #666666;">与世界一起感动 共享荣耀时刻<br /> 和全球一起撼动 共创世纪狂潮</span></span>

3首2006世足赛独家官方指定新曲+33首排行金曲+1首亚洲独占官方指定中文曲 共37首圣杯之歌打造史上最强音乐盛典！

独家收录
  
*美声男伶、唐妮布蕾斯顿梦幻合唱2006世足赛全球唯一官方指定曲&#8221;The Time Of Our Lives&#8221;，点燃足球超级战火！
  
*时代杂志赞誉“欧洲英雄”赫伯特演唱东道主德国主题曲&#8221;Celebrate The Day&#8221;，见证世纪足球风云！
  
*“拉丁女神”夏奇拉狂野变身，全球排行冠军曲&#8221;Hips Don&#8217;t Lie&#8221;足球混音版盛大登场！

亚洲版‘友情有义’加场收录
  
*全新精彩打造柯有纶、黄义达PK压轴合唱、台湾区唯一官方中文曲&#8221;荣耀的一天&#8221;

双CD单片特别价，领先全球发行！

全世界都在看，四年一度的世界杯足球赛打从1930年在乌拉圭开战来，迄今开踢16回的赛势每每造成无可比拟的全球狂热，继2002年首度以日、韩双国联合举办，造成213国、28亿以上的电视观看人次和270万人涌入现场的空前盛况后，今年转交睽违32年的德国主办，6月9日正式在幕尼黑、柏林等德国12城市点燃战火，32组超级强队争取足球最高荣誉的圣杯，绝对是今年全球最大盛事！如同今年世足赛的宗旨“友好相聚胜利时刻”〈A time to make friends〉，主办单位也设计三个代表欢乐的表情符号组成的形象标志，加上吉祥物&#8211;Goleo狮子及和它形影不离的说话足球Pille，2006年世足赛早已轰动全地球！

同样让世人高度期待的是唯一收录四年一度主题曲的2006世足赛全球唯一官方指定专辑《圣杯之歌》。不管是98年引爆拉丁狂潮的瑞奇马汀早已变成足球代名词的&#8221;The Cup Of Life/La Copa De La Vida&#8221;、走红欧陆的超级天后安娜贾西亚〈Anastacia〉演唱2002年主题曲&#8221;Boom&#8221;，都和足球一样席卷全球，成为球迷难忘的回忆。今年主办单位则再度出招，找来威震乐坛打造西城男孩、美声男伶瑞典超级制作人Jorgen Elofsson写歌，力邀两张英美冠军专辑创下全球千万销售的当红天团&#8211;美声男伶和“葛莱美天后”唐妮布蕾斯顿合唱2006全球唯一官方指定曲 &#8220;The Time Of Our Lives&#8221;〈荣耀时刻〉，他们将一同于世足赛开幕当日比赛之前及决赛时现场献唱，天王天后荡气回肠演唱描绘比赛带给人心无限悸动的主题曲揉合英文、西班牙文，气势磅礴交帜足球运动的喜悦泪水与光荣时刻，铁定是今年流行乐坛最受瞩目的年度演出；另外，东道主德国队的主题曲&#8221;Celebrate The Day&#8221;〈荣耀的一天〉则由被时代杂志赞誉为“欧洲英雄”的德国超级天王赫伯特〈Herbert Gronemeyer〉演唱、“拉丁女神”夏奇拉则推出火热全球排行冠军曲&#8221;Hips Don&#8217;t Lie&#8221;〈电动马达〉特定为本届世足赛所演唱的变身混音版本，都独家收录在专辑里。

除了三首全新打造世足赛新歌外，《圣杯之歌》还一口气汇集当今歌坛数位超级巨星，阵容超越历届，包括席琳狄翁、惠妮休斯顿、玛丽亚凯莉、芭芭拉史翠珊、洛史都华、艾尔顿强、乔治麦可、野人花园、西城男孩、瑞奇马汀、蒂朵、凯莉克莱森等30首叱吒流行歌坛排行经典，而台湾版本则加收王力宏“盖世英雄”、杨丞琳“庆祝”、柯有纶“Wake Up(拼了)”三首国语作品，此外，柯有纶和黄义达也首度携手合作演唱&#8221;Celebrate The Day&#8221;的中文版本〈荣耀的一天〉，总计双CD、37首歌曲，一举打造史上最强足球盛典！

CD1
  
01. IL DIVO WITH TONI BRAXTON 美声男伶．唐妮布蕾斯顿 &#8211; <a href="http://202.108.23.172/m?ct=134217728&tn=baidumt,The%20Time%20Of%20Our%20Lives%20Il%20Divo%20Toni%20Braxton%20Voices%20From%20FIFA%20World%20Cup&word=mp3,http://bbs.8dmc.com/UploadFile/2006-5/Y2JjampnbWljZWpmZmhtcWllMw$$.mp3,,[THE+TIME+OF+OUR+LIVES]&si=;;&lm=16777216" target="_blank">THE TIME OF OUR LIVES</a>: 荣耀时刻 2006世足赛全球唯一官方指定曲，全球十亿球迷屏息聆听梦幻合唱
  
02. ELTON JOHN 艾尔顿强 &#8211; YOUR SONG 给你的歌
  
03. MARIAH CAREY 玛丽亚凯莉 &#8211; HERO 英雄
  
04. ROD STEWART 洛史都华 &#8211; EVERYTIME WE SAY GOODBYE 每当我们道再见
  
05. ELVIS PRESLEY 猫王 &#8211; ALWAYS ON MY MIND 常驻我心
  
06. BARBRA STREISAND 芭芭拉史翠珊 &#8211; WOMAN IN LOVE 恋爱中的女人
  
07. SIMON & GARFUNKEL 赛门与葛芬柯 &#8211; BRIDGE OVER TROUBLED WATER 恶水上的大桥
  
08. GEORGE MICHAEL 乔治麦可 &#8211; PRAYING FOR TIME 为时间祈祷
  
09. ANASTACIA 安娜贾西亚 &#8211; ONE DAY IN YOUR LIFE 生命中的一天
  
10. SAVAGE GARDEN 野人花园 &#8211; TRULY MADLY DEEPLY 真诚地、疯狂地、深刻地
  
11. EROS RAMAZZOTTI 艾罗斯 &#8211; PIU BELLA COSA 更美好的事
  
12. YOUSSOU N’DOUR FEAT NENEH CHERRY 尤苏恩多尔．妮娜雪莉 &#8211; 7 SECONDS 七秒瞬间
  
13. WILL YOUNG 威尔杨 &#8211; YOUR GAME 你的游戏
  
14. NATALIE IMBRUGLIA 娜塔莉 &#8211; SHIVER 慌了
  
15. SADE 沙黛 &#8211; BY YOUR SIDE 伴你左右
  
16. R. Kelly 劳凯利 &#8211; I BELIEVE I CAN FLY 我相信我能飞
  
17. WESTLIFE 西城男孩 &#8211; YOU RAISE ME UP 真情守候
  
18. AMICI FOREVER 心灵歌手-亚米奇 &#8211; 公主彻夜未眠

CD2
  
01. WHITNEY HOUSTON 惠妮休斯顿 &#8211; ONE MOMENT IN TIME 闪亮时刻
  
02. IL DIVO & CELINE DION 美声男伶．席琳狄翁 &#8211; I BELIEVE IN YOU (JE CROIS EN TOI) 相信相依
  
03. KELLY CLARKSON 凯莉克莱森 &#8211; BECAUSE OF YOU 因为你
  
04. SANTANA 山塔那 &#8211; MARIA MARIA
  
05. SHAKIRA FEAT WYCLEF JEAN 夏奇拉．怀克里夫金 &#8211; HIPS DON&#8217;T LIE-BAMBOO (2006 FIFA WORLD CUPＴ MIX) 电动马达
  
06. OASIS 绿洲合唱团 &#8211; WONDERWALL 奇迹
  
07. DIDO 蒂朵 &#8211; THANK YOU 谢谢你
  
08. ANNIE LENNOX 安妮蓝妮克丝 &#8211; WHY 为什么
  
09. DELTA GOODREM 黛儿塔 &#8211; BORN TO TRY 生为挑战
  
10. DES&#8217;REE 黛丝瑞 &#8211; LIFE 人生
  
11. BILLY JOEL 比利乔 &#8211; JUST THE WAY YOU ARE 你就是你
  
12. RICKY MARTIN 瑞奇马汀 &#8211; PRIVATE EMOTION 私密的爱
  
13. ALICIA KEYS 艾莉西亚凯斯 &#8211; IF I AIN&#8217;T GOT YOU 如果没有你
  
14. TONI BRAXTON 唐妮布蕾斯顿 &#8211; UNBREAK MY HEART 别伤我的心
  
15. HERBERT GR?NEMEYER FEAT AMADOU & MARIAM 赫伯特 &#8211; <a href="http://202.108.23.172/m?ct=134217728&tn=baidumt,Celebrate%20The%20Day%202006%20Herbert%20Groenemeyer%20%CA%A5%B1%AD%D6%AE%B8%E8%202006%CA%C0%D7%E3%C8%FC%C8%AB%C7%F2%CE%A8%D2%BB&word=mp3,http://308.xiqiao.com.cn/music/%D2%F4%C0%D6%B5%EE%CC%C3%D7%A8%D3%C3%CE%C4%BC%FE%BC%D0/ZGVhd5qinJqjk6eZiZ6cfJKrW-nlySAPAlsz.mp3,,[celebrate+the+day]&si=;;&lm=16777216" target="_blank">CELEBRATE THE DAY</a>:2006 FIFA 时代杂志赞誉“欧洲英雄”赫伯特演唱德国东道主主题曲
  
16. ALAN KUO 柯有纶 &#8211; WAKE UP (BONUS TRACK) Wake Up(拼了)
  
17. RAINIE YANG 杨丞琳 &#8211; CELEBRATION (BONUS TRACK) 庆祝
  
18. LEEHOM WANG 王力宏 &#8211; HEROES OF EARTH (BONUS TRACK) 盖世英雄
  
19. ALAN KUO WITH YIDA HUANG 柯有纶．黄义达 &#8211; CELEBRATE THE DAY 柯有纶．黄义达首度合作演唱德国主题曲Celebrate The Day中文版“荣耀的一天

 <span style="color: #333333;">随着世界杯的临近，这个辑子里的曲子一定会频繁得萦绕在人们的耳边。我没有全部听，只听了介绍中推荐的3首，感觉Celebrate the day不错，热情激昂，多用和声渲染球场的喧嚣与激情。</span>

 <span style="color: #333333;">不过，感觉还是<span style="color: #1169ee;">生命之杯</span>和</span><span style="color: #226ddd;">我踢球你介意吗</span><span style="color: #000000;">更好听，即98年的两首。02年的主题曲莫名得想不起来了。</span>

<span style="color: #777777;">PS：以下吹毛求疵，请以娱乐的眼光看，</span>

<span style="color: #777777;">Jolin的《舞娘》里有首</span><span style="color: #44bb5c;">Mr. Q</span><span style="color: #666666;">，其中有句歌词：</span>

<div style="BORDER-RIGHT: #cccccc 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #cccccc 1px solid; PADDING-LEFT: 5px; BACKGROUND: #f3f3f3; PADDING-BOTTOM: 5px; MARGIN: 5px 20px; BORDER-LEFT: #cccccc 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #cccccc 1px solid">
  <p>
    <span style="color: #666666;">HEY U,Mr.Q 爱你耍Q的指数 电流像瀑布 好像重力加速度 </span>
  </p>
</div>

<span style="color: #666666;">想知道是Jolin更明白重力加速度的含义，还是那个作曲更懂。又莫名地想起“以愚昧无知为耻”……呃，再莫名地感觉到不要什么都和“八×八○”扯上关系。。。</span>