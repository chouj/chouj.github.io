---
title: Call Bitly/Google URL shorten API in MATLAB
author: Chouj
type: post
date: 2018-01-19T08:31:50+00:00
url: /2018/01/19/call-bitlygoogle-url-shorten-api-in-matlab/
views:
  - 635
categories:
  - 我尝试
  - 我表达
  - 我记录
tags:
  - Bitly
  - Google
  - matlab
format: aside

---
# Bitly

[Bitly API document: **/v3/shorten**][1]

Matlab code:

<pre class="line-numbers prism-highlight" data-start="1"><code class="language-ASP">url  = 'https://api-ssl.bitly.com/v3/shorten?access_token={your_access_token}&format=txt&longUrl=http://google.com/';
shortened = webread(url)
</code></pre>

Escape character is also supported / 支持转义字符:

<pre class="line-numbers prism-highlight" data-start="1"><code class="language-python">url  = 'https://api-ssl.bitly.com/v3/shorten?access_token={your_access_token}&format=txt&longUrl=http%3A%2F%2Fgoogle.com%2F';
shortened = webread(url)
</code></pre>

# Google

[Google API document: **URL Shortener**][2]

First, you should have a URL shortener API key. It can be generated in the [Credentials page][3].

Then, the matlab code:

<pre class="line-numbers prism-highlight" data-start="1"><code class="language-ASP">url='https://www.googleapis.com/urlshortener/v1/url?key={yours}';
options = weboptions('RequestMethod','post', 'MediaType','application/json');
Body = struct('longUrl', 'http://www.google.com/');
response = webwrite(url, Body, options);
</code></pre>

Note：确保你的MATLAB可以科学上网(Preferences->Web->Internet connection里设置use a proxy)。

 [1]: https://dev.bitly.com/links.html#v3_shorten
 [2]: https://developers.google.com/url-shortener/v1/getting_started
 [3]: https://console.developers.google.com/apis/credentials