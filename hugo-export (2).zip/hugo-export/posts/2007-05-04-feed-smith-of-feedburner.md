---
title: Feedburner发布WP插件Feed Smith
author: Chouj
type: post
date: 2007-05-04T13:31:30+00:00
url: /2007/05/04/feed-smith-of-feedburner/
views:
  - 1783
  - 1783
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969688
categories:
  - WordPress
  - 教程
  - 新闻
tags:
  - Feedburner
  - Plugin

---
<img src="http://blogs.feedburner.com/feedburner/images/flamocon.gif" alt="Feedburner" hspace="5" vspace="10" />

<big><big>5</big></big>月3日，<a href="http://blogs.feedburner.com/feedburner/archives/2007/05/feedburner_adopts_twoyearold_r_1.php" target="_blank">Feedburner官方blog发布消息</a>，称Feedburner采用了原作者为 <a href="http://www.orderedlist.com/" target="_blank">Steve Smith</a>的Wordpress插件<a href="http://orderedlist.com/wordpress-plugins/feedburner-plugin/" target="_blank">FeedBurner Plugin v2.2</a>，并发布Feedburner官方版本WP插件<a href="http://www.feedburner.com/fb/a/help/wordpress_quickstart" target="_blank">Feedburner Feed Smith</a>。

<big><big>F</big></big>eedburner Feed Smith与原版插件，并没有代码上的差别，原版插件用户无需升级或替换。该插件适用于由Wordpress 1.5-2.x搭建的blog，功能上可以不通过修改.htaccess文件，将blog中的所有原始feed地址（例如格式为http: //www.yoursite.com/feed/ 或 http://www.yoursite.com/wp-rss2.php，等等）转向到blogger自定义由Feedburner烧制的Feed。文 章Feed和评论Feed均可通过此插件实现全面转向，以使blogger可以通过Feedburner追踪潜在的订阅读者。

<big><big>如</big></big>果你使用WP搭建blog，就可以选用此款插件。安装起来也很便捷：

1、[下载Feed Smith插件][1]；
  
2、将文件ol_feedburner.php上载至WP默认的插件文件夹（wp-content/plugins/）下；
  
3、在WP后台，插件管理中，激活该插件，下面是WP后台中该插件的描述；

> Originally authored by <a href="http://www.orderedlist.com/" target="_blank">Steve Smith</a>, this official FeedBurner plugin detects all ways to access your original WordPress feeds and redirects them to your FeedBurner feed so you can track every possible subscriber. <cite>作者: <a href="http://www.feedburner.com/" target="_blank" title="访问作者主页">FeedBurner Inc.</a>.<br /> </cite>

4、 在WP后台的“选项”标签下，将有“Feedburner Feed Smith”项。在该项下，第一步即前往Feedburner烧制Feed，若已经有的话，跳过；在第二步的选项中填入您的Feedburner烧制的 Feed地址；第三步可选，即如果您给评论RSS也烧制了Feed的话，可使用此项。
  
5、点击“save”完成设置。

Technorati Tags: <a href="http://technorati.com/tag/Feedburner" class="performancingtags" rel="tag">Feedburner</a>, <a href="http://technorati.com/tag/Wordpress" class="performancingtags" rel="tag">WordPress</a>, <a href="http://technorati.com/tag/plugins" class="performancingtags" rel="tag">plugins</a>

 [1]: http://www.feedburner.com/fb/products/feedburner_feedsmith_plugin_2.2.zip