---
title: 两张漂亮的RSS FEED 图片
author: Chouj
type: post
date: 2007-07-15T16:19:03+00:00
url: /2007/07/16/feed-symbol-of-maike/
views:
  - 1611
  - 1611
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969964
categories:
  - 标志
tags:
  - button
  - Graph
  - RSS设计

---
从 [**麦可·志**][1] 发现了两张相当漂亮的RSS Feed小图，[麦可][2][原文][3]称可“随便取用”，特转存到[抽儿][4]的相册（[麦可][2]的图在Flickr上，GFWed），并推荐之。

[麦可][2]，上图图！

<p align="center">
  <img src="http://photo8.yupoo.com/20070715/235605_1094424568_bssbbgci.jpg" alt="cooler-rss-pink" class="Photo" height="32" width="180" />
</p>

<p align="center">
  <img src="http://photo8.yupoo.com/20070715/235604_918137229_hywpbcpl.jpg" alt="cooler-rss-blue" class="Photo" height="32" width="180" />
</p>

好心的[麦可][2]为了“仁至义尽”，同时放出了图片的psd文件，喜欢的朋友可以到[麦可][2]提供的[这个地址][5]去下载图片和文件！[抽儿][4]同时在猜测，会不会有春、秋、冬的系列作品出现，这个答案只能让麦可自己来揭晓啦！

[麦可][2]的blog上还有一些也很精美的小贴纸，如：<img src="http://menghao.net/blog/wp-content/themes/moko/images/c-rss.png" alt="RSS 2.0" height="15" width="80" />，[抽儿][4]猜测也是出自他的手笔，04号小字体非常适合做这种80×15的button。

[ <a href="http://menghao.net/blog/" target="_blank">麦可·志</a> | <a href="http://menghao.net/blog/archives/139.html" target="_blank">麦可的原文</a> ]

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://menghao.net/blog/
 [2]: http://menghao.net/blog
 [3]: http://menghao.net/blog/archives/139.html
 [4]: http://www.xuchi.name/blog
 [5]: http://www.box.net/shared/s9rz555a59