---
title: 广州书店 窥斑见豹
author: Chouj
type: post
date: 2007-04-16T08:35:32+00:00
url: /2007/04/16/bookstore-in-guangzhou/
views:
  - 2512
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969672
categories:
  - 我记录
tags:
  - 书店
  - 博尔赫斯
  - 学而优
  - 广州
  - 必得

---
<a href="http://xcchris.blogspot.com/2007/03/targets-locked.html" target="_blank"><big><big>T</big></big>arget Locked</a> ，成行，然后一定要补完所见所想。

<big><big>从</big></big>大四左右，开始对书本文 字间传达的思想有所兴趣，涉猎的题材也多为或影射现实、或本就着眼现实的敦促思考类书籍。说来奇怪，武侠性质的小说一本也没看过，却同样因文字的力量而对 书抱有好感。渐渐的，逛书店也成为乐趣所在，而评判一个书店好坏的标准慢慢过渡到了其有没有《读库》。不是《读库》这一系列书异常的好。而是说《读库》是 一个合适的下限，有《读库》说明这个书店的定位比较文艺，同时偏门如《读库》都有所收藏，那么肯定有很多值得一读的书星罗棋布于店中。最近正在考虑要不要 把下限降至《格列佛再游记》，能收藏这本书的店，眼光一定格外独到。可惜还没找到有这本书的店啊，当然，除了网店。

<big><big>回</big></big>到广州。<a href="http://www.douban.com" target="_blank">豆瓣网</a>上以广州品牌书店而自发构建的粉丝小组居然有五六个之多，我所逛到的也就三四家而已，本想写广州书店一览的念头只好作罢，否则有被羊城人民丢臭鸡蛋的风险。又不得不感叹羊城人民的幸福，有诸多优秀的书店供他们享用。

<a href="http://www.douban.com/group/xooyo/" target="_blank"><strong>学而优</strong></a>

<big><big>我</big></big>在广州去的第一家书店，中大西门旁那家旗舰店，从我这里步行即可，比较近。两层的建筑，布置得比较有格调，店里放着舒缓的轻音乐，书码放的整齐，顾客也不 多，环境是非常合我胃口的那种。藏书更是足以让我断言，这是全广州很不错的地方之一，不求全，但求精。从偏技术偏管理的《搜》、《长尾理论》、《撬动地球 的Google》到思想性文学性的《野火集》、《神了》、《读库》，纵然我的眼界只集中在这几本之上，但一家书店将这些都囊括其中，已经比较鲜见了，至少，武汉基本没有这样的店。

<big><big>一</big></big>层主营主流读物、文学类，最里面则有经管和计算机类书籍；二楼则首先是三联和商务专架，然后是历史、法律、 传媒、艺术类图书。书架之侧，贴出最新上架的新书，销量榜上的畅销书，按区域分类，比如“历史类书籍销量榜单”，其上还有吴思的《隐蔽的秩序》。闲来无事 想到书店逛逛的话，这里会成为我的首选福地；要掏钱的话，还是会倾向网购，毕竟这里是按原价售书。

<a href="http://www.douban.com/group/borgeslibreria/" target="_blank"><strong>博尔赫斯</strong></a>

<big><big>一</big></big>个非常牛的名字，搭配一干人等的推荐；第一次的擦肩而过，直至站在书店之外感叹其外观的别致，无形间已经将我的期许拔高了许多。

<big><big>我</big></big>去这间书店的时候正是中午，一路上和一位姑娘保持路线一致，在有种跟踪良家妇女的莫名之中一直到了书店，悬疑随即化解：姑娘是来换班的，接替一位老者。一人到岗，一人离去，片刻之后安静下来，只有视线从书册中捋过。老实说，和期许十分的不符，店子不到十平米，架子上的书又集思想性、逻辑性、文艺性、学术性于一身，实在不适合我这样的非专业顾客，倒是比较适合学究。视线随之转移：书架之上的海报、相框还有一些贴着石灰、露着水泥的砖石。好奇的向那位姑娘求 解，这些砖石有什么特殊的意义，答曰：“第一次拆迁搬过来就放在那里了。”过高的期许之下，这样的回答不会让我认为是书店的质朴，倒是觉得是对我希冀的摧 残，有点讨无趣。如果是我，我会说的更文学一点：“为了纪念书店的第一次搬迁。”

<big><big>倒</big></big>是听说这里经常举办文化学术活动，以此闻名，没能亲见。别人拍的书店见<a href="http://xrspook.blogbus.com/logs/2006/08/3084226.html" target="_blank">这里</a>和<a href="http://photo.163.com/photos/flyinight/74321131/" target="_blank">这里</a>。

<a href="http://www.douban.com/group/Citybook/" target="_blank"><strong>必得书店</strong></a>

<big><big>跑</big></big>了老远，终于到了天河购书中心，可能周六的缘故，人山人海。一楼什么都有；二楼教辅，少儿读物；三楼社科，还有三联专店，倒也能找到《读库》、《神了》、《野火集》，但书多人多，体验就差了；四楼专业书；五楼个体。层层净化之后，购书中心五楼的顾客已经稀少到刚刚好的程度。而必得书店亦不与经法考证店铺为 伍，在角落里偏安一隅。

<big><big>来</big></big>之前，并不知书店之名，只见网上说中心五楼有不错的去处，便找到了必得。店子稍显拥挤，却独具特色，书籍和杂志 都比较精到，老板娘果真有眼光。问可否有折扣，老板娘说凭书而论，随手抄起一本《读库0701》，答曰九折。欣喜的是终于找到一家可以打折的店，悲哀的是 路费绝非可忽略成本，还是网上买吧。

<big><big>这</big></big>里有别人拍的<a href="http://www.flickr.com/photos/pmlive/tags/%E5%BF%85%E5%BE%97%E4%B9%A6%E5%BA%97/" target="_blank">书店照片</a>。五楼之上，还有一家红枫叶书店，也可以去逛逛。

<big><big>广</big></big>州还有几家口碑不错的书店，比如<a href="http://www.douban.com/group/15078/" target="_blank">唐宁书店</a>，还有<a href="http://www.douban.com/group/chet/" target="_blank">缺书店</a>。尚没去过，困惑于地下铁和公交车的周转，怕舟车疲惫连累了发现的惊喜和逛店的兴致。这里给出的都是各自豆瓣小组的链接，活跃的帖子总比生硬的网站要亲切，信息也比较周全。不禁想到，顾客之中，上网的有多少，上豆瓣的又有多少，却汇聚起人气积攒出口碑， 从中可悟出两条经营之道。一是在豆瓣这样的地盘上挖个坑，来来往往的朋友如若发现自己曾去过的书店，尚有组织可循，必会进来看个究竟，这时店家贴一些进 货、销榜、折价、书评之类，自然可以笼络起一片Fans。二是有书店网站也好，有豆瓣小组也好，顺反向链接而上，凡有blog提及，店家留言答谢，说的堂皇点，这叫突显人文关怀。如若有书店站长组长看到如此idea，拿去受用，别忘给我办张会员金卡，我定经常前去捧场，o(∩_∩)o&#8230;

Technorati Tags: <a href="http://technorati.com/tag/%E5%B9%BF%E5%B7%9E" class="performancingtags" rel="tag">广州</a>, <a href="http://technorati.com/tag/%E4%B9%A6%E5%BA%97" class="performancingtags" rel="tag">书店</a>, <a href="http://technorati.com/tag/%E5%AD%A6%E8%80%8C%E4%BC%98" class="performancingtags" rel="tag">学而优</a>, <a href="http://technorati.com/tag/%E5%8D%9A%E5%B0%94%E8%B5%AB%E6%96%AF" class="performancingtags" rel="tag">博尔赫斯</a>, <a href="http://technorati.com/tag/%E5%BF%85%E5%BE%97" class="performancingtags" rel="tag">必得</a>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>