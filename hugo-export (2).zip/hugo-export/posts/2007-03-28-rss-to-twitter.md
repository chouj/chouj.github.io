---
title: RSS与Twitter结合的新玩法
author: Chouj
type: post
date: 2007-03-28T09:46:48+00:00
url: /2007/03/28/rss-to-twitter/
views:
  - 1587
  - 1587
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969940
categories:
  - 工具
tags:
  - RSS
  - twitter

---
<a href="http://www.rss2twitter.com/" target="_blank"><img src="http://photo1.yupoo.com/20070327/193737_1328341476_pfyurpcc.jpg" border="0" /></a>
  
<font size="5"><font style="font-weight: bold">从</font></font><a href="http://www.showeb20.com/" target="_blank">盗盗</a>那里再度发现有关RSS的新鲜服务，这次RSS的伙伴是风靡全球的<a href="http://twitter.com/" target="_blank">Twitter</a>。

<font size="5"><font style="font-weight: bold">只</font></font>要是<a href="http://twitter.com/" target="_blank">Twitter</a>用户，就可在这个站登录。她实现的功能就是：通过RSS，将最新的网志发布到<a href="http://twitter.com/" target="_blank">Twitter</a>上去，把<a href="http://twitter.com/" target="_blank">Twitter</a>变成了在线RSS阅读器，或者说是最新网志发布平台。而发布哪些RSS，全凭用户登录后在后台的订阅，可订阅多个RSS，也可对已订阅的RSS去订。

Blogging的Twitter用户还不赶紧去试试？

<a href="http://www.rss2twitter.com/" target="_blank">点击进入</a>