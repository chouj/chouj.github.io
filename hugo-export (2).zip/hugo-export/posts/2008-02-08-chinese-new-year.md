---
title: 本命年
author: Chouj
type: post
date: 2008-02-07T18:24:26+00:00
url: /2008/02/08/chinese-new-year/
views:
  - 2593
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969721
categories:
  - 我记录
tags:
  - blog
  - WordPress
  - 图片
  - 本命年

---
<p align="center">
  <img border="0" align="middle" width="500" src="http://pic.yupoo.com/xcchris/2990150ebc6f/medium.jpg" alt="单位附近的雕塑" height="375" />
</p>

[<big></big><big>上</big>一篇][1]说到控制面板进不去，八成是因为插件开多了。光靠人品来解决问题不是办法，趁年闲重装到了WordPress 2.3.2，换主题到Blackish，晚点儿是晚点儿，谁让猪年手懒呢。

<big></big><big>B</big>log还是要恢复更新，即便以流水帐的姿态。每每看着朋友们的文字，就算与我毫不相干，也能品味到一种鲜活，一抹温暖。换言之，我随便写点东西没准儿就让谁谁的神经产生了电脉冲呢。Blog Boom是否将阅读引向了信息快餐，这不是我想讨论的，我的目的只有一个：让诸懒人在阅读器里就能知道我还鲜活着。

<big></big><big>年</big>是过的异常萧条，缺乏与人交流的欲望，尤其不愿在相机面前挒开嘴角，因为很假。真的感觉看不到希望，感觉所有生龙活虎之物都是敌人，似乎想要摘掉印有“破灭”二字的封印，又似乎颓颓然无所动。本命年是惨大发了。

<big></big><big>贴</big>张旧图，拜年了事。

###### <font color="#999999">鲜果认领：BANGF5A6BC913C212C10164CA6E5XIANGUO</font>

<p align="center">
  <img src="http://xuchi.name/blog/wp-content/uploads/2011/01/hny.gif" />
</p>

 [1]: http://www.xuchi.name/blog/2008/02/01/back-again/ "久违"