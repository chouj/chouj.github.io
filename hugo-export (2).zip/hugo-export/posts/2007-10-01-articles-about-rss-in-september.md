---
title: '[草莓版]九月汇集：FB消化掉河蟹，GR发布中文版'
author: Chouj
type: post
date: 2007-09-30T18:15:06+00:00
url: /2007/10/01/articles-about-rss-in-september/
views:
  - 1755
  - 1755
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969986
categories:
  - 相关
  - 翻译
tags:
  - Feedburner
  - feedsky
  - Google Reader
  - Reader
  - Xianguo
  - Yeeyan
  - Zhuaxia

---
<img src="http://photo5.yupoo.com/20070828/184610_1275588803_rrcvhspd.jpg" title="RSS相关 草莓版信息汇集" alt="RSS相关 草莓版信息汇集" height="130" width="122" />

[**<a href="http://www.feedburner.com" target="_blank">FeedBurner</a>吃河蟹**]

8月底，[FB吃上了河蟹][1]，一月后，仍有朋友<a href="http://www.iamvip.net/blog/review/53" title="Feedburner被和谐之后…" target="_blank">撰文悼念之</a>，实属效力强劲，耐力持久，FeedBurner一“举”成为9月RSS相关话题中的热门关键词，实乃拜男性健康用品“河蟹”所赐。9月12日，<a href="http://www.williamlong.info/archives/1053.html" title="网通用户无法访问FeedBurner" target="_blank">报网通也无法访问feeds.feedburner.com二级域名</a>，标志着吃河蟹吃完满了，剩下全国bloggers给这一事件抹嘴。

<!--more-->

FeedBurner的倒下给我们带来了<a href="http://www.kuangfeng.cn/blog/?p=1388" title="Feedburner倒下之后带来的启示" target="_blank">什么启示</a>？是<a href="http://jiangzhanyong.com/2007/09/feedburner-is-blocked-by-the-wall-521.html" title="Feedburner 被封影响甚微" target="_blank">影响甚微</a>，还是<a href="http://www.williamlong.info/archives/1037.html" title="FeedBurner的广告影响的分析" target="_blank">FB广告歇菜</a>？是<a href="http://fisio.cn/feedburner-zhuaxia.html" title="FeedBurner: 抓虾还活着！" target="_blank">抓虾一族生命力的顽强</a>，还是<a href="http://www.ilmay.cn/post/google-reader-do-not-support-30-day-redirection.html" title="F确认：Google Reader不支持 FeedBurner 30 天退出服务" target="_blank">GR不甩FB的30天退出</a>？

面对FB的倒下，我们又能做什么？欲投奔Feedsky的，可参考下<a href="http://www.ilmay.cn/post/feedburner-to-feedsky.html" title="从FeedBurner转移到FeedSky的一些心得" target="_blank">转换心得</a>、<a href="http://www.ilmay.cn/post/feedburner-to-feedsky-2.html" title="Feed 订阅地址转移总结" target="_blank">转移总结</a>及<a href="http://fairyfish.net/2007/09/08/feedsky/" title="Feedsky 使用介绍" target="_blank">Feedsky使用介绍</a>，However，这样有被和菜头讥为：“<a href="http://www.caobian.info/?p=2517" title="Feedburner和FeedSky不能并存？" target="_blank">不单缴了械，居然连内裤都主动脱光了</a>”的风险，请慎重。换不换阵营自行定夺吧，还是先把订阅数显示整出来比较靠谱儿，RSS相关用的是<a href="http://kunshou.net/2007/09/feedburner.html" title="显示你的 FeedBurner 订阅数图标" target="_blank">困兽的方法</a>，还有不少方法可行，比如<a href="http://blogsdiy.org/2007-09/feedburner-awareness/" title="FeedBurner被和谐后显示订阅数的替代方案" target="_blank">博客学堂的插件法</a>和<a href="http://www.maoxinyu.cn/archives/166" title="如何复活Feedburner统计图标？" target="_blank">毛心宇的Zelune.us法</a>。

<a href="http://nings.cn/2007/09/01/nbweekly-3.html" title="Nbweekly：TOP17·CNNIC·Feedburner" target="_blank">Nings说</a>：“FB被釜底抽薪，<a href="http://www.feedsky.com" target="_blank">FS</a>爽了。”真的是这样吗？对Feedsky而言，好像是机遇与挑战并存，至少<a href="http://www.osxcn.com/web20/moved-to-feedsky.html" title="希望 Feedsky 能挺过这关" target="_blank">过这关的动作得是“挺”</a>。

[**<a href="http://www.feedsky.com" target="_blank">Feedsky</a>上线用户中心**]

来看看FS挺得怎么样。

他们<a href="http://blogs.feedsky.com/?p=161" title="用户中心上线" target="_blank">上线了用户中心</a>，其实不算大事件，但透漏出来的信号就是，<a href="http://www.jaylee.cn/feedsky-user-center/" title="Feedsky 用户中心上线 即将开放更改登录 Email 功能" target="_blank">自博客圈儿后，FS打算动用他们的客户资源进行社区化了</a>，先拿中心试试身手。抽儿认为，初看之下该功能——羽翼未丰比较鸡肋，挺没挺对方向有待观察。理由有：

  1. 个人首页link是随机分配的代码，比如抽儿的：http://www.feedsky.com/user/6ca56bca，不可自定义；
  2. 个人首页Title显示的是“- Feedsky.com”，简直是怪异的存在；
  3. 常用网络服务，显示出了ID，不给链接，实在不人性化。
  4. 抽儿上传头像没有成功过，- -b

他们又推出了<a href="http://blogs.feedsky.com/?p=163" title="新功能上线-谁在看你的Blog？" target="_blank">读者统计</a>，能让客户知道“谁在看你的blog”，就此<a href="http://www.qianblogger.com/2007/09/30/feedsky-tongji-wenti/" title="三问Feedsky读者调查" target="_blank">被前博客三问</a>，欢迎前去交流观点。

[**阅读器开玩widget**]

九月的阅读器市场上，大事两桩，一是GR中文版的发布，一是<a href="http://www.zhuaxia.com" target="_blank">抓虾</a>、<a href="http://www.xianguo.com" target="_blank">鲜果</a>widget的放出。

月初鲜果事先<a href="http://blog.xianguo.com/2007/09/03/web-widget-60.html" title="鲜果分享小部件(Widgets)升级上线" target="_blank">投放分享小部件升级版</a>， 中秋抓虾<a href="http://www.zhuaxia.com/blog/?p=193" title="中秋到、送好礼，首批widget上线" target="_blank">投放首批widget</a>。总体看来，鲜果的widget和GR的share items一样，满足基本的阅读分享；抓虾的widget则功能丰富，是加强其社区化的利器。但，曹增辉认为<a href="http://www.caozenghui.cn/?p=223" title="杀手Google和迷茫的抓虾" target="_blank">抓虾在满足用户需求上似乎弄扭了</a>，RSS阅读器到底该如何社区化，且看<a href="http://www.huahua.info/archives/401069" title="RSS阅读器：社区设计" target="_blank">花花的专业分析</a>。

抓虾最近有开放<a href="http://www.zhuaxia.com/blog/?p=192" title="每周博客推荐上线" target="_blank">每周blog推荐</a>，进一步和内容生产者——bloggers互动互惠，**RSS相关**有幸被相中，成为受推荐blog，特此感谢抓虾编辑的厚爱，:)

[**<a href="http://reader.google.com" target="_blank">Google Reader</a> 中文版上线**]

曹增辉<a href="http://www.caozenghui.cn/?p=223" title="杀手Google和迷茫的抓虾" target="_blank">那一文</a>里，把GR的职业敲定为杀手，因为GR没有社区，没有推荐，不存在随手订阅。现在，<a href="http://www.kenengba.com/post/241.html" title="Google Reader已推出中文版" target="_blank">这个杀手学会中文</a>了，叠加<a href="http://www.ilmay.cn/post/google-reader-number.html" title="Google Reader 的一些数据与未来发展" target="_blank">GR的数据统计优势</a>，（杀怪更加得心应手，练级更加游刃有余。要是某网游里，飘过一个杀手ID是Google Reader，那个寒～～imagine一下）中文RSS阅读器市场势必血雨腥风。再加上<a href="http://www.yeeyan.com/articles/view/%E9%A9%AC%E5%A4%AB/1935" title="Google收购Feedburner将如何改变RSS营销格局" target="_blank">Google收购FB对RSS营销格局的改写</a>，Google真是强势得之乎者也啊。

同时，GR也完善了不少，比如呼声最高的搜索功能的加入，让这款阅读工具在许多人眼中更加完美。

线上RSS阅读器，你选好了吗？

[**译言<a href="http://www.yeeyan.com/groups/show/rss" target="_blank">RSS小组</a>的最新翻译**]

感谢译言的朋友：<a href="http://yeshenyue.cn/" target="_blank">鱼</a>、<a href="http://www.yeeyan.com/space/show/%E9%A9%AC%E5%A4%AB" target="_blank">千里译</a>，翻译了大部分我推荐的文章：

[Google收购Feedburner将如何改变RSS营销格局][2]
  
[RSS营销的十个步骤][3]
  
[企业不乐于使用RSS的5个原因][4]
  
[RSS输出:全文还是摘要——关于Feed的大争议][5]

<font color="#c0c0c0"><small>最近有点儿倦怠期的意思，加上事情开始多起来，隔了一周多才更新， 强调下态度：这事儿难免会再发生，因为这个blog只能算是副业，我可以在闲暇之时写点儿东西帮帮需要的朋友。即便被抓虾推荐，我也不会逼自己迎合其更新频率固定的要求，现实生活不能被这里拖累的说。</small></font>

<small><strong><font color="#ff0000">祝黄金粥愉快～ </font></strong></small>

 [1]: http://aboutrss.cn/2007/08/29/is-feeds-dot-feedburner-gfwed/
 [2]: http://www.yeeyan.com/articles/view/%E9%A9%AC%E5%A4%AB/1935
 [3]: http://www.yeeyan.com/articles/view/%E9%A9%AC%E5%A4%AB/2040
 [4]: http://www.yeeyan.com/articles/view/%E9%A9%AC%E5%A4%AB/2089
 [5]: http://www.yeeyan.com/articles/view/fish/2108