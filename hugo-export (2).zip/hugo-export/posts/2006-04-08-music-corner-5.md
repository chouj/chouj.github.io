---
title: 音乐一隅之2006.4
author: Chouj
type: post
date: 2006-04-08T02:23:00+00:00
url: /2006/04/08/music-corner-5/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/04/20064.html
views:
  - 1838
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969771
categories:
  - 我表达
tags:
  - 音乐

---
有里知花，从<a href="http://atomicink.blog.hexun.com/2759320_d.html" target="_blank">击空明兮</a>那里见过这个名字，当时尚觉得这个名字竟如此的奇怪，甚至没想它是个日本名字。直至昨天，从<a href="http://bt.5qzone.net/" target="_blank">5Q</a>上拖下来一票英文歌，听到了有里知花的《I Cry》，内心中涌起一股纯净，一种想安静下来听歌的冲动。

于是，重新在<a href="http://atomicink.blog.hexun.com/2759320_d.html" target="_blank">击空明兮</a>那里翻出那些文字，细看一番，果如其言。当下，down了些 [Good luck to you] 精选集里的歌，细细聆听。正如那篇文字里写的一样，“有里知花的嗓音，如海风般透明舒服，她拥有忍不住让人驻足聆听的特质与舒缓听觉的甜美氛围”。

那边的文字一并转来……

<img src="http://photo1.hexun.com/p/2006/0315/12867/b_D4C8E0A0ED3F9BF0.jpg" border="0" alt="" />

一位让人忍不驻足聆听的柔美新女声，有里知花！随着“去见你”被选为2003年东南亚国协交流年的日本指定曲、以及专辑『美丽人生』在台湾发行，有里知花那舒缓听觉的清丽歌声早已是众人枕边不可或缺之物。

有里知花出生于日本横滨的一个音乐世家，这使得她在幼年的时候就有幸接触到了很多不同类型的音乐。3岁的时候，她就开始学钢琴，并且学会了自己作曲。有里知花在初、高中时期加入了学校的英语剧社，成为了其中的一员。在那里，有里知花将自己所学的古典音乐融入到表演当中，而她在歌唱和舞蹈方面的天赋也得以充分的发挥，她开始尝试通过音乐来表达自己的情感。

在就读大学期间出道。以外国歌手之姿一首《I cry》(夏威夷歌手”Kenneth Makuakane”创作，英文歌词)，获得夏威夷收听率最高电台“102.7 Da Bomb” 点播率第一的殊荣，并且于夏威夷的The Mountain Apple Company发行限定单曲《I cry》，消息传回日本，引起乐界一阵骚动，纷纷讨论这位新进女歌手。

2000年8月，有里知花的首张单曲CD《I Cry》在日本发行，其反响不但遍布全日本，还波及了海外，在夏威夷更是创下了点播率的新高。同年11月，由夏威夷著名音乐制作人Kenneth Makuakane为她度身定作的首张专辑《花》也接踵而至，很快就得到了多方的关注，迅速登上了电台点播率第一的位置。这一张专辑的大部分作品都是英文歌曲，而且有里知花在声音和情感的表现上游刃有余，这在当今的日本歌手当中是非常罕见的。

有里知花的嗓音，如海风般透明舒服，她拥有忍不住让人驻足聆听的特质与舒缓听觉的甜美氛围。一群顶尖的制作人与艺人决定参与她最新第三张专辑《美丽人生》。专辑除收录3首英文歌之外，值得一提的是，《去见你》被选为20 03年东南亚国协交流(j-asen pops)日本指定曲；此外她更特别翻唱南方之星百万经典《tsunami海啸》，将这首脍炙人口的畅销曲重新更加柔美而隽永动人。

半年前开始学中文的她，也已学得一手漂亮中文与标准的发音。日前随着最新精选辑『Good Luck To You』在大陆发行，她更特别秀了一手中文，献给中国歌迷！她笑称“虽然日文里有汉字，但真正的中文写起来却别有一番风雅呢”。2005年3月17日她受邀前往广州举办了『有里知花 3月之花演唱会』，这也是有里知花首次的海外个人演唱会，更有许多歌迷远从香港前来捧场。有里知花不仅与当地人气歌手合唱中文歌曲，同时在所有的中场串话时，她更是以标准的中文来表达，最后，她以流利的中文唱出了曾被亚洲10个地区翻唱过的“去见你”一曲来做为演唱会的最终曲，让会场响起一片热烈掌声久久不歇。让有里知花开心地表示“一定要继续将中文学得更好，这样就能与舞台下的观众直接交流了”。

最新精选专辑[Good luck to you]是有里之花首张精选，收录了她自出道以来的13首优秀歌曲，同时加入2首新曲，与LOST IN TIME主唱“海北大辅”合唱的“Good Luck To You”，及与曾提供乐曲给”放浪兄弟”等多数知名艺人的“山口雄”合作的“手心”。

有里知花 &#8211; I Crywords:Kenneth Makuakanemusic:Kenneth Makuakane
  
Every night I find it&#8217;s so hard to sleep&#8217;Cause I keep thinking of youAnd these feelings run deepOh baby Itry to hideAll these feelings for youI keep them battled insideI don&#8217;t know what else to doSo I cry and nobody hears meI cry,it&#8217;s my only solutionI cry,to all this confusionI cry, with all of my heartI cry…
  
Sometimes I wonderIn the blink of my eyeWould you be willing to love meWould you give it a tryI don&#8217;t know how else to show youThat our love could be realI&#8217;d be eternally faithfullForever I&#8217;d feelSo I cry and nobody hears meI cry,it&#8217;s my only solutionI cry,to all this confusionI cry, with all of my heartI cry…
  
No one can tell me that I may be wrong&#8217;Cause I know in my heartThis feeling&#8217;s still burning strongCan&#8217;t get you out of my headCan&#8217;t get you out of my heartCan&#8217;t get you out of my lifeNo matter if we&#8217;re apartSo I cry and nobody hears meI cry,it&#8217;s my only solutionI cry,to all this confusionI cry, with all of my heartI cry…And nobody hears meI cry,it&#8217;s my only solutionI cry,to all this confusionI cry, with all of my heartI cry…