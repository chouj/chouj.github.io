---
title: BlackBerry的另一些小东东
author: Chouj
type: post
date: 2007-09-22T14:43:54+00:00
url: /2007/09/22/something-for-blackberry-7230/
views:
  - 3084
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969709
categories:
  - 我表达
tags:
  - 黑莓

---
最近有点儿倦怠，有话题写也会发呆。而且遭遇河蟹，管网络的头头儿说，现在又17big又奥运，上头盯的紧，为了河蟹，为了科研保密工作，没正式申请的入网ip还是8要上网吧，否则非法上网被侦测出来，或者你的机器给别人作了路由或代理服务器，就以网络间_谍论处，顶丫个肺～

还是借博士后的ip，发点儿BlackBerry7230 用的东东比较安全。

  * **Ascendo Photos Blackberry Manager**

如果不爽IPDmanager.exe管理图片的繁琐，可以试试这个。分BB端软件和PC端管理器：BB端支持**图片浏览**，**SlideShow**，**屏保**；管理器支持**图片预览**，**图片直接导入BB**，**图片尺寸更改**。

缺点是：**锁键盘时，不能屏保**； 图片不在默认的/home/user/pictures/下，不能用BB自带图片浏览器浏览；没有BB自带图片浏览器的小图预览。

我没用这个软件，图片浏览器放一个就够。

**点此进入下载页面 <a href="http://www.box.net/shared/n0pz3zc72f" target="_blank">BB端</a> <a href="http://www.box.net/shared/t43rmtfy8x" target="_blank">PC端</a>**

  * **英文短信群发软件SMS BroadCast**

7230不支持群发比较遗憾，我只找到了这个群发英文短信的软件。53版下发中文，接到后是乱码。不知道35的中文系统下发中文如何。

发的时候，进入软件，先做个联系人List，把人都放进去（且手机号必须在Mobile位置 ），存好List，再编辑短信，选择把短信发至刚才存的List。

<a href="http://www.box.net/shared/mcr24qqar9" target="_blank"><strong>点此进入下载页面</strong></a>

  * **布谷鸟整点半点报时软件**

小小软件一个，还是中文的，我还不知道怎么把这个功能关掉，囧。

<a href="http://www.box.net/shared/afsh5naqrf" target="_blank"><strong>点此进入下载页面</strong></a>

  * **仙剑 For BB**

如果手机上玩儿游戏也能算数的话，那这是我人生中第二个玩儿过的大型RPG——第一个是Final Fantasy Ⅸ——在BB上通了一遍，情节简单，基本没难度，除了某些小迷宫绕起来比较头大（相对于PC上的迷宫，手机上的迷宫大小可忽略不计）。

<a href="http://www.box.net/shared/lgp3u0qmeh" target="_blank"><strong>点此进入下载页面</strong></a>

<strike>哦对，想起来<a href="http://parandroid.com/my-faviwordpress-plugin" title="Wordpress插件之我喜欢  " target="_blank">被老帕点了名</a>， 恕俺倦怠着呢，拿RSS相关那里一文：<a href="http://aboutrss.cn/2007/09/18/wordpress-plugins-used-for-feed/" title="我使用的Feed类WP插件" target="_blank"><em>我使用的Feed类WP插件</em></a>来充数吧，嘿嘿。</strike>