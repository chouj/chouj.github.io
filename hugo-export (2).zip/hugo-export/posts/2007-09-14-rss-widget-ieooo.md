---
title: 'Rss网页Widget: 泥狗狗 ieooo'
author: Chouj
type: post
date: 2007-09-14T12:05:25+00:00
url: /2007/09/14/rss-widget-ieooo/
views:
  - 1603
  - 1603
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969981
categories:
  - 工具
tags:
  - widget

---
[<img src="http://www.ieooo.com/logo.gif" alt="Rss Widget" border="0" />][1]

早上看到从<a href="http://www.weborn.org/Website/ieooo.html" title="网生代" target="_blank">网生代</a>过来的trackback，抽儿于是注意到了这款由网生代推荐的RSS widget服务，与之前介绍的FeedSweep一样，生成一个RSS内容列表，以置于blog侧栏实时共享信息。用泥狗狗（真是kawaii的名字）官方宣传来说就是：**简单,方便,迅速增强网站,分享你的内容**

<!--more-->

以下是个样例，有7个色彩搭配供选，Feed读者可能无法在阅读器里见到。



[ <a href="http://www.ieooo.com/" title="泥泡泡 ieooo" target="_blank">点此进入 <strong>泥狗狗 ieooo</strong></a> ]

 [1]: http://www.ieooo.com/