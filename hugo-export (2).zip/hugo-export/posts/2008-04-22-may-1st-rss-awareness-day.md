---
title: 五一RSS节，hoho~
author: Chouj
type: post
date: 2008-04-22T08:51:06+00:00
url: /2008/04/22/may-1st-rss-awareness-day/
views:
  - 1465
  - 1465
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969999
categories:
  - 新闻
tags:
  - RSS Day

---
[<img src="http://rssday.org/banners/rssday365.gif" border="0" alt="RSS Awareness Day" width="365" height="145" align="right" />][1]

哈，RSS(Really Simple Syndication)都有节了，毫不忧郁义不容辞排山倒海得在这里庆贺下，别管啥家乐福了，来为RSS欢呼吧！

**May 1st RSS Awareness Day**是由<a title="DailyBlogTips" href="http://www.dailyblogtips.com/" target="_blank">DailyBlogTips</a>的Daniel Scocco发起的活动，而且他还为这个日子建了官方网站<a title="点我点我！" href="http://rssday.org/" target="_blank">RSSDay.org</a>以便宣传。这个网站主页扼要得介绍了使用RSS的好处和使用方法，并且提供了<a title="RSS Awareness Day badges and banners" href="http://rssday.org/spread/" target="_blank">各规格的标识</a>供bloggers挂在blogs上（就像文中这个和侧栏那个）。当然，参与这个活动是有奖励的哦，具体见Daniel Scocco的<a title="May 1st RSS Awareness Day: Get Involved" href="http://www.dailyblogtips.com/may-1st-rss-awareness-day-get-involved/" target="_blank">原文</a>（中文翻译<a title="5月1号被定为RSS节" href="http://www.essentialblog.cn/may-1st-rss-awareness-day-get-involved/" target="_blank">在此</a>），不过，如果你像[抽筋儿][2]一样觉得RSS应用值得推广的话，就加入到活动中来吧！

之前写过《[为什么要用线上RSS阅读器][3]》，这里还是再小科普一下：

**使用RSS的最大好处就是，你能及时获知站点的更新而无须频繁访问站点。**

再把这个非常著名的RSS介绍视频（<a title="RSS in plain english" href="http://dotsub.com/films/inplainenglish/" target="_blank">多国语言字幕版</a>、<a title="Video: RSS in Plain English" href="http://www.youtube.com/watch?v=0klgLsSxGsU" target="_blank">Youtube英文版</a>）搬来压阵，怎么说这片儿也该在我的文里出现次，要不然就太不地道了，对不起[RSS相关][4]的名儿啊。RSS阅读器里看不到的话，就不用看了，都会用了，还看个毛。

[http://dotsub.com/api/player.php?filmid=444&filminstance=446&language=zh]

 [1]: http://rssday.org/
 [2]: http://www.xuchi.name "抽筋儿"
 [3]: http://aboutrss.cn/2007/11/10/why-do-we-need-rss-reader/ "为什么要用线上RSS阅读器"
 [4]: http://aboutrss.cn "RSS相关"