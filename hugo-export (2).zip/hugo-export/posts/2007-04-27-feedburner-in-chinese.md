---
title: Feedburner终于要出中文版了
author: Chouj
type: post
date: 2007-04-27T12:59:00+00:00
url: /2007/04/27/feedburner-in-chinese/
views:
  - 1171
  - 1171
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969944
categories:
  - 新闻
tags:
  - Feedburner

---
<img src="http://blogs.feedburner.com/feedburner/images/flamocon.gif" alt="Feedburner" align="left" hspace="5" vspace="10" /><font size="5">最</font>近诸多站点都报道了提供FEED烧制服务的国外知名站点[Feedburner][1]要推出中文版了。消息由其官方blog[发布][2]，且目前Feedburner已经开放出葡萄牙语、俄语、西班牙语版本的[多国语言版][3]，德语、法语、意大利语荷兰语、中文、印度语等语言版本的服务都会陆续上线。值得广大用户期待！

<font size="5">在</font>译言网上，[Richard.Barton声称获得了将Feedburner整站翻译为中文的授权][4]，并称即便一人翻译，也仅需一周时间，故可推知，随着校正、网页制作、调试等步骤过后，不久Feedburner中文版就将正式和用户见面。

Chou本来想写关于Feedburner的教程的，看来可以推后啦，等中文版发布了再写更好！

 [1]: http://www.feedburner.com/
 [2]: http://blogs.feedburner.com/feedburner/archives/2007/04/the_universal_language_of_feed_1.php
 [3]: http://www.feedburner.com/fb/a/languages
 [4]: http://www.yeeyan.com/groups/topic/121/288