---
title: 订阅统计DIY的可行性
author: Chouj
type: post
date: 2008-05-04T17:55:01+00:00
url: /2008/05/05/feedcount-diy/
views:
  - 1809
  - 1809
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970000
categories:
  - WordPress
  - 相关
tags:
  - Plugin
  - Statistic
  - Subscribe
  - WordPress

---
<img src="http://wpchina.org/images/w-event-plugin-1.gif" alt="我为WP中文化做贡献：推荐一款优秀的WP插件" width="200" height="80" />

较早前，曾兄曾在博客联盟分析过<a title="feedburner，feedsky还是原始 feed？" href="http://blogunion.org/blogging-tips/feedsky-feedburner-or-original-feed.html" target="_blank">feed到底要不要托管</a>，结论是**视订阅量为浮云的稳定独立博客何不使用原始feed**，这样更新更迅速（无需等托管商的爬虫来采集）。Charlee推出的一款<a title="Feed统计插件My Feed Stats发布" href="http://tech.idv2.com/2007/11/12/my-feed-stats/" target="_blank">My Feed Stats WordPress Plugin</a>则让feed不托管的适用范围更加广阔，我们使用原始feed一样能知道订阅量指标，姑且称之为订阅统计DIY。RSS相关曾<a title="[WP插件]My Feed Stats介绍" href="http://aboutrss.cn/2008/02/10/my-feed-stats/" target="_self">简介过这款插件</a>，经过我在WP2.5.1下的测试可用后，再次详细推荐一下，没有它我们的讨论就没有意义：

<img src="http://pic.yupoo.com/xcchris/946285840dc1/busvb7e4.jpg" alt="My Feed Stats" width="450" height="200" />

插件名称：<a title="Feed统计插件My Feed Stats" href="http://tech.idv2.com/2007/11/12/my-feed-stats/" target="_blank">My Feed Stats</a>
  
作者：<a title="idv2.com" href="http://tech.idv2.com/" target="_blank">Charlee</a>（国人哦）
  
适用版本：WordPress 2.3+
  
语言：中文
  
备注：需导入数据库文件，不适合yo2类BSP

**<a title="Feed统计插件My Feed Stats" href="http://tech.idv2.com/2007/11/12/my-feed-stats/" target="_blank">下载页面 安装方法</a>**

<!--more-->

安装上门槛稍微高点儿，需要PhpMyAdmin导入.sql文件。激活插件24小时后，即可在&#8221;管理&#8221;—&#8221;Feed统计&#8221;看到结果了，全部界面如下：

<img src="http://pic.yupoo.com/xcchris/598155840dc2/987vey9e.jpg" alt="My Feed Stats admin" width="485" height="968" />

和Feed托管的统计服务相比，

共性：

日订阅量走势；在线、离线阅读器种类统计；订阅量展示图片生成

优势：
  
1、原始feed即时更新，无需ping托管商；
  
2、无需担心feedburner feed屏蔽事件的发生，无需担心某些空间商以服务器压力过大为由关闭feed托管的爬虫访问，订阅图片还可DIY；
  
3、阅读器名称和描述DIY。

劣势：
  
1、阅读器抓取原始feed，给blog空间服务器带来访问压力，不过，Feed托管后，托管商的爬虫一样会访问原始feed，消耗流量；
  
2、无法加入FeedSky、FeedBurner之类的AD话题和展示系统，无法通过RSS赢利；
  
3、订阅统计状态不够细致、优化及发布服务不周全，比如无法生成订阅按钮。

综合考虑，订阅统计DIY还是有其市场的，尤其针对**不考虑借RSS赚钱**、**不需要花哨统计**、**订阅量不大**、**稳定独立的个人型blog**来说，优势明显，严重推荐。:)

**Update**：
  
来看一下Feed托管带来的延时，本文发布于1:55，feedsky的显示于5点，feedburner的好些，显示于2点。
  
<img src="http://pic.yupoo.com/xcchris/389895840dc2/a8tzfj3h.jpg" alt="Feed托管带来的延时" width="443" height="51" />