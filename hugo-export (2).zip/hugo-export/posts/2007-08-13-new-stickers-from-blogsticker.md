---
title: Blogsticker再增数款贴纸
author: Chouj
type: post
date: 2007-08-13T11:30:48+00:00
url: /2007/08/13/new-stickers-from-blogsticker/
views:
  - 2506
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969701
categories:
  - 我表达
tags:
  - widget

---
<big><big><img src="http://photo6.yupoo.com/20070504/175825_2095251123_ivpiqbsm.jpg" alt="blogsticker" /></big></big>

既然前一篇[blogsticker添加贴纸][1]的文在本blog热文里排到了[苍井空女王][2]的屁股后头，那我就再整一篇喽。这次又有9张新图，show几张：

Apple迷不能错过的：

<img src="http://www.blogsticker.net/ui/stickers/l/apple.gif" height="163" width="163" />

X-men，图里的是金刚狼不？

<img src="http://www.blogsticker.net/ui/stickers/l/x-men.gif" height="163" width="163" />

最近爆火的变形金刚，可惜不是擎天柱脑袋，而是字儿：

<img src="http://www.blogsticker.net/ui/stickers/l/transformers.gif" height="163" width="163" />

EVA的死忠也有福了，只是这条儿不好看，是预告：

<img src="http://www.blogsticker.net/ui/stickers/l/rebuild-of-evangelion.gif" height="163" width="163" />

意甲拉齐奥，蓝白主题：

<img src="http://www.blogsticker.net/ui/stickers/l/ss-lazio.gif" height="163" width="163" />

更多信息见blogsticker blog的<a href="http://www.blogsticker.net/blog/2007/08/12/we-have-new-stickers/" title="blogsticker has new stickers" target="_blank">这篇</a>，享用服务请移步至<a href="http://www.blogsticker.net/" title="blogsticker" target="_blank">blogsticker.net</a>。

 [1]: http://www.xuchi.name/blog/2007/05/04/blogsticker/
 [2]: http://www.xuchi.name/blog/2007/06/09/cangjingkong-youtube/