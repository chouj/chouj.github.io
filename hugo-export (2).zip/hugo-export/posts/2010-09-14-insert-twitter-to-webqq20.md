---
title: 在WebQQ 2.0添加推特为WEB OS桌面应用
author: Chouj
type: post
date: 2010-09-14T11:25:49+00:00
excerpt: 疼逊终于又上线了一款华丽丽的产品：Web QQ 2.0，我赶把时髦，体验过后觉得尚佳。发现它也可以像Chrome那样，将网站存储成桌面应用，在桌面一点即开。当然WebQQ存出来的是Web OS桌面应用。
url: /2010/09/14/insert-twitter-to-webqq20/
views:
  - 3302
duoshuo_thread_id:
  - 1279764464521970059
categories:
  - 我尝试
  - 我表达
tags:
  - QQ
  - twitter
  - WebQQ

---
疼逊终于又上线了一款华丽丽的产品：[Web QQ 2.0][1]，我赶把时髦，体验过后觉得尚佳。

发现它也可以像Chrome那样，将网站存储成桌面应用，在桌面一点即开。当然WebQQ存出来的是Web OS桌面应用。遂以Twitter网页客户端推操蛋为例，图示如下，点击放大：

点击浏览网页，打开推操蛋，点击左上红框，即可自定义应用信息：

[<img src="http://farm5.static.flickr.com/4133/4989250719_6e2c283bae.jpg" alt="在WebQQ 2.0添加推特为WEB OS桌面应用 1" width="500" height="308" />][2]

低调起见，还是不把推操蛋共享了。在上方的下拉图标菜单里，就有建好的应用图标啦。以后在任一台电脑登录，都会有这个应用：

[<img src="http://farm5.static.flickr.com/4151/4988972935_49b8a77a04.jpg" alt="WebQQ 2.0添加推特为WEB OS桌面应用 2" width="500" height="333" />][3]

疼逊终归还是将眼光放得稍微长远些了啊。

 [1]: http://web2.qq.com "WebQQ 2.0"
 [2]: http://farm5.static.flickr.com/4133/4989250719_6e2c283bae_b.jpg "Flickr 上 抽筋儿 的 Web2QQ-1"
 [3]: http://farm5.static.flickr.com/4151/4988972935_49b8a77a04_b.jpg "Flickr 上 抽筋儿 的 Web2QQ-2"