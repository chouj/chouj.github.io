---
title: About MMORPGs
author: Chouj
type: post
date: 2006-08-15T02:56:00+00:00
url: /2006/08/15/about-mmorpgs/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/about-mmorpgs.html
views:
  - 1667
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969793
categories:
  - 我尝试
  - 我表达
tags:
  - MMORPG

---
MMORPG——Massively Multiplayer Online Role Playing Games，翻译过来就是大型在线角色扮演类游戏，也就是网游。

今儿个中午看央视12套，就又在讲网游害人，沉迷网游导致犯罪的青少年比比皆是。顿时想，天天听到看到的这些全是国内的，不晓得国外是否也是如此。遂借助搜索引擎的power，上网一搜，还真小有所获。

＝＝＝＝＝＝＝＝＝＝＝国外主流媒体一例＝＝＝＝＝＝＝＝＝

原文地址：<a href="http://www.opinionjournal.com/taste/?id=110008780" target="_blank"><strong><span style="font-size: 180%; font-family: Garamond;">Don&#8217;t Read This</span></strong> <span style="font-size: 130%; font-family: Garamond,Times;">Or you may be an Internet addict</span></a>

摘自《华尔街日报》<span style="font-size: 85%; font-family: Verdana; color: #993300;"><strong>REVIEW & OUTLOOK版 </strong><span style="color: #000000;"><em>Friday, August 11, 2006 12:01 a.m. EDT</em> </span></span>

<span style="font-size: 85%; font-family: Verdana;">article就是最近发表的，摘俩段：</span>

<div style="BORDER-RIGHT: #cccccc 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #cccccc 1px solid; PADDING-LEFT: 5px; BACKGROUND: #f3f3f3; PADDING-BOTTOM: 5px; MARGIN: 5px 20px; BORDER-LEFT: #cccccc 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #cccccc 1px solid">
  <p>
    Accounts of the scourge pour in from around the globe. The University of Texas at Dallas offers advice for compulsive Internet users alongside information about eating disorders. In some countries, it has become an official matter, too. A government public-awareness campaign in Zurich cautions the Swiss: &#8220;Spending lots of time in virtual worlds, especially chat rooms, online games and sex sites, can lead to a dependence comparable to other addictions.&#8221;
  </p>
  
  <p>
    Young people are most often said to be at risk for Internet-related disorders, especially those involved in MMORPGs, or Massively Multiplayer Online Role Playing Games, in which millions of subscribers world-wide can compete for virtual prizes. A Shanghai youth got life in prison last year after he killed someone in a dispute over a stolen &#8220;virtual&#8221; sword. A Korean man reportedly died after a 50-hour marathon game session. Yet we&#8217;re also told that no one is immune: kids, adults, rich, poor&#8211;you know the drill. At least one expert has identified a particular threat to lonely older women.
  </p>
</div>

全文跟咱国内的主流报道差不多，先说有网游成瘾这么一现象，描述一番，然后援引一些学府的调查报告，或权威人士的观点建议，再找那么几个例子，比如上面选的第二段。只是里面的例子一个上海的，一个韩国的，说是国外文章还是拐到国内来了。 PS：这篇文章极适合作阅读理解！！

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

＝＝＝＝＝＝＝＝＝＝＝评论文章一例＝＝＝＝＝＝＝＝＝＝＝

－－－><a href="http://www.boulderweekly.com/archive/033105/coverstory.html" target="_blank">原文地址</a><－－－Brave New Virtual World，这篇通讯评论体裁的，比较长，不过观点涵盖的也相当全，从游戏者到沉迷者，到游戏产业，到游戏制造商，包圆儿了。

里面的例子很生活化，看着跟看晚报或楚天的《讲述》差不多：

<div style="BORDER-RIGHT: #cccccc 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #cccccc 1px solid; PADDING-LEFT: 5px; BACKGROUND: #f3f3f3; PADDING-BOTTOM: 5px; MARGIN: 5px 20px; BORDER-LEFT: #cccccc 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #cccccc 1px solid">
  <p>
    Her boyfriend first signed on to World of Warcraft in their Colorado Springs apartment on Dec. 27, 2004. Since then, he&#8217;s spent 17 days, 20 hours and 32 minutes in the game.
  </p>
  
  <p>
    &#8220;He&#8217;s lost in it,&#8221; says Megan. &#8220;Nothing gets done.&#8221;
  </p>
  
  <p>
    Megan&#8217;s boyfriend has dropped 14 pounds. He works nights, but instead of sleeping during the day, he sits in front of the computer, working on his warlock. His fingers are stained yellow from chain-smoking cigarettes. He&#8217;s played for 18 hours straight at times.
  </p>
</div>

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

＝＝＝＝＝＝＝＝＝＝＝blogger一例＝＝＝＝＝＝＝＝＝＝＝

很搞的搜到一WOW站，不过不是World of Warcraft，而是World of Waste，也叫WOW，不过网站内容属于anti－WOW，参见<a title="Permanent Link: How To Quit an MMORPG?" rel="bookmark" href="http://8ctane.free.fr/worldofwaste/?p=62"><span style="color: #8a3207;">How To Quit an MMORPG?</span></a>

<div style="BORDER-RIGHT: #cccccc 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #cccccc 1px solid; PADDING-LEFT: 5px; BACKGROUND: #f3f3f3; PADDING-BOTTOM: 5px; MARGIN: 5px 20px; BORDER-LEFT: #cccccc 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #cccccc 1px solid">
  <p>
    Before I realized it, it was 4pm the next day; I’d played for 11 hours straight and missed all my lectures.<br /> This in itself I still don’t think was addictive behavior. It was a new shiny thing and I just wanted to see it. We started our guild up with all my old NS mates and had some fun. Over the term though, I started to become addicted. I’d get up out of my bed, play wow, go to a lecture (sometimes), come back and play wow.
  </p>
</div>

<div style="BORDER-RIGHT: #cccccc 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #cccccc 1px solid; PADDING-LEFT: 5px; BACKGROUND: #f3f3f3; PADDING-BOTTOM: 5px; MARGIN: 5px 20px; BORDER-LEFT: #cccccc 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #cccccc 1px solid">
  <p>
    That was to remind me how long I’d, well I’m gonna say wasted, on Warcraft. I say wasted because for the large part of it I wasn’t having fun. I was grinding as a prerequisite to getting to the dungeons to have fun.
  </p>
</div>

这些学生的话，倒是清晰的反应出了东西方MMOs的一致性。

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

＝＝＝＝＝＝＝＝＝＝学术论文一例＝＝＝＝＝＝＝＝＝＝＝＝

<a href="http://www.nickyee.com/hub/addiction/home.html" target="_blank">Ariadne &#8211; Understanding MMORPG Addiction</a>，很详尽的一篇essay，作者如是说：

<div style="BORDER-RIGHT: #cccccc 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #cccccc 1px solid; PADDING-LEFT: 5px; BACKGROUND: #f3f3f3; PADDING-BOTTOM: 5px; MARGIN: 5px 20px; BORDER-LEFT: #cccccc 1px solid; PADDING-TOP: 5px; BORDER-BOTTOM: #cccccc 1px solid">
  It&#8217;s been a little over 3 years since I wrote this essay, and I wanted to put up a short note on how my thinking has since changed on the issue. While I believe that problematic usage is an important issue to discuss, I&#8217;ve come to feel that it is also a very distracting issue, much like the focus on violence and aggression in video game research. When the media incessantly claims that &#8220;EverCrack will eat your babies&#8221;, it traps us in the defensive and prevents us from talking about other much more interesting things happening in online games.
</div>

贴几个论文里的图，相信都看的懂：

<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://www.nickyee.com/hub/addiction/images/image002.gif" border="0" alt="" />
  
<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://www.nickyee.com/hub/addiction/images/image004.gif" border="0" alt="" />

<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://www.nickyee.com/hub/addiction/images/image008.gif" border="0" alt="" />

[论文点此下载][1]

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

全全搜过一遍，翻过一遍，发现网瘾还真是个international phenomenon！ over

 [1]: http://www.nickyee.com/hub/addiction/addiction.pdf