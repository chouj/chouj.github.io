---
title: '[翻译]给Twitter Favorites添加一个Feed'
author: Chouj
type: post
date: 2010-07-06T08:58:39+00:00
excerpt: '[翻译]给Twitter Favorites添加一个Feed'
url: /2010/07/06/create-an-feed-for-twitter-favorites/
views:
  - 2506
duoshuo_thread_id:
  - 1279764464521970051
categories:
  - 教程
  - 翻译
tags:
  - Feed
  - twitter favorites

---
原文：<a title="Create an RSS Feed for Twitter Favorites" href="http://www.twitterrati.com/2010/05/17/create-an-rss-feed-for-twitter-favorites" target="_blank">Create an RSS Feed for Twitter Favorites</a>
  
作者：[MARK EVANS][1]

推特的神奇之处在于，在这条信息长流之中，汇集了好玩的点子、稀奇的思绪、纷杂的内容和用户的观点。当然推特也有让人不爽的地方，那就是难以将这些存留下来。

一个解决办法是，运用推特的“favorite（收藏）”功能将tweets标记下来，过后再看。

但其中有个问题是，推特并未提供方便的管理和检索“收藏”的功能。特别是当我们想定期查阅和检索“收藏”时，此类功能的缺失让我们觉得比较不方便。那么我们该怎么做呢？

其实我们可以为这些“收藏”生成一个RSS Feed。这是推特所支持的，且很便捷。

http://twitter.com/favorites/[**insert\_your\_ID_here**].rss就是你的收藏的RSS Feed地址，以你的推特用户名替换掉方括号的部分。如果你用Google Reader的话，就可以把这个URL添加进你的订阅了。

 [1]: http://www.twitterrati.com/author/buckpost/ "View all posts by Mark Evans"