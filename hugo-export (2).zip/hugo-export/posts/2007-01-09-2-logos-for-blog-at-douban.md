---
title: PS了俩豆瓣博客标志
author: Chouj
type: post
date: 2007-01-09T02:31:00+00:00
url: /2007/01/09/2-logos-for-blog-at-douban/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/01/ps.html
views:
  - 2295
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969840
categories:
  - 我尝试
tags:
  - blog
  - 图片
  - 豆瓣

---
<span style="font-size:180%;"><span style="font-weight: bold;">每</span></span>个收录在<a href="http://www.douban.com/" target="_blank">豆瓣</a>“我上”里的博客，可以有其自己的logo，配合简介说明，醒目而个性。开动PS画了两个：一是应麦子所托，给他的<a href="http://manonfire.yculblog.com/" target="_blank">射手座的箭之所向</a>；一是单纯给自己。

<a href="http://bp3.blogger.com/_2MqU1LfBbeM/RaMF2zf33QI/AAAAAAAAABI/LBeV2wyse1M/s1600-h/u%3D2467558835,331480980%26gp%3D0.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5017860848915832066" style="margin: 0pt 10px 10px 0pt; cursor: pointer;" src="http://bp3.blogger.com/_2MqU1LfBbeM/RaMF2zf33QI/AAAAAAAAABI/LBeV2wyse1M/s400/u%3D2467558835,331480980%26gp%3D0.jpg" border="0" alt="" /></a>
  
<span style="font-size:180%;"><span style="font-weight: bold;">搜</span></span>到这个图，就知道该怎么处理了：麦子、箭、笔，三元素的交融，付之以热血与坚毅的红黄黑。
  
<a href="http://bp0.blogger.com/_2MqU1LfBbeM/RaMTuDf33RI/AAAAAAAAABU/8WmF59FNxLA/s1600-h/%E5%B0%84%E6%89%8B.gif" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5017876091754765586" style="margin: 0pt 10px 10px 0pt; cursor: pointer;" src="http://bp0.blogger.com/_2MqU1LfBbeM/RaMTuDf33RI/AAAAAAAAABU/8WmF59FNxLA/s320/%E5%B0%84%E6%89%8B.gif" border="0" alt="" /></a>
  
<span style="font-size:180%;"><span style="font-weight: bold;">听</span></span>取麦子的建议，舍弃对称，再度雕琢至：笔自有其角度与力度，箭自有其昂扬与凌厉。
  
<a href="http://bp0.blogger.com/_2MqU1LfBbeM/RaL_LTf33OI/AAAAAAAAAAw/Jgt8RUT7arE/s1600-h/%E5%B0%84%E6%89%8BRR.gif" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5017853504521755874" style="margin: 0pt 10px 10px 0pt; cursor: pointer;" src="http://bp0.blogger.com/_2MqU1LfBbeM/RaL_LTf33OI/AAAAAAAAAAw/Jgt8RUT7arE/s400/%E5%B0%84%E6%89%8BRR.gif" border="0" alt="" /></a>
  
<span style="font-size:180%;"><span style="font-weight: bold;">话</span></span>说到这份儿上，自不用掩饰我的愉悦：07年开篇即有得意之作，虽然技术上没什么含量，诚然贵在创意。
  
<a href="http://bp0.blogger.com/_2MqU1LfBbeM/RaL_0Tf33PI/AAAAAAAAAA4/1Ofa0-KjIKM/s1600-h/%E6%9C%AA%E6%A0%87%E9%A2%98-1.gif" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5017854208896392434" style="margin: 0pt 10px 10px 0pt; cursor: pointer;" src="http://bp0.blogger.com/_2MqU1LfBbeM/RaL_0Tf33PI/AAAAAAAAAA4/1Ofa0-KjIKM/s400/%E6%9C%AA%E6%A0%87%E9%A2%98-1.gif" border="0" alt="" /></a>
  
<span style="font-size:180%;"><span style="font-weight: bold;">这</span></span>个标志更没什么技术含量，玩了一把汉字与字母结合的小把戏，而且结合的生硬了。