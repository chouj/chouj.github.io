---
title: 我最喜欢的五个wordpress插件
author: Chouj
type: post
date: 2007-10-01T15:03:52+00:00
url: /2007/10/01/my-favourite-wordpress-plugins/
views:
  - 3102
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969710
categories:
  - 我表达
tags:
  - Plugin
  - WordPress

---
在小小的blog圈儿里，不被这种点名游戏波及到还真是难，尤其当大家发现你还没参与进来的时候。<a href="http://www.xuchi.name/blog/2007/09/22/something-for-blackberry-7230/" title="BlackBerry的另一些小东东" target="_blank">上一文</a>说<a href="http://parandroid.com/my-faviwordpress-plugin" title="Wordpress插件之我喜欢  " target="_blank">被老帕点了名</a>，想倦怠过去，结果发现更早的时候——9月15号——就被<a href="http://lauwei.com/2007/09/the-six-wordpress-plugin-i-love-192.html" target="_blank">EaSy</a><a href="http://lauwei.com/2007/09/the-six-wordpress-plugin-i-love-192.html" target="_blank">点了的</a>。一个胳膊拧不过俩大腿（其实一个大腿也拧不过），赶巧十一有空，就给芸芸众生（<a href="http://jiangzhanyong.com/2007/09/blogging-game-my-favorite-wordpress-plugins-541.html" target="_blank">总统</a>也算芸芸众生，哈哈）一个交代吧。

桑椹的**[中文 WordPress 工具箱][1] ★****★****★****★****★**

<small>中文wordpress blog居家旅行必备良药</small>

**[Ultimate Tag Warrior][2]** **★****★****★****★****★**

<small>UTW，标签支持；tag王者，谁与争锋</small>

**[©Feed][3]** **★****★****★****★☆**

<small>强大的feed footer信息添加功能，实在是弃之不能</small>

**[Math Comment Spam Protection][4]** **★****★****★****★**

<small>防御spam的小小算数题，人肉spam才攻的破</small>

**[ST Add Related Posts to Feed][5]** **★****★****★****☆**

<small>根据UTW标签生成相关文章到feed里，简单实用相关度高</small>

游戏已经过气了（我相信总统不会跟我一般见识，呵呵），加上周遭一干人全没落下，我就不点名儿了，点了也白点，谨祝黄金粥愉快～

 [1]: http://yanfeng.org/blog/wordpress/kit "访问插件主页"
 [2]: http://www.neato.co.nz/ultimate-tag-warrior/ "访问插件主页"
 [3]: http://bueltge.de/wp-feed-plugin/204/ "访问插件主页"
 [4]: http://sw-guide.de/wordpress/plugins/math-comment-spam-protection/ "访问插件主页"
 [5]: http://www.solo-technology.com/apps.html "访问插件主页"