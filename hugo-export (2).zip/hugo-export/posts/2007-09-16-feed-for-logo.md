---
title: 资源：RSS Feeds for Logos
author: Chouj
type: post
date: 2007-09-16T12:28:43+00:00
url: /2007/09/16/feed-for-logo/
views:
  - 1192
  - 1192
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969983
categories:
  - 资源
tags:
  - RSS设计
  - Symbol

---
<img src="http://www.logo-search.com/logo.png" height="100" width="101" />

<a href="http://www.logo-search.com/" title="logo search" target="_blank"><strong>Logo Search</strong></a>是一个以出售logo为业的商业网站，页面上陈列了诸多类别的标志，供买家选择，且提供了最新logo的rss feeds，方面查阅和检索。

喜欢logo设计的朋友可以订阅这些频道， 但请遵守该站<a href="http://www.logo-search.com/license.htm" title="协议" target="_blank">协议：</a>如若想使用该站提供的logo，请向该站购买，切勿擅自将该站logo篡改、转卖、发布，盗用。

[ <a href="http://www.logo-search.com/rss-feeds.htm" title="Rss Feeds for Logos" target="_blank"><strong>点此进入 Rss Feeds for Logos</strong></a> ]

[ <a href="http://www.rss-specifications.com/blog.htm#769" title="RSS Feeds for Logos" target="_blank">via </a>]