---
title: Feedburner已可统计来自鲜果的订阅数
author: Chouj
type: post
date: 2007-07-24T13:12:14+00:00
url: /2007/07/24/subscribe-number-from-xianguo/
views:
  - 1415
  - 1415
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969965
categories:
  - 新闻
tags:
  - Feed Dance
  - Feedburner
  - Subscribe
  - Xianguo

---
<img src="http://www.feedburner.com/fb/i/logo_150w.gif" title="feedburner-aboutrss" alt="feedburner-aboutrss" height="27" width="156" />

<img src="http://photo6.yupoo.com/20070626/224426_792388676_jrchrsfq.jpg" height="44" width="152" />

饭否上，IwfWcf[说][1]：

> 猜得没错，FeedBurner果然可以统计鲜果订阅数了&#8230;&#8230;

查看了下，确实如此，见图：

<img src="http://photo6.yupoo.com/20070724/204202_187304241_dhpzyzlg.jpg" alt="xianguo" height="194" width="310" />

这个小新闻所带来的订阅数Dance：

<p id="photoImgDivff80808113d707700113f83f8f9c00d6" style="width: 312px; position: relative">
  <img src="http://photo8.yupoo.com/20070724/204201_1882644165_evliciaq.jpg" alt="dance" height="124" width="310" />
</p>

 [1]: http://fanfou.com/statuses/Pb9T8_PsUPs