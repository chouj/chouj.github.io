---
title: 黑莓7230死机重启后再激活上网的技巧
author: Chouj
type: post
date: 2009-03-11T08:10:45+00:00
url: /2009/03/11/blackberry7230-reset-and-active/
views:
  - 3140
duoshuo_thread_id:
  - 1279764464521969918
categories:
  - 我尝试
  - 我表达
tags:
  - 激活上网
  - 黑莓

---
<img src="http://www.mobiletor.com/images/rim-blackberry-logo07.jpg" border="0" alt="blackberry" width="180" align="left" />

_生命不息，折腾不止，黑莓完好的符合了这一精神，尤其是在我把7230折腾上cmwap之后。_

似乎因为软件稳定性问题，我的BB总是会遭遇jvm 523 error系统进程严重错误，然后要求reset。再想上网就成了大问题，坛子里都说要重新导入Service Book云云，这要是在外面没电脑可咋办。综合网上资料摸索了番，发现如下方法可行：

  1. 黑莓死机或其他原因重启后，按shift(键位上A下面那坨)-alt(黑莓上cap这坨)-del三键再重启，重启过程挺快；
  2. 然后到Options里的Service Book，把internet[IPPP]undelete恢复回来；
  3. 再到TCP里置为空；
  4. 打开QQ(肯定有QQ的吧)，登录，进度走到10直到说网络不好连接中断；
  5. 回到Options里Service Book，把IPPP这个再删掉，TCP里填上cmwap（我是用的cmwap）；
  6. 再开QQ登录，就可以登上啦～～（至少我的这样可以成功）

解决jvm 523 error还是得靠软件，我换成BerryMail的QQ05就好了，没再error reset。现在可以上空中OperaMini、QQ、MSN了，就是Xrose连接不上，放弃之。