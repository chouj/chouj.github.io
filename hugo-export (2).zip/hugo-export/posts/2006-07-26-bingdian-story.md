---
title: 读鸟冰点故事
author: Chouj
type: post
date: 2006-07-26T04:42:00+00:00
url: /2006/07/26/bingdian-story/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/07/blog-post_6268.html
views:
  - 1849
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969789
categories:
  - 我思考
  - 我记录
tags:
  - 冰点故事
  - 读书

---
在我看来，新闻的最高使命，绝不是“记录”下来一点什么，以后供个把历史学家来做资料。恰恰相反，新闻如果不能影响“今天”，那才是失职和对我们职业天条的亵渎。新闻的使命在于“影响”当代而不是“记录”当代，完全是由新闻的基本特征所决定的。这个基本特征是——“新闻只有一天的生命力”！

——李大同

<p align="center">
  <a href="http://www.douban.com/subject/1437900/" target="_blank"><span style="font-size:85%;"><img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://images.dangdang.com/images/9054917.jpg" border="0" alt="" width="446" height="816" /></span></a>
</p>

<p align="left">
  回了武汉，就开始翻这本《<a href="http://www.douban.com/subject/1437900/" target="_blank">冰点故事</a>》，其实是为看《用新闻影响今天》作铺垫的。
</p>

<p align="center">
  <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://otho.douban.com/lpic/s1913740.jpg" border="0" alt="" />
</p>

<p align="left">
  之前一期《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》都没看过，只是从其被停刊整顿才知道有这么一个特别的周刊的。书里讲述了《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》由无到有，有软到硬的过程，最终成为了百姓喉舌，成为了舆论监督的利器。我看这本书主要还是用来了解《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》的，另外倒还有个收获，就是见识了纯搞文科的人是怎么写东西的，里面的一些句子在我看来跟CET－6里的句式似的，晦涩难懂。再提一个，里面的一些关于刊物创办的理论探索被我一目十行掉了，不做新闻这行的不必要关心，其实木想到新闻的理论也如此艰深。
</p>

<p align="left">
  关于李大同，倒是从字里行间看出丫有些恃才傲物，也确实有才。所以期待哈子新出的《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》周刊纪事，《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》被停后的故事也会相当精彩。
</p>

<p align="left">
  《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》：这个链接可以看到《<a href="http://zqb.cyol.com/node/node_3053.htm" target="_blank">冰点</a>》从1998到2003的文章。
</p>