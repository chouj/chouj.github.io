---
title: 还是暑假的photo
author: Chouj
type: post
date: 2006-09-17T00:00:00+00:00
url: /2006/09/17/photoes-in-summer-vocation/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/photo.html
views:
  - 2388
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969809
categories:
  - 我记录
tags:
  - 图片
  - 物理系
  - 苏州

---
![][1]

**<span style="font-size:180%;">焰</span>火** 常熟

![][2]

**<span style="font-size:180%;">东</span>**方之珠

![][3]

**<span style="font-size:180%;">金</span>**茂大厦 实在是高

![][4]

**<span style="font-size:180%;">从</span>**金茂85层往下看 晕不？ Ps.那底下是54层&#8230;

![][5]

**<span style="font-size:180%;">社</span>**会实践队队服 不是我design的

![][6]

**<span style="font-size:180%;">我</span>**之前为实践队队服做的一个标志，结果被枪毙了，死因：太抽象，不知道是哪校哪系的。不过我自我感觉良好，呵呵。

**<span style="font-size:180%;">最</span>**近为了社会实践参加评优忙活的屁颠屁颠的：几千字的东西，照片挑拣，DV剪辑处理，光盘Autorun制作，音频材料整理，1天内统统搞定，所有人都有分工总结，累死人。又不幸被辅导员钦点去做最后的材料整合，这两天也就充实了，可惜还得在总结里写上这么一句：“当一切美好通过自己的双手结晶出来时，心里只有感动。”不过，凭良心说，这次社会实践确实让我们赚到了。

**<span style="font-size:180%;">拜</span>**此次突击总结所致，不幸又玩转了一款傻瓜小软件：<span style="color: #ff9900;">AutoPlay Media Studio 6.0</span>。为光盘做Autorun界面的，确实傻瓜，可视化编辑器嘛，软件提供了很多模版，功能还是比较强大的。输出方式多样：直接刻录数据、驱动器文件夹、压缩EXE、ISO，相当完善周全。唉，为了咱系的学生工作，一个又一个Software就被我这样攻克了，虽然很符合我的兴趣，很有成就感，可惜完全落入了“能者多劳”这么一栓死我的窠臼中。每当丫们路过我的座位，看着屏幕上Premiere、CoolEdit等颇似“专业”的软件，我就能收到“丫真一强人”的赞叹了，是该苦笑呢？还是该得意呢？

<span style="font-size:180%;"><strong>PS</strong></span>.相片空间首次用了google的[picasaweb][7]，上传速度还相当的快，250M，比google pages空间还大。只是可惜：一，丫必须配备picasa本地软件，无法从网页上传；二，最不能让我容忍的是，丫居然不支持gif，真是相当无语，咋就不能完美点呢？

 [1]: http://lh3.google.com/xcchris/RQqviVGzABI/AAAAAAAAAAc/I1fVqjhA2U0/%E7%85%A7%E7%89%87-131.jpg
 [2]: http://lh5.google.com/xcchris/RQqx6n_QABI/AAAAAAAAAA0/cq6Ocv8INBA/DSC05414.jpg
 [3]: http://lh4.google.com/xcchris/RQqxY3EaABI/AAAAAAAAAAk/dWkvijs-Bfs/%E7%85%A7%E7%89%87-138.jpg
 [4]: http://lh4.google.com/xcchris/RQqxgfs8ABI/AAAAAAAAAAs/kTCn5Jz2XnQ/DSC05421.jpg
 [5]: http://lh3.google.com/xcchris/RQq1vdBLABI/AAAAAAAAAA8/nONO_UiULvU/%E7%A4%BE%E4%BC%9A%E5%AE%9E%E8%B7%B504%E5%89%AF%E6%9C%AC.jpg
 [6]: http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_社会实践.gif
 [7]: http://picasaweb.google.com