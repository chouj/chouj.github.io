---
title: '[转]达芬奇密码与宗教愤青'
author: Chouj
type: post
date: 2006-05-27T04:20:00+00:00
url: /2006/05/27/da-vinc-code/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/05/blog-post_27.html
views:
  - 1685
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969778
categories:
  - 我记录
tags:
  - 电影
  - 达芬奇密码

---
<img style="CURSOR: pointer" onclick="javascript:window.open(this.src);" src="http://img.verycd.com/posts/0605/post-302383-1148086060.jpg" border="0" alt="" width="500" />

<img style="CURSOR: pointer" onclick="javascript:window.open(this.src);" src="http://bt.newmov.com/torrents/2/4076.jpg" border="0" alt="" width="500" />

_<span style="font-size: 130%; color: #ff0000;">转一篇影评，来自 </span><a href="http://www.fawjournal.com/" target="_blank"><span style="font-size: 130%; color: #ff0000;">纵横</span></a>_ 

 **宗教战争从来残酷，宗教愤青也比喊喊口号的愤青同伴可怕得多。**[文/花落去]

索尼－哥伦比亚显然对影片抱有厚望，倾亿万巨金，请出朗·霍华德、汤姆·汉克斯两匹戴着奥斯卡金笼头的骏马，以伊安·麦克莱恩、奥黛丽·塔图、阿尔弗雷德 ·莫利纳和让·雷诺等名角并辔，用实景拍摄的卢浮宫独家印花地板做车厢，企望这部战车能一举超越《蜘蛛侠2》。

看起来这一注押对了，尽管影片在戛纳电影节首映时反响寥寥，但原著空前绝后的畅销已经是电影回本的保证。走出影院的大部分观众面带失望，很多人认为影片中规中矩，了无新意。阅读过原著的观众更认为，影片没有原著峰回路转的感觉，更没有反映出原书的深度和颠覆性意义。

梵蒂冈对待影片的态度毫无新意，号召全球信众群起抵制。尽管教皇早已承认审判伽利略的错误，但看起来教廷在对待异端的态度上并无多大进步。《达芬奇密码》中多处引用“伪经”——不在教廷正典经书之列的“福音书”——来作为解谜关键，这一点尤其激怒主教们。

相比之下，最终耶稣婚配产子、基督指定女性创立教会等结论倒因其戏剧性而不那么引起学术质疑。但随着去年考古学界最为轰动的成就——《犹大福音》的发现，“伪经”是基督教早期正统的经书这一观点已经为越来越多历史学家认可。

梵蒂冈如果只在细节上锱铢必较，哪天弄个伽利略第二出来也不是不可能。根深蒂固的信仰并不会因为一些新的学术观点出现就受到动摇，天主教立宗上千年来，无数智慧头脑早已奠定了它丰富淳厚的信仰基础，又岂是一本小说、一部电影所能动摇？

倒是塞拉斯这个人物颇堪玩味，这个角色我们姑且称之为“宗教愤青”。与一切愤青一样，塞拉斯文化程度不高，但人不论高低贵贱，总有寻找信仰、解释人生的冲动，既然修养不足以自产自销，那便只好唯能说者从之。

塞拉斯对阿林主教敬若神明，对冒牌导师也毕恭毕敬，正是思想信仰上极端无助后的反作用。恐怖组织中，人肉炸弹等基层人士往往头脑简单，教育低下，他们信奉的不是经书，而是对经书的解释。所以宗教战争从来残酷，宗教愤青也比喊喊口号的愤青同伴可怕得多——后者可从来没单枪匹马灭掉一个存在将近千年的神秘组织，一个零头都没有。

<table style="width: 100%;" border="0" cellspacing="1" cellpadding="5">
  <tr>
    <td style="BORDER-RIGHT: #cccccc 1px solid; BORDER-TOP: #cccccc 1px solid; BORDER-LEFT: #cccccc 1px solid; BORDER-BOTTOM: #cccccc 1px solid; BACKGROUND-COLOR: #f6f6f6" width="100%">
      走出影院的大部分观众面带失望，很多人认为影片中规中矩，了无新意。阅读过原著的观众更认为，影片没有原著峰回路转的感觉，更没有反映出原书的深度和颠覆性意义。
    </td>
  </tr>
</table>

<span style="color: #ff0000;">严重同意！</span>