---
title: FeedSweep:一款显示RSS内容的Widget
author: Chouj
type: post
date: 2007-08-09T11:18:09+00:00
url: /2007/08/09/feedsweep-to-show-feed-items/
views:
  - 1427
  - 1427
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969972
categories:
  - 工具
tags:
  - feedsweep
  - widget

---
<img src="http://photo4.yupoo.com/20070808/193358_1700384427_fjsvtful.jpg" alt="feedsweep" class="Photo" height="162" width="468" />

如果你想将RSS Feed里的内容显示到blog的侧栏上，那么就可以选用**FeedSweep**这项服务（无需注册），它支持将Feed里的标题，描述，日期等详尽信息读取出来，生成widget，用户可以将其贴到blog上。

此服务的Basic版本可免费使用，但只能添加一个Feed，目前Feed合烧早就不是问题，所以Basic版绝对够用。在widget定制中，用户可自行设置如下项目：

  1. widget标题
  2. 显示条目数量
  3. widget宽度
  4. 是否显示Feed标题
  5. 是否显示每篇头条
  6. 是否显示每篇摘要
  7. 是否显示每篇发布的日期
  8. 是否在新窗口打开条目
  9. widget标题的链接指向
 10. widget颜色

最后生成javascript代码，添加到合适的位置即可。<a href="http://www.xuchi.name/blog" title="抽儿" target="_blank">抽儿</a>做了一个供参考，如下(RSS订阅读者可能无法在阅读器中看到效果)：



[<a href="http://www.feedsweep.com/products/feedsweep/" title="点击进入FeedSweep" target="_blank"><strong>点击进入FeedSweep</strong></a>]

<font color="#c0c0c0"><small>以此矬文纪念070809，XD~~</small></font>