---
title: Yourrss.jp:用RSS打造Flash滚动标题榜
author: Chouj
type: post
date: 2007-03-02T13:14:12+00:00
url: /2007/03/02/yourrss-widget/
views:
  - 8841
  - 8841
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969936
categories:
  - 工具
tags:
  - widget
  - yourrss

---
<a href="http://yourrss.jp/" target=" _blank"><img src="http://yourrss.jp/images/top_logo.gif" border="0" height="69" width="167" /></a>

<big><big>该</big></big>站**YourRSS.jp**提供一款很炫的服务，即打造**blog的Flash滚动标题榜**，效果如下：

<!-- YOURRSS.JP BLOGPARTS TopiX-->

<!-- YOURRSS.JP BLOGPARTS TopiX-->

<big><big>是</big></big>不是很棒？想拥有她很简单，只要你有自己blog的RSS地址，不用惧怕其日文界面，这里有Chou截屏给出的步骤：先进入<a href="http://yourrss.jp/blogparts/topix/srcmaker.html" target="_blank">这里</a>。

<img src="http://photo8.yupoo.com/20070502/205350_713253051.jpg" height="233" width="468" />

<big><big>按</big></big>上图操作，即可生成代码，然后将代码贴在您blog的相应地方即可，推荐侧栏sidebar处。只是该站位于日本，可能要稍微loading一下。

** <a href="http://yourrss.jp" target="_blank">点此进入</a>**

Technorati Tags: <a href="http://technorati.com/tag/yourrss" class="performancingtags" rel="tag">yourrss</a>, <a href="http://technorati.com/tag/widget" class="performancingtags" rel="tag">widget</a>