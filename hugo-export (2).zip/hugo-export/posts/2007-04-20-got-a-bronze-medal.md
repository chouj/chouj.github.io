---
title: 得了个铜牌
author: Chouj
type: post
date: 2007-04-20T12:42:00+00:00
url: /2007/04/20/got-a-bronze-medal/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/blog-post_20.html
views:
  - 2151
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969875
categories:
  - 我记录
tags:
  - Yeeyan
  - 译言

---
<span style="font-size:180%;"><span style="font-weight: bold;">整</span></span>个题目忽悠下，一个多礼拜木在这边更新鸟。

<span style="font-size:180%;">今</span>天在译言网上注册了个ID，胡乱诌了篇之前的文章发了上去，居然被评为铜牌译作，升级为秀才名号，那个惊讶啊。胡乱往后翻，不是银牌就是金牌。。。。看来有可能随便整篇文章上去都是铜牌，hoho <a href="http://www.yeeyan.com/articles/view/Chris/780" target="_blank">地址见此</a>

<span style="font-size:180%;">随</span>便翻到个<a href="http://hichris.cn/" target="_blank">blog</a>，主人也叫Chris，去打了打招呼。

<span style="font-size:180%;">现</span>在写blog的时间非常零散，经常是Matlab在处理数据，我就在等结果出来的间隙，开个notepad.exe诌几个字，这时间节约的，要是用在背单词上该多好，哈哈。

再次开始没事逛论坛，<a href="http://forum.chinabloggernetwork.com/?fromuid=35" target="_blank">Forum of China Blogger Network</a>，这个站很新，目前还没什么值得看的，教程类文章还不够，也就和一些知名bloggers唠唠嗑。以后发展大了，原创教程多了才值得来找找资料。肯定很快，都是玩Blog的，必定能写。逛坛子附带的结论就是，独立blogger中，学生还是占大多数；写IT相关的诸多bloggers大部分不是IT相关行业的，有意思。

Update：铜牌长成白金牌了，貌似是根据读者数目的多寡由机器定的，hoho