---
title: '[翻译]为什么要用Feedburner的十大理由'
author: Chouj
type: post
date: 2007-09-02T13:29:27+00:00
url: /2007/09/02/10-reasons-why-you-should-choose-feedburner/
views:
  - 4498
  - 4498
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969978
categories:
  - 相关
  - 翻译
tags:
  - Feedburner
  - 理由

---
原文：[10 Ways You Can Use Feedburner to Improve Your Blog][1]
  
作者：_Mack Collier_
  
翻译：<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽筋儿 </a>

[<img src="http://bp1.blogger.com/_S_50sh4glvU/RrU0GQep7fI/AAAAAAAAAJA/kIITPv2Vz6o/s320/FB.gif" style="margin: 0pt 0pt 10px 10px; float: right" border="0" />][2]还在今年二月的时候，我就注意到一个有趣的现象：我的Feed读者赶上了我的日访者数。这值得我注意，我开始花费更多的时间来分析Feed统计数据，我也花掉大量的时间来研究[Feedburner][3]，我很快就发现Feedburner拥有一大堆丰富的功能来让bloggers传播、优化和追踪他们发布的内容。

1 &#8211; <span style="font-weight: bold">烧制一个Feed。</span>只要免费注册一个帐号，给Feed想一个好名字，(http://feeds.feedburner.com/你的blog名)就可以烧制啦。一旦你拥有了一个烧制的feed……<!--more-->

[<img src="http://bp2.blogger.com/_S_50sh4glvU/RrevAAep7iI/AAAAAAAAAJU/2KwtwvDTN1I/s200/VG.png" style="margin: 0pt 10px 10px 0pt; float: left" border="0" />][4]2 &#8211; <span style="font-weight: bold">添加订阅按钮到你的blog。</span> 你可以只添加一个RSS标志，也可以选择诸多的阅读器订阅按钮来添加，比如Google Reader、Netvibes、Bloglines等服务的订阅按钮。只要选好你想要的按钮，你blog的BSP或程序平台，Feedburner会自 动生成HTML代码！如果你提供的按钮正好是读者正在使用或熟悉的服务，那么他们更容易订阅你的blog，所以说摆几个按钮供选择会比较好。

3 &#8211; <span style="font-weight: bold">追踪blog的订阅状态</span>。 有趣的东西来了！Feedburner会告诉你，每天有多少人通过feed阅读你的blog，他们来自哪里，他们用了哪种浏览器和哪种feed阅读器，以 及其他的一些统计状态。优点就在于你能知道你的读者使用哪些阅读器来抓取你的feed。比如,一开始我只在blog上放了一个通用的Feedburner feed标志，最多加了个Bloglines的订阅按钮。但是当我开始追踪我的feed订阅状态时，我发现还有很多朋友是通过Google Reader、Netvibes、NewsGator来阅读我的blog的，所以我把这些服务的订阅按钮一股脑的加上啦。
  
[<img src="http://bp1.blogger.com/_S_50sh4glvU/Rreakwep7hI/AAAAAAAAAJM/B8hcnkOGdks/s400/FB%231.png" style="margin: 0px auto 10px; text-align: center" border="0" />][5]

4 &#8211; <span style="font-weight: bold">如果你拥有一个Blogger/Blogspot blog，用Feedburner来实现订阅状态追踪吧。</span> 如果你有一个Blogspot blog，这条新闻就有用了。Feedburner可以把你blog的feed地址转向到你用Feedburner烧制的feed地址。好处就是这样你就 可以清晰的掌握订阅状态，比如有多少订户，他们又是怎么在阅读你的内容。几个星期前，我就设置了feed地址转向，现在我知道我的日订阅量几乎翻了一倍。 Feedburner官方blog给出了[转向设置的详细解释][6]。

5 &#8211; <span style="font-weight: bold">让你的读者能通过E-mail来订阅你的feed。</span>这 是另外一种很棒的方法来让你的读者在获取你的内容上多一种选择。乐于通过邮件阅读你的内容的人可能没有规律的时间来阅读你的blog，所以希望能选择通过 电邮来获知更新。Feedburner可以方便的生成一个E-mail订阅框，用于显示在blog上，而且你也可以获知谁通过邮件订阅了你的feed，以 及每天有多少次阅读是通过邮件订阅完成的。我在四月加上了E-mail订阅功能，而且现在有了35个订阅者。看起来人数比较少，但没提供这个服务的话，一 个多月内通过e-mail的一千多次阅读量就没法实现了。总而言之，你为你的读者提供的订阅方式越多越好。

6 &#8211; <span style="font-weight: bold">追踪你的访客和访问统计。</span>Feedburner 同样可以追踪到你的blog有多少访客，以及他们来自哪里。只要在你blog的模板上加一小段代码，就可以实现这个功能。虽然在我看来这项服务不算精准和 及时，但如果你仅仅想知道有多少人访问了你的blog，他们看过哪些内容，那么这个功能足以胜任。而且，Feedburner刚刚将他们原来需要收费的一 些统计服务变成免费的了。（[译者][7]：这个功能还是不要启用的好。）

7 &#8211; <span style="font-weight: bold">添加feed交互按钮。</span>让 你的feed拥有一些交互、共享的功能是很棒的。你可以添加一些链接显示文章的评论数，Technorati的反向链接数，以及方便进行Email共享等 等。同时，该功能也可以添加一些链接按钮让你的读者将你的文章收录进Del.icio.us、Facebook、Digg和其他社会性站点。
  
[<img src="http://bp2.blogger.com/_S_50sh4glvU/RrewmAep7lI/AAAAAAAAAJs/m6yjDqix9Gk/s400/FeedFlares.png" style="margin: 0pt 0pt 10px 10px; " border="0" />][8]

8 &#8211; <span style="font-weight: bold">在你的Email里或blog上添加动态头条显示。</span>这个小巧的功能可以让你在email里或blog上开辟出一块儿区域，显示出你blog的名字，以动态滚动的形式显示最新文章的标题同时给出链接，而且还有一个feed的订阅按钮在上面。我没有用到这个功能，但看起来这个东东有利于在你的email对象面前展示你的文章。

[<img src="http://bp1.blogger.com/_S_50sh4glvU/Rre0Owep7mI/AAAAAAAAAJ0/n4sYRxcxEtk/s400/Headline.png" style="margin: 0pt 10px 10px 0pt; " border="0" />][9]

9 &#8211; <span style="font-weight: bold">点击率阅读率追踪。</span>这个功能可以列出你的每篇文章被阅读了多少次，你的读者点击了多少次接入你的blog的链接。和其他统计状态一样，你可以查看每日、每星期、每月或全部时间的结果。想知道哪篇日志最热门，读者最喜欢查看那篇日志的评论，那么这个功能就很有效。（[译者][7]：现在最好别打开这个功能）

10 &#8211; <span style="font-weight: bold">整合网摘或相册。</span>这个服务能让你实时发布你收藏的网摘（比如Del.icio.us上）或上传的相片（比如flickr上）。网摘和相片都会自动整合到你的feed中去。

总 结就是，Feedburner致力于提供bloggers需要的服务，而且他们已经做到，提供的服务功能强大。最近他们被Google收购，已经为 bloggers带来了巨大的变化。如果你确实想优化一下你的feed，那么feedburner正是你需要的工具。（译者：除了4、8两点，其他的[Feedsky][10]也可以做到，可对照着理解。现在为什么不用Feedburner的一大理由：因为被Gfwed。囧）

 [1]: http://moblogsmoproblems.blogspot.com/2007/08/10-ways-you-can-use-feedburner-to.html
 [2]: http://bp1.blogger.com/_S_50sh4glvU/RrU0GQep7fI/AAAAAAAAAJA/kIITPv2Vz6o/s1600-h/FB.gif
 [3]: http://www.feedburner.com/
 [4]: http://bp2.blogger.com/_S_50sh4glvU/RrevAAep7iI/AAAAAAAAAJU/2KwtwvDTN1I/s1600-h/VG.png
 [5]: http://bp1.blogger.com/_S_50sh4glvU/Rreakwep7hI/AAAAAAAAAJM/B8hcnkOGdks/s1600-h/FB%231.png
 [6]: http://blogs.feedburner.com/feedburner/archives/2007/07/feedburner_integration_for_blo.php
 [7]: http://www.xuchi.name//
 [8]: http://bp2.blogger.com/_S_50sh4glvU/RrewmAep7lI/AAAAAAAAAJs/m6yjDqix9Gk/s1600-h/FeedFlares.png
 [9]: http://bp1.blogger.com/_S_50sh4glvU/Rre0Owep7mI/AAAAAAAAAJ0/n4sYRxcxEtk/s1600-h/Headline.png
 [10]: http://www.feedsky.com/