---
title: 贴图不说话
author: Chouj
type: post
date: 2007-05-03T12:58:25+00:00
url: /2007/05/03/pictures-of-forbidden-city-in-golden-week/
views:
  - 3251
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969678
categories:
  - 我记录
tags:
  - 五一
  - 图片
  - 故宫
  - 旅游
  - 黄金周

---
<p align="center">
  <img src="http://photo7.yupoo.com/20070503/205027_1697128195_djixayjd.jpg" title="2007五一故宫" alt="2007五一故宫" height="300" width="450" />
</p>

<p align="center">
  <img src="http://photo8.yupoo.com/20070503/205027_1656776720_hmhvrwel.jpg" title="2007五一故宫" alt="2007五一故宫" height="450" width="300" />
</p>

**<a href="http://news.163.com/07/0503/10/3DIGMQN60001124J.html" target="_blank">报道见此</a>**

Technorati Tags: <a href="http://technorati.com/tag/%E4%BA%94%E4%B8%80" class="performancingtags" rel="tag">五一</a>, <a href="http://technorati.com/tag/%E6%97%85%E6%B8%B8" class="performancingtags" rel="tag">旅游</a>, <a href="http://technorati.com/tag/%E9%BB%84%E9%87%91%E5%91%A8" class="performancingtags" rel="tag">黄金周</a>, <a href="http://technorati.com/tag/%E6%95%85%E5%AE%AB" class="performancingtags" rel="tag">故宫</a>, <a href="http://technorati.com/tag/%E5%9B%BE%E7%89%87" class="performancingtags" rel="tag">图片</a>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>