---
title: 部长带来的（三）
author: Chouj
type: post
date: 2006-01-30T14:01:00+00:00
url: /2006/01/30/what-department-head-bring-3/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/01/blog-post_30.html
views:
  - 1635
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969755
categories:
  - 我记录
tags:
  - 部长

---
部长 当然带来了工作业绩！

通讯，一个经常和宣传弄混淆的部门，也是一个新兴的部门。每当有人问我，通讯都做什么，或通讯和宣传有什么区别时，我就会告诉他：通讯就是用现代化的手段，借助现代的一些平台，比如报纸、网络、广播等进行宣传；普通说的宣传，则是利用传统的展板、海报进行宣传，言语中仿佛透漏着自豪之情。

作部长，当然要有那么点成绩，2005.12.29－2006.12.30的一年时间里，独立创作了28篇挂在网上的新闻，不包括和别人一起的，以及网上见不到的，罗列在下面了。从不会写、尝试写，到最后写的得心应手；从醉晚亭网站到华中大在线，都可以瞥见偶的拙作。算是成长么？可以说是吧，至少知道了新闻该怎么写，悄悄告诉你，新闻想写的好不容易，嘿嘿。另外，也知道了学校媒体是怎么运作的之类，算是从另外的角度了解学校了，这不是每个人都会知道的事情，不一般的回忆了。

写新闻花了不少时间，因为事情多，很多杂事需要报道。无聊时想想自己走新闻这条路算了，新闻美女又多，呵呵，不过我还是有自知之名的，既没八两，也没半斤。

<a href="http://www.zuiwan.net/news/2005-4/2005415225948.htm" target="_blank">[物理]关注物理系特色团日大型活动</a>
  
<a href="http://www.zuiwan.net/news/2005-4/2005419185434.htm" target="_blank">[组图]物理系开放日发扬学科特色</a>
  
<a href="http://news.hustonline.net/Html/2005-4-24/19716.shtml" target="_blank">庆世界物理年 志愿者走进省科技馆</a>
  
<a href="http://www.zuiwan.net/news/2005-4/2005424224412.htm" target="_blank">[物理]省科技馆《走进物理——庆祝世界物理年》大型科普知识展览印象</a>
  
<a href="http://www.hustnews.com/html/2005-5-15/20179.shtml" target="_blank">物理系“与优秀团干面对面”主题活动举行</a>
  
<a href="http://www.hust.edu.cn/content/content_18156.html" target="_blank">清华大学朱鹤年教授为物理系师生作报告</a>
  
<a href="http://news.hustonline.net/Html/2005-6-3/20690.shtml" target="_blank">物理系足球联赛圆满结束 0401班取得冠军</a>
  
<a href="http://news.hustonline.net/Html/2005-6-10/20835.shtml" target="_blank">物理系本科生与毕业生交流会成功举行</a>
  
<a href="http://news.hustonline.net/Html/2005-6-19/21049.shtml" target="_blank">物理科普知识竞赛决赛圆满结束 水电学院代表队摘得桂冠</a>
  
<a href="http://www.zuiwan.net/news/2005-7/200579183055.htm" target="_blank">[物理]物理系学习16号文件之自拍DV首映</a>
  
<a href="http://news.hustonline.net/Html/2005-9-30/22527.shtml" target="_blank">物理系迎新晚会 一样的精彩 不一样的感觉</a>
  
<a href="http://www.zuiwan.net/news/2005-10/2005101882137.htm" target="_blank">[物理]物理系围棋比赛宣告结束</a>
  
<a href="http://www.zuiwan.net/news/2005-10/20051021185216.htm" target="_blank">[物理]重温入团誓词，增强团员意识</a>
  
<a href="http://zuiwan.net/zqtyys/news1.asp?id=160" target="_blank">[物理]增强团员意识 物理系在行动</a>
  
<a href="http://news.hustonline.net/Html/2005-11-2/23617.shtml" target="_blank">物理系学生党支部扎实推进党员先进性教育</a>
  
<a href="http://www.zuiwan.net/news/2005-11/2005115123223.htm" target="_blank">[物理]学生会内部建设：院系间加强交流 共同进步</a>
  
<a href="http://news.hustonline.net/html/2005-11-18/24393.shtml" target="_blank">物理系“摩擦力”杯拔河比赛考量团队精神</a>
  
<a href="http://news.hustonline.net/html/2005-11-19/24415.shtml" target="_blank">“手帕”代“纸巾”：物理学子倡导节约新方法</a>
  
<a href="http://news.hustonline.net/html/2005-11-21/24516.shtml" target="_blank">科技节物理设计与创新实验大赛初赛进行</a>
  
<a href="http://news.hustonline.net/html/2005-11-22/24552.shtml" target="_blank">物理系“友谊杯”乒乓球赛日前揭幕</a>
  
<a href="http://news.hustonline.net/html/2005-11-22/24558.shtml" target="_blank">物理学子特色团日：厨艺大比拼 能力大锻炼</a>
  
<a href="http://www.zuiwan.net/news/2005-11/20051124161012.htm" target="_blank">[物理]分团委开展增强团员意识大讨论</a>
  
<a href="http://news.hustonline.net/html/2005-11-29/24839.shtml" target="_blank">物理系第二届“友谊”杯乒乓球赛近日圆满结束</a>
  
<a href="http://news.hustonline.net/html/2005-12-6/25318.shtml" target="_blank">指点迷津 排忧解惑：优秀团员事迹报告会举行</a>
  
<a href="http://news.hustonline.net/html/2005-12-11/26056.shtml" target="_blank">你合理使用电脑了吗：电脑使用情况大调查</a>
  
<a href="http://news.hustonline.net/html/2005-12-11/26044.shtml" target="_blank">历时半个月 物理系寝室创新设计大赛举行</a>
  
<a href="http://www.zuiwan.net/news/2005-12/20051213115430.htm" target="_blank">[物理]物理设计与创新实验大赛圆满结束</a>
  
<a href="http://www.zuiwan.net/news/2006-1/200612155519.htm" target="_blank">[物理]物理系学代会：忆往昔 览今朝 贺新年</a>