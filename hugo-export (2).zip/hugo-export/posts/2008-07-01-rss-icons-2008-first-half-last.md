---
title: 08上半年出炉的RSS图标精选（完）
author: Chouj
type: post
date: 2008-07-01T05:31:35+00:00
url: /2008/07/01/rss-icons-2008-first-half-last/
views:
  - 1638
  - 1638
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969740
categories:
  - 标志
tags:
  - Download
  - Graph
  - Icon
  - RSS设计
  - Symbol
  - Vote

---
_08上半年精选RSS图标到了最后一辑，虽然图标质量参差不齐但仍然希望大家喜欢，积极投票_，:)

[poll id:5]

  * 2008.03.17 <a title="rss icons by ~billgoldbergmania" href="http://billgoldbergmania.deviantart.com/art/rss-icons-80260556" target="_blank"><strong>rss icons</strong> by ~billgoldbergmania</a>

![rss icons by ~billgoldbergmania][1]

<!--more-->

  * 2008.03.09 [**Pretty RSS Feed Icon** by ~Jvstin][2]

![Pretty RSS Feed Icon by ~Jvstin][3]

  * 2008.01.17 <a title="Free web 2.0 RSS icons by ~kurumizawa" href="http://kurumizawa.deviantart.com/art/Free-web-2-0-RSS-icons-74853733" target="_blank"><strong>Free web 2.0 RSS icons</strong> by ~kurumizawa</a>

<img src="http://pic.yupoo.com/xcchris/624835cafdd6/so4rd58t.jpg" alt="Free web 2.0 RSS icons by ~kurumizawa" width="425" height="300" />

  * 2008.03.13 <a title="stock icons by ~xmalami" href="http://xmalami.deviantart.com/art/stock-icons-79899248" target="_blank"><strong>stock icons</strong> by ~xmalami</a>

<img src="http://pic.yupoo.com/xcchris/490725cafdd8/0lgtnmf7.jpg" alt="stock icons by ~xmalami" width="468" height="406" />

  * 2008.03.13 <a title="My RSS icon by ~SETIcruncherXy" href="http://seticruncherxy.deviantart.com/art/My-RSS-icon-79879780" target="_blank"><strong>My RSS icon</strong> by ~SETIcruncherXy</a>

<img src="http://pic.yupoo.com/xcchris/469705cafdd7/nxpg9oss.jpg" alt="My RSS icon by ~SETIcruncherXy" width="468" height="468" />

  * 2008.03.07 <a title="RSS...? by ~wurstgott" href="http://wurstgott.deviantart.com/art/RSS-79386252" target="_blank"><strong>RSS&#8230;?</strong> by ~wurstgott</a>

<img src="http://pic.yupoo.com/xcchris/005145cafe38/medium.jpg" alt="RSS...? by ~wurstgott" width="467" height="325" />

  * 2008.01.26 <a title="Feed Sticker by *FoxSpellCaster" href="http://foxspellcaster.deviantart.com/art/Feed-Sticker-75656609" target="_blank"><strong>Feed Sticker</strong> by *FoxSpellCaster</a>

<img src="http://pic.yupoo.com/xcchris/727295cafdd7/8wcjycdm.jpg" alt="Feed Sticker by *FoxSpellCaster" width="350" height="350" />

  * 2008.01.02 <a title="TuxRSS - Universal .PNG by ~linuxmatt" href="http://linuxmatt.deviantart.com/art/TuxRSS-Universal-PNG-73641013" target="_blank"><strong>TuxRSS &#8211; Universal .PNG</strong> by ~linuxmatt</a>

<img src="http://pic.yupoo.com/xcchris/436945cafe38/oa2bash0.jpg" alt="TuxRSS - Universal .PNG by ~linuxmatt" width="192" height="192" />

  * 2008.01.19 <a title="RSS Feed Icons for Websites by ~SiddharthMaheshwari" href="http://siddharthmaheshwari.deviantart.com/art/RSS-Feed-Icons-for-Websites-75015314" target="_blank"><strong>RSS Feed Icons for Websites</strong> by ~SiddharthMaheshwari</a>

<img src="http://pic.yupoo.com/xcchris/558415cafe36/medium.jpg" alt="RSS Feed Icons for Websites by ~SiddharthMaheshwari" width="468" height="351" />

  * 2008.02.25 <a title="Blog Icons by ~reviewsaurusdotcom" href="http://reviewsaurusdotcom.deviantart.com/art/Blog-Icons-78394053" target="_blank"><strong>Blog Icons</strong> by ~reviewsaurusdotcom</a>

<img src="http://pic.yupoo.com/xcchris/749655cafdd7/7ur8zmh9.jpg" alt="Blog Icons by ~reviewsaurusdotcom" width="468" height="585" />

完结啦，完结啦～一定有你喜欢的图标吧，要知道总共有（[一][4]）（[二][5]）（[三][6]）（[完][7]）四辑哈～喜欢就拿去，不过**要注意图标作者的版权声明**哦～:)

 [1]: http://pic.yupoo.com/xcchris/459755cafe37/ewpk8q3y.jpg
 [2]: http://jvstin.deviantart.com/art/Pretty-RSS-Feed-Icon-79515344 "Pretty RSS Feed Icon by ~Jvstin"
 [3]: http://pic.yupoo.com/xcchris/166835cafe36/ws0oi3jo.jpg
 [4]: http://aboutrss.cn/2008/06/rss-icons-2008-first-half-1/ "08上半年出炉的RSS图标精选（一）"
 [5]: http://aboutrss.cn/2008/06/rss-icons-2008-first-half-2/ "08上半年出炉的RSS图标精选（二）"
 [6]: http://aboutrss.cn/2008/06/rss-icons-2008-first-half-3/ "08上半年出炉的RSS图标精选（三）"
 [7]: http://aboutrss.cn/2008/06/rss-icons-2008-first-half-last/ "08上半年出炉的RSS图标精选（完）"