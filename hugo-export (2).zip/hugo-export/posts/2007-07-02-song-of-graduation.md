---
title: 毕业歌
author: Chouj
type: post
date: 2007-07-02T07:48:28+00:00
url: /2007/07/02/song-of-graduation/
enclosure:
  - |
    http://law.ruc.edu.cn/Article/UploadFiles/200506/biyege.mp3
    2318966
    audio/mpeg
views:
  - 2393
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969690
categories:
  - 我记录
tags:
  - 校歌
  - 毕业

---
[audio:http://law.ruc.edu.cn/Article/UploadFiles/200506/biyege.mp3] 

<p align="center">
  <strong>毕 业 歌</strong>
</p>

<p align="center">
  田汉词
</p>

<p align="center">
  聂耳曲
</p>

<p align="center">
  同学们,大家起来,<br /> 担负起天下的兴亡!<br /> 听吧,满耳是大众的嗟伤!<br /> 看吧,一年年国土的沦丧!<br /> 我们是要选择&#8221;战&#8221;还是&#8221;降&#8221;?<br /> 我们要做主人去拼死在疆场,<br /> 我们不愿做奴隶而青云直上!<br /> 我们今天是桃李芬芳,<br /> 明天是社会的栋梁;<br /> 我们今天是弦歌在一堂,<br /> 明天要掀起民族自救的巨浪!<br /> 巨浪,巨浪,不断地增涨!<br /> 同学们!同学们!<br /> 快拿出力量,<br /> 担负起天下的兴亡!
</p>

学位授予仪式上第一次听到这首毕业歌，田汉词，聂耳曲，这歌儿也有些年头了。咱校<a href="http://news.hustonline.net/html/2007-6-21/xiaoge/" title="hust校歌" target="_blank">刚出台的校歌</a>倒是异常的新。载入比较慢，因为是教育网内的<a href="http://law.ruc.edu.cn/Article/UploadFiles/200506/biyege.mp3" title="毕业歌 download" target="_blank">文件</a>。

顺道为<a href="http://el-lzpig.blogbus.com/logs/6235196.html" target="_blank">summer同学的手机</a>默哀下下，大学四年内丢个手机也是人之常情了， 可没见过毕业临了的几天这么晚节不保的。