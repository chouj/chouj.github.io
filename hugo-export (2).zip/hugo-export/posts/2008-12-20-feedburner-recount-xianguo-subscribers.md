---
title: FeedBurner恢复计入本博鲜果订阅数
author: Chouj
type: post
date: 2008-12-20T07:58:18+00:00
url: /2008/12/20/feedburner-recount-xianguo-subscribers/
views:
  - 1730
  - 1730
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969766
categories:
  - 新闻
tags:
  - Feedburner
  - Xianguo
  - 订阅量

---
四月末，个别bloggers（<a href="http://jiangzhanyong.com/2008/04/feedburner-counter-without-xianguo-811.html" target="_blank">总统</a>、[月光][1]）报鲜果订阅数无法计入FeedBurner统计。RSS相关也遇到这样的问题，订阅数回落到700多，一直未恢复。前天，突然发现FB统计图标的数目达到1005，本年度关于订阅量的任务居然就这么完成了，惊异不已。

<img src="http://pic.yupoo.com/xcchris/259776b01609/3p6sshtp.jpg" alt="Feedburner恢复计入RSS相关鲜果订阅数" width="468" height="421" />

<!--more-->

像RSS相关这般缺失鲜果订阅量达半年多之久，可能是个别现象。有同此遭遇的blogger不妨留言一起讨论。

另外也有些有趣的发现：

  * **FB统计量图标比较实时**，前日图标显示1005时，FB网站内的统计仍是783。
  * **FB网站内统计似乎是按天更新，显示的是昨天的统计量。**

 [1]: http://www.williamlong.info/blog/archives/196.html