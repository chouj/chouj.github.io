---
title: 植物们
author: Chouj
type: post
date: 2006-11-11T14:36:00+00:00
url: /2006/11/11/plants-and-flowers/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/11/blog-post_11.html
views:
  - 1559
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969828
categories:
  - 我记录
tags:
  - 图片
  - 植物园

---
<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_DSCN0126.jpg" border="0" alt="" />
  
<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_DSCN0122.jpg" border="0" alt="" />
  
<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_DSCN0124.jpg" border="0" alt="" />
  
<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_DSCN0121.jpg" border="0" alt="" />
  
<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_DSCN0123.jpg" border="0" alt="" />
  
<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_DSCN0125.jpg" border="0" alt="" />

**<span style="font-size:180%;">前</span>**些日子到武汉中科院植物园晃了一下，陶冶情趣，顺手拍了几张，虽然不甚满意，但还是PS出来聊以纪念。

<span style="font-size:180%;"><strong>今</strong></span>年光棍节实在没什么好写，想想自己写blog都一年了，因为去年写过。“群光”广场，果真是一群光棍过节的好地方。

<span style="font-size:180%;"><strong>某</strong></span>群在闪：

甲：愿上帝赐予你勇气，勇于在单身的黑暗中寻找爱情的光明。

乙：愿主的荣光永远伴随你，至于我，还是让我沉沦在黑暗中吧。