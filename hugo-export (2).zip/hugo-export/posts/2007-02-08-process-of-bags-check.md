---
title: '[个人经验]毕业包裹托运流程'
author: Chouj
type: post
date: 2007-02-08T15:24:00+00:00
url: /2007/02/08/process-of-bags-check/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/blog-post.html
views:
  - 1988
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969849
categories:
  - 我尝试
tags:
  - 大学
  - 托运
  - 毕业

---
<span style="font-size: 180%; color: #666666;"><span style="font-weight: bold;">算</span></span><span style="color: #666666;">是提前一学期离校，自己把铺盖衣物打包寄回家，昨天收到了，也提醒我写点经验总结以备他人查用。最好的希望是，毕业时学校和运输部门把托运统一包办了，那基本就用不着我废劲敲字，多好。</span>
  
<span style="font-size:180%;"><br /> <span style="font-weight: bold;">在</span></span>网上搜罗了一阵，严重参考了<a href="http://bbs.ly321.com/dispbbs.asp?BoardID=2&id=532" target="_blank">这个贴</a>，获知托运包括两种方式，一种是<span style="font-weight: bold;">包裹寄送</span>，一种是<span style="font-weight: bold;">行李托运</span>。我采用了第一种，不过对第二种还是有发贴（<a href="http://www.douban.com/group/topic/1413175/" target="_blank">帖1</a><a href="http://www.douban.com/group/topic/1413181/" target="_blank">贴2</a>）调查，先把我所知的写出来：

<span style="font-weight: bold;">行李托运注意事项</span>
  
<span style="font-weight: bold;">1</span>、在火车站托运处办理；
  
<span style="font-weight: bold;">2</span>、要车票，若没有，会加价；
  
<span style="font-weight: bold;">3</span>、可提前几天办理，可办理随车托运；
  
<span style="font-weight: bold;">4</span>、计费标准：重量和行程距离；
  
<span style="font-weight: bold;">5</span>、可托运电脑，但无附带泡沫的外包装，将要求打箱，并收取额外费用。

<span style="font-size:180%;"><span style="font-weight: bold;">因</span></span>为我没有采用行李托运这一操作，所以像费用的清算细节，与包裹寄送相比孰贵孰便宜，我就无从告知了。而我选用第一种的首要原因，即是我所在的学校和火车站距离太远，但<span style="font-weight: bold;">包裹托运</span>可以到最近的邮局办理。以下是我在邮局办理包裹寄送的详细流程。

<span style="font-weight: bold;">1</span>、由于是衣物被褥，所以我买了编织袋，打包放入袋中。考虑到邮政部门可能会清验包裹，所以我没有在编织袋外捆绑打包，或者密封，仅仅拉紧了编织袋拉链，运到邮局。
  
<span style="font-weight: bold;">2</span>、邮局工作人员并没有如我所料清验包裹，只是询问了包内物件的种类，比如，是否全是衣物，是否有夹带书籍。可能与校内邮局办事积于对学生的信任有关，他们才没检查，但制度上确实要求这步骤，为了好订价（书籍的话，会贵些）。所以我建议运至邮局前，最好不要把包裹密封。不同地方的邮政部门应该有不一样的办事标准，提醒大家要灵活应对。
  
<span style="font-weight: bold;">3</span>、交了1元钱，买了一块膏药样的贴布（以前医院固定点滴针头贴手上的那种，现在绝迹了）和缝编织袋的线，贼贵啊。贴布上写好收件人和寄件人的地址邮编姓名，贴在包裹一侧；拿针线再把编织袋的拉链条缝上一道，很粗的那种针线，比较好缝，简易密封。
  
<span style="font-weight: bold;">4</span>、买包裹单，填好收件人寄件人的那些信息和是否保价之类。
  
<span style="font-weight: bold;">5</span>、过秤，我的包裹重27公斤。
  
<span style="font-weight: bold;">6</span>、选择邮寄方式，有慢件、快件、特快专递三种。慢件最多两周，快件一个礼拜之内，特快的两天寄到；价钱自然由低到高。我选了慢件，由武汉寄往襄樊，计价28元，基本上一公斤一元。计费标准跟物品易损程度、重量、邮寄方式、寄送距离有关。
  
<span style="font-weight: bold;">7</span>、2月9日才去领取的包裹，因为包裹单到的晚，要携带身份证，至少要填领取人身份证号码。一看邮戳，1月29日办理的，2月1日寄到的，说明慢件不算慢。当然，不同地点不同的邮政服务，慢件的邮寄时间也肯定不同，切莫一概而论。

<span style="color: #666666;">纯属我个人的经验，不同地方会有所出入，但希望能有用。</span>