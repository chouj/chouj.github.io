---
title: 再见了，FeedBurner！
author: Chouj
type: post
date: 2009-02-15T15:10:03+00:00
url: /2009/02/15/goodbye-feedburner/
views:
  - 1906
  - 1906
duoshuo_thread_id:
  - 1279764464521970038
categories:
  - 知识
tags:
  - Feedburner

---
<a title="FeedBurner" href="http://www.feedburner.com" target="_blank">FeedBurner</a>的<a title="About FeedBurner" href="http://www.feedburner.com/fb/a/about" target="_blank">About页面</a>上，写着这些字(我粗翻的)：

> <div class="mceTemp">
>   <dl class="wp-caption alignleft" style="width: 160px;">
>     <dt class="wp-caption-dt">
>       <img title="FeedBurner logo" src="http://www.feedburner.com/fb/i/logo_150w.gif" alt="FeedBurner logo" width="150" height="27" />
>     </dt>
>   </dl>
> </div>
> 
> FeedBurner是针对博客和RSS Feeds，提供信息配送和订阅服务的领航者。我们的浏览器端服务帮助博客、播客和商用信息发布人分享、传递他们在网络上的信息，并使其获益。
> 
> 同时FeedBurner向全世界的媒体公司、一流的博客和博客组织，以及独立发布人提供了最大的feed和博客广告营销网络，将他们的信息空前得聚合起来。

毋庸置疑，这是业界一个伟大的品牌。而<a title="Our 210th variation on the theme, &quot;Thank you for using FeedBurner.&quot;" href="http://blogs.feedburner.com/feedburner/archives/2008/12/our_210th_variation_on_the_the_1.php" target="_blank">FeedBurner官方博客宣布</a>停止更新，关于FB的一切将转移至<a title="Adsense for feed" href="http://adsenseforfeeds.blogspot.com/" target="_blank">Adsense For Feeds</a>，并感谢大家使用FeedBurner。这标志着FeedBurner品牌将离我们远去，<a title="FeedBurner" href="http://www.feedburner.com" target="_blank">FeedBurner</a>.com将逝去，FeedBurner.google.com的时代将到来。

<!--more-->

这里，借用 <a href="http://twitter.com/lvxinxin/status/1206476375" target="_blank">@lvxinxin</a> 最近的一句话作为题目，同时参考<a title="月光博客" href="http://www.williamlong.info/" target="_blank">月光</a>的日志，我们来共同缅怀一下<a title="FeedBurner" href="http://www.feedburner.com" target="_blank">FeedBurner</a>在国内的大事件：

<span style="background-color: #99ccff;">～～～～～～～～～～～～～～～～～～～～～～～～</span><span style="background-color: #99ccff;">～～～～～～</span>

2004 02 成立于美国芝加哥

2006.08.01 第一次遭遇GFW，封锁未超过24小时

2006.08.04 识别抓虾订阅数

2007 05.23 Google以一亿美元收购FeedBurner

2007 07.24 识别鲜果订阅数

2007 08.29 第二次遭遇GFW，电信网通先后封锁访问

2007 10.31 开始整合Adsense

2008 08.15 发布Adsense for Feeds

2008 12.03 全面解除封锁

2008 12.24 关闭官方博客Burning Questions

2009 01.23 因服务不可靠，订阅数丢失，而遭到知名bloggers抱怨

<span style="background-color: #99ccff;">～～～～～～～～～～～～～～～～～～～～～～～～</span><span style="background-color: #99ccff;">～～～～～～</span>