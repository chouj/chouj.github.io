---
title: '[翻译]RSS价值高于博客'
author: Chouj
type: post
date: 2007-07-31T08:57:00+00:00
url: /2007/07/31/rss-higher-value-than-blogs/
views:
  - 1377
  - 1377
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969969
categories:
  - 相关
  - 翻译
tags:
  - blog
  - podcast
  - 翻译

---
于7月25日发表的<a href="http://www.forrester.com/Research/Document/Excerpt/0,7211,42814,00.html" target="_blank">Forrester研究报告</a>表明，在众多Web 2.0应用中，RSS技术价值最高。四月至六月，有275位IT界的决策者接受了研究报告的调查。

23%的被调查对象认为RSS具有实质性的商业价值，三分之一的人为营销而使用RSS。排在RSS之后的最具价值Web 2.0应用为播客，有21%的被调查对象认同。

相对而言，只有11%的人认为写博客有助于实质性商业价值的传播。还有14%的人说他们的企业并不评测Web 2.0应用的商业价值。但即便评测Web 2.0应用价值的公司，还是侧重依赖于传统的商业价值衡量方法，例如投资收益率和总购置成本。

[<a href="http://www.rss-specifications.com/blog.htm#765" target="_blank">via</a>] <font color="#c0c0c0">不知道翻译的对不对，- -#</font>