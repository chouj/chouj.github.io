---
title: '[草莓版]八月汇集：Sociality,Marketing,Mobile,Filter'
author: Chouj
type: post
date: 2007-08-31T09:20:25+00:00
url: /2007/08/31/august-sociality-marketing-fliter-mobile/
views:
  - 1586
  - 1586
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969720
categories:
  - 广告
  - 相关
tags:
  - Affiliate
  - bloglines
  - Feedburner
  - feedsky
  - Filter
  - Marketing
  - Mobile
  - Social
  - Xianguo
  - Zhuaxia
  - 信息过载
  - 河蟹
  - 胖葫芦

---
<img src="http://photo11.yupoo.com/20070830/154027_188461499_uqlzfxyc.jpg" alt="Feedburner is blocked" align="left" />本以为八月过的比较平淡，没想到重磅炸弹都在月末：**Bloglines杀回市场**，**FeedBurner吃了河蟹**。搅得写草莓的人不得安生，改稿几次，郁闷又生了一级，- -|| 还是先为FeedBurner默哀三分钟吧，链接我就不贴了，24小时内GR里提到Feedburner的消息飙出近20条，风雨满城。综合几条**应对措施**如下：

  * <strike><a href="http://www.xianguo.com" title="鲜果" target="_blank">鲜果</a>用户可更换在线阅读器为国外服务，如<a href="http://www.google.com/reader/" title="GR" target="_blank">GR</a>或<a href="http://beta.bloglines.com/" title="Bloglines" target="_blank">Bloglines</a>，这些阅读器可正常抓取Feedburner烧制的Feed（鲜果一定很郁闷）；</strike>鲜果汇报已可正常抓取，期待Feedburner重新收纳鲜果的订阅数
  * 订阅其他Feed托管商提供的Feed，本站**Feedsky版Feed**为 <a href="http://feed.feedsky.com/aboutrss" title="本站Feedsky版Feed" target="_blank">http://feed.feedsky.com/aboutrss</a> ；
  * 将页面上的 FeedBurner 订阅数字图标、广告代码、或者页面统计代码删除或替换为静态图片。因为这些代码会严重影响博客的加载速度，导致整个页面无法打开。by <a href="http://www.ilmay.cn/post/hexie-feedburenr.html" title="Feedburner被和谐啦！" target="_blank">长天暮鼓</a>
  * 目前 FeedBurner 烧制者首要做的是**去掉 [FeedBurner 的跳转][1]**——肥嫂，<a href="http://fisio.cn/feedburner-solutions.html" title="给本次Feedburner事件受害者们支招" target="_blank">给本次Feedburner事件受害者们支招</a>
  * [给托管了Feed的FeedBurner用户和Feedsky用户的solution][2]——Zola，需翻墙，技术文
  * 站长们没事儿就去**备份数据**吧，参考如下信息：

> 继“紫田”机房、广东汕头“蓝芒”机房,总数超过2000多台服务器被断网关闭处理后,今天我机房参加了省公安厅召开的“十七大”前严打“交互性网站”(论坛/博客/留言板)通告会。会议精神明确要求,各IDC服务商在十七大之前,必须强制关闭所有论坛/博客/留言板等交互性网站；整个机房只要发现超过7例,采取关闭机房强制性措施,并处罚款5-100万元。

这时，我们需要<a href="http://www.kakug.com/blog/archives/201" title="怀念马丁·尼莫拉牧师" target="_blank">怀念下马丁·尼莫拉牧师</a>：

> **“当初他们封<a href="http://www.blogger.com/" onclick="javascript:urchinTracker ('/outgoing/www.blogger.com');">blogspot</a>，
  
> 我没有作声，
  
> 因为我很少更新我的Blogger；
  
> 后来他们封<a href="http://www.flickr.com/" onclick="javascript:urchinTracker ('/outgoing/www.flickr.com');">flickr</a>，
  
> 我没有作声，
  
> 因为我一直在用<a href="http://www.panoramio.com/user/173844" onclick="javascript:urchinTracker ('/outgoing/www.panoramio.com/user/173844');">panoramio相册</a>；
  
> 再接下来他们封<a href="http://feeds.feedburner.com/kaku" onclick="javascript:urchinTracker ('/outgoing/feeds.feedburner.com/kaku');">feedburner</a>的时候，
  
> 我仍然保持沉默，
  
> 因为我用的是<a href="http://www.kakug.com/blog/archives/163" onclick="javascript:urchinTracker ('/outgoing/www.kakug.com/blog/archives/163');">河南网通</a>，还没有<a href="http://www.williamlong.info/archives/1032.html" onclick="javascript:urchinTracker ('/outgoing/www.williamlong.info/archives/1032.html');">受到中国电信的这种骚扰</a>；
  
> 最后，当他们开始对付<a href="http://www.kakug.com/blog" onclick="javascript:urchinTracker ('/outgoing/www.kakug.com/blog');">我的网站</a>时，
  
> 已经没有人为我讲话了……”**

但是，在人们习惯性的把智慧都投入到揶揄和恶搞的时候，在人们对这些揶揄和恶搞麻木之前，请想想<a href="http://feed.feedsky.com/min-jian" title="《民间》 Feed" target="_blank">《民间》</a>的口号：“**行动改变生存**”，也许我们需要更多的周曙光：<a href="https://www.zuola.com/weblog/?p=876" target="_blank">“还是那句话，弄点钱，有空起诉GFW去，这才是终极solution。”</a>

<img src="http://photo5.yupoo.com/20070828/184610_1275588803_rrcvhspd.jpg" title="RSS 草莓版" alt="RSS 草莓版" align="left" height="130" width="122" />下面是半熟<font color="#ff0000"><strong>草莓</strong></font>时间，因为结的籽儿不够多，囧：<!--more-->

RSS这一<a href="http://webleon.org/2007/08/rss.html" title="漫谈：Web2.0的商业价值？" target="_blank">被认可度最高的Web 2.0技术</a>，正在为大伙<a href="http://fairyfish.net/2007/08/21/introduction-to-rss/" title="水煮鱼谈 RSS" target="_blank">广为推荐四下传播</a>，Feed不仅成为了<a href="http://www.yaoblog.com/?p=427" title="公民媒体的崛起" target="_blank">最重要的网络出版方式</a>，而且通过RSS我们还可以<a href="http://www.awflasher.com/blog/archives/1020" title="效率=生命（2） - RSS攻略之“三种以RSS为火药的武器”" target="_blank">在信息的战场上攻城拔寨</a>。正值八月，看似波澜不惊，实则暗流涌动，与RSS有关的新消息基本以题头中的四个词汇为核心，RSS将不再是单一的信息传播媒介，其应用势必多元化，单方面的封锁是无效的！

[**Sociality <font color="#ff0000">+</font> User Experience**]

盗盗<a href="http://www.showeb20.com/?p=677" title="Streamy社会性RSS订阅以及新闻服务初体验" target="_blank">说</a>：“Web2.0时代，在美国乃至全球互联网人中谈论最多的关键词莫过于“社会性/Sociality”，评论一个网络服务是否拥有Web2.0高贵的血统，‘社会性/Sociality’将是评价之的一个重要标准。”<a href="http://www.caozenghui.cn/?p=206" title="RSS阅读器：工具化还是媒介化" target="_blank">RSS阅读器是工具化还是媒介化</a>？答案从八月几款RSS阅读应用的初露娇容便知：[Fav.or.it][3]——<a href="http://www.wappblog.com/50226711/favoritieeeaeaeccccfeedee_111109.php" title="Fav.or.it：能让你更方便发现和管理内容的新Feed阅读器" target="_blank">社区型Feed阅读工具</a>；<a href="http://www.streamy.com/" title="Streamy" target="_blank">Streamy</a> ——<a href="http://www.showeb20.com/?p=677" title="Streamy社会性RSS订阅以及新闻服务初体验" target="_blank">提供社会性RSS订阅以及新闻服务Startup</a>；[Feedbuddy][4]——<a href="http://www.wappblog.com/50226711/feedbuddyiersseeecc_109554.php" title="Feedbuddy：RSS阅读匹配系统" target="_blank">面向RSS阅读者的社区型网站</a>，通过RSS阅读匹配寻找同好。社区化、社会性看来不可避免，但同时我们也不能忽略掉良好的用户体验。<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽儿</a>以为，一个兼得社会性和良好用户体验的产品方有成为常胜将军的潜质，即卖相好看又主动，自然回头客比较多。月末之时，在线Feed阅读器的始祖<a href="http://www.bloglines.com" title="Bloglines" target="_blank">Bloglines</a>成为了追求用户体验，以用户为中心的典范：<img src="http://beta.bloglines.com/c/images/r16741/bl-logo.png" title="bloglines beta" alt="bloglines beta" align="right" height="36" width="180" /><a href="http://www.wangtam.com/50226711/bloglines_c_beta_e_112859.php" title="Bloglines 推出新版 beta 测试" target="_blank">推出</a>的<a href="http://beta.bloglines.com/" title="Beta Bloglines" target="_blank">βloglines</a>在UI方面改进不少，Ajax的运用使得Feed管理和阅读更加smooth、sexy，只是国内接入Bloglines的速度不能令人满意。当其摘掉beta的帽子，<a href="http://www.showeb20.com/?p=687" title="RSS新闻聚合订阅服务商Bloglines推出Beta V3公测版！" target="_blank">收纳社会性小组、分享、收藏、标定等功能</a>后，<a href="http://iwfwcf.blogspot.com/2007/08/bloglinesv3beta-feed.html" title="Bloglines发布v3（beta）重回战局 在线Feed阅读器市场将再次清牌？" target="_blank">能否一搅在线Feed阅读器市场</a>，让我们拭目以待。

回到国内， <a href="http://www.dbanotes.net/review/zhuaxia_xianguo_google_reader.html" title="抓虾, 鲜果, 还是 Google reader?" target="_blank">抓虾、鲜果还是Google Reader？</a>用户仍然在抉择，<a href="http://www.duduwolf.com/post/rss_reader.asp" title="GR首选，其次抓虾，鲜果加油" target="_blank">有人选G Reader</a>，你选好了吗？抓虾<a href="http://www.zhuaxia.com/blog/?p=171" title="频道大全改版啦 :)" target="_blank">改版频道大全</a>，高举社区化大旗；鲜果秉承用户体验至上，<a href="http://blog.xianguo.com/2007/08/24/update0824-59.html" title="OPML导入功能升级" target="_blank">支持OPML自定义导入</a>，但无论你倾向于哪类，<a href="http://www.ilmay.cn/post/shequ-zhuaxia-ue-xianguo.html" title="社区化的抓虾与用户体验至上的鲜果" target="_blank">虾果相争，用户就得利</a>。

[**Marketing**]

<img src="http://photo5.yupoo.com/20070830/172657_749825055_yhnuqtua.jpg" title="RSS Marketing" alt="RSS Marketing" align="right" height="132" width="159" />Bloggers的Feed订阅量上到一定层次，比如<a href="http://jiangzhanyong.com/2007/08/new-blog-milestone-500-feed-readers-487.html" title="我的博客里程碑 - 500 Feed 读者" target="_blank">达到500</a>或<a href="http://blogunion.org/log/hello-bitch.html" title="说说跟博客联盟有关的三件事" target="_blank">达到1000</a>的时候，作为<a href="http://ljhui.yo2.cn/archives/337528" title="博客经济已初具规模" target="_blank">博客经济</a>中一个大项的RSS营销即可以施展开来。Feedburner开始<a href="http://www.williamlong.info/archives/993.html" title="FeedBurner用户可以投放自己的广告" target="_blank">支持用户投放自己的广告</a>，而目前国内比较成熟的RSS营销方式则是依托于Feedsky的<a href="http://blogs.feedsky.com/?p=152" title="让Feed为你带来收入！" target="_blank">Feed展示广告</a>。在Google Adsense和FeedBurner广告系统严重威胁之下，Feedsky于8月放出大手笔：内测<a href="http://blogs.feedsky.com/?p=157" title="页面内展示广告开始内测" target="_blank">页内展示广告</a>，继续完善其广告运营链，添砖加瓦以求生存。只是这次的内测时机比较点儿背，碰上<a href="http://www.alimama.com/" title="阿里妈妈 广告交易平台" target="_blank">阿里他妈</a>母仪天下；<a href="http://www.jaylee.cn/banner-blindness-offer-opportunity-for-blog-topic-ads/" title="Banner Blindness: Feedsky 话题营销的机遇和挑战" target="_blank">被人看好</a>的话题广告服务也在评测中显示<a href="http://jiangzhanyong.com/2007/08/feedsky-vs-blogool-paid-review-499.html" title="FeedSky vs. 博狗, 国内两家主流付费评论服务比较" target="_blank">和blogool平分秋色</a>。前有“世上只有阿里他妈好”，后有blogool狗视眈眈，想吃广告饭的Feedsky内忧外患举步维艰，一不小心感动了功夫网，蟹钳子一伸夹灭了FeedBurner的小火苗。调侃之余，还是希望Feedsky多点儿小变化（<a href="http://blogs.feedsky.com/?p=160" title="查看Feed更新状态" target="_blank">1</a>、<a href="http://blogs.feedsky.com/?p=156" title="增加一点小变化" target="_blank">2</a>），少点儿<a href="http://www.williamlong.info/archives/1017.html" title="FeedSky订阅数字清零" target="_blank">小问题</a>。

[**Information Filter**]

RSS的使用在提高了阅读效率的同时，也加重了信息过载的可能性，如何<a href="http://iwfwcf.blogspot.com/2007/08/blog-post_02.html" title="缓解信息焦虑--调整面对信息过载的心态" target="_blank">缓解信息焦虑</a>，享有<a href="http://wuzhiyong.name/fast-feed-reading.html" title="如何快速有效的阅读feed" target="_blank">快速有效的阅读</a>体验，逐渐成为用户关注的焦点。所以，[AideRss][5]一经出现就吸引了大众的眼球，其使用简单的评分机制，为<img src="http://www.aiderss.com/images/aideRSS_logo.gif" title="AideRSS" alt="AideRSS" align="right" height="76" width="190" />用户订阅的每一则消息赋予了相应权重，此手法<a href="http://www.caobian.info/?p=2482" title="AideRss---抓虾的可能方向" target="_blank">值得在线阅读服务借鉴</a>，成熟完善的信息过滤必将成为各线上阅读服务追寻的目标。不过，同时也有人担心信息过度过滤，认为：<a href="http://www.peterlu.cn/archives/239" title=" RSS的过度过滤" target="_blank">不能让冷冰冰的爬虫取代blogger间的真实互动</a>。

曹增辉在本月<a href="http://www.caozenghui.cn/?p=213" title="继续RSS订阅列表OPML的分享" target="_blank">继续着OPML共享运动</a>。为了让这个活动更加良性，避免产生信息过载的副作用，<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽儿</a>以为shared OPML所涵盖的内容越**小众**越好，谁要是能共享出Ubuntu相关OPML、AV女优blogs OPML、wp theme类OPML，肯定大受欢迎。各排行、榜单里有的feeds还是不要包括进去了。

[**Mobile RSS**]

借助手机网络实现RSS信息传输和Feed阅读早已不是新闻，此类服务亦是层出不穷。

<img src="http://photo5.yupoo.com/20070826/213917_2136069524_lirmhrhy.jpg" title="FeedM8 for Aboutrss.cn" alt="FeedM8 for Aboutrss.cn" align="right" height="412" width="291" />行业中依然是国外起步较早：<a href="http://www.mobispine.com/" title="Mobispine" target="_blank">Mobisipine Beta</a>、<a href="http://www.litefeeds.com/" title="LiteFeeds" target="_blank">LiteFeeds</a>等服务早就上线；盗盗<a href="http://www.showeb20.com/?p=643" title="FeedM8 - 盗盗" target="_blank">介绍</a>的<a href="http://feedm8.com/web/user_signup?refer=FM8311-83" title="FeedM8推荐链接" target="_blank">FeedM8</a>则是可将Feed烧制成供Wap浏览的一项服务；老牌线上RSS阅读器Bloglines也于7月底放出支持Apple iPhone的移动版本<a href="http://i.bloglines.com/" title="iBloglines" target="_blank">iBloglines</a>。

在国内，<a href="http://www.panghulu.com/" title="胖葫芦" target="_blank">胖葫芦</a>是该行业的先驱者，日前<a href="http://blog.modim.cn/2007/08/16/pc-edit-read-list/" title="胖葫芦新功能" target="_blank">已支持Web编辑手机RSS订阅列表功能</a>，挂出胖号的blog开始多起来；<a href="http://www.xianguo.com" title="鲜果" target="_blank">鲜果阅读器</a>则在近日<a href="http://blog.xianguo.com/2007/08/24/update0824-59.html" title="鲜果手机版上线" target="_blank">上线</a>了鲜果手机版，访问地址是wap.xianguo.com；Feedsky早就有Feed手机版阅读服务。

值得注意的是，结合Mobile和Marketing，一种新兴的营销模式即将兴起：广告将嵌入Mobile Feed（广告无处不在，- -b），而Feed Publisher又可通过Affiliate网络推销模式和广告盈利。WebLeon在评价FeedM8这类Feed2WAP服务时<a href="http://webleon.org/2007/08/feedm8feedwap.html" title="FeedM8：把Feed转换为Wap的服务 - WebLeon" target="_blank">说</a>：这类功能有望成为一种新的盈利渠道，通过FeedM8来赚钱(指Feed发布者，不是广告商)还是非常有潜力的。

广告：欢迎订阅RSS相关<a href="http://feedm8.com/web/feed_send?feedid=502" target="fmpopup" onsubmit="window.open('http://feedm8.com/web/feed_send?feedid=502', 'fmpopup', 'scrollbars=yes,width=550,height=520');return true"><img src="http://feedm8.com/web/images/send1.gif" border="0" /></a>，XD~~

[**Translation**]

<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽儿</a>在译言建立了一个<a href="http://www.yeeyan.com/groups/show/rss" title="译言RSS小组" target="_blank"><strong>RSS相关外文翻译小组</strong></a>，由于<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽儿</a>时间有限，不够精力把优秀的RSS话题文章都翻译成中文，就把好文推荐到那里，诚邀高手加盟翻译！我还在饭否做了个<a href="http://fanfou.com/statuses/8qAyKo4aOFM" target="_blank">广告</a>，XD~~

[**Useful Information**]

  * Feed Item统计有弊端，<a href="http://jiangzhanyong.com/2007/08/turn-off-click-tracking-483.html" target="_blank">如何关闭该功能？</a>
  * <a href="http://hellobmw.com/archives/how-to-add-interative-links-to-feeds.html" target="_blank">怎样给RSS Feed加入交互功能？</a>
  * <a href="http://blogsdiy.org/2007-08/declare-feed-url-in-html/" target="_blank">在HTML中如何正确声明RSS Feed？</a>
  * RSS资源：<a href="http://www.ilmay.cn/post/google-news-china-feed.html" target="_blank">Google资讯中国版提供RSS供稿</a>
  * <a href="http://fairyfish.net/2007/08/26/subscribe-to-firefox/" target="_blank">如何使用Firefox自带功能订阅Feed？</a>
  * 基于IM的RSS消息推送服务商——哪吒，<a href="http://www.showeb20.com/?p=689" target="_blank">全面升级</a>
  * <a href="http://parandroid.com/50-firefox-extensions-and-scripits-for-google-reader/" target="_blank">50多个增强</a><a href="http://parandroid.com/50-firefox-extensions-and-scripits-for-google-reader/" target="_blank" rel="external">Google</a> <a href="http://parandroid.com/50-firefox-extensions-and-scripits-for-google-reader/" target="_blank">Reader功能的Firefox扩展插件</a>

<font color="#ff0000"><big>Happy BlogDay ~~</big></font>
  
<big></big>
  
<font color="#c0c0c0"><small>九月份的汇集应该可以继续拿这四个词儿作题目，囧；开放了首页阿里他妈的广告位，4元一周试水玩，囧囧；不知道偶写这么长的东东有人看完吗？囧囧囧……fb77c85b 备份数据去……<br /> </small></font>

 [1]: http://fisio.cn/avoid-feed-link-redirecting.html
 [2]: https://www.zuola.com/weblog/?p=876 "给托管了Feed的FeedBurner用户和Feedsky用户的solution"
 [3]: http://fav.or.it/
 [4]: http://www.feedbuddy.de/
 [5]: http://www.aiderss.com/