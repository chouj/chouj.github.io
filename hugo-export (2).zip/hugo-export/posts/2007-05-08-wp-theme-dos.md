---
title: 命令行模式的WP模板
author: Chouj
type: post
date: 2007-05-08T11:08:06+00:00
url: /2007/05/08/wp-theme-dos/
views:
  - 2284
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969680
categories:
  - 我记录
tags:
  - DOS
  - theme
  - WordPress
  - 抓拍城市
  - 毛泽东
  - 雕像

---
<img src="http://themes.wordpress.net/snapshots/1418-medium.jpg" height="300" width="400" />

<a href="http://themes.wordpress.net/columns/1-column/1418/cli-10/" target="_blank">Site</a> | <a href="http://themes.wordpress.net/testrun/?wptheme=1418" target="_blank">Demo</a>

这个太牛逼了！**DOS命令行模式的Wordpress模板**，不信你可以点上面的Demo进去瞧瞧。输入“dir”可查询当前日志，输入“comment”可添加评论，输入“help”可查询更多可用命令！问题是这种WP模板你敢用否？

顺便通报下，<a href="http://www.50mm.cn/" target="_blank"><strong>抓拍城市</strong></a>的**白小刺**同学在收集**毛雕像**，不知哪位HUST的同学可以拍几张贡献过去，<a href="http://www.50mm.cn/tag.php?tag=%E6%AF%9B%E9%9B%95%E5%83%8F" target="_blank">地址及相关展示见此 </a>。PS.该站域名居然是50mm.cn，汗啊。