---
title: Dict.cn海词和谷词的完美搭配
author: Chouj
type: post
date: 2007-04-25T11:03:00+00:00
url: /2007/04/25/dict-with-godict/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/dictcn.html
views:
  - 2527
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969879
categories:
  - 我表达
tags:
  - 海词
  - 谷词

---
<div style="text-align: center;">
  <a title="点此进入" href="http://dict.cn/" target="_blank"><img src="http://dict.cn/img/logo1.gif" border="0" alt="" /></a>
</div>

这个<a href="http://review.feedsky.com/review/feedsky/chrischou/%7E/txt/25/r.html" target="_blank">海词</a>我要写，因为我发现，<a href="http://review.feedsky.com/review/feedsky/chrischou/%7E/txt/25/r.html" target="_blank">海词</a>搭配我之前用过的谷词，基本无敌了。
  
<span style="font-size:180%;"><br /> </span><a href="http://review.feedsky.com/review/feedsky/chrischou/%7E/txt/25/r.html" target="_blank"><span style="font-size:180%;">海</span>词</a>和<a href="http://www.godict.com/" target="_blank">谷词</a>相比，海词的优势很明显，是主打工具。其英文可搜，中文也可以搜，都能给出不错的释义短语和例句。而且[服务相当齐全][1]，包括论坛，用于即时交流和反馈；在线短文翻译；英文和繁体首页；浏览器toolbar，跟金山词霸的屏幕取词功能差不多；右键单词查询菜单，实时查询页面上的单词；blog或site widget，添加单词查询框，或者可发音的每日一句，帮助英语学习；MSN机器人，也是实时翻译；还可以在线背单词，有生词收集入库功能；开放api。一句话，功能多的用不完。反正我用不了这么多，基本的有就行了。专业词汇类别，我没过多尝试，因为我相信Feedsky的话题介绍，上面说包涵诸多专业门类的词汇，那就OK。对于我这种多是查词的人，<a href="http://review.feedsky.com/review/feedsky/chrischou/%7E/txt/25/r.html" target="_blank">海词</a>的服务完全够用了，但根据其给出的这诸多服务，其也是想学英语的朋友的上佳选择。

<div id="logo">
  <img src="http://www.godict.com/image/logo_index.gif" alt="" />
</div>

<span style="font-size:180%;">谷</span>词呢，逊色不少，但也有其特色。那就是搜英文的时候，我更倾向于谷词，因为谷词搜索有三个类别：<a href="http://www.godict.com/indexw.jsp" target="_blank">词典</a>／<a href="http://www.godict.com/indexp.jsp" target="_blank">短语</a>／<a href="http://www.godict.com/indexs.jsp" target="_blank">句子</a>，搜什么英文，对号入座就是了。而且搜索后，还可以更改输出结果，按照详细解释／专业解释／简单解释划分。有一点不好，就是响应速度有点慢。另外，在谷词搜中文的话，详细解释／专业解释／简单解释的输出结果都一样。不过谷词有个好玩的地方不在于单词翻译，而在于<a href="http://search.godict.com/" target="_blank">搜索引擎PK</a>，可多选几个引擎搜同一个词，比对输出结果的差异，很是funny！

<span style="font-size:180%;">所</span>以综上，<a href="http://review.feedsky.com/review/feedsky/chrischou/%7E/txt/25/r.html" target="_blank">海词</a>主打，辅以谷词，在拉上Google翻译，搭配金山词霸，牛逼完了 !

 [1]: http://dict.cn/tools.html