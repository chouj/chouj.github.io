---
title: RSS聚合器 之 XML News Aggregator
author: Chouj
type: post
date: 2007-07-05T16:46:28+00:00
url: /2007/07/06/xml-news-aggregator/
views:
  - 1597
  - 1597
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969961
categories:
  - 工具
  - 新闻
  - 知识
tags:
  - Aggregator
  - SXNA
  - XNA

---
  * **<font color="#009900">什么是RSS聚合器？</font>**

  **RSS聚合器**是一种以用户被动更新模式更新，由asp或php编写的，可读取RSS Feed / XML并显示新闻项的程序，可以方便地在线获取、阅读和管理RSS/XML格式的信息。

  * <font color="#009900"><strong>Sipo XML News Aggregator（SXNA）</strong></font>

<img src="http://www.dc9.cn/upload/logo.png" alt="SXNA" title="SXNA" align="rignt" />

**SXNA**是由[Sipo][1]开发的一款基于asp的聚合器程序，也是asp下最为流行的RSS聚合器。目前版本号1.7，特点如下：

  * <small>支持RSS0.9/1.0/2.0 Atom </small>
  * <small>支持OPML导入与导出</small>
  * <small>首页第一页采用缓存机制，更加快速</small>
  * <small>有列表显示模式和标准显示模式</small>
  * <small>可以订制多种显示模式组合</small>
  * <small>支持动态制定正则表达式</small>
  * <small>无需登陆即可浏览到聚合内容。</small>
  * <small>支持皮肤更换 </small>
  * <small>采用首页停留驱动自动更新的机制 </small>
  * <small>采用自动更新代码驱动自动更新 </small>
  * <small>列表显示和聚合源读取采用Ajax技术 </small>
  * <small>首页调用支持GB调用和UTF8调用</small>
  * <small>后台方便的数据库管理 </small>
  * <small>首页可以搜索或组合搜索</small>
  * <small><font color="#990000">不</font>支持favicon显示<br /> </small>

**[SXNA主页][2] | [下载页面][3] | [安装指南][3] | SXNA聚合器站点示例**：

  * <small><a href="http://blog.blueidea.com/">Blueidea XML News Aggregator</a></small>
  * <small><a href="http://www.whublog.com/">WAFX&#8211;武汉大学博客XML聚合(Whublog Aggregator For Xml)</a></small>
  * <small><a href="http://rss.thws.cn/">啸聚一庐&#8211;txna(技术博客聚合)Thw&#8217;s XML News Aggregator</a></small>
  * <small><a href="http://www.fanz.cn/meiju/ju/">美剧.COM | 美剧信息聚合平台(MXNA)</a></small>
  * <small><a href="http://rss.hanzify.org/">汉化新世纪聚合</a></small>
  * <small><a href="http://rss.hxblog.net/">何昕博客聚合</a></small>
  * <small><a href="http://www.yxeg.com/rss/">一笑而过RSS聚合器</a></small>

**SXNA聚合器界面截图**：

<p align="center">
  <a href="http://www.yupoo.com/photos/view?id=ff80808113958aa30113971c035f2ec7" title="来YUPOO看我的照片"><img src="http://photo8.yupoo.com/20070706/000001_1813193291_njrxbfhg.jpg" alt="Blueidea-XML-News-Aggregator" border="0" height="200" width="200" /></a><a href="http://www.yupoo.com/photos/view?id=ff80808113958aa30113971c04592ec8" title="来YUPOO看我的照片"><img src="http://photo6.yupoo.com/20070706/000001_67773597_sewxkxbf.jpg" alt="Hanzify-XML-News-Aggregator" border="0" height="200" width="200" /></a><br /> <a href="http://www.yupoo.com/photos/view?id=ff80808113958b11011397214c6f1833" title="来YUPOO看我的照片"><img src="http://photo6.yupoo.com/20070706/000548_75214406_pungmmol.jpg" alt="美剧COM--美剧信息聚合平台(MXNA)" border="0" height="200" width="200" /></a><a href="http://www.yupoo.com/photos/view?id=ff80808113958b11011397214b571832" title="来YUPOO看我的照片"><img src="http://photo6.yupoo.com/20070706/000547_762784028_ekzyzqra.jpg" alt="何昕博客聚合" border="0" height="200" width="200" /></a><br /> <a href="http://www.yupoo.com/photos/view?id=ff80808113958b11011397214a5b1831" title="来YUPOO看我的照片"><img src="http://photo6.yupoo.com/20070706/000547_1099079769_odesdggz.jpg" alt="一笑而过RSS聚合器" border="0" height="200" width="200" /></a>
</p>

&#8230;

  * <font color="#009900"><strong>Spvrk XML News Aggregator</strong></font>

这款开源RSS聚合器程序由**[剑气凌人][4]**于7月5号刚刚[发布][5]，<font color="#009900">需要php5+mysql4.1支持</font>。目前的功能还十分简单，但与Sipo XML News Aggregator比，UI相对较好，支持favicon显示。作者欢迎仁人志士一起进行此开源项目。

[**Spvrk XNA聚合器示例站点**][6] **| [Spvrk XNA聚合器程序说明与下载页][5] | 界面截图如下**

<p align="center">
  <a href="http://www.yupoo.com/photos/view?id=ff80808113958b110113971976ce17f1" title="来YUPOO看我的照片"><img src="http://photo8.yupoo.com/20070705/235713_1374281153_eukosuov.jpg" alt="Spvrk XML News Aggregator" border="0" height="399" width="300" /></a>
</p>

&#8230;

  * **<font color="#009900">HSTEAR XML News Aggregator</font>**

一款很漂亮的RSS聚合器程序，由[hubro][7]编写，[开放部分源码][8]，未开放整站程序下载，仅于以下地址可见：

[**HSTEAR XML News Aggregator**][9]

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://www.dc9.cn/catalog.asp?cate=11
 [2]: http://www.sxna.cn/
 [3]: http://www.dc9.cn/post/SXNA1-7.html
 [4]: http://zxsv.com/
 [5]: http://zxsv.com/post/241.html
 [6]: http://xna.spvrk.com/
 [7]: http://www.hubro.net/category/8/
 [8]: http://www.hubro.net/item/138/
 [9]: http://feed.hubro.net/