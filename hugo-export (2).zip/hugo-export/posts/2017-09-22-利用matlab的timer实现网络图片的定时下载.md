---
title: 利用MATLAB的Timer实现网络图片的定时下载
author: Chouj
type: post
date: 2017-09-22T09:09:31+00:00
excerpt: 利用MATLAB的Timer实现网络图片定时下载的一个个例
url: /2017/09/22/利用matlab的timer实现网络图片的定时下载/
views:
  - 674
categories:
  - 我表达
  - 我记录
tags:
  - matlab

---
以<a href="http://www.goes.noaa.gov/dimg/jma/fd/wvblue/10.gif" target="_blank" rel="noopener">这个约每小时更新的GIF格式遥感图片</a>为例：

在<a href="http://xuchi.name/tag/matlab/" target="_blank" rel="noopener">MATLAB</a>当前目录下新建一个.m脚本，本例里起名为wvgifdownload.m：

<pre style="border: 1px solid #c8c8c8; padding: 5px; background: #f9f7f3;"><span style="color: green;">%图片存储目录设定：
</span>folderpath=[<span style="color: purple;">'d:\temp\'</span>];

<span style="color: blue;">if</span> length(dir([folderpath,<span style="color: purple;">'*.gif'</span>]))==0  <span style="color: green;">%判断目录是否已有GIF文件
</span>    urlwrite(<span style="color: purple;">'http://www.goes.noaa.gov/dimg/jma/fd/wvblue/10.gif'</span>,[folderpath,<span style="color: purple;">'1.gif'</span>],<span style="color: purple;">'timeout'</span>,15); <span style="color: green;">%空目录则将下载的图片命名为1.gif
</span><span style="color: blue;">else</span> <span style="color: green;">%文件夹已有GIF文件
</span>    localinfo=imfinfo([folderpath,num2str(length(dir([folderpath,<span style="color: purple;">'*.gif'</span>]))),<span style="color: purple;">'.gif'</span>]); <span style="color: green;">%获取目录里最新GIF的文件信息
</span>    webinfo=imfinfo(<span style="color: purple;">'http://www.goes.noaa.gov/dimg/jma/fd/wvblue/10.gif'</span>);<span style="color: green;">%获取目标网络图片的文件信息
</span>    <span style="color: blue;">if</span> localinfo.FileSize~=webinfo.FileSize <span style="color: green;">%比较两者文件大小，若不一样，则表示网络图片已更新，可以下载
</span>        urlwrite(<span style="color: purple;">'http://www.goes.noaa.gov/dimg/jma/fd/wvblue/10.gif'</span>,[<span style="color: purple;">'f:\CloudGIF\wv\'</span>,num2str(length(dir([folderpath,<span style="color: purple;">'*.gif'</span>]))+1),<span style="color: purple;">'.gif'</span>],<span style="color: purple;">'timeout'</span>,15);
    <span style="color: blue;">end</span>
<span style="color: blue;">end</span>
</pre>

设定Timer对象，这里起名为down：

<pre style="border: 1px solid #c8c8c8; padding: 5px; background: #f9f7f3;">down = timer                                 ...
(   <span style="color: purple;">'Name'</span>          , <span style="color: purple;">'my_timer'</span>        ...
,   <span style="color: purple;">'TimerFcn'</span>      , @(varargin)evalin(<span style="color: purple;">'base'</span>,<span style="color: purple;">'wvgifdownload'</span>)  ...
,   <span style="color: purple;">'BusyMode'</span>      , <span style="color: purple;">'drop'</span>            ...
,   <span style="color: purple;">'ExecutionMode'</span> , <span style="color: purple;">'fixedRate'</span>      ...
,   <span style="color: purple;">'Period'</span>        ,  1800               ...
,   <span style="color: purple;">'StartDelay'</span>    ,  0                ...
);
</pre>

注意TimerFcn这里是调用当前目录脚本的写法，如果是函数则按函数调用去写。本例Period这里设定的是半小时执行一次，即每半小时检查网络图片是否更新，如有更新即可下载。

执行Timer：

<pre style="border: 1px solid #c8c8c8; padding: 5px; background: #f9f7f3;">start(down)
</pre>