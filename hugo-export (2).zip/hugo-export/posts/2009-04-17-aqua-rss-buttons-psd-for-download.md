---
title: '[下载]水晶风格RSS Feed按钮PSD文件'
author: Chouj
type: post
date: 2009-04-17T05:05:04+00:00
url: /2009/04/17/aqua-rss-buttons-psd-for-download/
views:
  - 1782
  - 1782
duoshuo_thread_id:
  - 1279764464521970041
categories:
  - 标志
  - 资源
tags:
  - button
  - Download
  - RSS设计
  - 下载

---
搜索按钮psd文件时，碰巧看到了iris design的<a title="Web 2.0 style buttons: PSD sources" href="http://iris-design.info/design/web-20-style-buttons-psd-sources/" target="_blank">这篇文章</a>，提供了5款RSS Feed按钮的PSD文件(Photoshop用图片编辑格式)，也许有朋友需要，发将上来。

<p style="text-align: center;">
  <a title="Web 2.0 style buttons: PSD sources" href="http://iris-design.info/design/web-20-style-buttons-psd-sources/" target="_blank"><img class="aligncenter" src="http://pic.yupoo.com/xcchris/4245274b8099/48qf49qm.jpg" border="0" alt="" /></a>
</p>

<p style="text-align: center;">
  <strong>点击上图转入文章页面，再点击按钮即可下载相应PSD文件</strong>
</p>

其实这是一个Web 2.0风格按钮PS教程中的实例，按钮的PS方法在<a title="Web 2.0 style buttons" href="http://iris-design.info/design/web-20-style-buttons/" target="_blank">这里</a>，有相应PNG格式文件提供下载。