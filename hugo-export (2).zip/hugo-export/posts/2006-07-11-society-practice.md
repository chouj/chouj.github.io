---
title: 社会实践行程
author: Chouj
type: post
date: 2006-07-11T02:30:32+00:00
url: /2006/07/11/society-practice/
views:
  - 1532
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969891
categories:
  - 我记录
tags:
  - 生活
  - 社会实践

---
<div class="contant">
  <p>
    13-14日        乘火车  抵上海<br /> 转大巴  抵苏州  入住苏州大学宾馆
  </p>
  
  <p>
    15日     上午  苏州游览沧浪亭、苏州参观企业<br /> 下午  自由活动
  </p>
  
  <p>
    16日     上午  参观苏州市人才市场、苏州新加坡工业园区<br /> 下午  座谈，（介绍苏州概况），解答相关问题
  </p>
  
  <p>
    17日               企业苏州参观学习
  </p>
  
  <p>
    18日     上午  沙家浜进行光荣传统教育<br /> 下午  参观苏州梦兰集团，波司登
  </p>
  
  <p>
    19日     上午  企业参观学习<br /> 下午  赴上海
  </p>
  
  <p>
    以上乃此次赴苏州社会实践活动的官方安排，三名老师带队。
  </p>
  
  <p>
    苏州、常熟、上海，挑战陌生，玩味新鲜，肯定比之前实习要强许多。另据说，有不少要在19号活动结束后逗留上海。
  </p>
  
  <p>
    还是没DC……
  </p>
  
  <p align="center">
    <img style="cursor: pointer;" onclick="javascript:window.open(this.src);" src="http://www.menglan.com/images/map.gif" border="0" alt="" />
  </p>
  
  <p>
    PS:世界杯完了，感觉印象最深的除了黄同学的激情解说外，就剩克林斯曼了。丫挺激昂挺有感染力的，记得丫在意大利进球后那忧伤的眼神，记得那丫在小猪发威后招牌式的笑容。没错，生活就是追求自己热爱的，然后享受快乐……
  </p>
  
  <p align="center">
    <img style="cursor: pointer;" onclick="javascript:window.open(this.src);" src="http://photo.sohu.com/20040725/Img221181523.jpg" border="0" alt="" />
  </p>
</div>