---
title: 80×15规格RSS按钮线上制作站点收集
author: Chouj
type: post
date: 2007-05-14T00:41:50+00:00
url: /2007/05/14/button-makers/
views:
  - 1601
  - 1601
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969952
categories:
  - 工具
  - 标志
tags:
  - button
  - RSS设计

---
[前文][1]介绍了一个收集**80×15规格button**的站点，如果还是没有令您心怡的RSS按钮的话，不妨自己动手，丰衣足食。正巧有很多线上站点提供此类**按钮DIY服务**，[RSS相关][2]将其搜罗如下：

<a href="http://rssbuttons.com" target="_blank"><img src="http://buy4cheap.brinkster.net/signs/rss/rss-button-generator.png" border="0" height="94" width="450" /></a>

正宗的左右两色按钮制作站点，可调参数为<font color="#0000ff">两色分隔位置</font>（bar position）、<font color="#0000ff">两边背景颜色</font>、<font color="#0000ff">字体</font>、<font color="#0000ff">字体大小</font>、<font color="#0000ff">字体颜色</font>、<font color="#0000ff">字符的左边距和上边距</font>。**优点在于支持的字体超级多**，上面标明有对中文、日文、韩文的支持，但貌似没法使用，有点遗憾。

样例：<img src="http://buy4cheap.brinkster.net/signs/rss/index.php?ALLOW=20528028&VBAR=30&FONT=album&LEFT_TEXT=RSS&LEFTSIZE=8&LS_BACKGROUND=ff6600&LS_COLOR=FFFF00&colorPreviewValue=&L_LR=1&L_UP=1&RIGHT_TEXT=Buttons&RIGHTSIZE=8&RS_BACKGROUND=898E79&RS_COLOR=FFFF00&R_LR=1&R_UP=1&Submit=Submit&MAKE=true" title="Aboutrss" alt="Aboutrss" height="15" width="80" />
  
<a href="http://rssbuttons.com" target="_blank"><strong>点此进入该站</strong></a>

<p align="center">
  *************************************************
</p>

<a href="http://rss-icons.com/index.html" target="_blank"><img src="http://rss-icons.com/images/title.gif" border="0" /></a>

和RSSbuttons.com不同的是，该站可**自定义按钮的大小**，但只有11种字体可选。

样例：<img src="http://rss-icons.com/button.php?ltext=About&lfcolor=000000&lcolor=FF6600&rtext=RSS&rfcolor=000000&rcolor=999966&vline=45&button_width=80&button_height=15&external_border_thickness=1&internal_border_thickness=1&right_side_text_offset=6&left_side_text_offset=5&font_size=8&font=hoog0555_cyr" title="aboutRSS" alt="aboutRSS" height="15" width="80" />
  
<a href="http://rss-icons.com/icon.php" target="_blank"><strong>点此进入该站</strong></a>

<p align="center">
  *************************************************
</p>

<img src="http://photo6.yupoo.com/20070508/235955_536459562_bogvedli.jpg" title="ButtonMaker" alt="ButtonMaker" height="69" width="206" />

这个服务页界面清新，可制作**80×15和88×31两种规格**的按钮，缺陷就是**无法定义左右两色各占的比例**，且**字体不可选**。

样例：<img src="http://tools.blogflux.com/buttonmaker/button.php?buttonSize=1&leftText=RSS&rightText=About&rightBG=%23EF9200&leftBG=%23FFFFFF&rightColor=%23FFFFFF&leftColor=%233169A5&buttonBG=%23FFFFFF&borderBG=%23000000&divAlign=1&leftAlign=3&rightAlign=3&fontFamily=" title="aboutrss" alt="aboutrss" height="15" width="80" />
  
<a href="http://tools.blogflux.com/buttonmaker/" target="_blank"><strong>点此进入该页</strong></a>

<p align="center">
  *************************************************
</p>

<img src="http://photo6.yupoo.com/20070509/000720_1976434658_gujeboqj.jpg" title="buttonmaker" alt="buttonmaker" height="42" width="147" />

该页面也很简单，特点在于可以**定义按钮的border属性**，一改外框黑内框白的格局，当然，**字体仅有一种**。

样例：<img src="http://kalsey.com/tools/buttonmaker/button.php?outerBorder=FF0000&innerBorder=FFFF99&barPosition=45&leftFill=0099FF&leftText=About&leftTextColor=ffffff&leftTextPosition=10&rightFill=FF0000&rightText=RSS&rightTextColor=ffffff&rightTextPosition=54" title="Aboutrss" alt="Aboutrss" height="15" width="80" />
  
<a href="http://kalsey.com/tools/buttonmaker/" target="_blank"><strong>点此进入该页</strong></a>

<p align="center">
  *************************************************
</p>

<a href="http://www.lucazappa.com/brilliantMaker/buttonImage.php" title="80x15 Brilliant Button Maker by LucaZappa.com" taget="_blank"><img src="http://www.lucazappa.com/brilliantMaker/button_maker.png" border="0" /></a>

别看logo小，这个站可不一般啊。他允许在按钮中<font color="#ffcc00"><strong>嵌入图片</strong></font>，两边都可以嵌入 ，支持**内外框的颜色定义**，**6种字体可选**。不过制作成功需要点人品。

样例： <img src="http://www.lucazappa.com/brilliantMaker/examples/gmail.png" title="Aboutrss" alt="Aboutrss" height="15" width="80" />
  
**<a href="http://www.lucazappa.com/brilliantMaker/" target="_blank">点此进入该站</a>**

<p align="center">
  *************************************************
</p>

<font color="#99ccff"><strong>RSS Graphic Tool</strong></font>
  
这个工具就很一般了，仅支持一种字体，只能靠空格来调整字符的左边距和上边距。不推荐。

样例：<img src="http://www.feedforall.com/public/phpbutton.php?lefttext=%20%20ABOUT&righttext=RSS&w=80&h=15&vline=55&leftcolor=FF6600&rightcolor=898E79&rightfontcolor=FFFFFF&leftfontcolor=FFFFFF" title="Aboutrss" alt="Aboutrss" height="15" width="80" />
  
**<a href="http://www.feedforall.com/public/rss-graphic-tool.htm" target="_blank">点此进入该页</a>**

 [1]: http://www.xuchi.name/rss/wp-admin/110%E4%B8%AA%2080%C3%9715%20Feed%20Buttons
 [2]: http://aboutrss.cn