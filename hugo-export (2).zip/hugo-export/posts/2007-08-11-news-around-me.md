---
title: 身边的河蟹
author: Chouj
type: post
date: 2007-08-11T13:23:49+00:00
url: /2007/08/11/news-around-me/
views:
  - 2717
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969700
categories:
  - 我记录
tags:
  - 新闻
  - 河蟹
  - 生活

---
总坐在电脑前，不利于人类进化，特在雨后趁着阴天，到珠江之畔散散心。搭了轮渡，吹着风，很是河蟹。不觉越走越远，直到新闻现场——

  * ** <a href="http://news.163.com/07/0809/14/3LFAL2A700011229.html" title="河蟹" target="_blank">特价猪肉引来顾客蜂拥抢购?超市电梯挤压伤人(图)</a>**

双休中的家乐福自然人声鼎沸，有如菜市场一般，全无襄樊沃尔玛的那种空旷自由。当然，今天的菜市场还是非常河蟹的，至少我没看出丝毫如新闻中所述的火爆。不过，海珠区有些<a href="http://news.sohu.com/20070811/n251534305.shtml" title="不河蟹" target="_blank">新开张超市出售每市斤6.9元的特价肉</a>，如此惹人眼馋嘴痒的价格，足以成为威胁河蟹的因素。

出行归来，在公寓活动室落坐，面前一硕大电视放着节目。不曾想离开两月再回来之后，河蟹社会造福于民，为我带来了数字电视，让我提前于内地享受了。瞟一眼桌上的报纸，映入眼帘的又是一则新闻——

  * ** <a href="http://news.ccidnet.com/art/1032/20070810/1174185_1.html" title="河蟹吗？" target="_blank">数字电视花脸多因线路问题 需要重新布线</a>**

其实不止花脸，看某些台就像网络不好时看pplive，会卡的。在大学，我们在线看NBA，看世界杯，关键时刻卡掉的体验怕是要重演了。近日德甲开场，有人说21：30来看拜仁，不知央视最受欢迎的5套，会不会看的人越多越流畅呢？

还有人问起歹命的凤凰卫视，家里人也因看不到鲁豫有约而惋惜过。时下网络上有“还我凤凰”的<a href="http://post.baidu.com/f?kz=235921050" title="还我凤凰" target="_blank">签名征集贴</a>，有停<a href="http://post.baidu.com/f?kz=243799641" title="大家都来说下你们是哪里的被禁播的" target="_blank">播地区调查</a>，<a href="http://zhidao.baidu.com/question/2089269.html" title="为什么凤凰卫视在内地许多省市都被禁播？" target="_blank">百度知道对停播问题的解释</a>更是千奇百怪。真正有些靠谱儿的，倒是华尔街日报的一则新闻：<a href="http://chinese.wsj.com/gb/20070806/bri112411.asp?source=rss" title="中国打击非法接收境外卫星电视节目" target="_blank">中国打击非法接收境外卫星电视节目</a>（想看带留言评论的请到CB的<a href="http://www.cnbeta.com/articles/35781.htm" title="CB的带留言板，268条。" target="_blank">这里</a>），文中说：

> 广电总局的这一指示大意是说，此举旨在强化监管，维护政府对信息的控制力，“阻止敌对势力的知识和文化渗透。”

> 香港《南华早报》(South China Morning Post)称，这一打击行动既是要禁绝官方媒体以外的声音也是要保护大陆本地电视台的商业和内容垄断权，凤凰卫视等境外媒体已经夺去了它们的一部分观众。

不禁让我和另一篇文章——[傅国涌：活在一个可怕的时代][1]（需代理翻墙，需要最新翻墙工具的到**<a href="http://www.douban.com/group/topic/1852044/" title="发放 u 83" target="_blank">这里</a>**）——联想到一起。其实不仅人们活在一个可怕的时代，**已经灭绝**且**<a href="http://www.bullog.cn/blogs/rosu/archives/89352.aspx" title="连岳：白鳍豚绝于谋杀" target="_blank">绝于谋杀的白暨豚</a>**应该最有发言权，再怎么悼念都是那么苍白。

顺道儿给自己普及个词儿：BRT——Bus Rapid Transit快速公交系统，广州最近<a href="http://news.163.com/07/0802/09/3KSMM90R000121EP.html" title="BRT？！" target="_blank">热议中的项目</a>。

 [1]: http://indymediacn.blogspot.com/2007/08/blog-post_11.html