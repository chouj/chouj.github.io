---
title: 飞豆网新版UI上线
author: Chouj
type: post
date: 2008-08-05T14:21:59+00:00
url: /2008/08/05/feedou-com-new-edition/
views:
  - 1826
  - 1826
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970015
categories:
  - 新闻
tags:
  - Feidou
  - Reader

---
<a title="飞豆网" href="http://feedou.com" target="_blank"><img src="http://feedou.com/img/logo.jpg" alt="飞豆网 LOGO" width="86" height="34" /></a>

<a title="飞豆网" href="http://feedou.com" target="_blank"><strong>飞豆网</strong></a>是抓虾、鲜果之外国内又一家线上RSS阅读器服务，今日下午，新版飞豆正式上线。与旧版相比，新飞豆以黑色为底，绿色为主，UI显得更加WEB 2.0，阅读体验更加友好，但坦白来讲，飞豆网与抓虾和鲜果还是有差距的，至少未提供频道订阅数，目前看来<a title="飞豆网" href="http://feedou.com" target="_blank">飞豆网</a>SNS属性并不强，期待其进一步的发展。

新版飞豆网RSS阅读界面：

<img src="http://pic.yupoo.com/xcchris/951515fb9637/nbrfzuqd.jpg" alt="我的订阅 飞豆网 AboutRSS.cn" width="468" height="310" />

<!--more-->

新版飞豆网文章排行界面：

<img src="http://pic.yupoo.com/xcchris/092245fb9637/obrtbb33.jpg" alt="文章排行 飞豆网 AboutRSS.cn" width="468" height="527" />

[ <a title="飞豆网" href="http://feedou.com" target="_blank"><strong>点此进入飞豆网</strong></a> ]