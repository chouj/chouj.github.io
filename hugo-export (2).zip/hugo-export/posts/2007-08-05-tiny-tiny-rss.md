---
title: RSS聚合器 之 Tiny Tiny RSS
author: Chouj
type: post
date: 2007-08-05T15:15:09+00:00
url: /2007/08/05/tiny-tiny-rss/
views:
  - 2148
  - 2148
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969971
categories:
  - 工具
tags:
  - Aggregator

---
  * **<font color="#009900">什么是RSS聚合器？</font>**

  **RSS聚合器**是一种以用户被动更新模式更新，可读取RSS Feed / XML并显示新闻项的程序，可以方便地在线获取、阅读和管理RSS/XML格式的信息。

<font color="#008000"><strong><img src="http://tt-rss.spb.ru/demo/images/ttrss_logo.png" height="33" width="225" /></strong></font>

一两月前<a href="http://www.xuchi.name/blog" title="抽筋儿" target="_blank">抽儿</a>在twitter上见到启羁提到这款新发布的聚合器——**Tiny Tiny RSS**，收入书签，此番来介绍哈子。

**TT-RSS**是目前很新的一款RSS聚合器程序，基于浏览器端，但可实现桌面级应用的用户体验，也就是说，她的功能非常强大。先来直观认识，上截屏，点击小图可看大图：

<a href="http://photo9.yupoo.com/20070804/004128_1852945724_eriypdpy.jpg" target="_blank"><img src="http://photo9.yupoo.com/20070804/004128_1852945724_eriypdpy.jpg" title="Tiny Tiny RSS 截屏" alt="Tiny Tiny RSS 截屏" border="0" height="195" width="354" /></a>

从界面看，布局和目前主流的RSS在线阅读器基本一致，容易上手。再来看其特性：

  * 需要数据库支持，浏览器端操作
  * 支持各种格式：RSS, RDF, Atom ，基于[<span class="icon">Magpie</span>][1]{.ext-link}的RSS Feeds后台管理
  * 支持[<span class="icon">OPML</span>][2]{.ext-link}导入导出
  * 安装和设置简单
  * 运用AJAX技术
  * 免费程序，licensed under [<span class="icon">GPL</span>][3]{.ext-link}
  * !支持文本搜索
  * 可工作于两款主流数据库 &#8211; [<span class="icon">PostgreSQL</span>][4]{.ext-link} and [<span class="icon">MySQL</span>][5]{.ext-link}
  * !支持 [<span class="icon">Technorati-style标签</span>][6]{.ext-link}<span class="ext-link"><span class="icon">，可显示标签云</span></span>
  * !支持灵活的 [内容筛选][7]{.wiki}
  * !支持多用户操作
  * 支持feeds分类，支持feed favicon显示
  * !支持 [快捷键][8]{.wiki}
  * 支持已读/未读标记，!支持Items星标
  * 三款颜色皮肤可选

是不是很诱人？要实现如此强大的功能，当然需要强劲的后台支撑，我们来看看其运行需要的环境：

  * 服务器，例如 [<span class="icon">Apache</span>][9]{.ext-link}
  * [<span class="icon">PHP</span>][10]{.ext-link} (OPML 导入/导出 需要 PHP4 DOMXML项 支持, 更多信息可见于 [FAQ][11]{.wiki} )
  * [<span class="icon">Magpie RSS</span>][1]{.ext-link} feed 分析 (内含)
  * [<span class="icon">PostgreSQL</span>][4]{.ext-link} (测试于 7.4, 8.1 &#8211; 推荐) 或 [<span class="icon">MySQL</span>][5]{.ext-link} (InnoDB 且 需要版本 4.1+ 或 5.0+)
  * [<span class="icon"></span>][12]{.ext-link}支持XML-RPC需要[<span class="icon">XML-RPC for PHP</span>][12]{.ext-link}库，可选
  * 在PHP中开启 [Gettext][13]{.wiki} 项 (若需使用界面语言转换)
  * 支持[<span class="icon">mbstring</span>][14]{.ext-link}函数的PHP 编译 (推荐)

可见运行环境还是比较苛刻的，目前该聚合器程序最新版本为1.2.13，发布于2007.7.20。

<a href="http://tt-rss.spb.ru/trac/" title="Tiny Tiny RSS " target="_blank"><strong>Tiny Tiny RSS 聚合器主页</strong></a> | <a href="http://tt-rss.spb.ru/trac/#Download" target="_blank"><strong>下载页面</strong></a> | <a href="http://tt-rss.spb.ru/demo/tt-rss.php" target="_blank"><strong>Demo 样例</strong></a>

 [1]: http://magpierss.sourceforge.net/
 [2]: http://www.opml.org/
 [3]: http://www.gnu.org/copyleft/gpl.html
 [4]: http://www.postgresql.org/
 [5]: http://www.mysql.com/
 [6]: http://technorati.com/tags
 [7]: http://tt-rss.spb.ru/trac/wiki/ContentFilters
 [8]: http://tt-rss.spb.ru/trac/wiki/KeyboardShortcuts
 [9]: http://apache.org/
 [10]: http://www.php.net/
 [11]: http://tt-rss.spb.ru/trac/wiki/FrequentlyAskedQuestions
 [12]: http://phpxmlrpc.sourceforge.net/
 [13]: http://tt-rss.spb.ru/trac/wiki/GettextSupport
 [14]: http://ru2.php.net/mbstring