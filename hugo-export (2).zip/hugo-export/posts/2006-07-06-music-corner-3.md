---
title: 音乐一隅 2006.6-7
author: Chouj
type: post
date: 2006-07-06T04:29:00+00:00
url: /2006/07/06/music-corner-3/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/07/20066-7.html
views:
  - 1798
enclosure:
  - |
    |
        http://filelodge.com/files/hdd7/165102/kusos.3cc.cc-12-23-01.mp3
        0
        video/x-ms-asf
        
  - |
    |
        http://www.dialogue.org.il/hava/lonely.mid
        35416
        audio/midi
        
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969785
categories:
  - 我表达
tags:
  - 音乐

---
这两个月听的大多都是旧歌，所以没找到什么极品的，故推荐三首至少还可以多听几遍的歌吧&#8230;

<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://happy.hustonline.net/music/CDImages/2232.jpg" border="0" alt="" />

<span style="color: #000000;">专辑：</span><span style="color: #cc3333;"><strong>我们都是好孩子</strong></span>

<span style="color: #000000;">歌手：</span><span style="color: #cc3333;"><strong>王筝</strong></span>

<span style="color: #000000;"><span style="cursor: default; color: #cc0000;"><span style="color: #000000;">发行日期：</span></span></span><span style="color: #cc3333;"><strong>2006年04月20日</strong></span>

<span class="red_12">唱片公司：</span>**<span style="color: #cc3333;">天凯唱片</span>**

**<span style="font-size: 100%; color: #ff0000;">推荐曲目：<a href="http://www.zhengcool.com/download/mp3/03.mp3">一杯咖啡到天亮</a></span>**

<span style="font-size: 100%; color: #ff0000;"><strong> </strong><span style="font-size: 85%; color: #555555;">个人感觉专辑里最好听的一首歌，当然，《我们都是好孩子》也是不错的歌，但《一杯咖啡到天亮》更加出彩，更加有特点和风味。</span></span>

<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://image2.sina.com.cn/ent/y/d/2005-12-27/U996P28T3D942794F329DT20060328164621.JPG" border="0" alt="" />

**<span style="color: #ff9900;">歌手名称：刘畊宏 Will Liu<br /> 专辑名称：彩虹天堂 Rainbow Heaven<br /> 唱片公司：新力博德曼<br /> 发行日期：2005年12月23日 </span>**

**<span style="color: #ff9900;"><span style="font-size:100%;">推荐曲目：</span><a href="http://filelodge.com/files/hdd7/165102/kusos.3cc.cc-12-23-01.mp3"><span style="font-size:100%;">彩虹天堂</span></a></span>**

<span style="color: #ff9900;"><strong> </strong></span><span style="color: #333333;">刘畊宏，和吴宗宪、周杰伦渊源颇深的一位新人。个人认为，整张专辑里就这一首歌不错，耐听一些，但没什么特别的地方。</span>

<img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://www.henanbear.com/2/lib/200501/30/031/9.jpg" border="0" alt="" />

 <span style="font-size:100%;"><span style="color: #ff0000;">重点推荐</span><strong>NANA</strong>的这首《<strong>Lonely</strong>》：</span>

<span id="text0" class="tpc_content"><span style="color: #dd2222;">下载地址：</span><a href="http://www.greenren.ngo.cn/music/lonely.mp3" target="_blank"><span style="color: #dd2222;">http://www.greenren.ngo.cn/music/lonely.mp3</span></a><br /> <span style="color: #dd2222;">１．DJ版本—《Lonely》<br /> </span><a href="http://www.binfenxx.com/bense01.wma" target="_blank"><span style="color: #dd2222;">http://www.binfenxx.com/bense01.wma</span></a><br /> <span style="color: #dd2222;">２．六分钟超长版—《Lonely》<br /> </span><a href="http://school.ecp.com.cn/download/music/liuxh_nana.wav" target="_blank"><span style="color: #dd2222;">http://school.ecp.com.cn/download/music/liuxh_nana.wav</span></a><br /> <span style="color: #dd2222;">３．标准版—《Lonely》<br /> </span><a href="http://mp3.baidu.com/r?url=http://xwm.ezeem.com/mp3/lonely.mp3" target="_blank"><span style="color: #dd2222;">http://mp3.baidu.com/r?url=http://xwm.ezeem.com/mp3/lonely.mp3</span></a><br /> <span style="color: #dd2222;">４．纯音乐版—《Lonely》<br /> </span><a href="http://www.dialogue.org.il/hava/lonely.mid" target="_blank"><span style="color: #dd2222;">http://www.dialogue.org.il/hava/lonely.mid</span></a></span>

<span class="tpc_content"><span id="text0" class="tpc_content"><span style="color: #0081ac;">震撼心灵的不朽之作——NANA《LONELY》<br /> 我们孤独,似乎拥有很多朋友，可是，夜深人静，<br /> 一人独处的时候,又有谁可以依KAO与倾诉，因为我们都是孤独的灵魂&#8230;&#8230;<br /> 歌手NANA出身于非洲加纳的一个富有家庭，很小的时候父亲就离他而去，<br /> 母亲带着年幼的NANA定居到了德国。肤色的歧视，家庭的破碎，<br /> 使得NANA从小就在压抑的环境中生存。这首LONELY是他最有名的作品，<br /> 也是最感人的作品之一。在这首歌曲中，爱情的失败，世事的的无奈，<br /> 人与人之间的勾心斗角，都被他赤裸裸的展露在你面前。<br /> 动情处的伤心呐喊，颓废时的无奈低吟&#8230;..</span></span></span>

<span class="tpc_content"><span class="tpc_content"><span style="color: #3c8dc4;"> 很多人都误解《Lonely》的那个女声是Nana（难怪误会，很女性化的名字，国内居然翻译成娜娜，有些误导），其实中间唱RAP的男声才是Nana，才是主角，女声是Sibela，建议看看歌词，可以说，没中间的大段RAP，《Lonely》也许只是一首很普通的歌而已。</span></span></span>

<span class="tpc_content"><span class="tpc_content"></span></span> <span style="color: #cc7033;">Lonely<br /> Nana Mouskouri</span>

I am lonely lonely lonely, I am lonely lonely in my life
  
I am lonely lonely lonely, god help me help me to survive

Remember first time we met day one
  
Kids in the garden playing games having fun
  
Exciting and amazing having a real friend of mine
  
Feel my heartbeat and for real friend of mine

Face to face and eye to eye, using our hands to buy and supply
  
Chilling is cool from january to june
  
And we still stiked together like the glue
  
And know the rules forever you and I and believe it was clear
  
If I ever should fall I could count on you with no fear

Running out of time I see who&#8217;s fake
  
Alone without protection from all them snakes
  
All for one one for all I was told
  
Black white yellow no matter if you&#8217;re young or old
  
Nana&#8217;s in the house to let you know
  
What I see is how I fell and damn: I&#8217;m alone

I am lonely lonely lonely, I am lonely lonely in my life
  
I am lonely lonely lonely, god help me help me to survive

Everybody&#8217;s trippping on me. Oh lord come help me please
  
I did some bad things in my life. Why can&#8217;t you rescue me?
  
&#8216;Cause you&#8217;ve got all I need. I know I got to pay the price
  
Cheeping through the streets at night after a fuss and fight
  
Tears in my eyes. I&#8217;m a man looking for the light

Dark is the path I know he will rescue me
  
The lord is my shepard. I&#8217;m cool despite emergency
  
Whom shall I fear exept the god?
  
Thank you for the blessing and the skils on the mic

Five years we know there&#8217;s no dignity
  
Free at last see the light in me. What goes up must come down
  
I&#8217;ll be around while you heading towards deathtown
  
Allways look forward hardly never look back
  
So many tears and the snakes on my jack
  
Now I&#8217;m riding in my big fat ride. Your ass is late so look for the line
  
Nana&#8217;s in the house to let you know
  
What I see is how I feel. So leave me alone

I am lonely lonely lonely, I am lonely lonely in my life
  
I am lonely lonely lonely, god help me help me to survive

Knock on my door. Whom you&#8217;re looking for?
  
A dream or reality enemies at my door
  
Eyes I realize it&#8217;s fantasize. I must be high
  
So let me live before I die. Once again grab the bottle twist the cap
  
To survive your life is yours. My life is mine

No emotions in this world full of lies. Step by step and be versatile
  
Love peace and cash. That&#8217;s what is&#8217;s all about
  
Alone by yourself than you lack. There&#8217;s no doubt about
  
I&#8217;m always into something making moves to improve
  
What would you do if you were in my shoes?
  
Boom a letter oops another suicide?

Meet me for a ride at the boulevard. Nana&#8217;s in the house to let you know
  
What I see is how I feel and damn I&#8217;m alone. I am lonely lonely lonely

参考译文（来自互联网）

我是这么孤独，我的生命是这样孤独
  
我是这么孤独，上帝呀，请给我活下去的勇气

还记得我们见面的那天，孩子们在花园里正玩的开心
  
很高兴找到自己的知心朋友

面对面的眼神交，用我们的双手来补偿和交换
  
从寒冷的一月到凉爽的六月天，我们还是无法离散
  
我们知道游戏的规则，是永远那么清楚明白
  
如果我跌倒，我并不害怕，还有你可依靠
  
日久见人心， 在这险恶的世界里
  
“人人为我，我为人人”他们这样告诉我
  
不论你的皮肤颜色还是年龄大小
  
Nana在这里告诉你，我看见的就是我感觉的。我只有我自己

我是这么孤独，我的生命是这样孤独
  
我是这么孤独，上帝呀，请给我活下去的勇气

所有的人都把我践踏，上帝呀，快来帮助我
  
我一定是做错了什么事，你为什么就不能拯救我？
  
因为你能给我想要的一切。我知道我必须付出代价。
  
穿过午夜孤独的大街，身上带着新添的伤痕
  
眼含泪水，去寻找光明。

黑暗是必经之路，上帝会拯救我
  
他就是我的领路人。虽然急迫但我内心依然冷静
  
除了上帝我谁也不怕。 感谢上帝保佑，赐予我美妙歌喉

五年了，我活的没有尊严，我终将获得灵魂的解放
  
生死交替无法避免，我会陪你走向死亡之城，永不回头
  
留过多少泪，受过多少磨难，我已踏上寻找光明的旅途
  
你来晚了就要排队。
  
Nana在这里告诉你，我看见的就是我感觉的。所以不要打扰我

有人敲我的门，你想找谁，找寻梦想还是残酷的现实？
  
我意识到这是幻想。我一定是太激动了
  
所以死之前要好好活一次。抓过酒瓶，卷起帽子
  
你过你自己的生活，我过我自己的生活，

在这个充满谎言的世界没有感情可言
  
一步一步来，随机应变。热爱和平和破坏，这就是一切
  
毫无疑问，你只能依靠自己。
  
我总是专注一件事情，努力改进。
  
如果你是我你会怎么办？情绪低沉然后自杀？
  
我会等着你一起去寻找解脱。
  
Nana在这里告诉你，我看见的就是我感觉的。我只有我自己。

<span style="color: #5e5ea2;">【歌词全难点，语法解释】</span>

1. 这首Lonely是一首黑人说唱歌曲，同时加入了R&B和Blues的曲风，歌曲的当中还有女声的伴唱，旋律非常优美。那我们就先来说说歌名 lonely这个词，它是一个形容词，表示“孤独的，寂寞的”，比如说：Living in a big city can be very lonely. 在大城市里生活会感觉孤独。Hers is a lonely life. 她的生活很寂寞。注意了，还有一个词大家要和lonely区分开，就是alone，它表示“单独的，独自的”，比如说，I don&#8217;t feel like going out alone after dark. 我不愿意天黑后独自外出。He lives all alone in that big house. 他独自一人住在那所大房子里。再举个例子大家就更清楚了，I live all alone but I never feel lonely. 我虽然孑然一身，但是从来不会感到寂寞。还有一个短语是lonely hearts，大家应该注意一下，表面意义是“孤独的心”，那么引申一下就不难把它理解为“征友者”，尤其是指那些征婚的人，我们在报纸上经常会看到的征友或者是征婚专栏，就可以说成 a lonely hearts column。

2. 因为这是一首说唱歌曲，所以歌词当中有很多音节的省略，比如动词的-ing形式，说话很快的时候通常就会省略掉那个后鼻音-g，歌词当中的playing 和having都作了这样的省略。Kids in the garden&#8217; playin&#8217; games havin&#8217; fun这句话我们可以把它补完整，就是Kids are playing games and having fun in the garden.。

3. Excitin&#8217; and amazin&#8217; havin&#8217; a real friend of mine这句歌词按照正常的顺序应该是It&#8217;s exciting and amazing to have a real friend of mine. 找到一个知心朋友真让人高兴。

4. face to face大家知道了，是“面对面”的意思，eye to eye表示“眼神交流”，同时还有一个短语跟它有关，就是see eye to eye with someone，跟某人的看法完全一致，例如：We&#8217;ve never seen eye to eye on this matter. 关于这件事我们的看法从来都不一致。

5. And we still sticked together like the glue，这句话是一个比喻的句子，跟汉语里的“形影不离”或者“焦不离孟，孟不离焦”差不多，是说两个朋友之间亲密无间。

6. count on someone，表示“依赖，信任或指望某人”，比如说，Don&#8217;t count on a raise in salary this year. 今年就别指望加薪了。

7. run out of something这个词组表示“消耗，用完”，比如说，We&#8217;re running out of gas. 我们的汽油快用完了。或者说成Our gas is running out. 还有，We&#8217;re running out of time. 我们剩下的时间不多了。或者Our time is running out. 再举个例子，Could I have a cigarette? I seem to have run out. 给我一根烟好吗？我的已经抽完了。

8. 这里的snakes并不是指真正的蛇，圣经故事中，snake引诱亚当和夏娃偷吃禁果，所以现在人们用snake来指那些“阴险的人”，有一个习语是a snake in the grass，就是指“伪装成朋友的阴险小人”，比如说，That snake in the grass reported me to the boss. 那个口蜜腹剑的阴险小人到老板那里告了我一状。

9. all for one one for all相当于我们汉语当中说的“人人为我，我为人人”，就是说无论来自何方，人们都应该互相关心互相帮助。但是现实却不是这么回事，这让Nana很失望。

10. survive表示“活下去，继续生存或存在”，特别是指“幸存”，比如说，Of the ten people in the plane that crashed, only one survived. 失事飞机上的10个人当中只有一个人幸存。

11. trip这里指“绊倒某人”，比如说，Be careful you don&#8217;t trip on the mate. 小心别被地上的席子绊倒了。Lord是指上帝。Nana发出内心的呼喊，希望上帝能帮助他从孤独的情绪当中解脱出来。

12. pay the price，这里并不是指“付钱”，而是指“为做成某事而付出代价”，比如说，Our troops recaptured the village, but they paid a heavy price for it. 我们的军队重新占领了那个村庄，但是他们却因此付出了沉重的代价。

13. cheep的意思是“发出吱吱的响声”，用在这里更加突出了午夜大街的空旷寂静，和Nana心里的孤独情绪。

14. fuss 是指“无谓的烦恼或激动，发怒的场面”，比如说，Don&#8217;t get into a fuss about nothing. 别没事找事，自寻烦恼。 There will be real fuss if you&#8217;re caught cheating. 你要是作弊的时候被人逮着，那可真够你受的了。fuss还可以作为动词，意思是“因为某事而烦恼或激动”，经常和about连用，举个例子，Stop fussing and eat your cereal! 别大惊小怪的，吃你的麦片吧！If you keep fussing about, we&#8217;re sure gonna be late. 你要是瞎忙个没完，我们肯定会迟到的。

15. shepherd, “牧羊人”，同时也有“带领人，指路人”的意思，这里Nana把自己比喻成了迷途的羔羊，等待“牧羊人”也就是上帝的指引。这也跟圣经故事有关。

16. cool在这里表示“不慌不忙的，冷静的”，比如说，She always stays cool, calm and collected in a crisis. 她在危难中总能保持冷静、平静和镇静，这个句子中出现的三个形容词cool，calm 和 collected都能表示“不慌不忙的，冷静的”这个意思。

17. mic是一个缩略形式，在口语当中指microphone 麦克风，the skills on the mic 字面翻译是“使用麦克风的技巧”，其实也就是“唱歌的技巧；美妙的歌喉”，幸好还有音乐陪伴Nana的生活，让他还有生存下去的勇气和希望。

18. What goes up must come down，是说世事无常，没有什么永久的东西。那么Nana要陪谁走向死亡之城呢？我想就是指上帝，而death town指的就是耶路撒冷，也就是圣经上记载耶稣殉难的地方。这里是说，Nana决心要追随上帝寻找光明和内心的平静，并且义无反顾。

19. 这里big fat ride是指“豪华的、奢华的旅程”，有一部电影的名字叫My Big Fat Greek Wedding，翻译过来就是《我的盛大的希腊婚礼》。那么big fat ride是指什么呢？应该是指寻找内心平静和光明的旅程。

20. high这里的意思是“兴高采烈的，异常激动兴奋的”，比如，Everybody was in high spirits at the party last night.昨天晚上大家在派对上玩的都很高兴。

21. versatile原意是指“多才多艺的或者多功能的”，这里引申为“随机应变”，不要那么死板，因为这个世界充满了谎言，如果太认真，就会受到伤害。有和平就会有破坏，只能接受这个事实。

22. be into something，表示“对某事物很感兴趣，对某事很专注”，比如说，I&#8217;m heavily into stamp collecting. 我疯狂喜欢集邮。make moves to do something，采取行动做某事。这里Nana好像完全想通了，觉得应该改变自己来适应社会，抱怨是没有用的。

23. be in one&#8217;s shoes 或者put oneself in one&#8217;s shoes 这个习语表示“处于某人的境地或处境来设想”，比如，I wouldn&#8217;t like to be in your shoes if they find out what you&#8217;re doing. 如果他们发现了你在干什么，我可不愿设想你得有多倒霉。我们大家比较熟悉的是stand in one&#8217;s shoes，站在某人的立场上设想。You wouldn&#8217;t do that if you stood in my shoes. 如果你是我的话，你也不会那么做的。

24. boom在这里表示“用低沉的嗓音说话”，比如，&#8221;Stay away from my children.&#8221; he boomed. 不要骚扰我的孩子，他用低沉的嗓音说。

25. damn这个词，在口语当中做感叹词，表示厌烦、愤怒等， 委婉一点的说法是darn。举个例子，Damn! I&#8217;ve lost my wallet. 倒霉！我的钱包丢了。Damn this useless computer! 这个破电脑真该死！