---
title: 领导归来
author: Chouj
type: post
date: 2008-08-20T14:50:43+00:00
url: /2008/08/20/girlfriend-comes-back/
views:
  - 1710
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969905
categories:
  - 我记录
tags:
  - 感情

---
  1. 地拖拖
  2. 席子擦擦
  3. 洗澡水烧烧
  4. 把自个儿拾掇拾掇
  5. 整壶凉白开，备喝
  6. 绿豆沙一锅，晾凉
  7. 买花瓶一只，插九坨玫瑰
  8. 默诵《爱老婆八荣八耻》十遍
  9. 扪心自问：合格没？合格没？合格没？……