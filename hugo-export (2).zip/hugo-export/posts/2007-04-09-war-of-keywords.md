---
title: 关键字的口水战
author: Chouj
type: post
date: 2007-04-09T06:37:19+00:00
url: /2007/04/09/war-of-keywords/
views:
  - 2665
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969669
categories:
  - 我表达
tags:
  - zola
  - 周曙光
  - 搜狗
  - 谷歌
  - 输入法

---
（<font color="#0000ff">谷歌</font>牵着<font color="#0000ff">搜狗</font>满世界溜达……）
  
 <font color="#0000ff">搜狗</font>： 多谢谷大哥赏识啊，方能像今天这般风光啊！
  
 <font color="#0000ff">谷歌</font>： 知道炒作的厉害了吧？稍微弄点噱头，咱就名利双收啦。<font color="#0000ff">紫光</font>那臭小子，坐着哭吧，谁让丫不跟我合作。老子名气在外，你也可以狗假虎威不是？
  
（<font color="#0000ff">周曙光</font>率<font color="#0000ff">Zola</font>、<font color="#0000ff">钉子户</font>杀将过来……）
  
 <font color="#0000ff">周曙光</font>：谷歌，我要找你算账！
  
 <font color="#0000ff">谷歌</font>： 护驾～～
  
 <font color="#0000ff">Google</font>：不关我事，我闪。。。
  
 <font color="#0000ff">搜狗</font>： 汪、汪、汪！<font color="#0000ff"><br /> 周曙光</font>：你丫也太不给面子了吧，我就是想出点小名儿，顺便也让我这俩兄弟沾点光，你可倒好，整一什么破输入法出来，铺天盖地的立马就把我哥仨给灭了。虽然房子倒了，但我人还没走，你这茶就凉了啊？
  
 <font color="#0000ff">谷歌</font>：你人品差嘛。实话告诉你，<font color="#0000ff">输入法</font>那小妮子跟太多人有染，罩不住啊。
  
 <font color="#0000ff">输入法</font>：谷歌你放屁，老娘天天陪你这个被阉的臭太监还有那只馊狗吃喝玩乐，到头来名声也臭了，钱也没捞到，你还给老娘在这儿造谣！
  
 <font color="#0000ff">谷歌</font>：你少在这儿<font color="#0000ff">Twitter</font>（Twitter：我招谁惹谁了我？！），别以为你带个“法”字儿你就牛×完了，就算你丫是个法，看到<font color="#0000ff">物权法</font>没有，丫们给她整了个Cao案，你也想试试？哈哈……
  
 <font color="#0000ff">输入法</font>：你！老娘跟你们拼啦！！！
  
！@汪##@￥%……￥%%￥汪#
  
 <font color="#0000ff">周曙光</font>：<font color="#0000ff">Zola</font>继续为您带来独立网志作者的独家报道。继<font color="#0000ff">谷歌</font>披露<font color="#0000ff">输入法</font>生活不检点、<font color="#0000ff">输入法</font>嘲笑<font color="#0000ff">谷歌</font>是宦官之后，双方的矛盾逐渐扩大，冲突也在升级之中。<font color="#0000ff">谷歌</font>、<font color="#0000ff">搜狗</font>、<font color="#0000ff">输入法</font>，到底最后是群P还是3P，<font color="#0000ff">字库</font>到底是<font color="#0000ff">谷歌</font>和<font color="#0000ff">搜狗</font>谁的小孩儿……
  
 <font color="#0000ff">字库</font>：别提我！谁再提我我跟谁急！
  
 <font color="#0000ff">周曙光</font>：呃，对不起……敬请关注<font color="#0000ff">Zola</font>的网志！
  
（<font color="#0000ff">Zola</font>：攒气儿～再攒气儿～放必杀！小～佐～飞～～～吻！）
  
 <font color="#0000ff">GFW</font>：<font color="#0000ff">周曙光</font>终被招安，八一卦也算和谐。横批：准予发表！
  
 <font color="#0000ff">钉子户</font>：没有<font color="#0000ff">Zola</font>香，没有<font color="#0000ff">谷歌</font>高，我是一颗无人知道的小～嗷～草～～啊！！（被某银必杀击中，卒。）

**以上文字纯属虚构，如有雷同纯属扯蛋，本文最终解释权归作者所有，钦此。**