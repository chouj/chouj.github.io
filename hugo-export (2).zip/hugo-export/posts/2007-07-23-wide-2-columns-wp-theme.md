---
title: 宽版二栏WP Themes
author: Chouj
type: post
date: 2007-07-23T12:26:17+00:00
url: /2007/07/23/wide-2-columns-wp-theme/
views:
  - 2681
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969693
categories:
  - 我表达
tags:
  - theme
  - WordPress

---
<img src="http://wordpress.org/style/header-logo.png" align="right" />

主题关键字：**宽版 二栏 右边栏 白底 简洁**

特色：大气 简单

  * <a href="http://www.idsg.it/2007/04/17/tema-wordpress-my-gray-time/" target="_blank">My Gray Time</a>

<a href="http://www.idsg.it/" target="_blank">SH</a>作品，相当简单，Single.php都没有，实用型。

  * [ShinRa House Blu 2c][1]

<a href="http://www.idsg.it/" target="_blank">SH</a>作品，比上一款要更加美观成型。

  * [blogool.org WordPress Theme][2]

博狗官方博客的主题，挺精致，但要改很多地方才能为己所用。

  * [Cubes][3]

相当靓，相当大气的一款主题。只是Sidebar的样式是用图片表示的，不适合自定义。

  * [YGosimple][4]

页眉有点窄小了，但一样很不错。

  * [YGo Black & White][5]

除了感觉边栏和正文背景反差太大外，也是很棒

个人非常喜欢这种宽版的主题，非常大气，不逼仄，虽然没有ajax之类的效果。所以我就在网上搜罗了些，应该不止这里所罗列的。要说看着最舒服的，得算<a href="http://www.awflasher.com/blog" target="_blank">aw</a>的。

 [1]: http://www.idsg.it/2007/05/10/tema-wordpress-shinra-house-blu-2c/ "Tema WordPress: ShinRa House Blu 2c"
 [2]: http://wordpresstheme.cn/2007/06/blogoolorg-wordpress-theme-released-306.html "blogool.org WordPress Theme Released"
 [3]: http://www.hosterio.com/blog/cubes-free-wordpres-theme/ "Link to Cubes - Free Wordpres theme"
 [4]: http://www.ygosearch.com/seoblog/?p=6 "Permanent Link to YGosimple - 2 column wordpress theme"
 [5]: http://www.ygosearch.com/seoblog/?p=28 "YGo Black & White - 2 column widget ready wordpress theme"