---
title: RSS资源：国家地理新闻
author: Chouj
type: post
date: 2007-07-30T15:39:20+00:00
url: /2007/07/30/feed-for-nationalgeographicnews/
views:
  - 1833
  - 1833
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969968
categories:
  - 资源
tags:
  - Feed

---
<a target="_top" href="http://www.nationalgeographic.com/index.html" title="Click for National Geographic\'s home page." class="ngheader"><img border="0" vspace="4" align="middle" width="220" src="http://www.nationalgeographic.com/meta/logo.gif" alt="nationalgeographic.com logo" height="24" /></a>

<a target="_blank" href="http://news.nationalgeographic.com/" title="国家地理新闻频道">国家地理新闻频道</a>的头条和新闻概要已经可以通过RSS Feed实现订阅啦！虽然只能看到小图和简介，想见到精美图片和新闻还是要访问网站，但聊胜于无。RSS地址如下：

[<img border="0" width="36" src="http://news.nationalgeographic.com/news/images/global/xml.gif" alt="After installing a news reader, click on this icon to download National Geographic News's XML/RSS feed." height="14" />][1] [<img border="0" width="36" src="http://news.nationalgeographic.com/news/images/global/rss.gif" alt="After installing a news reader, click on this icon to download National Geographic News's XML/RSS feed." height="14" />][1] <http://news.nationalgeographic.com/index.rss>

[via [1][2] [2][3]]

 [1]: http://news.nationalgeographic.com/index.rss
 [2]: http://news.nationalgeographic.com/news/misc/rss.html
 [3]: http://www.rss-specifications.com/blog.htm#764