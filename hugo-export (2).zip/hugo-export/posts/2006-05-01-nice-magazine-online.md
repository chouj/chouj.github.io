---
title: 一些不错的网刊
author: Chouj
type: post
date: 2006-05-01T03:21:00+00:00
url: /2006/05/01/nice-magazine-online/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/05/blog-post.html
views:
  - 1420
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969775
categories:
  - 我表达
  - 我记录
tags:
  - 网刊

---
<a title="manonfire" href="http://manonfire.yculblog.com/" target="_blank">manonfire</a> 那里 有一文——<a href="http://manonfire.yculblog.com/post.1230461.html" target="_blank">网刊小窥，小思，展望</a>——介绍了不错的一些网上刊物。

最近从 <a href="http://zhivago.bokee.com/" target="_blank">王怡</a> 那里也发现了一个不错的网刊，全当补充。

<a href="http://www.blsq.com/qianyan/" target="_blank">前沿周刊</a> 涵盖政治、经济、宗教、历史、文化等诸多方面，主编： 王怡 乾言 王光泽，里面很有些不错的文章，推荐一看！目前第三十四期。