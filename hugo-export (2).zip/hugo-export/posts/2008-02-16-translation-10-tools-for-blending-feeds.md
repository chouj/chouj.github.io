---
title: '[翻译]10个用于合并RSS Feeds的工具'
author: Chouj
type: post
date: 2008-02-15T17:17:46+00:00
url: /2008/02/16/translation-10-tools-for-blending-feeds/
views:
  - 4207
  - 4207
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969995
categories:
  - 工具
  - 翻译
tags:
  - Aggregation
  - Feed
  - Feedtwister
  - Filter
  - Merge
  - Yeeyan

---
原文：<a href="http://www.tothepc.com/archives/10-tools-to-combine-mix-blend-multiple-rss-feeds" target="_blank">10 Tools to Combine, Mix, Blend Multiple RSS Feeds</a>
  
作者：Davinde
  
译者：<a href="http://www.xuchi.name/blog" target="_blank">抽筋儿</a>

<big>越</big>来越多的网民开始接触RSS feed及其应用，以致涌现出一批优良的线上或线下RSS feed管理工具，其中Feedburner和Feeblitz是行业领袖。

<big>每</big>当你想从不同的渠道获取信息时，使用工具对RSS Feeds的内容进行过滤是必要的，同时将同类RSS Feeds合并，消灭内容重复的RSS Feeds，似乎更加重要。这有助于你整合Feeds内容，打造统一的RSS Feeds。十个能完成此类任务的工具值得介绍一哈：

<p style="text-align: center">
  <img src="http://pic.yupoo.com/xcchris/3326051923f3/gii3ddzu.jpg" alt="RSS mix" />
</p>

<p style="text-align: center">
  <!--more-->
</p>

<p style="text-align: left">
  <strong>1. <a href="http://www.rssmixer.com/">RSS Mixer</a></strong> —— 只要输入需整合的RSS Feed链接地址和合并后Feed的名称，然后点击“Mix”按钮，就能得到所有单一feeds的整合版。而且还有很多格式供选：苹果式面板widget、网页嵌入式widget、iPhone支持版，等等。
</p>

<p style="text-align: left">
  <strong>2. <a href="http://www.feedblendr.com/">FeedBlendr</a> </strong>—— 简简单单合并feeds的又一线上服务。输入想合并的feeds地址，然后点“Blend Your Feed”按钮即可，无需注册或下载什么东东。得到的输出有RSS/ATOM格式、浏览器用HTML链接、移动工具用(.m)链接、OPML格式和用以显 示feed内容的widget的Javascript代码。
</p>

<p style="text-align: left">
  <strong>3. <a href="http://www.feedtwister.com/">FeedTwister</a> </strong>—— 这个服务允许你合并你喜爱的feeds并将最新的更新显示在你的站点上。想创建多少feed列就可以创建多少，每列可塞进50个feeds；而且还可以给 每个feed加张图释，选择是按时间还是按标题排列文章，以及选择文章输出的条目数，或者每个feed最多显示出几条标题。
</p>

<p style="text-align: left">
  <strong>4. <a href="http://www.blogsieve.com/">BlogSieve</a></strong> —— 通过过滤、整合、分类现有feeds以创建新feeds的一款免费的线上服务。BlogSieve可以识别各种标准的feed格式，并依据用户的选择生成对应的feed格式。
</p>

<p style="text-align: left">
  <strong>5. <a href="http://www.feedforall.com/rssmesh.htm">RSSMesh</a> ——</strong> rssMesh.php脚本可以将多个feeds的最新条目整合到一个feed中。针对每个生成的feed，RSSmesh通过一个配置文件予以构造。
</p>

<p style="text-align: left">
  <strong>6. <a href="http://www.rssmix.com/">RSS Mix</a> ——</strong> 可将任何数目的feeds合并到一个单独的feed里，也是基于线上的服务，界面简单，只要复制已存的feeds地址，粘贴到选框中点击创建即可。
</p>

<p style="text-align: left">
  <strong>7. <a href="http://www.blastfeed.com/">BlastFeed</a> </strong>—— 可以让用户聚合feeds、过滤feeds内容的一款线上服务，而且BlastFeed可以马上通知用户信息整合过滤的结果。BlastFeed只收集每 个feed里符合用户订制标准的条目，并以单一的文件通过email或即时通信消息或新feed的形式，在用户需要的时候发布出来。
</p>

<p style="text-align: left">
  <strong>8. <a href="http://www.feedcombine.co.uk/">Feed Combine</a> ——</strong> 就像名字一样，用户可以用它无缝拼贴feeds，整合feeds迅速高效。
</p>

<p style="text-align: left">
  <strong>9. <a href="http://www.biggu.com/frankenfeed">FrankenFeed</a> —— </strong>一款开源应用，以Ruby写成,同样可将多个RSS或ATOM格式feeds（xml）合并为单一的feed，想法在于让RSS和ATOM应用的老主顾为新手打造一个单一的feed。
</p>

<p style="text-align: left">
  <strong>10. <a href="http://pipes.yahoo.com/pipes/">Yahoo Pipes</a> ——</strong> 最后的才是最好滴。以上这些线上feed合并服务的问题是，它们随时会消失。Yahoo Pipes则是最稳的选择，原因简单，因为是雅虎滴嘛。虽然对于新手来说听起来有点悬乎，但真正掌握之后，你就会发现她的魅力了。
</p>

<p style="text-align: left">
  <big>你</big>还知道其他的RSS合并工具吗？留言来和大家分享吧！
</p>