---
title: 我用到的校内应用程序
author: Chouj
type: post
date: 2008-07-20T17:05:13+00:00
url: /2008/07/21/my-xiaonei-apps/
views:
  - 2347
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969902
categories:
  - 我表达
tags:
  - AW
  - 图片
  - 校内网
  - 网络

---
<img src="http://pic.yupoo.com/awflasher/385375e4489f/jiu7bz1g.jpg" alt="校内 app 是男人应用系列游戏" width="500" />

先囧一下开发<a href="http://apps.xiaonei.com/gameboy/" target="_blank">校内应用程序-是男人系列游戏</a>的<a title="郭启睿-AW" href="http://awflasher.xiaonei.com" target="_blank">aw</a>。

  1. [**好友买卖**][1]：所有怪黍熟嫩阿姨都来满足自己的怪趣味吧。
  2. **[是男人系列游戏][2]**：煽动高校男人火拼的无良游戏。
  3. [**鲜果阅读器**][3]：在校内吃鲜果，享受Web 2.0的阅读体验。
  4. [**好友照片墙**][4]：照片墙一直是我觉得很有趣的东东，不管她出现在哪里。
  5. [**历史的今天**][5]：历史不容忘却，不知道这个app能不能活到我有资格看“我历史上的今天”。
  6. [**秀show！**][6]：改了多次名字，还待完善，算是校内上的LifeStream，追踪尚不算及时。
  7. [**饭否3D**][7]：<a title="饭片" href="http://handycode.cn/fanfou/ff.html" target="_blank">widget饭片</a>的校内版，饭友&校友必备。
  8. [**阿瓦的闲话周末**][8]：通过安装这个给<a title="郭启睿-AW" href="http://awflasher.xiaonei.com" target="_blank">aw</a>压力，让丫把闲话写得色香味俱全点儿。

 [1]: http://apps.xiaonei.com/friendsell/home.do
 [2]: http://apps.xiaonei.com/gameboy/
 [3]: http://apps.xiaonei.com/xianguo/
 [4]: http://apps.xiaonei.com/buddywall/
 [5]: http://apps.xiaonei.com/todayonhistory
 [6]: http://apps.xiaonei.com/planbus/index.php?action=everyone
 [7]: http://apps.xiaonei.com/myfanfous
 [8]: http://apps.xiaonei.com/awflasher/