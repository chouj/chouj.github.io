---
title: Oct上半月个人俗事播报
author: Chouj
type: post
date: 2007-10-14T04:41:22+00:00
url: /2007/10/14/first-half-october/
views:
  - 2220
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969713
categories:
  - 我记录
tags:
  - 广州
  - 生活
  - 白云山
  - 穗港澳动漫游戏展
  - 笑翻天乐园
  - 素质拓展

---
  * **10.4 广州白云山半日游**
<iframe width="500" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://ditu.google.com/maps/ms?ie=UTF8&hl=zh-CN&msa=0&msid=102575039203066245657.00043c6b96ec250963aed&om=1&s=AARTsJrPvY3u9TuRa8NazsRBLZLEaE7cag&ll=23.169954,113.299856&spn=0.031563,0.042915&z=14&output=embed"></iframe>  
<small><a href="http://ditu.google.com/maps/ms?ie=UTF8&hl=zh-CN&msa=0&msid=102575039203066245657.00043c6b96ec250963aed&om=1&ll=23.169954,113.299856&spn=0.031563,0.042915&z=14&source=embed" style="color:#0000FF;text-align:left">查看大图</a></small>

终于去了久负盛名的白云山景区一次，人确实不少啊。坐索道上山，登顶海拔382m的摩星岭；最后怀疑论和坚持论打了一架，因为在半山腰的盘山公路上，我们找不到下山索道，来来回回中意志力和身体都得到了极大的锻炼。幸运的是在18:30索道停运前赶到，终成功下山。

  * **10.5 穗港澳动漫游戏展一日游**
<iframe width="500" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://ditu.google.com/maps/ms?ie=UTF8&hl=zh-CN&om=1&s=AARTsJr9FzfsgLE_wlp_6osZsQhgm77z4Q&msa=0&msid=102575039203066245657.00043c6be4552ea81f088&ll=23.14478,113.285522&spn=0.126276,0.171661&z=12&output=embed"></iframe>  
<small><a href="http://ditu.google.com/maps/ms?ie=UTF8&hl=zh-CN&om=1&msa=0&msid=102575039203066245657.00043c6be4552ea81f088&ll=23.14478,113.285522&spn=0.126276,0.171661&z=12&source=embed" style="color:#0000FF;text-align:left">查看大图</a></small>

从白云山回来，就马不停蹄的接待了从东莞赶来的[kuku][1]——校友、blogger、摄影发烧友，媒体专业却混迹公司IT部门，襄樊动漫Cosplay的鼻祖级人物。晚九点，边吃边聊，从网络扯到《[School Days（日在校园 &#8211; -#）][2]》，其实是为了商量同去动漫展的，真的。我挺佩服他的思维能力和谈吐。

第二天准时赶赴[穗港澳动漫游戏展][3]，我们照的照片都被kuku发到他自己的论坛了，想看的点[这里][4]和[这里][5]。

只放出一张10月5日动漫展上最敬业最萌最高人气的公主装loli一只：

![10月5日穗港澳动漫游戏展上最萌公主装loli一只][6]

可以和我在[hust漫舞白云Cosplay][7]上看到的女仆装小loli PK一下：

![hust漫舞白云colplay 女仆装小loli][8]

  * **10.13 广州笑翻天乐园素质拓展**
<iframe width="500" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://ditu.google.com/maps/ms?ie=UTF8&hl=zh-CN&om=1&s=AARTsJqo-7hm3PUYuUDs88LKZ4Gl_j-Wfg&msa=0&msid=102575039203066245657.00043c6b526819fdc6360&ll=23.108155,113.530655&spn=0.126311,0.171661&z=12&output=embed"></iframe>  
<small><a href="http://ditu.google.com/maps/ms?ie=UTF8&hl=zh-CN&om=1&msa=0&msid=102575039203066245657.00043c6b526819fdc6360&ll=23.108155,113.530655&spn=0.126311,0.171661&z=12&source=embed" style="color:#0000FF;text-align:left">查看大图</a></small>

07级研究生新生都参与了，玩儿得非常开心。经过一堆山间和水上的极限运动项目，我有幸成为少数几个没有落水没有受伤的队员之一，看来rp攒的不错。顺道佩服下宿舍隔壁同级的一女生，一样没落水没受伤～弓虽～

这里有[笑翻天乐园的主页][9]，居然整理出了[10大精彩落水瞬间][10]，太邪恶了。

本文纯属纪念意义～看到这儿了pass不pass都无所谓了，囧～

 [1]: http://blog.sina.com.cn/xfpopkuku
 [2]: http://www.schooldays-anime.com/
 [3]: http://www.google.cn/search?complete=1&hl=zh-CN&newwindow=1&client=firefox&rls=org.mozilla%3Azh-CN%3Aofficial&hs=ApE&q=%E7%A9%97%E6%B8%AF%E6%BE%B3%E5%8A%A8%E6%BC%AB%E6%B8%B8%E6%88%8F%E5%B1%95&btnG=Google+%E6%90%9C%E7%B4%A2&meta=
 [4]: http://www.xfpop.org/bbs/thread-2845-1-1.html
 [5]: http://www.xfpop.org/bbs/thread-2853-1-1.html
 [6]: http://photo5.yupoo.com/20071014/120834_165589647_sgjwjkuo.jpg
 [7]: http://news.hustonline.net/html/2006-4-23/29074.shtml
 [8]: http://images.hustnews.com/Interpretation/2006-4-23/9044.jpg
 [9]: http://www.xiaofantian.com/
 [10]: http://www.xiaofantian.com/newEbiz1/EbizPortalFG/portal/html/InfoContent.html?InfoPublish_InfoID=c373e90bb0a636f78f6ede4d4f600f9c