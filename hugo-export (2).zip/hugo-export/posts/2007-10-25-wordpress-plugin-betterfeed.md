---
title: '[WP插件]BetterFeed使用指南'
author: Chouj
type: post
date: 2007-10-25T13:04:48+00:00
url: /2007/10/25/wordpress-plugin-betterfeed/
views:
  - 2268
  - 2268
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969990
categories:
  - WordPress
  - 教程
tags:
  - Plugin
  - Tutorial
  - WordPress

---
<img src="http://photo5.yupoo.com/20071025/144157_423535404_lmeqxrcy.jpg" title="WordPress" alt="WordPress" height="112" width="112" />

除了[上文][1]介绍的WordPress[©Feed][2]，<a href="http://planetozh.com/blog/my-projects/wordpress-plugin-better-feed-rss/" title="Wordpress Plugin : Better Feed" target="_blank"><strong>BetterFeed</strong></a>也是一款用于更改Feed footer信息的强大插件。两者相比，前者具备Option界面，使用上比较傻瓜，后者则需要自己编辑插件部分代码；但前者不支持php语言调用，后者则可借助php参数调用，为feed添加进更有针对性、更智能的信息。所以说，两个插件各有优劣，不过，**切勿同时启用**。

<!--more-->

**BetterFeed**主页上说其能实现的功能有：

  1. 在Feed中添加“Read more &#8230;”或“Next Page &#8230;”链接；
  2. 添加版权声明；
  3. 添加分类、评论数；
  4. 添加置底文章链接；
  5. 添加bookmark链接和反向查询链接；
  6. 添加其他你能想的到的信息，比如广告、口号、推广之类。

下图是一张启用**BetterFeed**后的效果图：

<img src="http://photo5.yupoo.com/20071024/223308_1250673943_sgbgnxsu.jpg" title="RSS相关 betterfeed 效果" alt="RSS相关 betterfeed 效果" height="225" width="459" />

要想得到这种效果，我们要做的是：**更改插件php文件中的相关代码**：

<img src="http://photo11.yupoo.com/20071024/223308_1017096139_mwinjbvh.jpg" title="RSS相关 betterfeed 设定" alt="RSS相关 betterfeed 设定" height="382" width="438" />

wp\_ozh\_betterfeed.php头部插件注释之后，即有“Edit Here”的字样提示从这里开始插件设定啦。“General Behavior”中需要设定两个参量的值，图中的**split**量用来设定是否在feed中支持wordpress<!&#8211; more &#8211;>标签输出“Read More”，值1表示开启，值0表示停用；第二个参数**multipage**量则用来设定是否在feed中支持wordpress<!&#8211; nextpage &#8211;>标签输出“Read More”，同样值1表示开启，值0表示停用。

再往下，我们可以看到：

<img src="http://photo11.yupoo.com/20071024/223309_40671525_nabinmjq.jpg" title="RSS相关 betterfeed 代码" alt="RSS相关 betterfeed 代码" height="402" width="437" />

橙红色区域的注释告诉我们，将写好的html填充到“<<<FEEDFOOT”和“FEEDFOOT;”之间即可。BetterFeed提供了若干变量名供我们调用WordPress信息，注解翻译如下：

  * **%%blogname%%** : 博客名称 (My Weblog)
  * **%%blogurl%%** : 博客链接 (http://myblog.com/)
  * **%%posttitle%%** : 本文题目 (Hello World)
  * **%%posturl%%** : 本文链接 (http://myblog.com/archives/2001/02/03/hello-world/或 http://myblog.com/?p=123)
  * **%%id%%** : 本文 ID (文章数字号, 比如上例中的123 )
  * **%%date[Y]%%** :日期，发文时间, 括号内时间样式遵循PHP [date()][3]语法
  * **%%categories%%** : 以逗号间隔列出文章归入的分类
  * **%%categorylinks%%** : 各个以逗号间隔的分类的链接
  * **%%comments%%** : 评论数量
  * **%%comments_text%%** :评论文本，0条评论、1条评论或x条评论，默认显示为英文，可更改。
  * **%%readmore%%** : 若开启，则添加&#8221;Read more&#8221;链接文字，亦可更改。
  * **%%wordcount%%** : 本文字数
  * **%%wordcount_remain%%** : 阅读更多中未显示的文本字数
  * **%%author_first%%** : 作者的名
  * **%%author_last%%** : 作者的姓
  * **%%author_nick%%** : 作者昵称

其中，%%readmore%%和%%comments_text%%所显示出的文本可找到相应的默认代码，做更加个性化的更改。这里给出一个[RSS相关][4]原来用的代码：

`</p>
<p>%%readmore%%</p>
<hr noshade style="margin:0;height:1px" />
	<small></p>
<p>&copy; %%author_nick%% for <a href="%%blogurl%%">%%blogname%%</a>, 2007. | <a href="%%posturl%%">Permalink</a> | <a href="%%categorylinks%%">%%categories%%</a> | <a href="%%posturl%%#comments/">%%comments%%</a></p>
<p>Add to <a href="http://del.icio.us/post?url=%%posturl%%&#038;title=%%posttitle%%">Del.icio.us</a> | Who's linking? <a href="http://www.technorati.com/search/%%posturl%%" title="Search on Technorati">Technorati</a></p>
<p></small><br />
` 

您可在utf-8编码下打开插件php文件，自行编辑代码，再上传wp\_ozh\_betterfeed.php到wordpress/wp-content/plugins/，在后台激活插件即可；或者上传插件后，开启写入属性，在wordpress管理后台的插件页面下编辑该插件相应代码，再激活。

[ <a href="http://planetozh.com/blog/my-projects/wordpress-plugin-better-feed-rss/" target="_blank">点此进入<strong>BetterFeed主页</strong></a> ]

 [1]: http://aboutrss.cn/2007/10/17/wordpress-plugin-copyfeed/ "[WP插件]©Feed指南及其汉化版"
 [2]: http://wordpress.org/extend/plugins/copyfeed/ "©Feed"
 [3]: http://planetozh.com/blog/go.php?http://php.net/date
 [4]: http://aboutrss.cn/