---
title: 海盗三 一般般
author: Chouj
type: post
date: 2007-06-20T04:14:25+00:00
url: /2007/06/20/pirates-of-the-caribbean-3/
views:
  - 2368
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969685
categories:
  - 我记录
tags:
  - IMAX
  - movie
  - 加勒比海盗

---
![][1]

[<big><big>白</big></big>云黄鹤影版][2]的[毕业生电影包场][3]，实惠啊，巨幕影院，两部片子35元。这种机会岂能错过，就当是离开武汉前的留念庆典了，而且还是我长这么大第一次进正规影院看电影，惭愧。:P

<big><big>观</big></big>影效果自然不用说，IMAX巨幕，第十排正中间。要说不足，也有，中文配音，片子不是完整版，看电影前什么东西都没吃，空腹啊，就等这精神食量了。

<big><big>另</big></big>起一段好好评述下主食——海盗三。个人感觉，效果场景自然不错，恢弘壮丽，However，悬念和情节的衔接却显得生硬了，不像在娓娓道来地讲故事，倒像是费劲儿捏巴一个故事出来。有评论说的好：

> <big><big>搞</big></big>笑部分太过僵硬，让人想笑笑不出声，想哭感情又干巴巴！……层层忽悠，层层设局，结果啥都没有，就换来两个人最后的结合……饼子摊大了

<big><big>期</big></big>望大了失望就大了，海盗一里的幽灵船，海盗二里的水车、章鱼，比海盗三的螃蟹海神加漩涡海神要出彩更多。

<big><big>再</big></big>说说甜点——国际空间站，在[豆瓣][4]上居然搜不到，奇怪。但立体电影的效果果真不一般，透过眼镜，前排观众不是被撞死了，就该被水泡着，眼睛被欺骗的厉害，立体的魅力在某些程度上比海盗三那让人琢磨得想睡的剧情更为精彩。

<big><big>总</big></big>结来说，辉常不错的体验，虽然被一同去的生活观念迥异的同学小影响了下心情。PS.看完之后，穿过新民众乐园出来，发现该地界上的小美女还挺不少。。

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://photo8.yupoo.com/20070620/080643_1707506905_arfhjeqf.jpg
 [2]: http://www.byhh.net/cgi-bin/bbsdoc?board=Movies
 [3]: http://www.byhh.net/cgi-bin/bbscon?board=HUSTExpress&file=M.1181721477.A&num=2093&start=2075
 [4]: http://www.douban.com