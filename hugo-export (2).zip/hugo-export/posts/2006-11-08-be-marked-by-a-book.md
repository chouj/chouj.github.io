---
title: 被丫标记了
author: Chouj
type: post
date: 2006-11-08T14:28:00+00:00
url: /2006/11/08/be-marked-by-a-book/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/11/blog-post_08.html
views:
  - 1687
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969827
categories:
  - 我思考
tags:
  - 读书

---
[<img style="FLOAT: left; MARGIN: 0px 10px 10px 0px; CURSOR: hand" src="http://www.douban.com/mpic/s1358641.jpg" border="0" alt="" />][1]
  
**<span style="font-size:180%;">闲</span>**极无事，在课堂上翻《<a href="http://www.douban.com/subject/1193990/" target="_blank">长河如烟</a>》，历史文化散文书系，看到以下两段：

> P25
> 
> **<span style="font-size:180%;">纵</span>**观中外历史，有几个雄才大略的政治家不是好色之徒？从秦皇汉武到唐宗宋祖，又有哪一个身边不是佳丽如云？好色是一种体魄的强劲和生命激情的旺盛，而这些正是一个有作为的政治家必须具备的。拿破仑在攻打奥地利战役的隆隆炮声中，仍忘不了书写火热的情书，倾诉他渴望同情人幽会的相思之情，不如此他就不是拿破仑。相比之下，那些所谓的“道德伟人”要不就是庸常之辈，要不就是伪君子。

> P38－39
> 
> **<span style="font-size:180%;">刀</span>**没有砍下去就想到将来给人家平反，这是多么高瞻远瞩的预见！不要以为这是作者的主观揣测，古往今来，这样英名大度的政治家难道还少吗？仅凭这一点，一般的芸芸之辈就玩不成政治家，你缺乏那种超越性的思维，缺乏那种明知不该杀也要坚决杀的大无畏气概，也不可能那样永远占有真理：当初杀你是对的，现在平反也是对的，你还得对我感激涕零呢。

**<span style="font-size:180%;">看</span>**过之后，靡靡中给自己打上了几个标签：“庸常之辈”、“芸芸之辈”。罢了，作不了主角，就作观众。

 [1]: http://www.douban.com/mpic/s1358641.jpg