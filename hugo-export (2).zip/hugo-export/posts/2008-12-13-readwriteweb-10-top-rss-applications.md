---
title: ReadWriteWeb：08年度十个顶级RSS应用
author: Chouj
type: post
date: 2008-12-13T14:04:41+00:00
url: /2008/12/13/readwriteweb-10-top-rss-applications/
views:
  - 1741
  - 1741
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970030
categories:
  - 新闻
tags:
  - 2008
  - dapper
  - Feedburner
  - friendfeed
  - gnip
  - Google Reader
  - greasemonkey
  - postrank
  - readwriteweb
  - Snackr
  - twitterfeed
  - yahoo pipes

---
<img style="float: left; margin-left: 10px; margin-right: 10px;" src="http://www.readwriteweb.com/images/150-red-star.jpg" alt="ReadWriteWeb：08年度10个顶级应用" align="left" />**ReadWriteWeb**于11日发布了一篇题为“<a title="Top 10 RSS and Syndication Products of 2008" href="http://www.readwriteweb.com/archives/top_10_rsssyndication_products_of_2008.php" target="_blank">Top 10 RSS and Syndication Products of 2008</a>”的日志，评选出了08年度十个顶级的RSS应用类产品。他们的评价翻译过来就是：“这些都是我们日夜使用的feed工具，我们喜爱他们的优点，讨厌他们的缺陷，却绝对不想失去他们。”

越有用，影响越大，越能进入这个榜单；也就是说并不是评选08年RSS应用类的新产品。当然，这个榜单里的服务比较合适母语为英语的人群；对于国人来说，就不是那么适用了。

**08年度十个顶级RSS应用** by ReadWriteWeb

  * [Postrank][1]
  * [FriendFeed][2]
  * [Gnip][3]
  * [Snackr][4]
  * [Google Reader][5]
  * [Google Reader RSS Subscriber Count Greasemonkey Script][6]
  * [Dapper][7]
  * [Twitterfeed][8]
  * [FeedBurner][9]
  * [Yahoo! Pipes][10]

[ <a title="Top 10 RSS and Syndication Products of 2008" href="http://www.readwriteweb.com/archives/top_10_rsssyndication_products_of_2008.php" target="_blank">详细信息请访问ReadWriteWeb</a> ]

 [1]: http://postrank.com/
 [2]: http://friendfeed.com/
 [3]: http://gnipcentral.com/
 [4]: http://snackr.net/
 [5]: http://www.google.com/reader
 [6]: http://userscripts.org/scripts/show/21909
 [7]: http://dapper.net/
 [8]: http://twitterfeed.com/
 [9]: http://www.feedburner.com
 [10]: http://pipes.yahoo.com/