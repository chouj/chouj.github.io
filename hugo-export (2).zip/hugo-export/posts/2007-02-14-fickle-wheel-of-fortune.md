---
title: 不可承受的生活之轻
author: Chouj
type: post
date: 2007-02-14T15:41:00+00:00
url: /2007/02/14/fickle-wheel-of-fortune/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/blog-post_14.html
views:
  - 2032
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969852
categories:
  - 我表达
tags:
  - 图片
  - 大学
  - 情人节
  - 生活

---
<span style="font-size:180%;"><span style="font-weight: bold;">不</span></span>知道你是否发过这样的感慨：谁谁16岁就奥运冠军啦，谁谁18岁就唱TROY主题曲啦，谁谁谁21就赚了大笔钱啦！我是有的。想想人一生下来一无所有，之后就开始在生活的一夯一击中，走出迥异的方向，这真是个奇迹。而且，生活总是能让人无比惊愕。初中同学聚会，居然传出某某都离婚了的消息，被打趣为：看！人家都离婚了！愣是让我哑然陪笑。二十来年的时光，就将人与人修饰的这般不同。

<span style="font-size:180%;"><span style="font-weight: bold;">从</span></span>大学里出来，经过两次同学聚会的高潮，伴随周遭空气成分的巨变，忽然百感陈杂了起来。单单一个研究生头衔，即可从大学寝室里的“不值钱”，摇身一变成为高中同学逃避聚会的借口（暂且不论这借口的真假），再瞬间套上光环成为初中同学眼中一生都不可企及的幻像，我只能说这氛围的转变，魔术般的，将漫不经心、蝴蝶效应似的生活塑造力突然暴露在我面前。

> 我们就这样依靠着父母，年少张狂，意气风发，过着随心所欲的日子，偶尔无病呻吟，把碌碌无为这四个字诠释到淋漓尽致。

<span style="font-size:180%;"><span style="font-weight: bold;">之</span></span>前在<a href="http://penglei.iyublog.com/archives/37" target="_blank">Penglei那里</a>看到的文字，不禁让我觉得，在对别样生活状态的不知情中，我是安逸的过分了，而生活轻描淡写的将我引领至此后，又将其他人引领到了别处。这样写，我把生活归为了主动者，是在逃避责任，因为我质疑，这种触动能坚持多久？窝居家中之后，这触动是否又会沦为隔靴搔痒一般？

<span style="font-size:180%;"><span style="font-weight: bold;">居</span></span>安思危。当没有比对，当我就这么轻飘飘随生活而去，当一切重归自然而然之时，我要怎么开启“思危”的步骤？有人说“生活就是强奸，反抗不了就要学会享受”，我觉得，生活也许更像迷奸，怎能让你有反抗的念头。

<img src="http://imgs.xkcd.com/comics/useless.jpg" border="0" alt="" width="420" />

转张图算了，标签：情人节、大学。祝节日快乐貌似没什么意义。真正过节的，不是在街上就是在床上，谁TM在网上啊。