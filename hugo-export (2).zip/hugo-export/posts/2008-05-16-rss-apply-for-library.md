---
title: 图书馆的RSS应用之路
author: Chouj
type: post
date: 2008-05-16T06:00:06+00:00
url: /2008/05/16/rss-apply-for-library/
views:
  - 1490
  - 1490
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970002
categories:
  - 相关
  - 知识
tags:
  - Library
  - RSS应用

---
<img class="alignleft" style="float: left;" src="http://pic.yupoo.com/xcchris/7155059095ff/qdvxbe62.jpg" alt="图书馆的RSS应用之路" />近年来，RSS在图书馆学上的应用似乎成为图书馆学界的热点，网络上有两篇代表性的文献值得浏览：

[pdf]2006年7月——<a href="http://www.lac.org.tw/epaper/200607/RSS20060716.pdf" target="_blank"><span style="color: #cc0033;">RSS</span> 介绍及其在<span style="color: #cc0033;">图书馆</span>的应用</a><span>&#8211; <span class="a">繁</span></span>
  
[pdf]2008年1月——<a href="http://www.lis.ac.cn/download/LIS_NET/2008-01/03-%E5%9F%BA%E4%BA%8ERSS%E6%8E%A8%E9%80%81%E6%8A%80%E6%9C%AF%E7%9A%84%E5%9B%BE%E4%B9%A6%E9%A6%86%E6%96%B0%E5%9E%8B%E4%BF%A1%E6%81%AF%E6%9C%8D%E5%8A%A1-%E6%9D%A8%E5%BF%83%E5%AE%81.pdf" target="_blank">基于<span style="color: #cc0033;">RSS</span> 推送技术的<span style="color: #cc0033;">图书馆</span>新型信息服务</a>

**图书馆网站应用RSS技术的好处**：

  1. 实现新书通报、馆藏动态等信息的推送服务，为资源的热门程度等角度进行导航；
  2. 实现关键词订阅、信息门类订阅，辅助图书馆用户搜索资源。

**图书馆网站应用RSS技术的现状**：

稍微搜索一下便知，目前国内借助RSS作为信息推送和搜索辅助的图书馆不多。

<!--more-->

在这一方面，台湾地区起步较早，发展得也较为成熟。高校图书馆多有RSS订阅服务页面，信息分类也比较细致。

大陆方面，高校图书馆支持RSS订阅的较少，即便支持订阅，类目也不够完善，多为最基本的新书通告或信息公告。社会性图书馆更是基本缺乏RSS支持，<a title="中科院国家科学数字图书馆的RSS新闻聚合" href="http://blog.donews.com/keso/archive/2004/03/06/5561.aspx" target="_blank">中科院国家科学数字图书馆曾经推出过一些RSS新闻源</a>，却也失效久矣。

可见，RSS技术在图书馆领域的应用尚在“初出茅庐”阶段。

**图书馆网站应用RSS技术的瓶颈：**

图书馆学比较冷门，知识结构更新较慢。RSS技术在图书馆领域的应用属于计算机、信息学、图书馆学的学科交叉范畴。所以，图书馆管理人员即便意识到RSS技术的优势，也需要时间补充相关知识和技术，很多图书馆RSS服务平台就是他们在摸索学习中搭建起来的。

**结语**：

RSS技术在图书馆网站上的推广依然任重道远，但随着RSS使用的普及，更多图书馆人认识到RSS所带来的便捷，这一过程必然会加速，一定会有图书馆“雨后春笋”般推出RSS订阅服务的那一天。

**附录**：以“图书馆 RSS”为关键词在G.cn搜索所得到的已有RSS支持的图书馆站点列表（实际支持RSS的图书馆应该不止这么几家）：

_台湾地区部分_

<a href="http://www.lib.ntu.edu.tw/rss/nturss.htm" target="_blank">国立台湾大学<span style="color: #cc0033;">图书馆</span>＊NTU LIBRARY</a>
  
<a href="http://acq.lib.nttu.edu.tw/RSS/" target="_blank">国立台东大学<span style="color: #cc0033;">图书馆RSS</span>订阅服务系统</a>
  
<a href="http://www.lib.pccu.edu.tw/rss.html" target="_blank">中国文化大学<span style="color: #cc0033;">图书馆</span>－<span style="color: #cc0033;">RSS</span>订阅服务</a>
  
<a href="http://www.lib.ntnu.edu.tw/rss/rss.jsp" target="_blank">国立台湾师范大学<span style="color: #cc0033;">图书馆</span>：<span style="color: #cc0033;">RSS</span>订阅服务</a>
  
<a href="http://www.takming.edu.tw/lib/htm/rss.htm" target="_blank">德明财经科技大学<span style="color: #cc0033;">图书馆</span>&#8211;<span style="color: #cc0033;">RSS</span>服务</a>
  
<a href="http://www.kmu.edu.tw/%7Elib/news11-5.htm" target="_blank">高雄医学大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://www.ctust.edu.tw/lib/libnew/service/RSS.htm" target="_blank">中台科技大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://140.113.39.155/rss/RSS_feeds.asp" target="_blank">国立交通大学<span style="color: #cc0033;">图书馆</span>新书通报<span style="color: #cc0033;">RSS</span>订阅服务系统</a>
  
<a href="http://www.lhu.edu.tw/lib/fast2.htm" target="_blank">龙华科技大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://lib.dyu.edu.tw/00_news/RSS/" target="_blank">大叶大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://140.120.80.33/rss/" target="_blank">国立中兴大学<span style="color: #cc0033;">图书馆</span>新书通报<span style="color: #cc0033;">RSS</span>订阅服务</a>

_大陆高校部分_

<a href="http://www.lib.tsinghua.edu.cn/service/RSS.html" target="_blank">清华大学<span style="color: #cc0033;">图书馆RSS</span></a>
  
<a href="http://www.library.fudan.edu.cn/services/rss.htm" target="_blank">复旦大学<span style="color: #cc0033;">图书馆RSS</span>服务</a>
  
<a href="http://lib.tongji.edu.cn/infoservices/rss2.htm" target="_blank">:&#8230;同济大学<span style="color: #cc0033;">图书馆</span>&#8211;<span style="color: #cc0033;">RSS</span>&#8230;</a>
  
<a href="http://lib.nit.net.cn/dlib/rss/" target="_blank"><span style="color: #cc0033;">RSS</span>推送服务&#8211;『浙江大学宁波理工学院<span style="color: #cc0033;">图书馆</span>』门户</a>
  
<a href="http://www.lib.nankai.edu.cn/nav/main/lib20/RSS/RSS.htm" target="_blank">南开大学图书馆<span style="color: #cc0033;">RSS</span> 信息订阅</a>
  
<a href="http://lib.nefu.edu.cn/main/about/about_rss.asp" target="_blank">东北林业大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://lib.shift.edu.cn/second/rss/rss.php" target="_blank">上海对外贸易学院<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://lib.wzu.edu.cn/rss/rss.asp" target="_blank"><span style="color: #cc0033;">RSS</span>频道温州大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://202.120.82.36/catrss/" target="_blank">新书通报<span style="color: #cc0033;">RSS</span>服务:: 华东师范大学<span style="color: #cc0033;">图书馆</span></a>
  
<a href="http://www.lib.bnu.edu.cn/fuwu/gd_rss1.htm" target="_blank">欢迎访问北京师范大学<span style="color: #cc0033;">图书馆</span>网站！</a>

_大陆社会性图书馆部分_

<a href="http://www.zjlib.net.cn/rss/rsswhat.asp" target="_blank">浙江<span style="color: #cc0033;">图书馆</span>——<span style="color: #cc0033;">RSS</span>新闻中心</a>
  
<a href="http://www.sdll.cn/plus/rssmap.html" target="_blank">苏州独墅湖<span style="color: #cc0033;">图书馆</span>&#8211; <span style="color: #cc0033;">RSS</span>订阅</a>
  
<a href="http://dlib.zjwu.net/rss/" target="_blank"><span style="color: #cc0033;">RSS</span>推送服务&#8211;『浙江万里学院数字<span style="color: #cc0033;">图书馆</span>』门户</a>
  
<a href="http://scinews.clas.ac.cn/newscenter.htm" target="_blank">国家科学<span style="color: #cc0033;">图书馆</span>科技新闻聚合服务系统</a>
  
<a href="http://www.nlc.gov.cn/rss/seeds.xml" target="_blank">国家<span style="color: #cc0033;">图书馆</span></a>