---
title: QQ群小秘密
author: Chouj
type: post
date: 2008-06-30T17:15:25+00:00
url: /2008/07/01/secret-of-qq-group/
views:
  - 2232
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969899
categories:
  - 我尝试
  - 我表达
tags:
  - MSN
  - QQ

---
<img class="alignnone size-medium wp-image-283" title="qq-group-1" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/qq-group-1.jpg" alt="qq群 关键字 屏蔽" width="500" />

**vs**

<img class="alignnone size-medium wp-image-284" title="qq-group-2" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/qq-group-2.jpg" alt="qq群 关键字 屏蔽" />

\***\***\***\*****\*\\*\* 测试分割线 one \*\*\***\***\***\***\****

<img class="alignnone size-medium wp-image-285" title="qq-group-3" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/qq-group-3.jpg" alt="qq群 关键字 屏蔽" width="500" />

**vs**

<img class="alignnone size-medium wp-image-286" title="qq-group-4" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/qq-group-4.jpg" alt="qq群 关键词 屏蔽" />

\***\***\***\*****\*\\*\* 测试分割线 two \*\*\***\***\***\***\****

<img class="alignnone size-full wp-image-287" title="qq-group-5" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/qq-group-5.jpg" alt="qq群 关键词 屏蔽" width="500" height="486" />

**vs**

<img class="alignnone size-full wp-image-288" title="qq-group-6" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/qq-group-6.jpg" alt="qq群 关键词 屏蔽" width="406" height="387" />

\***\***\***\*****\*\\*\* Post Script \*\*\***\***\***\***\****

<img class="alignnone size-full wp-image-289" title="msn-group" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/msn-group.jpg" alt="msn群 关键词 屏蔽" width="306" height="52" />