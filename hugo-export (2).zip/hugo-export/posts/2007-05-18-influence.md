---
title: 什么叫潜移默化
author: Chouj
type: post
date: 2007-05-18T11:03:00+00:00
url: /2007/05/18/influence/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/05/blog-post_18.html
views:
  - 2125
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969885
categories:
  - 我记录
tags:
  - 生活

---
记得挺小的时候，可能初中可能小学，一家三口看电视。电视里有个女人总是觉得恶心，呕啊呕的想吐，我当即丢了一句：

“这女的怀孕了吧？”

换回来的是两道目光，分别来自惊异大于好奇的我妈和好奇大于惊异的我爸。

“你怎么知道的啊？”

“电视上都这么演的。” 我的表情呢，估计是装下委屈那种。

现在想想，这篇的题目还可以是“什么叫润物细无声”，嗯～～