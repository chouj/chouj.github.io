---
title: 赞豆瓣
author: Chouj
type: post
date: 2006-08-17T03:03:00+00:00
url: /2006/08/17/praise-douban/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/blog-post_17.html
views:
  - 2279
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969795
categories:
  - 我思考
  - 我表达
tags:
  - 网络
  - 豆瓣

---
<p align="center">
  <a href="http://www.douban.com/" target="_blank"><img src="http://www.douban.com/pics/douban3.gif" border="0" alt="豆瓣" /></a>
</p>

一时搜书，翻了<a href="http://www.douban.com/" target="_blank">豆瓣</a>。。之前久仰其大名，但未曾谋面，最近细细翻过，果真是很合心的站点。

据说是web 2.0的代表网站，但我不是权威，我决不敢下这样的定论，我对web 2.0这个概念都相当的模糊，这里仅从用户的角度谈谈对<a href="http://www.douban.com/" target="_blank">豆瓣</a>的感受了。

整体而言，<a href="http://www.douban.com/" target="_blank">豆瓣</a>是书籍、音乐、电影等资源的介绍评论站，但建这个平台的人相当聪明，挖了个坑，众多网民就唰唰的往里跳了。何以如此说？从与用户的交互程度以及用户积极性的调用上就可以看出来。

这里绝大部分的东西都是网民主动提供的，封面图片、作者、简介、评论、推荐程度。比如，我看完了一本书，甚喜欢，那我手上又有书封面的图片、简介、作者之类，我就可以把这些统统发布到<a href="http://www.douban.com/" target="_blank">豆瓣</a>上去，然后再补上我自己的评论。再比如，我搜一本书，我可以在<a href="http://www.douban.com/" target="_blank">豆瓣</a>上看到别人发布的关于此书的东东，而且看过的读者的评论往往比较受用；另外，还可以看到各网店的出售价格，以及有多少人想转让此书。注册用户还可以借助<a href="http://www.douban.com/" target="_blank">豆瓣</a>这个平台，记录自己的阅历，把自己读过、看过、听过、去过的统统记录在<a href="http://www.douban.com/" target="_blank">豆瓣</a>上，还可以标出自己想看的，正在看的；同时找寻兴趣相同的小组加入进去，探讨爱好的问题，或者找寻有共同爱好的友邻。比较有特色的是，<a href="http://www.douban.com/" target="_blank">豆瓣</a>提供blog上用的代码，可以在blog上发布自己正在看的听的东西等等。

<a href="http://www.douban.com/" target="_blank">豆瓣</a>的理念如此特别，每个人都可以在<a href="http://www.douban.com/" target="_blank">豆瓣</a>找到一片天地，相信她能一直发展下去。也欢迎把我加为豆瓣友邻。

<span style="text-decoration: line-through;">BTW，一个好的网站总有其模仿者，<a href="http://www.douban.com/" target="_blank">豆瓣</a>也不乏此类。看看这个网站：<a href="http://www.duolo.com/" target="_blank">堕落</a>。</span>

<span style="text-decoration: line-through;">完全模仿，只不过是餐饮类的，还是武汉的站点。</span>

唉，写的真是烂，凑合看吧。