---
title: Cannot modify header information问题的解决方法
author: Chouj
type: post
date: 2008-04-29T03:26:06+00:00
url: /2008/04/29/cannot-modify-header-information/
views:
  - 3756
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969731
categories:
  - 我尝试
tags:
  - blog
  - php
  - WordPress

---
昨晚升级WordPress 2.5.1 ，记事本编辑了wp-config-sample.php为wp-config.php，结果登录管理页面/wp-admin/时遭遇如下问题：

**Warning: Cannot modify header information &#8211; headers already sent by ……**

搜索“<a title="Google:Cannot modify header information" href="http://www.google.cn/search?client=pub-5322016286177578&forid=1&prog=aff&ie=UTF-8&oe=UTF-8&hl=zh-CN&q=Cannot%20modify%20header%20information" target="_blank">Cannot modify header information</a>”得到一票解决方法，简单说就是**拿记事本编辑的php文件不是UTF-8（无BOM）编码**的，更改php文件还是用<a title="Notepad Plus" href="http://notepad-plus.sourceforge.net/" target="_blank">Notepad++</a>(<span style="color: #888888;">这是一款主页上抵制北京奥*运的软件，囧</span>)或UltraEdit靠谱。

<img class="aligncenter size-full wp-image-81" title="notepad-plus" src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/notepad-plus.gif" alt="切换编码" width="272" height="323" />

切换编码后保存，再上传就可以解决问题。