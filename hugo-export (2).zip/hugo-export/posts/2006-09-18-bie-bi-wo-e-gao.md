---
title: 别逼我恶搞【转载】
author: Chouj
type: post
date: 2006-09-18T00:30:00+00:00
url: /2006/09/18/bie-bi-wo-e-gao/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post_17.html
views:
  - 1775
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969810
categories:
  - 我记录
tags:
  - 视频

---
**<span style="font-size:180%;">转</span>**载 <span style="color: #666666;">来源：悠视网</span>



<span style="color: #666666;"><strong><span style="font-size:180%;">国</span></strong>家广电总局有关部门正在制定互联网视频的新规定，限制网络恶搞的消息一传出，网上出现的众多的反对呼声，让我们来听听这些恶搞视频原创者的呼声吧！</span>

**<span style="font-size:180%;">这</span>**个相当逗啊。。可悲的广电总局。。首次在<a href="http://www.sohoxiaobao.com/chinese/bbs/blog_view.asp?id=471196" target="_blank">钱烈宪那里</a>看到滴。。

**<span style="font-size:180%;">下</span>**载地址：<http://www.uusee.com/upload/video/joke/egao/060828_bwgn.wmv>