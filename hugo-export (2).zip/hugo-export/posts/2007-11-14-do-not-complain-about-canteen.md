---
title: 不要抱怨食堂的理由
author: Chouj
type: post
date: 2007-11-14T12:08:22+00:00
url: /2007/11/14/do-not-complain-about-canteen/
views:
  - 2372
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969718
categories:
  - 我记录
tags:
  - 生活
  - 食堂

---
男生经过长期追求，女生经过艰苦等待，此后，

**不仅要做饭，**

**还要给别人做饭；**

**不仅要吃剩饭，**

**还要吃别人剩下的饭。**

—— 某报告会，<a href="http://www.gscas.ac.cn/gscascn/Presentation/Person.aspx?channelId=39&topicid=205&nameId=7" target="_blank">报告人</a>对那些希望食堂能集中华美食之大成的人如是说。