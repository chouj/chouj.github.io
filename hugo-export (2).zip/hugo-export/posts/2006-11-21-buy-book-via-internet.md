---
title: 网上买本书
author: Chouj
type: post
date: 2006-11-21T13:11:00+00:00
url: /2006/11/21/buy-book-via-internet/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/11/blog-post.html
views:
  - 1715
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969830
categories:
  - 我尝试
  - 我记录
tags:
  - 网上购物
  - 网络
  - 读书

---
<img src="http://photos1.blogger.com/x/blogger2/4366/415671023967385/1600/736547/%3F%3F%3F.jpg" border="0" alt="" width="500" />

**<span style="font-size:180%;">第</span>**一次网购书籍，要是没有发送费还是挺划的来的。《[搜][1]》，挑了本价格不算太高，市面上又没找到过，然后又算是想看想收藏的书。

**<span style="font-size:180%;">与</span>**上一次网购相隔甚久，所以这次的体验留下了明晰的记忆之痕，第一次的印象早就模糊了。还好操作不算繁琐，只是担心送货上门时我不在，或者我在但钱不够罢了。

**<span style="font-size:180%;">第</span>**一次网上购物，还是因为贪小便宜。那还是大一的时候，手头上有那种代金券似的优惠小帐号，可抵五元，于是乎班上一票人簇拥在机房屏幕前，在卓越网上东挑西拣。记得我挑了张8元的S.H.E的专辑，那盘《Super Star》。当时货到的时候一脸莫名，之后才顿悟，到处翻钱。不过那碟子没听两次就塞到屉子里“珍藏”起来了。其他人有买塑料饭盒的，有买磁带的，只是有些人因为恰逢搬寝室，没收到东西罢了。那次也没留意几天内到货，这次可以留心下了，今天下的订单，估计考试周的时候可以到。

**<span style="font-size:180%;">图</span>**书馆捞新书是无的放矢，想看就揣回来；自己买书则目的明确，一定要物有所值，感觉果真不同。希望丫网购的书别出现什么脏、皱等瑕疵，同时祈祷丫blogspot别又抽筋儿就是了。

 [1]: http://www.douban.com/subject/1474667/