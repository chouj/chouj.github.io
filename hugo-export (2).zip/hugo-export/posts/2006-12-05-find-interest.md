---
title: 寻找口味
author: Chouj
type: post
date: -001-11-30T00:00:00+00:00
draft: true
url: /?p=202
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /feeds/posts/default/4369978846189174318
categories:
  - 我记录
tags:
  - 生活

---
<span style="font-weight: bold;font-size:180%;">从</span>没有像这段时间一样，如此频繁的看电影。

<span style="font-weight: bold;font-size:180%;">记</span>得小的时候，家里的VCD基本只具备卡拉圈K的功用，看碟是一件不敢想的事情，因为家里管制甚严，爸妈不喜欢我看这个，我只好知趣。每每被同学问，什么什么看过没，我失落的摇摇头，然后骄傲的说，我基本什么都没看过。路过碟店，看着那满墙花花绿绿的招摇，已然与我无关。

<span style="font-weight: bold;font-size:180%;">学</span>校里有了电脑后，赶上2005的动画旺季，绝无看电影的欲念，一直追随高达、钢炼、Bleach而去，电影离我相当之远。托室友的福，电视剧倒是离我相当近，韩剧港剧半搭半送得收获了一箩筐。