---
title: '[照片]山头有宝'
author: Chouj
type: post
date: 2009-01-30T14:11:35+00:00
url: /2009/01/30/valuables/
views:
  - 2196
duoshuo_thread_id:
  - 1279764464521969916
categories:
  - 我记录
tags:
  - 2009
  - 寒假
  - 春节
  - 牛年

---
山头上目力可及之处：<figure style="width: 500px" class="wp-caption aligncenter">

[<img title="襄樊市未来的烟花爆竹基地" src="http://pic.yupoo.com/xcchris/560016e24c88/medium.jpg" alt="襄樊市未来的烟花爆竹基地" width="500" height="375" />][1]<figcaption class="wp-caption-text">襄樊市未来的烟花爆竹基地</figcaption></figure> <figure style="width: 500px" class="wp-caption aligncenter">[<img title="襄樊市殡仪馆" src="http://pic.yupoo.com/xcchris/440016e24c0c/medium.jpg" alt="襄樊市殡仪馆" width="500" height="375" />][2]<figcaption class="wp-caption-text">襄樊市殡仪馆</figcaption></figure> 

更多踏青照片见[这里][3]

 [1]: http://pic.yupoo.com/xcchris/560016e24c88/pszs57rc.jpg
 [2]: http://pic.yupoo.com/xcchris/440016e24c0c/tisqhmnf.jpg
 [3]: http://www.yupoo.com/albums/view?id=ff8080811ef1de5b011f1771d0326d6f