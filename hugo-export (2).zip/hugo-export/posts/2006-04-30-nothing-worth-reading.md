---
title: 这篇没啥好看的
author: Chouj
type: post
date: 2006-04-30T02:50:00+00:00
url: /2006/04/30/nothing-worth-reading/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/04/blog-post_30.html
views:
  - 2342
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969772
categories:
  - 我记录
tags:
  - 生活
  - 电脑

---
最近花在PC前的时间多了点。。。纠缠于firefox与blog、PS间。

将firefox升到了1.5.0.1，重新开代理装插件，Adblock、Launchy、All-in-One Gestures、Sage、FlashGot、Fasterfox、IE Tab、Tab Mix Plus、FoxyTunes、MediaPlayerConnectivity的装了一堆。还有几个感觉不错的没下到，一个weather，一个proxy，一个close tab on double click。发现居然不能正常显示flash，郁闷。。。改天继续找找。。。

顺便下了两个主题。。。还8错。。。担心火狐穿了这么多层皮，加上天气渐热，会不会消极怠工。。。要是怠工了，没关系，我还比较能忍ie。。。

又花了点时间给blog小修饰了一番。。从<a href="http://www.bitman.cn/" target="_blank">blogweather</a>那里蹭了个天气预报过来。。。有时候会Service Unavailable&#8230;加载起来也有点慢，但希望能对大家有点用。。。只是默认地点是上海，想看武汉的话，手动拉下菜单啦。。

随后，开PS画了blogTop和blogBottom两个图，挂了出来。。之前选了这个版子就是因为CSS定义的正文字体大一些，布局比我自己写的当然更成熟，但之前的图大众化了，于是彰显下个性，自己改之。。。只是这图一个40多K，一个60多K，有点影响页面下载的速度。。。

从<a href="http://skin.oblog.cn/default_down.asp" target="_blank">Oblog官方模板下载站</a>里，捞了一票模板，但像我这样还没钱自己找服务器架blog的，这些板子没有用。。。所以看看人家的板子找找画图的感觉罢了。Top和Bottom都是取材一个Desert的模板里的，稍微改了改：没表现出沙子的材质，选择了壁纸加粉刷喷涂的形式。。。但受限于原模板的CSS加上色调，没办法大改。TOP左边那个写着“Customer”的纸片，就是因为没办法全部去掉只有保留了，顺便把自己现在用的PC桌面摆了进去，黑崎一护，Bleach男一号，配合俺滴qq脑袋，呵呵。看到他手心里写的什么了么？right，Fighting！原来写的是祝Rukia生日快乐的句子的，抹掉了。另外，右边那个灰灰的狰狞的脸请无视，抓过来就摆那里了。

画图画的小郁闷，机子里装了一千以上的字体，要么一不小心忘了刚才用的是什么字体，然后怎么找也找不到，要么就是从巨多字体中挑一个满意的、合适的，难啊！改代码也改的心烦，要让页子在firefox和ie下同时完美真是困难。。。什么时候出个秦始皇一统浏览器市场，那就万事大吉了。。。

最后发个表，偶在<a href="http://bt.5qzone.net/" target="_blank">5Q</a>上的发布一览，乱七八糟什么都有。

 <span style="font-size:100%;">最后发个表，偶在<a href="http://bt.5qzone.net/" target="_blank">5Q</a>上的发布一览，乱七八糟什么都有。</span>

<table style="color:#e5e3e3;" border="0" cellspacing="1" cellpadding="3" width="98%" align="center">
  <tr style="color:#0066ff;" height="25" align="center">
    <td class="head" width="5%">
      <span style="font-size:100%;"><strong>状态</strong></span>
    </td>
    
    <td class="head">
      <span style="font-size:100%;"><strong>标题</strong></span>
    </td>
    
    <td class="head" width="15%">
      <span style="font-size:100%;"><strong>论坛</strong></span>
    </td>
    
    <td class="head" width="13%">
      <span style="font-size:100%;"><strong>作者</strong></span>
    </td>
    
    <td class="head" width="5%">
      <span style="font-size:100%;"><strong>回复</strong></span>
    </td>
    
    <td class="head" width="5%">
      <span style="font-size:100%;"><strong>人气</strong></span>
    </td>
    
    <td class="head" width="20%">
      <span style="font-size:100%;"><strong>最后发表</strong></span>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=514775&keyword=" target="_blank">【ChinaUI.com2006新春大礼包】【exe】【见介绍】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=79">电脑资料镜像区</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-04-07</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">131</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=514775&page=e#a" target="_blank">2006-04-07 07:14</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=514105&keyword=" target="_blank">【北航单片机视频教程】【格式】【查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=81">专业区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-04-06</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1</span>
    </td>
    
    <td>
      <span style="font-size:100%;">82</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=514105&page=e#a" target="_blank">2006-04-06 16:54</a><br /> by: bioss </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=505656&keyword=" target="_blank">【HUST2005世界物理年纪念视频&纪念册】【mpg&exe】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-03-27</span>
    </td>
    
    <td>
      <span style="font-size:100%;">3</span>
    </td>
    
    <td>
      <span style="font-size:100%;">142</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=505656&page=e#a" target="_blank">2006-03-27 23:37</a><br /> by: lord_chen </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topichot.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=486491&keyword=" target="_blank">【premiere极品插件 部分有教程】【rar exe】【应求发布】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-03-03</span>
    </td>
    
    <td>
      <span style="font-size:100%;">13</span>
    </td>
    
    <td>
      <span style="font-size:100%;">238</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=486491&page=e#a" target="_blank">2006-03-08 15:57</a><br /> by: zhaohu361 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=488423&keyword=" target="_blank">【ADOBE.PREMIERE.PRO】【iso】【V7.0】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-03-05</span>
    </td>
    
    <td>
      <span style="font-size:100%;">2</span>
    </td>
    
    <td>
      <span style="font-size:100%;">75</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=488423&page=e#a" target="_blank">2006-03-06 13:22</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=486773&keyword=" target="_blank">【Adobe Premiere 6.5】【rar】【可汉化】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-03-03</span>
    </td>
    
    <td>
      <span style="font-size:100%;">7</span>
    </td>
    
    <td>
      <span style="font-size:100%;">89</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=486773&page=e#a" target="_blank">2006-03-05 01:11</a><br /> by: chenaiaixi </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=487233&keyword=" target="_blank">【各格式转asf软件及不少asf】【asf rar】【mp4播放用】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-03-03</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">284</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=487233&page=e#a" target="_blank">2006-03-03 21:15</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476205&keyword=" target="_blank">【HUST世界物理年纪念册】【exe】【HUST_Chris制作】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-19</span>
    </td>
    
    <td>
      <span style="font-size:100%;">3</span>
    </td>
    
    <td>
      <span style="font-size:100%;">198</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476205&page=e#a" target="_blank">2006-02-24 08:43</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476819&keyword=" target="_blank">【韩剧My Girl原声配乐】【mp3 192kbps】【A ZA！】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=39">音乐区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;">4</span>
    </td>
    
    <td>
      <span style="font-size:100%;">187</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476819&page=e#a" target="_blank">2006-02-23 08:44</a><br /> by: tigre0408 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476824&keyword=" target="_blank">【仓木麻衣音乐集合】【mp3】【挺乱】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=39">音乐区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;">4</span>
    </td>
    
    <td>
      <span style="font-size:100%;">120</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476824&page=e#a" target="_blank">2006-02-21 22:53</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476823&keyword=" target="_blank">【05年左右华语pop music】【mp3】【挺乱】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=39">音乐区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1</span>
    </td>
    
    <td>
      <span style="font-size:100%;">141</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476823&page=e#a" target="_blank">2006-02-20 17:31</a><br /> by: bebeelau </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476835&keyword=" target="_blank">【最终幻想音乐】【mp3 wma】【忒乱见查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=39">音乐区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">133</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476835&page=e#a" target="_blank">2006-02-20 15:24</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476829&keyword=" target="_blank">【动感新势力 霜月】【15首 wma】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=39">音乐区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">94</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476829&page=e#a" target="_blank">2006-02-20 15:22</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=476817&keyword=" target="_blank">【韩剧My Girl原声配乐】【wma 64kbps】【A ZA！】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=39">音乐区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-02-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">91</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=476817&page=e#a" target="_blank">2006-02-20 15:09</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=456296&keyword=" target="_blank">【高校最新电子翻页刊物《探索》】【exe】【完美打造 铸就非凡】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-01-09</span>
    </td>
    
    <td>
      <span style="font-size:100%;">9</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1247</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=456296&page=e#a" target="_blank">2006-01-10 22:35</a><br /> by: lj4835599 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=456551&keyword=" target="_blank">【电子刊物《探索》bug修正2.0版】【EXE】【完美打造 铸就非凡】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-01-09</span>
    </td>
    
    <td>
      <span style="font-size:100%;">3</span>
    </td>
    
    <td>
      <span style="font-size:100%;">618</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=456551&page=e#a" target="_blank">2006-01-09 17:42</a><br /> by: dicp </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=456340&keyword=" target="_blank">【下载】hust物理系系刊《探索》 完美打造 铸就非凡</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=129">华中地区校园讨论区</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-01-09</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1</span>
    </td>
    
    <td>
      <span style="font-size:100%;">239</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=456340&page=e#a" target="_blank">2006-01-09 16:08</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=456281&keyword=" target="_blank">【高校最新电子刊物翻页《探索》】【EXE】【完美打造 铸就非凡】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2006-01-09</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">81</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=456281&page=e#a" target="_blank">2006-01-09 09:08</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=449415&keyword=" target="_blank">【500信纸模板＋祖玛】【rar】【信纸outlook专用】【重发】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-12-27</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">529</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=449415&page=e#a" target="_blank">2005-12-27 18:19</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=448730&keyword=" target="_blank">【500信纸模板＋祖玛】【rar】【注意：outlook专用】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-12-26</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">126</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=448730&page=e#a" target="_blank">2005-12-26 19:01</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=432343&keyword=" target="_blank">【一些图片素材】【jpg gif】【查看里写了都有什么】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-12-03</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1</span>
    </td>
    
    <td>
      <span style="font-size:100%;">381</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=432343&page=e#a" target="_blank">2005-12-06 23:33</a><br /> by: topic99 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=432347&keyword=" target="_blank">【电子书制作软件】【zip】【DesktopAuthor 4】【查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-12-03</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1</span>
    </td>
    
    <td>
      <span style="font-size:100%;">589</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=432347&page=e#a" target="_blank">2005-12-04 19:44</a><br /> by: 问剑天下 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topichot.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=415939&keyword=" target="_blank">【EVA全】【RMVB】【重发经典 纪念光棍节】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=33">动漫区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-11-11</span>
    </td>
    
    <td>
      <span style="font-size:100%;">15</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1118</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=415939&page=e#a" target="_blank">2005-11-27 19:22</a><br /> by: 48335382 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=424714&keyword=" target="_blank">【开源软件】【OpenOffice.Org.2.O】【比微软的好用】【见查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-11-23</span>
    </td>
    
    <td>
      <span style="font-size:100%;">6</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1143</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=424714&page=e#a" target="_blank">2005-11-25 11:47</a><br /> by: yeatech </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=422900&keyword=" target="_blank">【ebook workshop 1.5中文版】【电子书制作工具&教程】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-11-20</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">601</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=422900&page=e#a" target="_blank">2005-11-20 16:07</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topichot.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=394777&keyword=" target="_blank">【物理系原创DV】【梦想在希望升起的地方】【RMVB】【见查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-10-15</span>
    </td>
    
    <td>
      <span style="font-size:100%;">11</span>
    </td>
    
    <td>
      <span style="font-size:100%;">249</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=394777&page=e#a" target="_blank">2005-10-26 14:01</a><br /> by: kabb1217 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topichot.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=393508&keyword=" target="_blank">【剧场版动画】【云之彼端，约定的地方】【DVDrip】【外挂字幕】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=33">动漫区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-10-13</span>
    </td>
    
    <td>
      <span style="font-size:100%;">12</span>
    </td>
    
    <td>
      <span style="font-size:100%;">706</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=393508&page=e#a" target="_blank">2005-10-17 15:05</a><br /> by: 天恨 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topichot.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=364738&keyword=" target="_blank">【找了N久的premiere极品插件】【836M】【该有的都有见查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=79">电脑资料镜像区</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-08-26</span>
    </td>
    
    <td>
      <span style="font-size:100%;">18</span>
    </td>
    
    <td>
      <span style="font-size:100%;">738</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=364738&page=e#a" target="_blank">2005-10-12 16:22</a><br /> by: citygun </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=391088&keyword=" target="_blank">【个人收藏的壁纸大全】【jpg】【吐血推荐】【选下见查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-10-10</span>
    </td>
    
    <td>
      <span style="font-size:100%;">5</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1898</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=391088&page=e#a" target="_blank">2005-10-10 21:52</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=390846&keyword=" target="_blank">【一些图片声音素材】【选下见查看】【貌似刚才没发成功】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-10-10</span>
    </td>
    
    <td>
      <span style="font-size:100%;">3</span>
    </td>
    
    <td>
      <span style="font-size:100%;">511</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=390846&page=e#a" target="_blank">2005-10-09 23:31</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=390800&keyword=" target="_blank">【乱78糟的一些图片声音素材】【选下】【见查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-10-10</span>
    </td>
    
    <td>
      <span style="font-size:100%;">2</span>
    </td>
    
    <td>
      <span style="font-size:100%;">164</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=390800&page=e#a" target="_blank">2005-10-09 19:28</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=364062&keyword=" target="_blank">【动漫小图】【高达gif/OP头像Q版/倒吊男史前动物系列gif】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=33">动漫区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-08-25</span>
    </td>
    
    <td>
      <span style="font-size:100%;">4</span>
    </td>
    
    <td>
      <span style="font-size:100%;">28</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=364062&page=e#a" target="_blank">2005-09-26 12:31</a><br /> by: 披着羊皮的狼 </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=375232&keyword=" target="_blank">【RMVB压制必备软件见查看】【求VirtualDUB 1.5.10】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-09-15</span>
    </td>
    
    <td>
      <span style="font-size:100%;">8</span>
    </td>
    
    <td>
      <span style="font-size:100%;">55</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=375232&page=e#a" target="_blank">2005-09-18 07:28</a><br /> by: w23erty </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=368310&keyword=" target="_blank">【ProCoder_2附专业音频软件】【premiere插件补完查看】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=46">软件区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-09-02</span>
    </td>
    
    <td>
      <span style="font-size:100%;"></span>
    </td>
    
    <td>
      <span style="font-size:100%;">476</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=368310&page=e#a" target="_blank">2005-09-03 00:09</a><br /> by: xcchris </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
  
  <tr class="f_one" align="center">
    <td>
      <span style="font-size:100%;"><img src="http://bbs.5qzone.net/image/5qzone/thread/topicnew.gif" border="0" alt="" /></span>
    </td>
    
    <td align="left">
      <!---->
      
      <span style="font-size:100%;"> <a href="http://www.52blog.net/read.php?tid=334038&keyword=" target="_blank">【ZS#10】【WMV】【物理年物理科普知识竞赛决赛录像】</a></span> <!---->
    </td>
    
    <td>
      <span style="font-size:100%;"><a href="http://www.52blog.net/thread.php?fid=47">其他区镜像</a></span>
    </td>
    
    <td class="smalltxt">
      <span style="font-size:100%;"><a href="http://www.52blog.net/profile.php?action=show&uid=319476">xcchris</a><br /> 2005-06-28</span>
    </td>
    
    <td>
      <span style="font-size:100%;">1</span>
    </td>
    
    <td>
      <span style="font-size:100%;">34</span>
    </td>
    
    <td>
      <table class="f_one" border="0">
        <tr>
          <td class="smalltxt" align="center">
            <span style="font-size:100%;"><a href="http://www.52blog.net/read.php?&tid=334038&page=e#a" target="_blank">2005-06-28 17:51</a><br /> by: apo11o </span>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  
  <p>
    <!---->
  </p>
</table>

 <span style="font-size:100%;">自己刷新一下，点击率顶上3400，估计有1/3是本少自己刷的。。。残念。。。</span>