---
title: '[草莓版]七月汇集：共享与广告 竞争与生存'
author: Chouj
type: post
date: 2007-07-31T15:00:04+00:00
url: /2007/07/31/what-happened-in-july/
views:
  - 2192
  - 2192
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969970
categories:
  - 广告
  - 相关
tags:
  - Feedburner
  - feedsky
  - firefox
  - Google
  - Google Reader
  - Graph
  - OPML
  - Reader
  - RSS Marketing
  - Xianguo
  - Zhuaxia

---
火热七月，大事有三：刚入七月的OPML共享活动，紧接着Feedsky首开国内RSS展示广告的先河，再然后大家都能感觉到的：鲜果 VS 抓虾，这样的竞争无处不在。

[**OPML共享**]

 <img src="http://static2.podcatch.com/blogs/pics/opml/opml.gif" alt="opmllogo: " align="right" border="0" height="47" width="115" />7月3日，月光[分享了][1]他的Opml订阅Feed，6日Src[发起OPML共享运动][2]，一时间订阅数飙升，参与和讨论不断，分外河蟹。活动意义诸多：通告大家在面对[信息过载][3]，[和未读数斗争的日子][4]里，[如何管理你的订阅][5]，如何学会[筛选和过滤][6]，以避免[RSS阅读焦虑的灾难][7]；同时也可[开阔视野][8]，避免坐井观天。忧虑的声音也有，因为[信息重叠][9]和[喜好有别][10]。

看来初识RSS的新鲜感已经过去，随之而来的问题是，海量信息（特别是微内容兴起之后）冲刷之下谁能站得更稳。如何找寻[个性化阅读][11]，如何学会攀登[信息时代的通天塔][12]，和菜头说“[资讯的量未必意味着质，披沙沥金这种事情是必须要做的][13]”，故方法一是人主观为之。方法二则是机器为之，目前大家可以运用的有[OgOg——dig性质的RSS联合服务][14]，或借助[AideRSS来提高RSS Feed的阅读效率][15]，但这些服务都尚在机器过滤的摸索中。要我说，还是自己人肉过滤来的靠谱儿，XD～

[**Feedsky展示广告**]

[<img src="http://www.feedsky.com/images/logo_147x47.gif" alt="feedsky logo" title="feedsky" align="left" border="0" />][16]
  
7月2日，盗盗说[Feedsky进军RSS广告业][17]，一石激起千层浪（[1][18]、[2][19]），随着官方[正式宣布][20]展示广告开通，广告Banner就旗帜般挂满Feed世界的大街小巷，博客赚钱愈发炙手可热。[如何在WP下把默认Feed转向Feedsky][21]，如何实现Feedburner到Feedsky的无缝无痛切换（[1][22]、[2][23]）， 纷至沓来。真正要能赚到钱，月光在[Feedburner的RSS广告收益分析][24]中告诉了我们要点，值得一看；但还需要忍受Athere大叔在[实验报告][25]中指出的Feedsky抓取慢的诟病。现状呢？在Google Adsense单价颇低的基本国情下，在博客赚钱甚嚣尘上的初级阶段中，嗷嗷待哺的诸bloggers（包括俺，- -b）都把一线生机寄托于敢啃螃蟹的Feedsky，殊不知Feedsky脚下步履蹒跚、胃里半饥半饱，上游广告商链条的良性与否直接影响了 Feedsky的奶水量，而如狼似虎的bloggers自然因吃不饱或味道不好而发难（[1][26]、[2][27]、[3][28]）。且让我们从竞争与生存的角度分析下：

<font color="#ff0000">VS</font> FeedBurner

自Feedburner Pro[免费][29]之后，WebLeon[说][30]：“RSS Feed终究会成为一个主流的媒介，我一直这样坚信。我看到Google也这样认为，在这样努力”；Shawn[说][31]：“预计Google接下来会将Adsense集成到Feedburner当中”；长天暮鼓也就[吕帅造访Google][32]一事[说过][33]：“不管 Google 中国有多么本地化，它始终是其全球战略的组成部分，怎么可能自家的 FeedBurner 不用，而与 Feedsky 合作呢？”在此情形之下，Feedsky若想依赖广告收入而生存，只有抢先开放RSS展示广告，提前摸索道路打造品牌争取用户，要是等到Adsense整合进Feedburner的那天，就没戏了。而用户面对被收购之后[十分危险][34]的Feedburner，[选择Feedsky][35]与否还得靠你自己定夺。

 <font color="#ff0000">VS</font> 博狗 Blogool

话题广告口碑传播得以发展的需求是，广告商能从该形式的广告中看到收益，能对该新兴的广告模式抱以信心。而上游广告商这种信心的建立需要中游Feedsky和博狗这些平台良好的运作，需要下游Bloggers的配合与传播。目前看来，这一链条能否良性循环尚在摸索之中，要真正达到三方获益还需时日。在不能满足所有bloggers得利的发展前期，我们bloggers如何解决和中游平台之间的矛盾冲突将决定该广告模式的存亡；而Feedsky和博狗谁能更好得解决问题，争得更多的“[500强企业][36]”，又将决定两者在该领域的生死。

[**[鲜果][37] PK [抓虾][38]**]

每每在饭否上看见[duberry][39]和[小虾][40]的轮番上场 ，联想到[鲜果日志][41]和[抓虾日记][42]的频频更新，再配合长天暮鼓这篇[在线RSS阅读器门槛并不低][43]，就愈发能够嗅到RSS在线阅读器市场上浓烈的竞争气息。用户的疑问是，我们[需要那么多RSS阅读器吗][44]？不论是否需要，至少可以多些选择，至少我们可以[感谢鲜果][45]，让市场一片繁荣。[鲜果 VS Fastladder][46]，[抓虾 VS Google Reader][47]，是鲜果更嫩还是抓的虾更鲜，比来比去你选好了吗？愚以为，鲜果更加便捷，抓虾更加social，对用户都是好事，他们应该侧重于利用这些吸引刚接触RSS的新用户，毕竟用户习惯成形，有了众多收藏和依赖情感后，不会轻易离开，稳住老用户相对容易。像[抽儿][48]就一直忠于Google Reader，嘿嘿（鲜果和抓虾很郁闷~~）。

为了生存，就得面对竞争，学会竞争，愿鲜果和抓虾好运。

[RSS杂碎]

<img src="http://www.xuchi.name/rss/wp-content/themes/ubminim/images/header.jpg" title="RSS杂碎" alt="RSS杂碎" align="right" height="174" width="174" />

RSS能玩出什么花样，看看[盗盗介绍的Bloglive][49]便知。喜欢鲜果的用户可以参照困兽的教程[添加FireFox订阅收取点][50]或[Feedburner FeedFlare][51]。喜欢Google Reader的朋友可以看看<a href="http://www.williamlong.info/archives/986.html" target="_blank">Google Reader高级技巧快速入门</a>，或者给Firefox安装这款插件[Google Reader Watcher 0.0.8][52]。想找合烧工具的朋友可以看看[RSS Mixer][53]或[aFeeda][54]。想把RSS文本转化为声音的话，可以使用[Odiogo][55]。Feedburner用户可以参考月光的[十二个Feedburner技巧汇总][56]。[RSS Feed应用及周边汇总][57]也很全乎。

[正确看待RSS订阅者的价值][58]后，我们也许会全文输出RSS，但这本为方便订阅者的行为，可也方便了聚合网站或[滋长了抄袭][59]，解决方法[月光这里有介绍][60]。也有人认为全文输出不好，就像[阅读裸体信息][61]，缺失了特定网站构架和图形的阅读氛围，觉得还是穿着衣服的更美。

RSS标志依然受到设计者的追捧，又有漂亮标志现身网络，详见[这篇][62]和[这篇][63]。

<font color="#c0c0c0">写草莓体真费劲儿，以后读研了八成没功夫写这玩意儿。</font>

 [1]: http://www.williamlong.info/archives/954.html
 [2]: http://glif.cn/2007/07/opml.html
 [3]: http://ishawn.net/2007/07/information-overload.htm
 [4]: http://nings.cn/2007/07/05/nings-opml/
 [5]: http://www.binbinmath.com/archives/217017
 [6]: http://www.ilmay.cn/post/zhuaxia-opml.html
 [7]: http://www.wangtam.com/50226711/ec_rssieaeeececce_106140.php
 [8]: http://www.kuangfeng.cn/blog/?p=1294
 [9]: http://shenxiangl.com/opml/
 [10]: http://4rks.yo2.cn/archives/211175
 [11]: http://www.cnblogs.com/zhengyun_ustc/archive/2007/07/03/803698.html
 [12]: http://www.awflasher.com/blog/archives/975
 [13]: http://www.caobian.info/?p=2348
 [14]: http://www.thws.cn/article.asp?id=1419
 [15]: http://www.showeb20.com/?p=622
 [16]: http://www.feedsky.com/
 [17]: http://www.showeb20.com/?p=575
 [18]: http://www.williamlong.info/archives/955.html
 [19]: http://nings.cn/2007/07/02/feedsky-rss-ad/
 [20]: http://blogs.feedsky.com/?p=152
 [21]: http://since1984.cn/blog/?p=915
 [22]: http://nings.cn/2007/07/06/the-domain-feed-of-feedsky-feedburner/
 [23]: http://www.qianblogger.com/2007/07/04/feedsky-switch/
 [24]: http://www.williamlong.info/archives/957.html
 [25]: http://www.athere.net/Archive/experimental-report-feed-and-reader/
 [26]: http://caitou.com/blog/article.asp?id=338
 [27]: http://www.athere.net/Archive/collaborative-blog-feedsky-part-2/
 [28]: http://dupola.com/post/175
 [29]: http://blogs.feedburner.com/feedburner/archives/2007/07/freeburner_for_everyone.php
 [30]: http://webleon.org/2007/07/feedburner-pro.html
 [31]: http://ishawn.net/2007/07/feed-ad-of-10.htm
 [32]: http://www.lvxinxin.com/archives/209
 [33]: http://www.ilmay.cn/post/about-feed-ad.html
 [34]: http://www.wangtam.com/50226711/feedburner_cce_106989.php
 [35]: http://www.ilmay.cn/post/feedsky-feed-ad.html
 [36]: http://www.lvxinxin.com/archives/211
 [37]: http://www.xianguo.com
 [38]: http://www.zhuaxia.com
 [39]: http://fanfou.com/duberry
 [40]: http://fanfou.com/zhuaxia
 [41]: http://blog.xianguo.com/
 [42]: http://www.zhuaxia.com/blog/
 [43]: http://www.ilmay.cn/post/zhuaxia-xianguo-menkan.html
 [44]: http://www.osxcn.com/web20/xianguo-rss-reader.html
 [45]: http://www.ilmay.cn/post/thanks-xianguo.html
 [46]: http://ishawn.net/2007/07/xianguocom-and-fastladdercom.htm
 [47]: http://blog.donews.com/sogoo/archive/2007/06/21/1177981.aspx
 [48]: http://www.xuchi.name/blog
 [49]: http://www.showeb20.com/?p=634
 [50]: http://kunshou.net/2007/07/firefox_27.html
 [51]: http://kunshou.net/2007/07/feedflare.html
 [52]: http://www.cactos.cn/index.php/archives/430
 [53]: http://www.showeb20.com/?p=624
 [54]: http://www.showeb20.com/?p=572
 [55]: http://e-spacy.com/blog/2195.html
 [56]: http://www.williamlong.info/archives/969.html
 [57]: http://www.showeb20.com/?p=457
 [58]: http://blogsdiy.org/2007-07/the-value-of-rss-subscribers/
 [59]: http://robertmao.com/archives/63
 [60]: http://www.williamlong.info/archives/982.html
 [61]: http://ifire.cn/blog/life/ifire/archives/2007/0712.asp
 [62]: http://www.wangtam.com/50226711/eeierss_icons_png_105435.php
 [63]: http://blog.bsdos.cn/archives/810