---
title: 非常时期非常规访问方法
author: Chouj
type: post
date: 2007-03-20T14:17:00+00:00
url: /2007/03/20/unnormaly-way-to-view-blogspot/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/blog-post_20.html
views:
  - 2468
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969865
categories:
  - 我尝试
tags:
  - blog
  - Google

---
[<span style="font-size:180%;"><span style="font-weight: bold;">上</span></span>一篇][1]是给GFW挠痒痒，结果丫狮子大张口吞了整个blogspot国度，害得本应欣欣向荣、如火如荼的google blogger中国用户群被当头被泼了一盆冷水，煞是凄惨。

<span style="font-weight: bold;">抽丫的筋儿：以下渠道尚可正常访问和交流：</span>

<http://www.inblogs.net/xcchris/>
  
<http://www.pkblogs.com/xcchris/>

这两个地址，可正常<span style="font-weight: bold;">访问</span>和<span style="font-weight: bold;">评论</span>。将xcchris改为您自己的，亦即可访问您自己的blogger。

或者更改本地host文件，路径为<span id="fullpost" style="display: inline;">系统安装盘/windows/system32/drives/etc/hosts，以记事本打开，添加如下类似文本：<br /> </span>
  
72.14.219.190 beta.blogger.com
  
72.14.219.190 dugangs.blogspot.com
  
72.14.219.190 sz-iris.blogspot.com
  
72.14.219.190 liubinjob.blogger.com
  
72.14.219.190 mylovegarden.blogspot.com
  
72.14.219.190 ggpi.blogspot.com
  
72.14.219.190 chenbo.blogspot.com
  
<span style="font-weight: bold;">72.14.219.190 xcchris.blogspot.com</span>
  
72.14.219.190 allofrss.blogspot.com

保存后，即可访问您所添加的blog。

抽丫的筋儿的<span style="font-weight: bold;">rss feed</span>地址：<http://feed.feedsky.com/chrischou>,feed保持正常输出，可用订阅工具查看。

<span style="color: #ff0000;">与GFW斗，其乐无穷啊！</span>

 [1]: http://xcchris.blogspot.com/2007/03/blog-post_19.html