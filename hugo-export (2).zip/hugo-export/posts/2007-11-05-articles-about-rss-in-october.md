---
title: '[草莓版]十月汇集：订阅数风波迭起，挑战赛拼搏到底'
author: Chouj
type: post
date: 2007-11-05T05:53:47+00:00
url: /2007/11/05/articles-about-rss-in-october/
views:
  - 1792
  - 1792
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969991
categories:
  - WordPress
  - 相关
tags:
  - feedsky
  - Google
  - Google Reader
  - Plugin
  - Xianguo
  - Yeeyan
  - Zhuaxia

---
<font color="#999999">在<a href="http://www.yeeyan.com/articles/view/7683/2294" target="_blank">世界顶级赚钱博客Rss订阅挑战赛</a>中，十月开始了，不过我不知道结果，囧～最近忙的像条狗（狗们好像挺悠闲的，都可以按点儿睡觉），所以此文迟到5天，顺道热烈祝贺<a href="http://www.cnbloggercon.org/" target="_blank">2007中文网志年会</a>结束！圆不圆满不好说，因为我看到了<a href="http://www.kenengba.com/post/285.html" title="有点失败的网志年会" target="_blank">不满</a>。</font>

 <small></small>

<p class="post" style="margin-top: 1em">
  <img src="http://photo5.yupoo.com/20070828/184610_1275588803_rrcvhspd.jpg" title="RSS相关 草莓版信息汇集" alt="RSS相关 草莓版信息汇集" height="130" width="122" />
</p>

[ **Google Reader 订阅数那点事** ]

<a href="http://www.google.com/reader" target="_blank"><img src="http://photo11.yupoo.com/20071104/214230_579105010_xfybkhzb.jpg" title="Google Reader" alt="Google Reader" align="left" border="0" height="39" width="130" /></a>

模仿一下曹增辉“<a href="http://www.caozenghui.cn/?p=230" title="订阅数这点事" target="_blank">订阅数这点事</a>”的标题先。这小风波算是从国外一路吹到国内，历程基本一致：先是<a href="http://www.ilmay.cn/post/google-reader-show-numbers.html" title="到底有多少人用Google Reader订阅你的博客" target="_blank">揭密阶段</a>，说Google Reader的订阅数可查；后来辟谣阶段，说<a href="http://googlereader.blogspot.com/2007/10/subscriber-stats-summed-up.html" target="_blank">官方发话</a>啦，<a href="http://www.williamlong.info/archives/1094.html" title="那不是Google Reader的订阅数" target="_blank">那不是GR的订阅数</a>。抽儿和<a href="http://www.caozenghui.cn/?p=230" title="订阅数这点事" target="_blank">曹某的看法</a>一致，以IT为主题的blog自然会报道这些，但对诸bloggers来说，**那只是个数字而已，不要过于追求**；而且，<a href="http://www.kenengba.com/post/278.html" title="至少一半的订阅数是无用的" target="_blank">至少一半的订阅数是无用的</a>。

还好奇的话，就去TechCrunch看看<a href="http://www.techcrunch.com/2007/10/14/top-blogs-on-google-reader/" title="top blogs on google reader " target="_blank">Top Blogs on Google Reader</a>吧～

<!--more-->

[ **Feedsky最近比较忙活** ]

<img src="http://www.feedsky.com/images/logo_147x47.gif" title="Feedsky" alt="Feedsky" height="47" width="147" />

首先，月初<a href="http://blogs.feedsky.com/?p=165" title="话题营销测试期结束" target="_blank">停掉了话题营销测试期</a>，让某群（群号：22305020）的同志们叫苦不迭，好在这不是RSS相关的讨论范畴。

接着，每年<a href="http://www.cnbloggercon.org/" target="_blank">中文网志年会</a>(Chinese Blogger Conference)前的<a href="http://blogs.feedsky.com/?p=166" title="Feed评选活动又开始啦" target="_blank">Feed评选活动如期开始</a>，似乎其间有不河蟹的声音传出，因为<a href="http://www.gomain.net/articles/feedsky_2007cbc.html" title="Feed评选活动上一些不愿意看到的结局" target="_blank">有人Cheat</a>。这是不是<a href="http://www.awflasher.com/blog/archives/1096" title="从Alexa排名到Feed订阅数 - cheat show？" target="_blank">aw所说的Cheat Show</a>时代，你认为呢？这个活动倒是结束了，关心活动结果的到<a href="http://blogs.feedsky.com/?p=178" title="Feed评选活动结束啦！" target="_blank">这里</a>。

<img src="http://www.feedsky.com/challenge/images/challenge_feedsky.jpg" align="right" />然后就是最近宣传力度颇大的<a href="http://www.feedsky.com/challenge/" title="2007拼搏到底博客挑战赛" target="_blank">2007“拼搏到底”博客挑战赛</a>啦。乍看到这个比赛，我的第一反应是“<a href="http://fanfou.com/statuses/GEcfvn5sZ7M" target="_blank">Feedsky在找人玩儿过家家么？</a>”，想想后才发现该活动是为了让更多的bloggers接触Feed，拓展市场，这点WebLeOn也承认（<a href="http://fanfou.com/statuses/dsvouG4-idw" target="_blank">1</a>、<a href="http://fanfou.com/statuses/Y7qJxymB744" target="_blank">2</a>）。还有5天比赛正式开始，和菜头已经<a href="http://www.caobian.info/?p=2628" title="Feedsky的拼搏到底" target="_blank">高调表示参加</a>，不过他已经不在<a href="http://www.feedsky.com/challenge/rank.html" target="_blank">邀请排行榜</a>的榜首了。当然，除了有<a href="http://www.iamvip.net/blog/review/123" title="进步中的Feedsky" target="_blank">支持Feedsky的声音</a>，也有<a href="http://qeegi.net/post/16776595" title="种天快成了信噪比催化剂了" target="_blank">反对的声音</a>存在。

还有些关于Feedsky的边角料，都是月光的作品：<a href="http://www.williamlong.info/archives/1115.html" title="FeedSky订阅最多的二十个博客" target="_blank">FeedSky订阅最多的二十个博客</a>、<a href="http://www.williamlong.info/archives/1083.html" title="FeedSky订阅来源的查看技巧" target="_blank">FeedSky订阅来源的查看技巧</a>

[ **RSS边角料** ]

<a href="http://yeeyan.com/articles/view/4393/2754" title="到底什么是RSS频道呢？ " target="_blank"><strong>到底什么是RSS频道呢？</strong></a>可以看看这篇译言上极有意义的翻译，在此感谢译者<a href="http://twiity.cn/" title="yii" target="_blank">yii</a>。那么到底用谁家的Feed最好呢？推荐看看博客联盟的这篇“[feedburner，feedsky还是原始 feed？][1]”。至于<a href="http://www.qianblogger.com/2007/10/04/feed-picture-margin/" title="rss中图片边距丢失的问题" target="_blank">RSS中显示图片的边距丢失问题</a>，老前来教你轻松搞定 。博客学堂还介绍了个<a href="http://blogsdiy.org/2007-10/increase-rss-subscribers-in-black-ways/" title="提高博客订阅量统计的“另类”技巧" target="_blank">增加订阅数的“另类”技巧</a>，不过太另类了点。

有两篇对WordPress用户来说有用：<a href="http://www.appinn.com/feed-add-301/" title="解决订阅 (Feed) 地址混乱的问题" target="_blank"><strong>如何解决订阅地址混乱的问题</strong></a>，scavin写的很清楚。sofish则整理出了<a href="http://www.happinesz.cn/archives/304" title="全面装备RSS Feed的19个Wordpress插件" target="_blank"><strong>全面装备RSS Feed的19个WordPress插件</strong></a>，肯定有你感兴趣的。

在移动装备上阅读RSS Feed越来越受到关注，也许你可以尝试一下[MobiSpine——手机上的RSS阅读工具][2]。月底，[FeedM8正式开通了中国站][3]，好事一桩，这种阅读方式必将为更多人所知。

因为“<a href="http://www.awflasher.com/blog/archives/1099" title="你不是一个人在阅读：RSS阅读器纷纷加入SNS功能" target="_blank">你不是一个人在阅读</a>”，所以国内RSS阅读器似乎找到了一致的出路，鲜果就在这月<a href="http://blog.xianguo.com/2007/10/25/personal-hompage-70.html" title="鲜果版本更新-个人页面和文章拖拽收藏、分享" target="_blank">引入了SNS元素</a>，开始以人为本了。抓虾则上线了连<a href="http://www.caobian.info/?p=2644" title="Ping抓虾一把" target="_blank">和菜头都要ping一把</a>的<a href="http://www.zhuaxia.com/blog/?p=202" title="抓虾ping功能上线咯" target="_blank">ping功能</a>，其ping地址是[**http://www.zhuaxia.com/rpc/server.php**][4]，WP用户可参照<a href="http://aboutrss.cn/2007/05/11/auto-ping-by-wordpress/" title="嗨!我更新了，你要抓取哟！" target="_blank">这个教程</a>把ping地址加进来，以自动ping抓虾。

<font color="#999999">十月草莓版的汇集到此结束，写法上属于照本宣科式，不喜欢可以留言骂偶，偶有权表示无视，XD</font>

 [1]: http://blogunion.org/blogging-tips/feedsky-feedburner-or-original-feed.html "feedburner，feedsky还是原始 feed？"
 [2]: http://www.wappblog.com/50226711/mobispineieaecrssee_122905.php "MobiSpine：手机上的RSS阅读工具"
 [3]: http://www.wappblog.com/50226711/feedm8aece_123679.php "FeedM8中国站正式开通"
 [4]: http://www.zhuaxia.com/rpc/server.php