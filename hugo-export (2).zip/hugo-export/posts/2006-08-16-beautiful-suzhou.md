---
title: 锦绣苏州
author: Chouj
type: post
date: 2006-08-16T03:02:00+00:00
url: /2006/08/16/beautiful-suzhou/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/blog-post_16.html
views:
  - 2135
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969794
categories:
  - 我记录
tags:
  - 图片
  - 苏州

---
<p align="center">
  <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-297.jpg" border="0" alt="" />
</p>

<p align="center">
  网师园 四大名园之一 可惜我没去 5555
</p>

<p align="center">
  <strong></strong>
</p>

<p align="center">
  <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_004-077.jpg" border="0" alt="" />
</p>

<p align="center">
  寒山寺里的一个塔
</p>

<p align="center">
  <p align="center">
    <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-337.jpg" border="0" alt="" />
  </p>
  
  <p align="center">
    沧浪亭外
  </p>
  
  <p align="center">
    <p align="center">
      <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-502.jpg" border="0" alt="" />
    </p>
    
    <p align="center">
      寒山寺上
    </p>
    
    <p align="center">
      <p align="center">
        <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-477.jpg" border="0" alt="" />
      </p>
      
      <p align="center">
        梦兰苑 梦兰集团下的别墅区
      </p>
      
      <p align="center">
        <p align="center">
          <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-479.jpg" border="0" alt="" />
        </p>
        
        <p align="center">
          波司登下的别墅区
        </p>
        
        <p align="center">
          <p align="center">
            <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-438.jpg" border="0" alt="" />
          </p>
          
          <p align="center">
            常熟 苏州
          </p>
          
          <p align="center">
            <p align="center">
              <img style="BORDER-LEFT-COLOR: #000000; BORDER-BOTTOM-COLOR: #000000; BORDER-TOP-COLOR: #000000; BORDER-RIGHT-COLOR: #000000" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_照片-472.jpg" border="0" alt="" />
            </p>
            
            <p align="center">
              梦兰龙芯产业园 内的概念型网络空间
            </p>