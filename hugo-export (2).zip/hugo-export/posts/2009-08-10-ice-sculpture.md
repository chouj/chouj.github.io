---
title: 正佳广场哈尔滨冰雪节冰雕展
author: Chouj
type: post
date: 2009-08-10T13:56:03+00:00
url: /2009/08/10/ice-sculpture/
views:
  - 2785
duoshuo_thread_id:
  - 1279764464521969924
categories:
  - 我记录
tags:
  - photo
  - 冰雕
  - 广州
  - 正佳广场
  - 生活

---
在大广州能看冰雕展~！奇迹吧。人都能热化，何况冰乎。可还真有这种地方，我和挠挠就去了。以门卡当学生证，我们各花20元，挑了棉衣就冲进去了。据说里面有零下十度，看图为证：

<p style="text-align: left;">
  <figure style="width: 500px" class="wp-caption alignnone"><img title="室内场景" src="http://pic.yupoo.com/xcchris/506937e3932d/medium.jpg" alt="室内场景" width="500" height="375" /><figcaption class="wp-caption-text">室内场景，我站的位置是个大滑梯，看旁边的小滑梯</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="葫芦娃" src="http://pic.yupoo.com/xcchris/005217e3931a/medium.jpg" alt="葫芦娃，太粗糙了。" width="500" height="375" /><figcaption class="wp-caption-text">葫芦娃，太粗糙了。</figcaption></figure> <figure style="width: 375px" class="wp-caption alignnone"><img title="未来动物" src="http://pic.yupoo.com/xcchris/038727e39309/medium.jpg" alt="未来动物主题，鸟身猫头？" width="375" height="500" /><figcaption class="wp-caption-text">未来动物主题，鸟身猫头？</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="忘了叫什么" src="http://pic.yupoo.com/xcchris/962437e392f8/medium.jpg" alt="忘了叫什么，还挺好看" width="500" height="375" /><figcaption class="wp-caption-text">忘了叫什么，还挺好看</figcaption></figure> <figure style="width: 375px" class="wp-caption alignnone"><img title="冰河世纪主题" src="http://pic.yupoo.com/xcchris/047357e392e5/medium.jpg" alt="冰河世纪 猛犸象" width="375" height="500" /><figcaption class="wp-caption-text">冰河世纪 猛犸象</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="钢琴家" src="http://pic.yupoo.com/xcchris/943637e392d5/medium.jpg" alt="钢琴家" width="500" height="375" /><figcaption class="wp-caption-text">钢琴家</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="白雪公主和七个小矮人" src="http://pic.yupoo.com/xcchris/276267e39396/medium.jpg" alt="白雪公主和七个小矮人，白雪公主贼难看了。" width="500" height="375" /><figcaption class="wp-caption-text">白雪公主和七个小矮人，白雪公主贼难看了。</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="卖火柴的小女孩" src="http://pic.yupoo.com/xcchris/126797e39386/medium.jpg" alt="卖火柴的小女孩，愣是没看出哪个是火柴。" width="500" height="375" /><figcaption class="wp-caption-text">卖火柴的小女孩，愣是没看出哪个是火柴。</figcaption></figure> <figure style="width: 375px" class="wp-caption alignnone"><img title="爱斯基摩人" src="http://pic.yupoo.com/xcchris/551997e39360/medium.jpg" alt="爱斯基摩人" width="375" height="500" /><figcaption class="wp-caption-text">爱斯基摩人</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="爱斯基摩人的工具" src="http://pic.yupoo.com/xcchris/381867e39374/medium.jpg" alt="爱斯基摩人的工具，这个好，本来他们的工具就挺粗糙的" width="500" height="375" /><figcaption class="wp-caption-text">爱斯基摩人的工具，这个好，本来他们的工具就挺粗糙的</figcaption></figure> <figure style="width: 375px" class="wp-caption alignnone"><img title="海马" src="http://pic.yupoo.com/xcchris/199077e3934f/medium.jpg" alt="海马，很漂亮" width="375" height="500" /><figcaption class="wp-caption-text">海马，很漂亮</figcaption></figure> <figure style="width: 500px" class="wp-caption alignnone"><img title="七彩滑梯" src="http://pic.yupoo.com/xcchris/514937e3933d/medium.jpg" alt="七彩滑梯，滑了下，风驰电掣~" width="500" height="375" /><figcaption class="wp-caption-text">七彩滑梯，滑了下，风驰电掣~</figcaption></figure> 
  
  <p style="text-align: left;">
    里面还有冰桌冰椅冰马桶冰吧，当然冰吧只是摆设。
  </p>
  
  <p style="text-align: left;">
    被冰得差不多了，我们就撤了，回归暖洋洋的广州。想想“天鹅”来之前的那个酷闷热，怀念下冰窟也是挺不错的，里面拿大通风机吹冷风，那个寒峭啊，纯当望梅止渴了。:)
  </p>