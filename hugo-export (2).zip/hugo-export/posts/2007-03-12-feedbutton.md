---
title: FeedButton:制作下拉式Feed按钮
author: Chouj
type: post
date: 2007-03-12T09:07:34+00:00
url: /2007/03/12/feedbutton/
views:
  - 1081
  - 1081
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969938
categories:
  - 工具
tags:
  - button
  - Feedbutton

---
<a style="text-decoration: none" href="http://www.feedbutton.com/"><span style="margin: 0pt; padding: 0pt 3px; background: #ffffff none repeat scroll 0% 50%; font-style: normal; font-variant: normal; font-weight: bold; font-size: 22px; line-height: normal; font-size-adjust: none; font-stretch: normal; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; text-decoration: none; font-family: verdana,sans-serif; color: #3399ff;">FEED</span><span style="margin: 0pt; padding: 0pt 0px; background: #ff6600 none repeat scroll 0% 50%; font-style: normal; font-variant: normal; font-weight: bold; font-size: 20px; line-height: normal; font-size-adjust: none; font-stretch: normal; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; text-decoration: none; font-family: verdana,sans-serif; color: #ffffff;">BUTTON</span></a>

<span style="font-size: large;">这</span>个站很早就有了，很多人都选用该站制作的**Feed Button**，其优点是“**<span style="color: #ff9900;">One Button, For All XML/RSS Readers</span>**”。

<p align="center">
  <span style="font-style: normal; font-variant: normal; font-weight: bold; font-size: 24px; line-height: normal; font-size-adjust: none; font-stretch: normal; font-family: arial; color: #3399ff;">Replace All These（取代这些）:</span><br /> <img src="http://www.feedbutton.com/icons.gif" alt="ugly rss icon mess" />
</p>

<big><big>只</big></big>需要一个按钮，当鼠标移动到按钮上时，其隐藏的下拉菜单就显示出来，里面囊括支持各样阅读器的按钮。技术简单，但很实用，Blog上不用罗列大堆Feed按钮了，美观又节约地盘。

<big><big>现</big></big>有两种菜单样式，一种是两列式，一种是一列式，两列式效果如下：

<!-- feedbutton code -->

<!-- end feedbutton code -->

<big><big><br /> 想</big></big>拥有这样一个按钮菜单基本不需要什么步骤：

在“<span style="color: #33ccff;">Create My Feed Button</span>”下的选框中，填入您的Feed地址，再点击其下的“<span style="color: #ff9900;">Make My Feed Button</span>”按钮即可生成代码，然后将所生成的代码添加到您blog上需要的位置即告完成。

<big><big>C</big></big>hou觉得下拉菜单中的诸多按钮还是乱了点儿，模样不统一，:)

Technorati Tags: <a class="performancingtags" rel="tag" href="http://technorati.com/tag/FeedButton">FeedButton</a>, <a class="performancingtags" rel="tag" href="http://technorati.com/tag/button">button</a>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>