---
title: '[yuanlin推荐]台湾部落客专用RSS图示'
author: Chouj
type: post
date: 2009-02-20T03:21:50+00:00
url: /2009/02/20/rss-symbol-used-in-taiwan/
views:
  - 1611
  - 1611
duoshuo_thread_id:
  - 1279764464521970039
categories:
  - 标志
tags:
  - Graph
  - RSS设计
  - Symbol
  - Taiwan

---
_很早就收到台湾博友yuanlin的[推荐][1]，结果时隔一个月才发布，实在抱歉。_

该组RSS标志由 [yuanlin][2] 和 <a href="http://www.wretch.cc/blog/idesign0601" target="_blank">小葵</a> 共同构想设计，是台湾本地部落客的标识（以<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/tw/">創用CC 姓名標示-非商業性-禁止改作 2.5 台灣 授權條款</a>釋出。 ）。

上图：

<img src="http://pic.yupoo.com/xcchris/6418070183f3/peb6q6mv.jpg" border="0" alt="" /><img src="http://pic.yupoo.com/xcchris/3768970183f4/ol3ag1pu.jpg" border="0" alt="" />

台湾RSS正常版

<img src="http://pic.yupoo.com/xcchris/8652170183f4/udxiffy1.jpg" border="0" alt="" /><img src="http://pic.yupoo.com/xcchris/6660970183f4/wszttdar.jpg" border="0" alt="" />

台湾RSS方图版

欢迎台湾的bloggers朋友下载到自己空间使用，同样欢迎协助推广！由于yupoo的原因，我这里的图片是jpg格式，需要png格式的朋友，请到<a title="台灣部落客專用 RSS 圖示" href="http://blog.yalinfo.com/2008/06/rss.html" target="_blank">yuanlin的页面</a>下载:

[ via **<a href="http://blog.yalinfo.com/2008/06/rss.html" target="_blank">台灣部落客專用 RSS 圖示</a>** ]

 [1]: http://aboutrss.cn/2007/02/messageboard/#comment-802
 [2]: http://blog.yalinfo.com/