---
title: 乌班兔
author: Chouj
type: post
date: 2008-03-19T17:39:12+00:00
url: /2008/03/20/only-ubuntu/
views:
  - 2756
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969725
categories:
  - 我尝试
tags:
  - Linux
  - Ubuntu
  - 笔记本

---
刚弄到本儿时，还是有瘟豆子叉屁系统的，所以折腾了几天<a href="http://www.douban.com/subject/2154096/" title="士兵突击" target="_blank">士兵突击</a>。还没看完，我就把瘟豆子砍了，直接引进了乌班兔，开始折腾这只兔子。

<p style="text-align: center">
  <img src="http://www.ubuntu.org.cn/themes/ubuntu07/images/ubuntulogo.png" alt="Ubuntu" height="55" width="202" />
</p>

虽然现在还停留在对着教程在终端里复制粘贴一气的程度， 但折腾这只倒霉兔子也算有趣，因为它长得和瘟豆子比较不一样。之前看一师兄对着黑乎乎的命令行界面一阵high敲，觉得特神秘，现在也吸引不到我了，不就是控制台嘛。

之前没网，天天从办公室拷deb回来装，真是痛苦死，一气之下买了交换机，即便绑MAC绑IP，还是弄到了室友的网络，所以目前兔子被折腾成了这样：看突击不成问题了，可以QQ啦，还拿微软雅黑美化了下，并且装matlab成功，不容易啊。下一步想给兔子喝点WINE，让丫能吃点儿瘟豆子的程序，比如迅雷啥的。不多说了，上个桌面：

<img src="http://pic.yupoo.com/xcchris/39361542b9e6/medium.jpg" alt="Desktop Screenshot" height="375" width="500" />

PS. 全面更换各应用和服务的头像，好像有很多要换哦。

<p align="center">
  <img src="http://pic.yupoo.com/xcchris/20348542ba27/nffdlbgf.jpg" alt="Chris" height="120" width="360" />
</p>