---
title: '[译]RSS 1.0/2.0 Atom – 你订阅哪一种？'
author: Chouj
type: post
date: 2007-04-26T09:33:46+00:00
url: /2007/04/26/different-feed-format/
views:
  - 3054
  - 3054
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969943
categories:
  - 相关
tags:
  - Atom
  - Rss 1.0
  - Rss 2.0

---
[RSS 1.0, RSS 2.0 or Atom &#8211; How Do You Subscribe to Blog Feeds ?][1]<span class="author-data"></span>

posted by [Amit Agarwal][2] on 4/25/2007 01:27:00 PM 以获翻译授权

( 译者：写给刚刚认识RSS的朋友）

在网页上，我们经常能见到一个写有XML的小小的橘色图标，<img src="http://bp0.blogger.com/_XYizHvjgLrA/Ri8L5dRGFkI/AAAAAAAAA-4/o_EBpudtx34/s400/RSS+Feeds.png" alt="Rss" align="right" border="�" />或者一个像水波的橘色正方形符号，这表示该站支持RSS供稿。只是有一些博客或网站会更进一步的提供不同格式的联合供稿源（Feed），诸如Atom、RSS 1.0、RSS 0.92和RSS 2.0。

截图来自<a href="http://joi.ito.com/" target="_blank">Joi的博客</a>，访客可以通过3种不同格式的供稿源订阅他的博客文章。但实质上，这些供稿源都是XML档案文件，都按倒序排列，唯一的不同在于内容布局格式上的微小差别。

你是否被这些“烦人”的订阅选择给迷惑住了呢？答案当然是否定的，因为好在你的订阅软件或线上服务能接受任何形式的联合供稿源（Feed）。

只要将网站地址输入你的RSS阅读器，它就会自动选择合适的格式。如果你选用火狐浏览器的实时书签来订阅不同格式的供稿源（Feed），推荐选择RSS 2.0——这是[Dave Winer][3]提过的最佳选择。

世界上有两种互联网用户，一种是用RSS的，一种是不利用RSS的。<a href="http://www.commoncraft.com/rss_plain_english" target="_blank">这里有个视频</a>适合那些能通过RSS的使用节省时间，却不知道从何下手的朋友。

 [1]: http://labnol.blogspot.com/2007/04/rss-10-rss-20-or-atom-how-do-you.html
 [2]: http://www.labnol.org/about.html
 [3]: http://www.scripting.com/