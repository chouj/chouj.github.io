---
title: 部长带来的（五）
author: Chouj
type: post
date: 2006-03-18T02:19:00+00:00
url: /2006/03/18/what-department-head-bring-5/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/03/blog-post_18.html
views:
  - 1799
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969763
categories:
  - 我记录
tags:
  - 软件
  - 部长

---
相逢不如偶遇，作个通讯部的部长，竟然能让人熟悉一门软件，貌似不相干的东东就这样被我联系在了一起。Adobe Premiere 就是这个了，从茫然不知世界上还有这么一玩意儿，到现在拍个什么都少不了用到它，少不了有人找到我。

其实，这种事情只要多看看书上教程，自己摸索摸索，加上手上软件资源齐了，又不怕麻烦，那什么剪片儿、压片儿、字幕、玩格式都是小儿科，我决不敢在此说自己多么多么精通，以免哗众取宠。做了那么多片子，多是稍微剪剪，加几个字而已，特效就不用讲了，更谈不上什么艺术。这么一来，我自己摸索了，ok，我明白是这么一回事了，离高级影视编辑人才差得远。可其他人呢，不亲自去试的，丢我一身盲目崇拜的目光＋夸奖，唉，也不怪人家，不知者不为过。

忽然想起“能者多劳”，这破词真是害人不浅，现在想想发号施令的就是比执行施令的爽的多，不管你发号施令的时候是颐指气使，还是低三下四。

系里整一DV真是方便了大家，锻炼了老子我，既然得到了锻炼，就不抱怨了。

罗列下出手的视频，不为炫，只为证明这精力耗费的那叫一个多。。。想想俺也可以变身为胡戈，hoho：

<a href="http://www.hustetv.net/n253c29.shtml" target="_blank">系学习十六号文件DV 《梦想在希望升起的地方》</a>

<a href="http://www.hustetv.net/n305c29.shtml" target="_blank">系05年迎新晚会</a>

以上这两个网上有&#8230;but华工内才可以流畅播放。

系05年开放日活动

湖北省世界物理年科普知识展我系志愿活动
  
世界物理年系列活动物理科普知识决赛
  
世界物理年之光传递活动武汉地区
  
世界物理年系列活动之创新设计实验大赛（初赛＋决赛）
  
世界物理年华工系列活动闭幕式播放的总结短篇
  
系03级拔河比赛
  
系05级新生军训阅兵剪影
  
系05团学联纪念特辑
  
系05年度学代会
  
系社会实践部06.3.5学雷锋活动采风

最恶的是有个延安红色革命之旅的视频也是我做的，片子里出现了壶口瀑布、华山……还有诸多TEaChers、Masters、Leaders ……

另外，关于PS，这个不能算部长头衔带来的，因为早就在用。but在任期间PS也发挥了不少作用，比如PS个系徽、ps个浮动链接gif、ps个海报、ps个DV剧CD封面、PS个物理年纪念册、Ps个系刊…… 想起前些天看考研的帖子，一文里写：想考计算机的要搞清楚的是，画个图、做网站、剪片子、做皮肤、截音乐、做字幕之类的，那统统不叫计算机，要是为了这个考计算机，那就是大错特错。

真理啊！

再附个接触到的software列表&#8230;
  
……………………………………………………
  
Premiere 6.5用：
  
Adobe Premiere MPEG Encoder 激活程序
  
JPG公司的AVI文件解码器MJPEG VIDEO CODEC
  
百老汇公司的AVI文件解码器
  
MPG剪辑软件IEDIT
  
PREMIERE输出MPG格式插件XING ENCODER
  
模板定位软件 UltraEdit
  
Titledeko
  
title express
  
TMPGEnc + Video Server
  
极品字幕软件TitleMotion（有教程）
  
极品转场软件AdorageI-GfxDatas.ISO
  
PREMIERE的好莱坞转场特效插件Hfx313,还有5.1 和 4.58 gold 两个版本的安装程序，共3个好莱坞
  
PREMIERE的雨雪插件Final Effects
  
premiere输出插件ProCoder_2.0
  
音频处理：
  
专业音频处理软件Magix.Samplitude.Professional.v7.22.Retail.KG.HH
  
CoolEdit
  
压片或转格式用：
  
Batch Real Producer
  
Easy RealMedia Producer
  
EOVideo_v1.36H
  
Elecard MPEG2 Video Decoder
  
MainConcept MPEG Encoder
  
RealMedia Editor
  
RealMedia Analyzer
  
VirtualDub
  
VobSub\_2.29\_All
  
Windows Media Encoder 9.0
  
WMEncoder9
  
XMPEG
  
……………………………………………………