---
title: '[WP插件]My Feed Stats介绍'
author: Chouj
type: post
date: 2008-02-10T11:46:08+00:00
url: /2008/02/10/my-feed-stats/
views:
  - 1929
  - 1929
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969993
categories:
  - WordPress
tags:
  - Plugin
  - WordPress

---
<img border="0" width="348" src="http://pic.yupoo.com/xcchris/7994550fbabe/medium.jpg" alt="Happy new year ~" height="500" />

<!--more-->

这回要介绍的是国人——<a target="_blank" href="http://tech.idv2.com/" title="idv2">Charlee</a>——自行开发的一款Feed订阅统计插件：**My Feed Stats**，发布于去年11月12日，厌倦了Feed烧制服务的朋友可以试试这款能够提供Feed统计状态和显示的插件，其功能是：

> 可以输出FeedBurner样式的统计图；
  
> 支持在线、离线阅读器的统计；
  
> 可以自定义各种阅读器的UserAgent标识，自行判断某个UserAgent是否为合法的阅读器；
  
> 可以生成FeedBurner样式的订阅者数图片。

具体安装方法和使用方法请参考**<a target="_blank" href="http://tech.idv2.com/2007/11/12/my-feed-stats/" title="Feed统计插件My Feed Stats发布">My Feed Stats插件发布页</a>**。这里给出插件设置界面的截图供参考：

<img border="0" width="460" src="http://pic.yupoo.com/xcchris/94471510df91/eswh08vp.jpg" alt="aboutrss my feed stats dashboard" height="549" />

###### <font color="#999999">鲜果认领：BANG9476C6BF5186D3C824EE4C47XIANGUO BANG32DF4A83A2A407F1D1756EF2XIANGUO BANGB9BA9E5B4FC30531E510609DXIANGUO</font>