---
title: 暂时回归
author: Chouj
type: post
date: 2007-03-28T08:53:00+00:00
url: /2007/03/28/temporary-back/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/blog-post_28.html
views:
  - 2643
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969869
categories:
  - 我记录
tags:
  - blog
  - 网络

---
<span style="font-size:180%;"><span style="font-weight: bold;">这</span></span>口G_Blogger(牌号32269107)锅再度小炸之后，我知道blogspot又可正常访问了。加之<a href="http://www.gseeker.com/50226711/blogspoteeaeie070328ie_78129.php" target="0">GSeeker的第一时间报道</a>，更加确信blogspot暂时回归。虽然<a href="http://lingouyi.blogspot.com/" target="0">L.G.Y</a>说仅仅是从上次封锁的IP:72.14.207.190
  
换到了现在的IP:72.14.207.191，也不知道是不是Google的公关起了作用，但总算谢天谢地又能访问了。

<span style="font-size:180%;"><span style="font-weight: bold;">无</span></span>论如何，这里都将继续，如果我要换BSP的话，下一个一定是独立架站。只是非常不爽GFW将俺们这些小民玩弄于股掌之中。最近看《<a href="http://www.douban.com/subject/1426971/" target="0">野火集</a>》，觉得改host、加代理、代Tor，都是避，都是绕，而抵抗或者声讨自身权利的一概没发现，比方弄个antiGFW.com，发出点声音，虽然这种站绝对会上GFW的黑名单。就像虚飞说的那样，封了，解了，还得感谢，这难道不是病态么？

<span style="font-size:180%;"><span style="font-weight: bold;">B</span></span>logspot暂时可访问，加之一点不闲的<a href="http://blogs.feedsky.com/?p=133" target="0">吕帅的“闲话”</a>，回归<a href="http://beta.feedsky.com/" target="0">Feedsky</a>的理由足够了，虽然肯定是和Feedburner烧的Feed并存。各位到底订哪个，看自己的立场，顺便检验下两家受欢迎的程度，有竞争才有生存。回归的另一个主要原因就是，实在想知道自己这块儿地值多少钱，有没有发展为钉子户的价值，很俗的欲念。这么写让我挺惭愧，捣腾了一遍结果有自己抽疯之嫌，只能怨GFW闹的，而且一下给我闹出两个激活的话题广告Feed，不好收场。不知道吕帅能否给话题广告开个删号的功能。最后奉上激活码：efa22884，要说的是，当然不会仅仅估个价就完事，有时间我肯定会就邀请话题写点什么的。

<span style="font-size:180%;"><span style="font-weight: bold;">U</span></span>pdate：Blog定价：￥ 30.00元，看来我在对“人工干预”这四个字的估计上严重失误。