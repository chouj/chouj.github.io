---
title: 摆弄blog也是种幸福
author: Chouj
type: post
date: 2007-08-01T15:06:30+00:00
url: /2007/08/01/happiness-with-blogging/
views:
  - 117110
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969697
categories:
  - 我思考
tags:
  - blog
  - 幸福
  - 生活
  - 饭否

---
<big><big>老</big></big>早前就在<a href="http://fanfou.com/Chris" target="_blank">饭否</a>上说过：有时间折腾Blog的都是幸福的人，结果被<a href="http://iwfwcf.blogspot.com/" target="_blank">IwfWcf</a>反驳，大意是个人对幸福的定义不一样，不见得谁都以为弄blog是幸福的事情。也许我最近的心境比较卑微，我还是觉得能Blogging就是十分幸福的。有电脑，有网络，更有时间，有精力，也有接触blog这种概念的优越条件，即便患上blogging综合症，怎么看也是一种幸福的病。

这些天来，我似乎又体验到一种幸福，那就是静静得看朋友们blogs上的文字，看到他们的喜怒哀乐，能让我随时意识到他们的存在，知道他们过的好好的。谁要是在blog里消失掉，也许我会真的不安。虽然oneoo<a href="http://fanfou.com/statuses/DIaPnwE88j4" target="_blank">说过</a>，大部分人不是在写博客，而是在写日记，这样对blog内容的质量和站点的排名环境不利，但那份为自己而写的真实，那种让我触动的真实，怕也丧失掉了吧。

还有些幸福的小困扰：

我能写多久？在网络上，我遇到过形形色色的Bloggers，多数都已经有了稳定的生活。我则仍在考虑前途考虑谋生，揣测未知的未来是否还允许我拥有blogging的幸福。当我没有办法执掌这高级的幸福时，我又会怎样抽身离去？比如<a href="http://aboutrss.cn/" target="_blank">RSS相关</a>没法继续的时候，我该说什么呢？好像做这个站的时候没想过这么多。

我现在又该不该写，该不该关心？花精力写类似<a href="http://aboutrss.cn/2007/07/31/what-happened-in-july/" target="_blank">草莓版RSS消息</a>，获取认同服务大众，一切都那么美好；追随即时的消息，了解社会和网络纷杂的变化，似乎非常的充实。但我没稳定下来之前，我是不是该长远的想想：这些过于短期效应，如果不去作职业blogger，这都不大能够直接服务于求生；我是不是该去多看看书，补补英语什么的。

过几天我就要去广州读研，也许意识到将和网络疏远才让我有此番思考。有取有舍，有失有得，高中时我就信奉这句，现在又是抉择的时候。可能更新会少，但我还是会在网络上出现，因为未来离不开网络，也因为我需要大家知道我的存在。很高兴能有<a href="http://fanfou.com/" target="_blank">饭否</a>这个网站，即便没有网络，我还是能用手机短信，在<a href="http://fanfou.com/chris" target="_blank">我的饭否</a>记录一切feeling、idea、thought和experience。现在我可以肯定的是，以后如果出海，我会发短信到<a href="http://fanfou.com/chris" target="_blank">饭否</a>报平安。

<a href="http://fanfou.com/Chris" title="饭否" target="_blank"><img src="http://b.fanfou.com/u/Chris/single.png" alt="饭否" border="0" /></a>