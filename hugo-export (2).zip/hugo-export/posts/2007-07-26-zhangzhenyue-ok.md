---
title: 张震岳 OK | 思念是一种病
author: Chouj
type: post
date: 2007-07-26T08:01:00+00:00
url: /2007/07/26/zhangzhenyue-ok/
enclosure:
  - |
    http://www.d5bbs.com/UploadFile/2005-12/2005122622481681609.mp3
    4520789
    audio/mpeg
views:
  - 3034
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969696
categories:
  - 我记录
tags:
  - 张震岳
  - 思念是一种病
  - 音乐

---
<img src="http://www.douban.com/lpic/s2591057.jpg" title="张震岳 OK | 思念是一种病" alt="张震岳 OK | 思念是一种病" height="432" width="309" />

<span class="oblog_text">专辑名称：OK（思念是一种病）<br /> 歌手姓名：张震岳<br /> 唱片公司：滚石唱片<br /> 发行日期：2007年07月06日<br /> 专辑语言：国语专辑<br /> </span>

 <a href="http://www.mediafire.com/?duznn2xmrzf" title="download" target="_blank">点此进入下载页面（DOWNLOAD）</a>

<span style="font-size: 8pt">歌曲只做试听用途，请在下载后24小时内删除，<br /> 音乐版权归相关音像公司所有。<br /> 如果喜欢，请支持歌手，购买正版音像制品。</span>

<big><big>许</big></big>久不曾写音乐方面的东西，因为听的少。看到有bloggers推荐流行圈内的辑子，就听了些。林俊杰的西界，好像过了听这种歌的年龄似的；王力宏的改变自己，又有点儿接受不了其风格；只发现了<a href="http://www.douban.com/subject/2134548/" title="张震岳 OK" target="_blank">张震岳的《OK/思念是一种病》</a>。有人说，听了后有种飙泪的惊喜和感动，估计境遇类似的人都会这么想。曲调轻松，歌词朴实，却值得随着歌随着词慢慢回味，每一首都是这样。

01. 思念是一种病
  
02. 你说有个女孩
  
03. 路口
  
04. 很难
  
05. OK
  
06. 孤独的夜哨
  
07. 再见
  
08. 小宇
  
09. 就让这首歌 &#8211; 张震岳/MC HotDog/侯佩岑
  
10. 小星星 &#8211; 张震岳/阿里山桃花村姐妹
  
11. 再见 (真情版)

再见 <small>载入有点慢</small>
  
[audio:http://www.d5bbs.com/UploadFile/2005-12/2005122622481681609.mp3]
  
再见（真情版）<small>载入速度适中</small>
  
[audio:http://gmr.hilp.cn/再见.mp3]

<big><big>特</big></big>别推荐这首再见，挺适合毕业之类生活中要go our separate ways的人听。顺便推荐两个找音乐的地方，也都是blogs。

<a href="http://kadeblog.com" target="_blank">Kade</a> —— 一个叫Kade的女生，把自己听的单曲都写出来，更新很快，有下载链接。
  
<a href="http://www.ben3.net/blog/user1/9/index.shtml" target="_blank">影月孤风娱乐杂志</a> —— 借助网络硬盘关注专辑更新的blog，挺全乎，可下载。