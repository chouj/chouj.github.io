---
title: 怎样经由Twitter实现RSS Feed同步到微博
author: Chouj
type: post
date: 2013-04-12T06:41:49+00:00
excerpt: 怎样经由Twitter实现RSS Feed同步到微博
url: /2013/04/12/怎样经由twitter实现rss-feed同步到微博/
views:
  - 2884
duoshuo_thread_id:
  - 1279764464521969666
categories:
  - 我尝试
  - 教程
tags:
  - RSS
  - twitter
  - Weibo

---
  1. RSS Feed to Twitter: <a title="IFTTT" href="http://ifttt.com" target="_blank">IFTTT</a>, <a title="TwitterFeed" href="http://twitterfeed.com/" target="_blank">TwitterFeed</a>, etc.
  2. Twitter Tweets to Weibo: <a title="twitter-to-weibo-appengine" href="https://github.com/yfli/twitter-to-weibo-appengine" target="_blank">twitter-to-weibo-appengine</a>

感谢<a title="GAE" href="https://appengine.google.com/" target="_blank">GAE</a>、<a title="github" href="https://github.com/" target="_blank">github</a>、<a title="Gtalk机器人" href="http://world.sinaapp.com/" target="_blank">新浪微博Gtalk机器人</a>。

警告：一折腾就死星人请绕行。