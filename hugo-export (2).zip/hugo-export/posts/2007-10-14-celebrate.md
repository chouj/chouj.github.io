---
title: 热烈庆祝～
author: Chouj
type: post
date: 2007-10-14T12:32:40+00:00
url: /2007/10/14/celebrate/
views:
  - 2290
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969714
categories:
  - 我表达
tags:
  - blog
  - 图片
  - 网络

---
**热烈庆祝**[个人首页][1]访问量破千～[个人blog][2]访问量破五千～[RSS相关][3]访问量破万，订阅量破400～

值此良辰，17大也选择这时召开，偶感到荣幸之至，特转图两张表达下人民大众的心声：

<img src="http://photo5.yupoo.com/20071014/202452_1334796695_xcadlivr.jpg" height="1393" width="492" />

<img src="http://photo11.yupoo.com/20071014/202453_1892927289_unytbygx.jpg" height="281" width="500" />

 [1]: http://www.xuchi.name/
 [2]: http://www.xuchi.name/blog/
 [3]: http://aboutrss.cn