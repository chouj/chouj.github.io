---
title: 贴图不说话
author: Chouj
type: post
date: 2006-09-04T05:30:00+00:00
url: /2006/09/04/picture-with-no-words/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post_04.html
views:
  - 1998
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969803
categories:
  - 我记录
tags:
  - 图片

---
[<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_345.jpg" border="0" alt="" />][1]

<div>
  <a href="http://club.chinaren.com/77797226.html"></a>
</div>

<div>
  直接搜 <span style="color: #c0c0c0;">中国最强悍的</span>
</div>

 [1]: http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_345.jpg