---
title: 证书
author: Chouj
type: post
date: 2008-07-03T07:44:38+00:00
url: /2008/07/03/certification-firefox-3/
views:
  - 2213
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969900
categories:
  - 我记录
tags:
  - firefox
  - 图片

---
<a title="点我点我" href="http://www.spreadfirefox.com/zh-CN/worldrecord/certificate_form" target="_blank"><img class="alignnone size-full wp-image-291" title="firefox-download-day" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/firefox-download-day.jpg" alt="Firefox 3.0下载日世界纪录" width="497" height="377" /></a>