---
title: Feedsky:国内首推RSS广告业务！？
author: Chouj
type: post
date: 2007-07-02T16:47:24+00:00
url: /2007/07/03/rss-advertisement-feedsky/
views:
  - 1333
  - 1333
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969960
categories:
  - 广告
  - 新闻
tags:
  - feedsky
  - RSS广告

---
<big><big>老</big></big>早前，[keso][1]就多次提到RSS广告问题（[1][2]、[2][3]、[3][4]、[4][5]），RSS具备广告投放价值已经成为一种事实。国外的RSS内嵌广告早就有所发展，比较成熟的是<a href="http://www.feedburner.com/fb/a/advertising" target="_blank">Feedburner Ads</a>项目和[Pheedo][6](可参考 [7个用Rss Feed赚钱的办法][7]——前博客)。

<p class="wrap">
  &nbsp;
</p>

<p id="hp">
  <a href="http://www.feedsky.com/"><img src="http://www.feedsky.com/images/logo_147x47.gif" alt="feedsky logo" title="feedsky" border="0" /></a>
</p>

<p id="hp">
  &nbsp;
</p>

<big><big>刚</big></big>从[盗盗那里][8]获悉，国内知名Feed烧制托管服务商[Feedsky][9]也将尝试RSS展示广告，虽然目前尚处在小范围测试阶段，但这足以视为国内RSS应用上的大事件。有兴趣的朋友可参考盗盗的介绍——**[Feedsky进军RSS广告行业!][10]**和**[Feedsky RSS展示广告帮助文档][11]**。

<small><font color="#666666">有朋友第一反应是：收入来啦！ XD ..</font></small>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://blog.donews.com/keso
 [2]: http://www.donews.net/keso/archive/2004/06/03/24657.aspx
 [3]: http://www.donews.net/keso/archive/2004/09/26/110169.aspx
 [4]: http://www.donews.net/keso/archive/2004/11/20/176199.aspx
 [5]: http://www.donews.net/keso/archive/2005/03/01/292083.aspx
 [6]: http://pheedo.com/
 [7]: http://www.qianblogger.com/2007/05/21/7rss-zhuanqian/ "前博客: 7个用Rss Feed赚钱的办法"
 [8]: http://www.showeb20.com
 [9]: http://www.feedsky.com
 [10]: http://www.showeb20.com/?p=575
 [11]: http://www.feedsky.com/help_adcpm.html