---
title: 趋势科技红色风暴
author: Chouj
type: post
date: 2008-06-22T13:43:20+00:00
url: /2008/06/22/trend-micro-red-storm/
views:
  - 2380
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969897
categories:
  - 广告
tags:
  - 趋势科技杀毒专家

---
<img class="alignnone size-full wp-image-276" title="趋势科技携手网络百名博主，共同倡导互联网安全环境" src="http://www.xuchi.name/blog/wp-content/uploads/2008/06/trend-news.gif" alt="趋势科技携手网络百名博主，共同倡导互联网安全环境" width="495" height="398" />

最近，**[趋势科技携手网络百名博主，共同倡导互联网安全环境][1]**引起了广泛的注意，让人们不得不把目光再次转移到杀毒软件上来。

话说每位和电脑打交道的人都免不了要挑选杀毒软件，就我个人而言，由于网络上国产杀软均口碑不佳，我一开始就瞄准了国外的杀毒软件，而说来也巧，用的第一款杀软就是趋势科技的PC-cillin。这款随华硕主板附赠的正版杀软，陪伴我度过了刚拥有电脑时，尚不知病毒厉害的懵懂时期，算是那时的电脑保护神。这次，趋势科技转而使用博客口碑营销的方式，杀回国内，打算掀起趋势红色风暴，我这里也算风暴一角，因为下面我想简单介绍下趋势科技针对个人用户推出的**[趋势科技杀毒专家2008][2]**。[这里可免费下载试用][3]

<img class="alignleft size-full wp-image-278" title="趋势科技杀毒专家2008" src="http://www.xuchi.name/blog/wp-content/uploads/2008/06/tvs2008_b.jpg" alt="趋势科技杀毒专家2008" width="196" height="196" />现在这个时代，电脑不上网就是摆设，上了网又有中病毒的风险，趋势科技的这款杀毒专家正是为保障网络和电脑安全而来。官网上用安全、快捷、强劲三个词来形容她，自然因为该杀软在病毒防治、资源占用效率和用户体验上表现出色，老牌公司的产品，质量上必然有诚信为保证。稍微试用一下即知，趋势科技杀毒专家2008能够为入网电脑提供全方位的安全保护，使用简单，界面友好，有下图为证：

<img class="alignnone size-full wp-image-279" title="趋势科技杀毒专家2008" src="http://www.xuchi.name/blog/wp-content/uploads/2008/06/trends.jpg" alt="趋势科技杀毒专家2008" width="500" height="370" />

特别想提一下的就是，bloggers即作为网民中更需要杀软保障密码、信息、交易安全的群体，，同时又是网络上拥有话语权的民众，被趋势科技选为产品宣传的先锋队，实为各取所需，出奇制胜。我觉得这是非常不错的方式，[趋势公司的新闻页][1]上更是热心的给出了博客信息安全防范的若干提示。

闲话少说，无论怎样，网络上多了趋势科技杀毒专家，即多了把保障网络安全的武器，对大众来说，肯定是有利无弊的。

 [1]: http://cn.trendmicro.com/cn/about/news/pr/article/20080604032206.html
 [2]: http://cn.trendmicro.com/cn/products/personal/trend_micro_antivirus_tav/index.html
 [3]: http://www.trendmicro.com/download/zh-cn/product.asp?productid=46