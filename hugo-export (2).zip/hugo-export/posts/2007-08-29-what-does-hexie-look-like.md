---
title: 河蟹长啥样？
author: Chouj
type: post
date: 2007-08-29T03:30:26+00:00
url: /2007/08/29/what-does-hexie-look-like/
views:
  - 4922
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969706
categories:
  - 我表达
tags:
  - 图片
  - 河蟹

---
  * 河蟹长啥样

<img src="http://photo5.yupoo.com/20070829/102900_615895184_jalonlpx.jpg" title="河蟹长这样" alt="河蟹长这样" height="375" width="500" />

  * 河蟹舌会会旗

<img src="http://photo11.yupoo.com/20070829/102902_1512814121_kidjqtdu.jpg" title="无奖竞猜" alt="无奖竞猜" height="200" width="300" />

  * 河蟹舌会会员必备

<img src="http://photo11.yupoo.com/20070829/103139_1174455110_ndoocnzp.jpg" title="very good very strong" alt="very good very strong" height="460" width="520" />

  * 河蟹舌会会员专项健身运动

![翻墙][1]

  * 河蟹舌会的电脑长啥样

<img src="http://photo1.yupoo.com/20070323/233342_1277263086_qjkabmhv.jpg" title="上网有风险" alt="上网有风险" height="250" width="374" />

  * 河蟹舌会的猪都是怎么死的

<img src="http://photo5.yupoo.com/20070829/103140_1794578480_alyatuwi.jpg" title="撞墙撞死的" alt="撞墙撞死的" height="388" width="353" />

  * 河蟹的宠物

<img src="http://photo11.yupoo.com/20070829/102902_905293131_rkxftqqj.jpg" title="GFW" alt="GFW" height="344" width="500" />

  * 该宠物的口头禅

<img src="http://photo5.yupoo.com/20070829/102901_541589717.jpg" title="今天你被Gfw了吗？" alt="今天你被Gfw了吗？" height="125" width="500" />

  * 该宠物的窝

<img src="http://photo11.yupoo.com/20070829/103140_1202285187.jpg" title="Nice Place" alt="Nice Place" height="333" width="500" />

  * 该宠物的癖好

<a href="http://caitou.com/archives/voodoo-curse/" title="点击本图等于扎一针" target="_blank"><img src="http://photo5.yupoo.com/20070827/203430_1148288094_pqwthdud.jpg" alt="voodoo curse" border="0" height="250" width="160" /></a>

<p align="center">
  ××××××××××××××××××分割线××××××××××××××××
</p>

<p align="center">
  &nbsp;
</p>

<p align="center">
  <img src="http://photo5.yupoo.com/20070827/015710_327812605_xbyhkddh.jpg" />
</p>

<p align="center">
  <img src="http://photo11.yupoo.com/20070827/015709_511176313_luxwxora.jpg" />
</p>

<p align="center">
  <strong>声援<a href="http://caitou.com/archives/voodoo-curse/" title="VOODOO CURSE" target="_blank">大猫</a>，友情贴图</strong>
</p>

 [1]: http://photo5.yupoo.com/20070829/102901_1249397725_ydemiklp.jpg "翻墙"