---
title: 3款黑莓用全屏时钟屏保
author: Chouj
type: post
date: 2007-10-11T14:38:58+00:00
url: /2007/10/11/3-screensaver-for-blackberry/
views:
  - 7929
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969712
categories:
  - 我表达
tags:
  - 屏保
  - 时钟
  - 黑莓

---
<font color="#ff0000"><strong>For BlackBerry 72XX</strong></font>

又找到了好东东，共享出来。这次是三款各有特色的全屏时钟屏保，有截图和个人体验介绍哦～

**1st. 动态背景时钟屏保：Spruce**

装上这款软件之后，桌面上就有3个程序图标，分别对应三种动态屏保：

![][1]

SpruceRain对应屏保截图如下：

![][2]

还有两种动态，分别是Snow和Star：

![][3]

![][4]

没有定时功能，没有报时功能，但是动态的哟。可以控制显示日期还是时间，可以选择取消动态效果。按滚轮下面的esc键退出屏保状态。

2nd. **据说可定时当闹钟的AlarmClock**，- -||

顾名思义，有Alarm功能，可惜我设定了它没响，不知何故，先上PP：

![][5]

长得还是很好看的，按滚轮可调出菜单：

![][6]

可设置闹钟，选择各显示项目，功能相对来说很强大。点滚轮下esc键退出屏保。

**3rd. 整点报时的数字时间屏保**

![][7]

很大气，我喜欢。整点，振动加播放北京站的那个整点报时音乐（不知道叫啥名儿，- -b），再叮咚。一刻、半点、三刻，振动加叮咚。注意：振动无声状态，好像也会叮咚哦。而且，在我机器上，也许是调用的液晶点阵多了耗CPU，有时会召唤 出沙漏。点滚轮下面的esc也无法退出屏保状态，要按滚轮，选close。

[ <a href="http://www.box.net/shared/z1uqigseb6" title="黑莓72XX用全屏时钟屏保下载" target="_blank"><strong>点此下载</strong>包含三款屏保的压缩包文件</a> ]

 [1]: http://photo5.yupoo.com/20071011/205358_404103231_m.jpg
 [2]: http://photo11.yupoo.com/20071011/203440_461286329_m.jpg
 [3]: http://photo11.yupoo.com/20071011/203440_722652101_m.jpg
 [4]: http://photo11.yupoo.com/20071011/203440_1153197155_m.jpg
 [5]: http://photo5.yupoo.com/20071011/205357_1148185946_m.jpg
 [6]: http://photo11.yupoo.com/20071011/203440_1614776096_m.jpg
 [7]: http://photo5.yupoo.com/20071011/203439_1953817777_m.jpg