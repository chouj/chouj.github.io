---
title: Ubuntu下基于Pure-ftpd建FTP记录
author: Chouj
type: post
date: 2013-07-31T08:43:26+00:00
url: /2013/07/31/以ftp作为小团队内部资料共享方案：基于pure-ftpd/
views:
  - 1814
duoshuo_thread_id:
  - 1279764464521970079
categories:
  - 我尝试
  - 我记录
tags:
  - FTP
  - Ubuntu

---
<a title="小团队的内部资料共享协作是怎样的？" href="https://www.v2ex.com/t/30716" target="_blank">一年前就开始寻找课题组内资料共享的解决方案</a>，现在发现，我把事情想复杂了：在内网建外网可访问的FTP的话，以为要在单位出口网关上做映射才行，以为要搞DDNS。其实都不用。以下记录一些关键信息，备查。

一开始尝试vsftpd，装好后发现21端口都没打开，作罢（查端口命令：#sudo netstat -npltu | grep 21）。

安装pure-ftpd可参照网上的教程，不过其配置比较奇怪。Ubuntu 12.04下的/etc/pure-ftpd里确实有auth、db、conf三个文件夹，但<a href="http://wiki.ubuntu.org.cn/Pure-ftpd" target="_blank">官方wiki</a>说的在conf里以选项为文件名，以选项值为文件内容进行配置，却不起作用。只好在启动命令里加switch：

#sudo pure-ftpd -F ~/Message -lpuredb:/etc/pure-ftpd/pureftpd.pdb &#8211;fscharset=gbk &#8211;clientcharset=gbk -b -A -B -c15 -C5 -E -G -k95 -r -K -H  &

这些switch的控制作用可以在官网查。诡异的是“-l”这个，后面紧跟的虚拟用户数据库路径和“l”间居然不用空格。

然后，在办公室Buffalo路由做端口映射，开放21端口。另外，在/etc/rsyslog.conf里做了ftp日志的单独输出，输出日志以gedit打开不能正常显示中文字符，但用配置好utf-8的GVIM打开就可以。

目前运行良好，因为本来访问量就小。最大的问题在于WIN下部分浏览器不能正常显示中文，以致进入不了某些中文名的文件夹，最佳解决方案还是用FlashFXP等FTP工具访问。