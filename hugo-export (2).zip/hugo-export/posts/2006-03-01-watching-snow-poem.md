---
title: 观雪
author: Chouj
type: post
date: 2006-03-01T02:03:00+00:00
url: /2006/03/01/watching-snow-poem/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/03/blog-post.html
views:
  - 1464
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969758
categories:
  - 我表达
tags:
  - 诗

---
观 雪
  
柳绿千载复，
  
雪瑞万古苏。
  
奈何人自问，
  
几时赴殊途。
  
公元2006年2月28日，天降瑞雪。念及时初春色乍现，奈何年复一年，已然无所触。值雪落大地，四处皑皑，人心复又勃勃。愚观雪而思，未知归路，故有此拙作，贻笑大方。
  
日前愚作一联，一并奉上。
  
花漫漫，日彤彤。龙腾四海，春雨浓。
  
草萧萧，月朦朦。凤翔九天，秋实红。
  
故友闻之，同对一下联。
  
花漫漫，日彤彤。龙腾四海，春雨浓。
  
木萧萧，月皎皎。虎跃山林，秋风高。