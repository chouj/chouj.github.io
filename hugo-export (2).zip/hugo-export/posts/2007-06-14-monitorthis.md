---
title: MonitorThis:实现搜索结果的订阅
author: Chouj
type: post
date: 2007-06-13T21:21:39+00:00
url: /2007/06/14/monitorthis/
views:
  - 1944
  - 1944
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969958
categories:
  - 工具
tags:
  - Feedburner
  - feedsky
  - MonitorThis
  - Search Engine

---
<a target="_blank" href="http://alp-uckan.net/free/monitorthis/" title="MonitorThis"><img border="0" width="147" src="http://photo6.yupoo.com/20070614/042145_1237572663_xbqqzjnr.jpg" alt="monitorthis" height="34" /></a>

<big><big>每</big></big>天网络上将产生许多新的页面，而搜索引擎的爬虫们在积极地抓取，努力把所有网络上的内容都纳入其搜索引擎中。如果能让爬虫们为你服务，**将你关心的关键字的内容抓取到，再通过RSS推送到你面前**，这是不是很激动人心呢？那么<a target="_blank" href="http://alp-uckan.net/free/monitorthis/" title="MonitorThis"><strong>MonitorThis</strong></a>就可以帮到你的忙，她能让你订阅到你需要的关键字在22个搜索引擎上的结果。MonitorThis直译的意思是：“监视这个”，对于<a target="_blank" href="http://alp-uckan.net/free/monitorthis/" title="MonitorThis"><strong>MonitorThis</strong></a>的功能来说，非常贴切。而22个搜索引擎分别为：

>   * [Google Blog Search][1]
>   * [Google News][2] search
>   * [Technorati][3] tag search
>   * [del.icio.us][4] tag search
>   * [furl][5] search
>   * [Flickr][6] tag search
>   * [MSN][7] search
>   * [MSN News][7] search
>   * [Yahoo][8] search
>   * [Yahoo News][9] search
>   * [Icerocket][10] search
>   * [Feedster][11] rss search
>   * [Topix.net][12] search
>   * [Feedsfarm.com][13] search
>   * [Newspad PRWeb][14] search
>   * [Search4RSS][15] rss search
>   * [Blogdigger][16] search
>   * [Plazoo][17] search
>   * [NewsNetPlus][18] search
>   * [Blogmarks][19] tag search
>   * [Find articles][20] search
>   * [Wired News][21] search
>   * [blogg.de][22] tag search

<big><big>OK</big></big>，让我们开始，我们需要做的只有**三**步：

  1. 在<a target="_blank" href="http://alp-uckan.net/free/monitorthis/" title="MonitorThis"><strong>MonitorThis</strong></a>页面上的“enter search term”中**填入**你所关心的**关键词**，比如“Google”之类（对中文支持不佳），点击右侧的“make monitor.opml”；
  2. “your monitor.opml”中即生成opml文件的代码，点击“select all”，拷贝到记事本中，**保存为monitor.opml文件**。高手可以直接更改opml文件的代码，一个“outline”标签即对应一个搜索引擎的关键词搜索，可自行添加或删减，再存储为opml文件；
  3. 一般的**RSS**阅读器都支持opml文件导入。**将该文件导入阅读器**后即出现22个订阅，可阅读可管理。最好管理下，将22个订阅归为一类，再删掉不需要的搜索引擎的结果订阅。

<big><big>通</big></big>过３步，爬虫们找到的新东西就可以实时出现在你面前了，很实用的功能，可以拿来监视某关键字在搜索引擎中的流行程度，监视相关关键字的新信息，等等。

<big><big>PS</big></big>.最近**RSS**界同样是新消息不断：<a target="_blank" href="http://www.ilili8.cn/post/48.html" title="抓虾改版"><strong>抓虾</strong>改版</a>，<a target="_blank" href="http://blogs.feedsky.com/?p=147" title="Feedsky改版"><strong>Feedsky</strong>改版</a>，<a target="_blank" href="http://www.wappblog.com/50226711/ietechnoratiecae_100003.php" title="technorati解禁">著名<strong>RSS</strong>搜索引擎<strong>Technorati</strong>解禁</a>，<a target="_blank" href="http://blog.istef.info/2007/06/13/feedburner-will-be-add-into-google-account/"><strong>FeedBurner</strong>将于6月中旬并入<strong>Google Account</strong></a>，纷纷杂杂，好不热闹。

 [1]: http://blogsearch.google.com/
 [2]: http://news.google.com/
 [3]: http://technorati.com/
 [4]: http://del.icio.us/
 [5]: http://www.furl.net/
 [6]: http://www.flickr.com/
 [7]: http://msn.com/
 [8]: http://yahoo.com/
 [9]: http://news.yahoo.com/
 [10]: http://blogs.icerocket.com/
 [11]: http://feedster.com/
 [12]: http://topix.net/
 [13]: http://www.feedsfarm.com/
 [14]: http://newspad.prweb.com/
 [15]: http://www.search4rss.com/
 [16]: http://www.blogdigger.com/
 [17]: http://www.plazoo.com/
 [18]: http://www.newsnetplus.com/
 [19]: http://blogmarks.net/
 [20]: http://www.findarticles.com/
 [21]: http://wired.com/
 [22]: http://blogg.de/