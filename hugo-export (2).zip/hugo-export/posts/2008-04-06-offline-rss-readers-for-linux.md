---
title: Linux下三款离线RSS阅读器简介
author: Chouj
type: post
date: 2008-04-05T17:23:02+00:00
url: /2008/04/06/offline-rss-readers-for-linux/
views:
  - 1794
  - 1794
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969998
categories:
  - 工具
tags:
  - Linux
  - Reader

---
<img SRC="http://pic.yupoo.com/xcchris/9269555b1fcd/hmje19zh.jpg" ALT="liferea" BORDER="0" WIDTH="214" HEIGHT="43" />

主页 <a HREF="http://http://liferea.sourceforge.net/" TARGET="_blank" TITLE="Liferea">http://liferea.sourceforge.net/</a>

截图

<a HREF="http://pic.yupoo.com/xcchris/2262455b1fcd/nj46tnji.jpg" TARGET="_blank" TITLE="Liferea"><img SRC="http://pic.yupoo.com/xcchris/2262455b1fcd/small.jpg" ALT="Liferea" BORDER="0" WIDTH="240" HEIGHT="159" /></a>

<p ALIGN="center">
   ============================
</p>

<p ALIGN="center">
  <!--more-->
</p>

<img SRC="http://pic.yupoo.com/xcchris/1755655b1fcc/uxigesp3.jpg" BORDER="0" WIDTH="126" HEIGHT="35" />

主页 <a HREF="http://akregator.kde.org" TARGET="_blank" TITLE="akregator">http://akregator.kde.org </a>

截图

<a HREF="http://pic.yupoo.com/xcchris/2445355b1fcd/b99q1wk8.jpg" TARGET="_blank" TITLE="screenshot-"><img SRC="http://pic.yupoo.com/xcchris/2445355b1fcd/small.jpg" ALT="akregator" BORDER="0" WIDTH="240" HEIGHT="180" /></a>

<p ALIGN="center">
   ============================
</p>

<img ALT="RSSOwl" SRC="http://pic.yupoo.com/xcchris/1082555b1fcc/bxr1eoxg.jpg" />
  
主页 <a TITLE="RSSOwl" TARGET="_blank" HREF="http://www.rssowl.org">http://www.rssowl.org</a>

<p ALIGN="center">
  ============================
</p>

三款都是目前主流的linux下离线RSS阅读器，功能齐全。前两个在源里可以找到，也有ubuntu适用的deb包供下载，后一种没有deb包，所以我也没有安装，详细截图都可以到各主页查阅。