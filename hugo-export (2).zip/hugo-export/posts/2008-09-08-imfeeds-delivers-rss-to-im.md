---
title: IMFeeds.com:RSS信息的IM订阅
author: Chouj
type: post
date: 2008-09-08T14:39:18+00:00
url: /2008/09/08/imfeeds-delivers-rss-to-im/
views:
  - 1998
  - 1998
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970020
categories:
  - 工具
tags:
  - IM
  - IMFeeds
  - Subscribe

---
<img src="http://pic.yupoo.com/xcchris/66071628a4c0/hqhkxea7.jpg" alt="imfeeds.com 首页" width="468" height="270" />

很早前，我介绍过[实现信息推送至IM的Anothr][1]，这次介绍下功能一样的<a title="IM Feeds Beta - RSS feeds delivered via IM " href="http://imfeeds.com/" target="_blank">IMFeeds</a>。借助<a title="IM Feeds Beta - RSS feeds delivered via IM " href="http://imfeeds.com/" target="_blank">IMFeeds</a>，我们可以将RSS信息实时推送到AIM、MSN、Gtalk和Yahoo!四种IM上，将IM转化为订阅工具和阅读器，即时跟踪您关心的信息。

<!--more-->

步骤很简单，添加机器人，点击注册链接即可：

<img src="http://pic.yupoo.com/xcchris/96062628a4c1/buxuithl.jpg" alt="imfeeds step" width="468" height="340" />

和IM机器人对话，使用相应命令即可实现订阅功能：

> <img src="http://pic.yupoo.com/xcchris/80017628a2f8/rintd95z.jpg" alt="imfeeds subscribe" width="305" height="143" align="right" />help: 帮助菜单
  
> latest: 最近推送过来的10条信息
  
> feeds: 已订阅feeds条目列表
  
> lost: 重置账户密码
  
> sub/subscribe/+ <feed url>: 订阅feed
  
> unsub/unsubscribe/- <feed url>: 退订feed

推送过来的信息，包含标题、链接和Feed名：

<img src="http://pic.yupoo.com/xcchris/32447628a8f7/z3ib9ae0.jpg" alt="imfeeds message" width="457" height="169" />

想尝试的朋友，**<a title="IM Feeds Beta - Sign up" href="http://imfeeds.com/general/get_started" target="_blank">点击这里</a>**，开启IM订阅之旅吧！

 [1]: http://aboutrss.cn/2007/03/anothr/ "用IM订阅RSS 实现信息主动推送"