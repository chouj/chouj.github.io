---
title: 民主 乱象 轮回
author: Chouj
type: post
date: 2007-07-24T11:32:52+00:00
url: /2007/07/24/two-worth-reading-articles/
views:
  - 2155
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969694
categories:
  - 我思考
tags:
  - 忧
  - 思想
  - 民主
  - 猪
  - 轮回
  - 郎咸平
  - 鼠

---
<big><big>最</big></big>近存了两篇长文在Google Docs里，对于这样的文章我只说“值得看看”，因为文章如何需要读者自行定夺，但不论好坏都值得您定夺一番：

<big><a href="http://docs.google.com/Doc?id=dgn53rq3_21ffsgdb">什么是民主？ 作者不详</a></big>

<big><a href="http://docs.google.com/Doc?id=dgn53rq3_23fhm3v8">90年代中期的曲解造成今天的乱象——郞咸平7月15日多伦多演讲文字实录</a></big>

<big><big>未</big></big>来几十年，都将是由我们这一代面对，环境如何，机遇如何，不能不让我关心。主体怎么走，个体是去是留是予是夺，总得未雨绸缪。

[Yee][1]说：

> 十二属相里，鼠排在首位，猪排在末位。湖南是猫的故乡，老鼠却泛滥成灾，成为最贱之物；今年全国猪肉价格离奇大涨，猪成了稀缺、珍贵之物。从鼠到猪，正好一个轮回。头大尾小，说明要出头了，一个新的轮回要开始了。不要说我迷信，任何事物冥冥之中，自有安排，这不是自我安慰说成迷信就能解决得了的

<big><big>有</big></big>人扬名立万，也有人垫脚于历史的车轮之下，先不说个人成败，至少在轮回中，我们都需要对得起牵挂你的那颗心。

 [1]: http://fanfou.com/statuses/qj4TWdRjDqg