---
title: RSS相关祝您牛年大吉～！
author: Chouj
type: post
date: 2009-01-26T12:35:41+00:00
url: /2009/01/26/happy-ox-year/
views:
  - 1525
  - 1525
duoshuo_thread_id:
  - 1279764464521970036
categories:
  - 广告
  - 相关
tags:
  - 拜年

---
我要给两种人类拜年！一种是知道RSS的朋友，一种是不知道RSS的朋友！哈哈！

[<img class="aligncenter" title="digitalboy的油炸RSS icon" src="http://pic.yupoo.com/xcchris/447256e12086/erbatnge.jpg" alt="" width="468" />][1]

特此感谢老乡<a title="twitter:digital" href="http://twitter.com/digitalboy" target="_blank">digitalboy</a>密制的油炸RSS标志！

 [1]: http://www.flickr.com/photos/digitalboy100/3222586572/in/photostream/