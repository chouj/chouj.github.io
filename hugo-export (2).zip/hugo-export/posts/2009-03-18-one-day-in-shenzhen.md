---
title: '创意市集&Punch Party'
author: Chouj
type: post
date: 2009-03-18T05:00:37+00:00
url: /2009/03/18/one-day-in-shenzhen/
views:
  - 1994
duoshuo_thread_id:
  - 1279764464521969920
categories:
  - 我记录
tags:
  - PunchParty
  - 创意市集
  - 深圳

---
为避讳地缘近亲，襄樊学院都不招襄樊人了，你看，多元和交流是多么重要。所以，要多走走，就有了深圳一行，with<a title="挠挠" href="http://twitter.com/coffeenaonao" target="_blank">挠挠@twitter</a>。

@**动车组**

很和谐，凭票可领动车组特供西藏圣水。有些遗憾，跟在飞机上的时候一样，忘了参观厕所。陆姐比空姐出现次数少了许多。

@**东门**

胶着的繁华。广州的还挺宽，深圳的好挤，所以我能想像香港这弹丸地。油炸鸡软骨很贵。

@<a title="T街创意市集" href="http://www.douban.com/event/10142206/" target="_blank"><strong>创意市集</strong></a>

<img src="http://photo1.bababian.com/upload15/20090306/F4D09BE08FC99DCD010BF46B40C4898D_800.jpg" border="0" alt="" />

总是觉得想一个好玩的点子折腾些什么比想一个科研切入点要容易许多。



入手“雷人标语”公交卡贴，写着“我被社会活活得和谐了”，打算贴到饭卡上，免得羊城通上的one piece海贼旗下岗。

@<a title="Punch Party@Shenzhen" href="http://groups.google.com/group/punchpary" target="_blank"><strong>Punch Party<br /> </strong></a><a href="http://www.flickr.com/photos/zhimadoudou/sets/72157615307845622/" target="_blank">zhimadoudou&#8217;s photo@flickr</a> <a title="梁晓智 栋笃笑" href="http://www.tudou.com/programs/view/YDpZNDgSoDQ/" target="_blank">梁晓智-栋笃笑视频@tudou</a>

懒得看字的童鞋可以看以上的影像。

如果说创意市集对得起75一张的票价，那么PP就令我失望了。虽然线上的扯淡往往会勾引出线下的拓展，但这次拓展显然不大合乎我的想象。一句话，我看不到PunchParty的单纯。