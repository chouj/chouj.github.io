---
title: Fun for blog
author: Chouj
type: post
date: 2007-04-21T07:23:00+00:00
url: /2007/04/21/fun-for-blog/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/miniblog.html
views:
  - 1885
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969876
categories:
  - 我记录
tags:
  - blog

---
<a href="http://www.cnblog.org/imnotboke/" target="_blank"><img src="http://www.cnblog.org/imnotboke/imnotboke.gif" border="0" alt="" /></a>

“<span style="font-size:180%;">我</span>不是博客”的页面貌似抓瞎了：

> # Directory Listing Denied
> 
> This Virtual Directory does not allow contents to be listed.

<span style="font-size:180%;">曾</span>经看过不少blog上有这个标签，不过说实在的，这个运动让我想起小品里的一句话：“我们乡下人用卫生纸擦屁股了,城里人却用它擦嘴了……”

<span style="font-size:180%;">发</span>个关于blog的冷笑话：

> 说在一个QQ高级群里，有人问：
  
> “谁知道blog的？”
  
> 应者寥寥，又问：
  
> “谁知道Qzone？”
  
> “知道啊！”
  
> “浇花的地儿！”
  
> “天天浇花的地方啊！”
  
> “来我的Qzone浇花吧！”
  
> “……”
  
> 那人继续问：
  
> “为什么要浇花啊？”
  
> 群里半天没反应，过了阵子终于有人怯怯的回复了：
  
> “好让花开。”