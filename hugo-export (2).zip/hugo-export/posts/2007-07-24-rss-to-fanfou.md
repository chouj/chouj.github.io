---
title: FanfouFeed将RSS更新推送到饭否
author: Chouj
type: post
date: 2007-07-24T13:32:52+00:00
url: /2007/07/24/rss-to-fanfou/
views:
  - 1534
  - 1534
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969966
categories:
  - 工具
  - 新闻
tags:
  - Fanfou

---
[RSS2Twitter.com将即时更新的RSS信息发布到Twitter][1]，<strike>FanfouFeed.com</strike>则可以将Feed内更新的信息标题发布到<a href="http://fanfou.com" title="饭否" target="_blank">饭否</a>。

<img src="http://photo8.yupoo.com/20070724/204201_124846785_jdhtqowv.jpg" alt="fanfoufeed" class="Photo" height="273" width="460" />

其主页上介绍的使用需知有三：

  1. 有饭否帐号，即为饭否用户；
  2. 只可使用OpenID登录；
  3. 登录后台，添加或管理Feed和消息前缀。

发文时此服务用户仅21名，有blog的饭否用户可以尝试下，让信息传播得更远些吧 🙂

[<a href="http://fanfoufeed.com" title="fanfoufeed.com | RSS相关" target="_blank"><strike>点此进入</strike>（该站目前关闭中）</a>]

 [1]: http://aboutrss.cn/2007/03/28/rss-to-twitter/ "RSS与Twitter结合的新玩法"