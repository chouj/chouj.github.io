---
title: 双脚离地的感觉都那么久违
author: Chouj
type: post
date: -001-11-30T00:00:00+00:00
draft: true
url: /?p=383
btc_comment_counts:
  - 'a:0:{}'
categories:
  - 我表达
  - 我记录

---
每次写日志都很纠结，改了写，写了再改。我很想写得流畅，却发现连“久违”都不可能，因为几乎从没“流畅”过。还是多吃些蔬菜为妙。

  * Ubuntu 8.04 LTS

我在1号给旭日150换了个液晶后，就磨刀霍霍向Windows。终于在某天，格式化了C盘，成功做到了让瘟豆子无屁可插。