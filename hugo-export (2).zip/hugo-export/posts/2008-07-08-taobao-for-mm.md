---
title: 给MM淘宝的下场
author: Chouj
type: post
date: 2008-07-08T06:37:18+00:00
url: /2008/07/08/taobao-for-mm/
views:
  - 2167
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969901
categories:
  - 我记录
tags:
  - MM
  - 淘宝

---
在<a title="尚品嘉艺" href="http://shop34267081.taobao.com/" target="_blank">店里</a>给MM买东西，结果……

<img class="size-full wp-image-293" title="给MM淘宝的下场" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/taobao-for-mm.jpg" alt="给MM淘宝的下场" width="217" height="424" />

囧rz