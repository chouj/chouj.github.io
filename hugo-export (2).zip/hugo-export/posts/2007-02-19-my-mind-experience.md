---
title: 回顾2006：思想小花的翻转腾挪
author: Chouj
type: post
date: 2007-02-19T10:31:00+00:00
url: /2007/02/19/my-mind-experience/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/2006_19.html
views:
  - 1917
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969854
categories:
  - 我思考
tags:
  - 忧
  - 网络

---
<span style="font-size:180%;"><span style="font-weight: bold;">放</span></span>假没多久，撞见一期鲁豫有约，访问当红炸子鸡黄健翔。我记得他说过一句话：“男人四十一支花，我现在还是花骨朵儿呢。”所以说，像我这样儿的小花还基本没发芽呢，好在06 年借Internet让小脑袋瓜儿透了透气，见见世面。

<span style="font-size:180%;"><span style="font-weight: bold;">俗</span></span>话说的好，饱暖思淫欲，咱这都小康了，没事儿我就开始想些上层建筑上的事情。这不，今儿个又破了回<a href="http://zh.wikipedia.org/w/index.php?title=GFW&variant=zh-cn" target="_blank">GFW</a>，下了一组<a href="http://zh.wikipedia.org/w/index.php?title=%E5%85%AD%E5%9B%9B&variant=zh-cn" target="_blank">六四</a>的照片，看得一个心惊肉跳。自责啊，电视里胡core这儿慰问那儿关怀的，我竟在网上看些不着调的非和谐东西，该去把那没“猪”的春晚或者NBA全明星看个几遍作忏悔（后者好点儿）。

<span style="font-size:180%;"><span style="font-weight: bold;">言</span></span>归正转。06年前，我是一个不知八九、不知GFW、不管言论自不自由的乖孩子，跟我寝室里的其他同学一样，发展下去就是play with WOW、周杰伦、Rain、Scofield、苏菲马索，etc。可惜经高人点拨，我没能和谐下去。基于对未知事物的好奇，基于无知苟且的可怖，活明白点儿成了小小的追求。且不说有知却殉身历史的先烈，单无知而陪葬历史的百姓就无计其数，我只是想真到泯身历史中的那一天，我能选个自认为正确的死法。

<span style="font-size:180%;"><span style="font-weight: bold;">安</span></span>替的<a href="http://xcchris.googlepages.com/nn.txt" target="_blank">新新闻人自学手册</a>、<a href="http://www.fawjournal.com/" target="_blank">纵横</a>、吴思的《<a href="http://www.douban.com/subject/1050929/" target="_blank">隐蔽的秩序</a>》、李大同的两本<a href="http://www.douban.com/subject/1437900/" target="_blank">冰点</a><a href="http://www.douban.com/subject/1831600/" target="_blank">纪事</a>；龙应台、<a href="http://lianyeah.blog.com/" target="_blank">连岳</a>、<a href="http://www.wangxiaofeng.net/" target="_blank">王小峰</a>、<a href="http://www.sohoxiaobao.com/chinese/bbs/blog.asp?id=9213" target="_blank">钱烈宪</a>；BBC、德国之声；……一条不归路下来，这小花也算是晒着了不少个太阳（不管孰优孰劣，有点儿价值的一概先以太阳论之）。晒了归晒了，到底长成什么样儿了呢？

<span style="font-size:180%;"><span style="font-weight: bold;">先</span></span>罗列几个峰顶浪尖儿的问题。是

> 主权高于人权。
  
> 如果人民都不热爱自己的国家，国家何谈要保护其人民？
  
> 你这个人到底爱不爱国？
> 
> 少来超客观理想化，少来世界大同，别说你是国际主义者，世界永远和平之类的屁话，有些东西是人心中追求的，但这是现实社会，只要国家的概念不消失，国界不消失，国家间就会你争我夺，一国的公民就应该捍卫其国家利益！如果一个国家的子民，他们的爱国情绪已经不能被煽动被利用，是多么的让人难过！

还是

> 人权高于主权。
  
> 如果国家都不保护其人民，又从何要求其人民热爱这个国家？
  
> 你这个国家值不值得爱？
> 
> 不思考者只会成为棋子却不自知，理性对待是前提，不说理性下来能保持和平发展的局面，单不冲动，不向往暴力即可避免无辜的流血甚至历史的重演。“抵制日货”仅仅满足了民族情绪，其不但限制公民自由选择的权利，还对国家发展毫无益处！天天关注国际事务仇日仇韩仇老美，还不如想想办法保障民主自由，反腐反贪！

言论自由，畅所欲言是好事，但不同的观点摆太近了，也能把人忽悠晕。给出一篇<a href="http://docs.google.com/Doc?id=dgn53rq3_13cz4m3t" target="_blank">中国大陆酱缸里的真真假假左左右右</a>,以助理解。倒是不知各位看官如何看待如上的问题，期待能各抒己见，但，切莫PK。

<span style="font-size:180%;"><span style="font-weight: bold;">整</span></span>个06年，我就是在这观点与观点的碰撞中找寻自己的见解，惶且不论中国现在新闻、言论的不自由或虚假，难度可想而知。要命的是，发现自己属于墙头草，易受煽动蛊惑，甚至受制于生活中的小细节。拿拜年短信说事儿：基于拉拢人脉，套套近乎，短信该发；基于蔑视移动，看不惯逢个坎儿就要对人虚情假意一番，短信不该发。得，最后成礼尚往来了。

<span style="font-size:180%;"><span style="font-weight: bold;">不</span></span>管如何，小花儿还是要继续找他的太阳雨露，继续生长。环视四周，如我般稍稍瞥见<a href="http://zh.wikipedia.org/w/index.php?title=%E5%85%AD%E5%9B%9B&variant=zh-cn" target="_blank">六四</a>端倪的同龄小花已经少之又少了，丫们大多不向往太阳而向往李宇啊那个春。本小花又有幸结识几朵新闻学院的小花，钦佩其新闻编造能力的同时，也耳闻过某为拍到未成年人购烟而给小孩儿钱令其买烟的新闻制造先例，故也不对祖国的新闻事业抱有信心。这在污泥之中，虽不大能出污泥，但如何选对“稍稍有知”的方向仍是以后要摸索的。

<span style="font-size:180%;"><span style="font-weight: bold;">连</span></span>岳说过，求知不是为了求职，而求职是为了保障更好的求知。即便“知”有风险，但“知”总比“不知”强。