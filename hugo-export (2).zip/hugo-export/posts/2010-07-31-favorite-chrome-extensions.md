---
title: 我所用的10+Chrome扩展
author: Chouj
type: post
date: 2010-07-31T09:41:34+00:00
excerpt: 我所使用的Chrome浏览器扩展，推荐这些给大家，希望大家择你所好，量力而为。共13个。
url: /2010/07/31/favorite-chrome-extensions/
views:
  - 3962
duoshuo_thread_id:
  - 1279764464521970055
categories:
  - 我尝试
tags:
  - Chrome
  - 扩展

---
<a title="Google Chrome Extensions" href="https://chrome.google.com/extensions" target="_self"><img src="https://www.google.com/intl/en/images/logos/chrome_extensions_logo.gif" border="0" alt="Chrome Extensions" /></a>

点击图片链接进入扩展页面（若图片无法显示，请进入扩展页面后再刷新本页）：

 <img src="https://addons.mozilla.org/en-US/firefox/images/addon_icon/173/1275608192" border="0" alt="" /><span style="font-size: 14.4px;">Google Mail Checker <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<a style="color: #0000cc;" title="点击进入Google Mail Checker" href="https://chrome.google.com/extensions/detail/mihcahmgecmbnbcchbopgniflfhgnkff"><img style="width: 243px; height: 170px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/mihcahmgecmbnbcchbopgniflfhgnkff/1276209361.53/screenshot/1" alt="Google Mail Checker" /></a>

不多说了，查Gmail的

<span style="font-size: 14.4px;"><img src="https://addons.mozilla.org/en-US/firefox/images/addon_icon/3615/1279229372" border="0" alt="" /> <span style="font-size: 14.4px;">Delicious BookMarks Extension(Beta) <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com//reviews/images/small_star_half-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_empty-f3f7fc.gif" alt="" /></span></span>

[<img style="width: 396px; height: 342px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/lnejbeiilmbliffhdepeobjemekgdnok/1279828762.34/screenshot/1" alt="Delicious BookMarks Extension(Beta)" />][1]

美味书签的官方扩展。delicious的扩展蛮多的，不乏优秀扩展。我用的是官方的。

<!--more-->

<img src="http://code.google.com/p/chrowety/logo?cct=1278300115" alt="Chrowety" width="30" /><span style="font-size: 14.4px;">Chrowety </span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /></span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<span style="font-size: 14.4px;"><a style="color: #0000cc;" href="https://chrome.google.com/extensions/detail/ffcbeckjmgmgigkmnhmgjplmomcpfall"><img style="width: 263px; height: 342px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/ffcbeckjmgmgigkmnhmgjplmomcpfall/1279748276.49/screenshot/3002" alt="点击进入Chrowety" /></a></span>

挑了好久Chrome下的Twitter扩展，想寻求Firefox上Echofon的效果，终于还是用了Chrowety。可自定义API，字体大小，更新间隔什么的，也比较顺眼。

 ![][2]Hover Zoom <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" />

<a style="color: #0000cc;" title="点击进入Hover Zoom" href="https://chrome.google.com/extensions/detail/nonjdcjchghhkdoolnlbekcfllmednbl"><img style="width: 400px; height: 319px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/nonjdcjchghhkdoolnlbekcfllmednbl/1280397147.92/screenshot/4001?hl=en-US" alt="Hover Zoom" /></a>

鼠标悬停在网页缩略图上即可预览全尺寸大图，很方便实用。

 <img src="http://image.chromefans.org/i100/id113/pagerank-status.png" alt="" width="30" />PageRank Status <span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /></span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<a style="color: #0000cc;" title="点击进入PageRank Status" href="https://chrome.google.com/extensions/detail/hbdkkfheckcdppiaiabobmennhijkknn"><img style="width: 410px; height: 308px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/hbdkkfheckcdppiaiabobmennhijkknn/1269946668.05/screenshot/1001?hl=en" alt="PageRank Status" /></a>

很方便的显示网页评级的扩展，也可以显示Alexa排名，另外，可以查询一些SEO指标，比如收录数、反链数等。

 ![][3]下载助手(由Google提供) <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_empty-f3f7fc.gif" alt="" />

<a style="color: #0000cc;" title="点击进入Download Helper" href="https://chrome.google.com/extensions/detail/mfjkgbjaikamkkojmakjclmkianficch"><img style="width: 410px; height: 295px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/mfjkgbjaikamkkojmakjclmkianficch/1279680365.24/screenshot/1?hl=en" alt="Download Helper" /></a>

<a style="color: #0000cc;" title="点击进入Download Helper" href="https://chrome.google.com/extensions/detail/mfjkgbjaikamkkojmakjclmkianficch?hl=en"></a>
  
点击该插件即可调用FlashGet或Xunlei下载页面中的元素，只支持Windows。

 ![][4]中国天气预报与万年历 <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" />

<a style="color: #0000cc;" title="点击进入中国天气预报与万年历" href="https://chrome.google.com/extensions/detail/chllelencipbhdcelplgadmefkopmpgd"><img style="width: 410px; height: 173px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/chllelencipbhdcelplgadmefkopmpgd/1278237731.09/screenshot/5001" alt="中国天气预报与万年历" /></a>

可定制性很高的天气显示插件，虽然真正用到的频率不高。可显示当前天气温度、也可显示预报的天气和温度，是否显示万年历也可设置。数据来源于中国天气网。

 <img src="https://addons.mozilla.org/en-US/firefox/images/addon_icon/162178/1280528567" border="0" alt="" />人人网改造器 <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" />

<a style="color: #0000cc;" title="点击进入人人网改造器" href="https://chrome.google.com/extensions/detail/bafellppfmjodafekndapfceggodmkfc"><img style="width: 410px; height: 245px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/bafellppfmjodafekndapfceggodmkfc/1280564165.08/screenshot/1001" alt="人人网改造器" /></a>

这个太强大了，功能一言两语说不清楚，总之就是能大幅改造人人网的界面，削掉广告什么的。具体还是去其页面上看吧，十分适合有洁癖的反感花哨的童鞋。

 ![][5]分享家:addthis中文版 <img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" />

<a style="color: #0000cc;" title="点击进入分享家Addthis" href="https://chrome.google.com/extensions/detail/ooemehnijdacefdfdlccnelgcnaeonpb/"><img style="width: 410px; height: 205px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/ooemehnijdacefdfdlccnelgcnaeonpb/1276481626.86/screenshot/1" alt="分享家Addthis" /></a>

有了<a title="分享家" href="http://addthis.org.cn/" target="_self">分享家</a>，不用再在书签栏搞一排分享小书签了，<a title="分享家" href="http://addthis.org.cn/" target="_self">分享家</a>全的很。

 ![][6]网络硬盘文件搜索引擎 <span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /></span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<a style="color: #0000cc;" title="点击进入网络硬盘文件搜索引擎" href="https://chrome.google.com/extensions/detail/egeapepfahdapfkbdkmiiogjoccjiann"><img style="width: 406px; height: 142px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/egeapepfahdapfkbdkmiiogjoccjiann/1279682683.52/screenshot/1001" alt="" /></a>

官方介绍：“目前网上有大量提供网络硬盘存储功能的网站，而在这些网站存储的文件无法较好的进行检索。此插件提供方便快捷的搜索网络硬盘文件的方法，涵盖27个主要的网络硬盘提供网站，例如：纳米盘、飞速网、魔方网等等。可搜索下载各类网友共享的文档、视频、压缩包，例如：考研秘籍、激荡三十年、XX门视频下载、搜索引擎优化完全手册。。。” 其邪恶意义不言自明。。。嗤。。嗤。。嗤。。

 ![][7]网页截图(由Google提供) <span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /></span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<a style="color: #0000cc;" title="点击进入网页截图" href="https://chrome.google.com/extensions/detail/cpngackimfmofbokmjmljamhdncknpmg"><img style="width: 410px; height: 295px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/cpngackimfmofbokmjmljamhdncknpmg/1280311920.4/screenshot/1001" alt="网页截图" /></a>

截取网页为图片，支持窗口截图，区域截图和整个网页截图三种方式。截图的扩展有很多，似乎某个叫“[截图快手][8]“的扩展也很牛掰。

 ![][9]RSS Subscription Extension（由 Google 提供）<span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /></span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<a style="color: #0000cc;" title="点击进入RSS Subscription Extension" href="https://chrome.google.com/extensions/detail/nlbjncdgjeocebhnmkbbbdekmmmcbfjd"><img style="width: 410px; height: 154px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/nlbjncdgjeocebhnmkbbbdekmmmcbfjd/1279719888.7/screenshot/3001" alt="RSS Subscription Extension" /></a>

不能识别页面是否包含RSS Feed地址是很恼火的，这个插件就是解决这个问题的。

 ![][10]IE Tab <span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /></span><span style="font-size: 14.4px;"><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_full-f3f7fc.gif" alt="" /><img style="width: 10px; height: 9px; display: inline; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/reviews/images/small_star_half-f3f7fc.gif" alt="" /></span>

<a style="color: #0000cc;" title="点击进入IE Tab" href="https://chrome.google.com/extensions/detail/hehijbfgiekmjfkfjpbkbammjbdenadd"><img style="width: 387px; height: 342px; padding: 0px; margin: 0px; border: 0px initial initial;" src="https://chrome.google.com/extensions/img/hehijbfgiekmjfkfjpbkbammjbdenadd/1272650587.09/screenshot/5001" alt="IE Tab" /></a>

实现IE和Chrome标签页切换的，没办法，有时候还是少不了IE。

**WARNING**:插件能丰富浏览器的功能，但绝对不是越多越好。Chrome每个标签页都在独立沙盒下运行，有单个的进程；插件也是单个的进程。所以页面开多了，插件装多了，容易造成Chrome的不稳定。

这些插件我都在用，1.5G内存下全部启用再开七八个页面尚可，但真的会卡了。推荐给大家，但一定要择你所好，量力而为。你有什么好的扩展也欢迎留言推荐！ 🙂

 [1]: https://chrome.google.com/extensions/detail/lnejbeiilmbliffhdepeobjemekgdnok "点击进入Delicious Bookmarks Extension (Beta)"
 [2]: https://addons.mozilla.org/en-US/firefox/images/addon_icon/6118/1275610402
 [3]: https://addons.mozilla.org/en-US/firefox/images/addon_icon/11243/1275608167
 [4]: http://www.mconline.com.au/images/weather.gif
 [5]: http://addthis.org.cn/images/logo16b.gif
 [6]: http://www.yuqiaotech.com/images/netdisk.jpg
 [7]: http://www.iemate.com/img/cutpic.gif
 [8]: https://chrome.google.com/extensions/detail/alelhddbbhepgpmgidjdcjakblofbmce
 [9]: https://addons.mozilla.org/en-US/firefox/images/addon_icon/4869/1280568130
 [10]: https://addons.mozilla.org/en-US/firefox/images/addon_icon/92382/1275608158