---
title: 音乐一隅 2006.8
author: Chouj
type: post
date: 2006-08-14T02:55:00+00:00
url: /2006/08/14/music-corner-2/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/20068.html
views:
  - 1814
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969792
categories:
  - 我表达
tags:
  - 自然卷
  - 音乐

---
<p align="center">
  <a href="http://www.douban.com/subject/1468214/" target="_blank"><img src="http://otho.douban.com/lpic/s2401377.jpg" border="0" alt="大卷包小卷" align="absmiddle" /></a>
</p>

<p align="left">
  <span style="font-size:85%;">专辑名称 ：大卷包小卷</span>
</p>

<span style="font-size:85%;">艺人姓名 ：</span>[<span style="font-size:85%;">自然卷</span>][1]

<span style="font-size:85%;">发行公司 ：风和日丽</span>

<span style="font-size:85%;">发行日期 ：2005年12月24日</span>

<span style="font-size:85%;">演唱语种 ：国语</span>

 <span style="font-size:85%;">被一blog的背景音乐吸引了，很轻灵的那种，也很小女生，当时放的是《答应要》。仔细查来，是自然卷的作品，完全陌生无名的乐团，对我来说。</span>

<p align="left">
  <span style="font-size:85%;"> down了7、8首反复听。女声很俏皮，生活气息浓郁，风格很有台北大都市下草根一族的感觉。也看见有人把他们的歌当儿童节歌曲推荐的，所以是有点幼稚和小女生的感觉的。</span>
</p>

<p align="left">
  <span style="font-size:85%;"> 随心所欲，朴实无华，正如这几张图。</span>
</p>

<p align="left">
  <span style="font-size:85%;"> 娃娃和奇哥打造了如此与众不同的两张专辑，但自然卷还是解散了。推荐几首我觉得不错的：<span style="color: #ff9900;">答应要、修鞋的阿伯、天气晴、How much</span></span>
</p>

 [1]: http://www.haoting.com/special/msp_2833.htm