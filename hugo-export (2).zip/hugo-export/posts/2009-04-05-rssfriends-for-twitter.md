---
title: RSSFriends：实现Twitter (un)followers的变化跟踪
author: Chouj
type: post
date: 2009-04-05T08:34:05+00:00
url: /2009/04/05/rssfriends-for-twitter/
views:
  - 1699
  - 1699
duoshuo_thread_id:
  - 1279764464521970040
categories:
  - 工具
tags:
  - RSSfriends
  - twitter

---
<img style="float: left; margin-left: 10px; margin-right: 10px;" src="http://s3.amazonaws.com/twitter_production/profile_images/109485517/RSSFriends_Logo_bigger.png" border="0" alt="RSSFriends" />Twitter是微博客的鼻祖，支持输出用户Tweets的RSS Feed，但有三种变化是不输出RSS的：follow我的朋友，我follow的朋友，以及我所喜爱(Favorited)的Tweets。如果想让这三个玩意儿也能被订阅，就得靠<a title="RSSFriends" href="http://www.rssfriends.com" target="_blank">RSSFriends</a>啦！

只要提交你在Twitter的用户名即可：

<img src="http://pic.yupoo.com/xcchris/9266673bddef/n03ggzsz.jpg" border="0" alt="RSSFriends" />

<!--more-->

点击Create  RSS，得到RSS地址：

<img src="http://pic.yupoo.com/xcchris/9281973bddf1/m2q6q97b.jpg" border="0" alt="RSSFriends" />

把这些订阅到阅读器里就可以实现追踪啦~所生成的条目信息很详细的，包括该用户updates数、最近一条Tweets、发布的方式等等：

<img src="http://pic.yupoo.com/xcchris/4506173be09d/hvr8jrit.jpg" border="0" alt="RSSFriends" />

[ <a title="RSSFriends" href="http://www.rssfriends.com" target="_blank"><strong>点此进入RSSFriends</strong></a> ]