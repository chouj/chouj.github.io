---
title: 8荣8耻英文版
author: Chouj
type: post
date: 2006-09-14T00:48:00+00:00
url: /2006/09/14/english-edition-for-8r8c/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/88.html
views:
  - 1681
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969807
categories:
  - 我记录
tags:
  - 图片

---
<a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_20069721322843.jpg" target="_blank"><img style="BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; WIDTH: 400px; HEIGHT: 300px; BORDER-RIGHT-WIDTH: 0px" src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_20069721322843.jpg" alt="" /></a>

点击上图看大图