---
title: 念及Google Blogger的境遇
author: Chouj
type: post
date: 2007-07-08T09:14:00+00:00
url: /2007/07/08/think-of-google-blogger/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/07/google-blogger.html
views:
  - 1709
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969887
categories:
  - 我表达
tags:
  - blog
  - Google Blogger

---
<span style="font-size:180%;">时</span>光恍惚，GFW作祟之后，我这161篇距160篇就差了一个半月多。饭否上，无意间[房房][1]提到[要坚持][2]，不然怕是会隔得更加久远。

<span style="font-size:180%;">GFW</span>依然强势得挺立着，不知道会不会腿毛飘飘。其脚下俨然是整个大陆Blogger圈的残迹，遗址尚且存有保护价值，咱这个圈儿怕是没有这好的命。忽然想起，《九品芝麻官》里的黄一飞演的[小县官][3]，都能毒尸灭迹，宁杀勿漏，何况威风凛凛的GFW，怕是即便出一个吵架之王包龙兴也没法奈他怎样。

<span style="font-size:180%;">非</span>议之下，自有能人志士讨伐之。比如这个尚“健在”的站（已经不健在了。）：
  
[
  
Www.letusstickupourmiddlefingertothegreatfirewallofchina.org.cn][4]

“Let us stick up our middle finger to the great firewall of china ！”就是该站的深情的呼唤，随机刷新出手势“凸”的图片，表达对GFW的不满。站长是这么解释的：

> 对于政治还有某些与生理需求相关的站被你(们)XX那就不提了,可现在这样的局面相信让很多人都很疑惑吧,太和谐点,好像&#8230;
> 
> 现在,别吝啬,对<span class="red">G F W</span> ,伸出你的中指吧!!

<span style="font-size:180%;">政</span>治还有某些与生理需求相关的站比如[这里][5]和[这里][6]（少儿不宜），倒还都是基于Blogger的，但，无可奈何，我还是得继续缅怀之，追忆几个月前大陆Blogger圈儿那看似远去的红红火火。

 [1]: http://fqch.blogspot.com/
 [2]: http://fanfou.com/statuses/2MTl5i52AnY
 [3]: http://www.baguaren.com/post/98.html
 [4]: http://www.blogger.com/Www.letusstickupourmiddlefingertothegreatfirewallofchina.org.cn
 [5]: http://chinaweeks.blogspot.com/
 [6]: http://bodily-beauty.blogspot.com/