---
title: 我看过的blogger hack站点
author: Chouj
type: post
date: 2007-02-22T10:16:00+00:00
url: /2007/02/22/google-blogger-hack-blogs/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/blogger-hack.html
views:
  - 3085
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969855
categories:
  - 我表达
tags:
  - blog
  - Blogger
  - Google

---
<span style="font-size:180%;"><span style="font-weight: bold;">G</span></span>oogle Blogger的自由度有目共睹，templates、hacks层出不穷。这里摆弄至今，看过不少写blogger代码技巧的站，受益匪浅。赶上最近有朋友问到，罗列几个，都是中文的，想必对以Google Blogger作为BSP开博客的用户有很大帮助。

<span style="color: #ff6600;">简体站点：</span>

  * <a style="font-weight: bold;" href="http://sunr.blogspot.com/search/label/Blogger" target="_blank">色彩斑斓——http://sunr.blogspot.com/</a>

我最早参考的站点之一，山东咖啡鱼的博客。一开始还看过[博之道][1],但现在没开放了。

  * <span style="font-weight: bold;"><a href="http://ggpi.blogspot.com/" target="_blank">GG派——http://ggpi.blogspot.com/</a></span>

同样不错的站点。GG＝GooGLe。GG和咖啡鱼现在在共同打造[中文blogger导航][2],关于中文blogger推荐。

<ul style="font-weight: bold;">
  <li>
    <a href="http://dugangs.blogspot.com/search/label/%E5%8D%9A%E5%AE%A2%E6%8A%80%E5%B7%A7">Chinese Blogger </a><a href="http://dugangs.blogspot.com/search/label/%E5%8D%9A%E5%AE%A2%E6%8A%80%E5%B7%A7" target="_blank">禾草唐楷</a><a href="http://dugangs.blogspot.com/search/label/%E5%8D%9A%E5%AE%A2%E6%8A%80%E5%B7%A7">——http://dugangs.blogspot.com/</a>
  </li>
</ul>

这个站太漂亮了，推荐浏览，不过是不久前才经由豆瓣看到的，先感谢博主把我这里加入他的博客亲友团。这里技巧教程贴也很多，值得大家共同学习。

  * <a style="font-weight: bold;" href="http://bloooooooogger-beta.blogspot.com/search/label/beta%E6%8A%80%E5%B7%A7" target="_blank">八个圈圈儿的Blogger-Beta——http://bloooooooogger-beta.blogspot.com/</a>

这里的技术贴写的比较通俗，适合初次接触代码hack的朋友。

<span style="color: #ff6600;">繁体站点，博主均来自宝岛台湾：</span>

  * <a style="font-weight: bold;" href="http://klcintw4.blogspot.com/search/label/Beta%20Hacks" target="_blank">良人的大秘宝——http://klcintw4.blogspot.com/</a>

国良先生在早些时候写过一些hack贴，现在写的少了，也是我很早参考过的站。该站左侧栏就有beta hacks组项。

  * <a href="http://joshnote.blogspot.com/search/label/Hacks" target="_blank"><span style="font-weight: bold;">Josh&#8217;s Note——http://joshnote.blogspot.com/</span></a>

很专业的站，除了常用hacks外，还有Blogger相关技术内容。

  * <a href="http://ibenjamin.blogspot.com/search/label/New%20Blogger" target="_blank"><span style="font-weight: bold;">Ben&#8217;s部落不及格——http://ibenjamin.blogspot.com/</span></a>

这个站非常精美，推荐一看，即便是hack，文章也写的比较逗趣。

<li style="font-weight: bold;">
  <a href="http://racklin.blogspot.com/search/label/Blogger" target="_blank"><span style="font-size:100%;">Racklin&#8217;s 阿土伯程式大觀園——http://racklin.blogspot.com/</span></a>
</li>

又一个专业级的，看起来比Josh&#8217;s Note还专业，别吓着了:)

<li style="font-weight: bold;">
  <a href="http://chenkaie.blogspot.com/search/label/blogger%20hack" target="_blank">Kaie&#8217;s Blog——http://chenkaie.blogspot.com/</a>
</li>

又一个漂亮的站，技巧也挺实用。高人手下，blogger就可以变得很精美。

<span style="font-size:100%;"><span>也许有更好的站我没浏览到，但仅</span></span>仅这些，对于新人修饰blogger已经绰绰有余了，真正的高人，还请参详国外的站点。

<span style="color: #ff0000;">Update：</span>刚看到 <span class="secttl"><a href="http://groups.google.com/group/ggpi/web/hack" target="_blank">博客hack扩展大全wiki by GG派</a> ，太赞了！</span>

<span style="font-size: 180%; color: #999999;"><span style="font-weight: bold;">最</span></span><span style="color: #999999;">后发点儿牢骚，因为不值得再开一贴，见谅。</span>

<span style="font-size: 180%; color: #999999;"><span style="font-weight: bold;">又</span></span><span style="color: #999999;">有人把“</span><a style="color: #999999;" href="http://www.douban.com/subject/1768351/" target="_blank">死亡笔记真人电影版</a><span style="color: #999999;">”和“推荐”绑一起传达给我，让我分外不爽。两个帅哥以那么多人的生命为代价争酷斗狠，其中之一起初还算伸张正义，后来变成为了斗智而杀人，这都宣扬的什么价值观念啊？酷和帅就可以遮蔽一切？要我说，这本子的作者属于那种——套用一时髦歇后语，</span><a style="color: #999999;" href="http://www.douban.com/subject/1876781/" target="_blank">越狱</a><span style="color: #999999;">里的手机男Kim——找抽型。还有就是决定把这么一明显适合动画题材的故事翻拍成真人电影的那家伙，就算后来兜里进了不少银子，丫脑袋里估计也进了不少水。还是豆瓣上第一条影评定性的好：反映资本主义腐朽堕落空洞无聊精神世界的片子。</span>

<span style="color: #999999;"><span style="font-weight: bold;font-size:180%;">另</span>外，各位女同胞们，你们爱看帅哥，爱到不论他们是对是错，这样的心情我能理解。但向别人推荐的时候能不能考虑下别人的性别？怎么说要推荐的也得是佳丽三千的后宫动画吧（算了，想想也知道你们不会津津乐道这种题材）？要是以将此片推荐给我，来测试本人的sex取向，那我再套用一句</span><a style="color: #999999;" href="http://www.douban.com/subject/1837856/" target="_blank">Heroes</a><span style="color: #999999;">里的名言，不过得多个单词：I&#8217;m NOT special !</span>

 [1]: http://bhic.blogspot.com/
 [2]: http://showr.blogspot.com/