---
title: Feedburner:Adsense for feeds下周试运行
author: Chouj
type: post
date: 2008-05-31T08:10:48+00:00
url: /2008/05/31/feedburner-partially-launch-adsense-for-feeds/
views:
  - 1679
  - 1679
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970005
categories:
  - 广告
  - 新闻
tags:
  - Feedburner
  - feedsky
  - Google
  - Google Adsense
  - RSS Marketing

---
[<img style="margin: 0pt 0pt 10px 10px; float: right;" src="http://bp1.blogger.com/_S_50sh4glvU/RrU0GQep7fI/AAAAAAAAAJA/kIITPv2Vz6o/s320/FB.gif" border="0" alt="Feedburner logo" />][1]30日，FeedBurner官方blog发布了一篇日志：<a title="Into the wild:Adsense for feeds-FeedBurner" href="http://blogs.feedburner.com/feedburner/archives/2008/05/into_the_wild_adsense_for_feed_1.php" target="_blank">Into the wild:Adsense for feeds</a>，宣称Feedburner将于下周在部分用户中试行Adsense for feeds！

Google购入FeedBurner后，这最重要的整合终于到来了，意味着同时发布GGAD并使用FeedBurner烧制Feed的博客主将可直接利用Google Adsense将广告投放于feed中。

文中也强调，目前只是该服务的测试阶段，相应详细操作和要求等等事宜都还只能等到正式发布时获知。不过，这仍然值得广大bloggers翘首期待，毕竟Google & Feedburner强强联合所推出的Adsense for feeds将成为RSS Feed广告营销中重要的一环。广告主们多了一个新的发布平台，博客主则多了一个新的获利渠道。

此举一出，我比较关心两个问题：

一是，**Feedsky会如何应对**。Feedsky话题广告和展示广告运营尚不足一年，但已经成为bloggers网赚的一大途径。细看之下，Feedsky话题广告更加受宠，每每被一抢而空，而feed展示广告似乎营养不良。在本地化方面，Feedsky和谷歌似乎拉不开差距；而在广告精准投放方面，借助blog分类的Feedsky肯定无法和Google Adsense相抗衡。此类局面下，Feedsky是否会走与Google不同的路，避Google之锋芒，即主营话题广告，以bloggers间的口碑效应为广告价值所在，值得拭目以待。

二是，**Feed广告是会造成阅读体验的下降，还是会成为readers喜见的广告形式**。RSS Feed搭载广告的模式势必如洪流般不可阻挡，再加上，如果FeedBurner和Feedsky的广告可在一个feed内共存，那么可以想象feed中广告面积将增大不少。这会不会造成读者为提高阅读体验而倾向于订阅无广告feed呢？

暂时想到这么多，欢迎探讨。要是阿里妈妈和淘宝也摻乎进来，针对blog post关键字在feed里挂店铺链接的话，是不是效果更好呢？XD&#8230;

 [1]: http://bp1.blogger.com/_S_50sh4glvU/RrU0GQep7fI/AAAAAAAAAJA/kIITPv2Vz6o/s1600-h/FB.gif