---
title: RSS相关一周年数据统计
author: Chouj
type: post
date: 2008-04-18T03:39:03+00:00
url: /2008/04/18/aboutrss-anniversary/
views:
  - 27523
  - 27523
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969733
categories:
  - 相关
tags:
  - Anniversary
  - Statistic

---
<img src="http://www.xuchi.name/2.png" alt="RSS相关" height="66" width="314" />

RSS相关一周年矣。这一年数据统计：

**日志68 篇
  
评论320 条
  
ip访问量25000+
  
订阅量700+
  
PR=3**

### 10 hottest posts

  1. [[翻译]10个用于合并RSS Feeds的工具][1]{#r_l_23}
  2. [帕兰整理的RSS Feed图标大集合][2]{#r_l_24}
  3. [为什么要用线上RSS阅读器？][3]{#r_l_25}
  4. [[WP插件]My Feed Stats介绍][4]
  5. [[草莓版]十月汇集：订阅数风波迭起，挑战赛拼搏到底][5]
  6. [[WP插件]BetterFeed使用指南][6]
  7. [学术领域的RSS应用][7]{#r_l_26}
  8. [[WP插件]©Feed指南及其汉化版][8]
  9. [TagMindr：Remember the future][9]
 10. [又有RSS标志设计出炉][10]

### 10 most commented posts

  1. <span>17</span> [[翻译]为什么要用Feedburner的十大理由][11]
  2. <span>16</span> [[WP插件]©Feed指南及其汉化版][8]
  3. <span>15</span> [为什么要用线上RSS阅读器？][3]
  4. <span>11</span> [[草莓版]七月汇集：共享与广告 竞争与生存][12]
  5. <span>11</span> [[WP插件]BetterFeed使用指南][6]
  6. <span>9</span> [[翻译]为什么我的FeedBurner订阅数会上下振荡呢？][13]
  7. <span>9</span> [我使用的Feed类WordPress插件][14]
  8. <span>8</span> [feeds.Feedburner.com二级域名访问失效？][15]
  9. 8 [[草莓版]十月汇集：订阅数风波迭起，挑战赛拼搏到底][5]
 10. 8 [又有RSS标志设计出炉][10]

一时心动开了这个blog，没想到一年后交出的答卷还成。其间有努力，有懈怠，被赞赏过，估计也让大家失望过；但不管怎么说，很高兴自己能做点事情，也很高兴借此认识了不少朋友。不敢说以后会做的更好，但我会一直在这里。:)

 [1]: http://aboutrss.cn/2008/02/16/translation-10-tools-for-blending-feeds/
 [2]: http://aboutrss.cn/2008/02/12/rss-icon-from-parandroid/
 [3]: http://aboutrss.cn/2007/11/10/why-do-we-need-rss-reader/
 [4]: http://aboutrss.cn/2008/02/10/my-feed-stats/
 [5]: http://aboutrss.cn/2007/11/05/articles-about-rss-in-october/
 [6]: http://aboutrss.cn/2007/10/25/wordpress-plugin-betterfeed/
 [7]: http://aboutrss.cn/2008/03/05/rss-apply-for-academic/
 [8]: http://aboutrss.cn/2007/10/17/wordpress-plugin-copyfeed/
 [9]: http://aboutrss.cn/2007/10/12/tagmindr-remember-the-future/
 [10]: http://aboutrss.cn/2007/10/08/new-styles-of-rss-icons/
 [11]: http://aboutrss.cn/2007/09/02/10-reasons-why-you-should-choose-feedburner/
 [12]: http://aboutrss.cn/2007/07/31/what-happened-in-july/
 [13]: http://aboutrss.cn/2007/08/18/translation-why-feedburner-subscriber-count-fluctuate/
 [14]: http://aboutrss.cn/2007/09/18/wordpress-plugins-used-for-feed/
 [15]: http://aboutrss.cn/2007/08/29/is-feeds-dot-feedburner-gfwed/