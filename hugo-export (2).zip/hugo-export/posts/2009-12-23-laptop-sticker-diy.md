---
title: 自制笔记本小贴纸
author: Chouj
type: post
date: 2009-12-23T09:28:00+00:00
url: /2009/12/23/laptop-sticker-diy/
views:
  - 2869
duoshuo_thread_id:
  - 1279764464521969928
categories:
  - 我尝试
tags:
  - DIY
  - 小贴纸
  - 笔记本

---
<img src="http://farm4.static.flickr.com/3071/3037182759_b7afbdf499.jpg" border="0" alt="@shizhao老师的笔记本儿" />

( <a title="cool notebook at CNBloggerCon 2008" href="http://www.flickr.com/photos/elliottng/3037182759/" target="_blank">via</a> )

最近迷恋于laptop stickers，梦想折腾成题图<a title="@shizhao" href="https://twitter.com/shizhao" target="_blank">@shizhao</a>老师的那样。本来希冀于从网上买，但被推友驳回，说还不如自己做。OK，我就自己做吧。

<!--more-->

材料：

<img src="http://farm5.static.flickr.com/4046/4205566349_9e4fb677cf.jpg" border="0" alt="laptop stickers 模版一张" />
  
自制 laptop stickers 模版一张 [download id=&#8221;2&#8243;]
  
规格：A4 RGB 300dpi

亚光不干胶打印纸
  
购于广州岗顶百脑汇 7元50张

激光彩打机
  
寻于中山大学内，2元打印一张

效果（用BlackBerry 8310拍摄）：

<http://twitgoo.com/a84z9>
  
<http://twitgoo.com/a84zd>
  
<http://twitgoo.com/a851x>

感想：

  1. 和<a title="@shizhao" href="https://twitter.com/shizhao" target="_blank">@shizhao</a>老师的比起来，我印的偏小，不够大气。
  2. 欢迎大家推荐更多好玩，更geeky的logo。