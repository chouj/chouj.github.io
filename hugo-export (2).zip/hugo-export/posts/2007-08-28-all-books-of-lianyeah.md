---
title: 莲藕们的圣物：连岳全集
author: Chouj
type: post
date: 2007-08-28T03:20:21+00:00
url: /2007/08/28/all-books-of-lianyeah/
views:
  - 2771
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969705
categories:
  - 我记录
tags:
  - photo
  - 读书
  - 连岳

---
<p align="center">
  <img width="400" src="http://photo11.yupoo.com/20070828/110939_556325173_cpyglyya.jpg" alt="连岳的书们" height="368" style="width: 400px; height: 368px" title="连岳的书们" />
</p>

连岳粉丝们，顶礼膜拜吧！

**注**：照片来源于<a target="_blank" href="http://moredeep.org/blog/2007/08/blog-post_07.html" title="全集当然是有快感的">网络</a>，摄于8月7日下午4点47分。