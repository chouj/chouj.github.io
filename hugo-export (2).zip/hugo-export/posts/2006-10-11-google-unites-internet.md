---
title: Google一统江湖
author: Chouj
type: post
date: 2006-10-11T02:56:00+00:00
url: /2006/10/11/google-unites-internet/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/10/google.html
views:
  - 1963
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969819
categories:
  - 我思考
  - 我表达
tags:
  - Google
  - 图片
  - 网络

---
<img src="http://photos1.blogger.com/blogger2/4366/415671023967385/1600/google-services.jpg" border="0" alt="" />

**<span style="font-size:180%;">随</span>**便瞟一眼我的Google Account，就知道我被那个叫“谷歌”的家伙给统治成了什么样子（破输入法还没与时俱进，害我差点敲成“骨骼”）。虽然我并没有完全享用以上的服务，但还是必须承认：凡我用到的，都是相当不错和专业的。

**<span style="font-size:180%;">不</span>**过，丫对我的统治还不彻底，至少未来还会增加俩服务，一个<a href="http://www.flickr.com" target="_blank">flickr</a>，一个[video][1]。前者是因为教育网内访问不了，否则丫早就该出现了；后者可以访问，我也试用了下，自打<a href="http://www.chinaui.com/news/newsInfo.aspx?ARTICLE_ID=1202" target="_blank">Google宣布收购YouTube</a>，前景可谓一片光明。另外丫少列了个google earth。也许，不久的将来，google将占领我们的屏幕！

**<span style="font-size:180%;">技</span>**术领域的日新月异跟洪水下山似的，把我们这些草根儿冲得哪还有根儿啊，结果丫们还是拼命挤占我们脚底下的沃土。为了不被冲走，我就这么牢实的踩在google这片地儿上，然后丫再拼命施肥，再然后你说我是营养过剩，还是营养单一？忽然不知道这种现象是该赞还是该叹，咱有可能享受技术领先带来的优秀服务，也贡献出眼球让丫们服务提供商来你争我夺肆意践踏。这字敲着敲着就又被践踏了一遭：<a href="http://www.chinaui.com/news/newsinfo.aspx?ARTICLE_ID=1210" target="_blank">AMD有可能收购ATi</a>，看来丫们笃信“海纳百川，有容乃大”，而对“水不在深，有龙则灵”视而不见。

当我们的眼球前满是Google或者满是AMD的时候，也就是丫们罢手的时候？

 [1]: http://video.google.com