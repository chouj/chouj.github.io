---
title: 分享家:让你的订阅按钮更优雅
author: Chouj
type: post
date: 2010-08-16T15:00:17+00:00
excerpt: 两年前我也介绍过一些国外的All in ONE订阅按钮生成应用，但他们要么夭折了，要么不大符合贵国国情。但分享家十分国产，如果你需要生成一个订阅按钮的话，我十分推荐。
url: /2010/08/16/addthis-org-cn/
views:
  - 4208
duoshuo_thread_id:
  - 1279764464521970056
categories:
  - 工具
tags:
  - button

---
![分享家logo][1]

正如<a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/">分享家</a>的“关于”页面所说：<a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/">分享家</a>是一个提供收藏和分享按钮、订阅按钮服务的网站。这里我们主要关注<a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/">分享家</a>所提供的All in One订阅按钮服务。这个服务和国外应用[AddThis][2]很像，但他们没有什么关系。

两年前我也介绍过一些<a title="All in ONE订阅按钮免费制作站点收集" href="http://www.xuchi.name/blog/2007/05/all-in-one-feed-button/" target="_self">国外的All in ONE订阅按钮生成应用</a>，但他们要么夭折了，要么不大符合贵国国情。但分享家十分国产，如果你需要生成一个订阅按钮的话，我十分推荐。下面简要介绍下<a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/">分享家</a>的功能。

  * 首先转引分享家订阅按钮的特性和作用：

<!--more-->

> **分享家订阅按钮特性：**
> 
>   * 收录按钮更全面: 收录了常用订阅按钮；
>   * 可自由定制按钮: 可自由定制样式和显示方式；
>   * 同页面多按钮支持: 只要一次安装代码，同页面可放置多处按钮；
>   * 超小体积，速度快: 超小js文件，并通过Google Code托管加速；
>   * 全面的浏览器兼容: 兼容IE 6.0、IE 7.0、IE 8.0、FF 2.0+、Chrome 1.0+、Opera 9+、Safari 3+；
>   * 可设置绑定事件：可以设置click|mouseover作为触发事件，默认为mouseover；
>   * 支持后期绑定: 当你在文档加载后插入html或者ajax内容后，可调用$$addfeed.rebind();重新绑定。
> 
> **网站和博客添加订阅按钮的作用**
> 
>   * 方便读者订阅，增强用户体验；
>   * 增加来自订阅用户的访问量；
>   * 当用户分享订阅内容时，可增强SEO作用。
> 
> **我是一般浏览者，这个对我有什么用？**
> 
> 一般浏览者可以安装我们的小插件到浏览器，一个插件就包含所有主流订阅按钮，方便你的日常订阅操作。<a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/about/browser/">详情</a>

  * 再来看他有什么样式和可定制性让我们选择：

<img title="分享家样式和定制" src="http://pic.yupoo.com/xcchris_v/AoYLFqq8/Ic48A.png" border="0" alt="分享家样式和定制" />

从上图可以知道分享家所支持的订阅到的RSS服务，按钮样式，颜色定制以及鼠标行为定制，相当齐全。下面是一个实例了：

<span class="addfeed_cn"><a title="订阅我吧" href="http://www.xuchi.name/blog/feed/"><img src="http://addfeed.cn/images/f3.gif" alt="分享家:Addfeed" align="absmiddle" /></a></span>

  * 当然，作为blogger也可以选择在自己的博客程序平台上安装他们的插件：

> <ul style="font-size: 14px;">
>   <li>
>     <a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/feedtools/wordpress/">WordPress插件</a>
>   </li>
>   <li>
>     <a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/feedtools/z-blog/">z-blog插件</a>
>   </li>
>   <li>
>     <a style="color: #0083b1; text-decoration: none;" href="http://addfeed.cn/feedtools/widget/">Widget、Gadget等小窗体</a>
>   </li>
> </ul>

综上，分享家是很漂亮的订阅按钮生成工具，值得推荐！

[ **[点此进入 分享家][3]** ]

 [1]: http://addthis.org.cn/images/p_10.gif
 [2]: http://addthis.com
 [3]: http://addthis.org.cn "分享家"