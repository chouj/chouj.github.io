---
title: 今天过节~~
author: Chouj
type: post
date: 2005-11-10T16:24:00+00:00
url: /2005/11/11/single-day/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2005/11/blog-post.html
views:
  - 1624
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969737
categories:
  - 我记录
tags:
  - 光棍节
  - 生活

---
光棍节&#8230;全天没课 qq上有同学说是不是你们老师商量好了 我想没可能 老师不会这么好心吧

上午继续完善这里 就这样了 不打算再管了 以后没事换换背景就可以了

到现在收到了几条短信祝福 一条来自妹妹 一条来自远在同济的学妹 还有两条是认识的校媒体记者发 过来的 妹妹问我什么时候她能有个嫂子 学妹希望下次过节我不再用她来祝福了 剩下的就是祝开心快乐之类 我不置可否 这种事情如何说的清楚

11：11已过去 光棍节最经典的时刻 晚上有饭局 寝室一弟兄9号的生日 改在今天撮 过节可以饱餐一 顿也还不错 有点过节的样子

白云黄鹤上 进版画面早就换成了Single的 紫色 感觉还不错 没有光棍的孤独感 bbs里早就闹开了锅 十大就有好几个跟光棍有关 我们学校光棍就是多 计划K歌 吃饭的 借这个机会发泄派遣 无可非议

过节时可以安心写写字 感觉挺惬意的 下午干什么 快考试了 有两门 还没底 是该看书的时候了