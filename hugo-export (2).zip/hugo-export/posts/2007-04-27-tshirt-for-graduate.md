---
title: 毕业衫貌似敲定了
author: Chouj
type: post
date: 2007-04-27T11:46:00+00:00
url: /2007/04/27/tshirt-for-graduate/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/blog-post_27.html
views:
  - 2516
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969880
categories:
  - 我记录
tags:
  - 华中科技大学
  - 图片
  - 毕业
  - 毕业衫
  - 物理系
  - 纪念

---
<a href="http://bp2.blogger.com/_2MqU1LfBbeM/RjHiyjZlN3I/AAAAAAAAAH4/nmP1NcL_xWE/s1600-h/T%E6%81%A4.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5058073214637651826" style="margin: 0px auto 10px; display: block; text-align: center; cursor: pointer; width: 440px; height: 291px;" src="http://lh5.google.com/image/xcchris/RjHiyjZlN3I/AAAAAAAAAH4/m5HnWXsPceE/T%E6%81%A4.jpg?imgmax=912" border="0" alt="" /></a>

<div style="text-align: center;">
  Department of PHYSICS , HUST , 2003 &#8211; 2007<br /> 点击上图见大图
</div>

<span style="font-size:180%;">袖</span>标比较差，背后那个标语不错，就是字体我不喜欢，不协调，要我画，一定整个彪悍的字体！整体而言还是比较令人满意的。

<span style="font-size:180%;">之</span>前为应付差事也胡画了个，从bbs上搜出来丢到现现眼，哈哈！这标志要是暖色系的，当袖标还可以。

<a href="http://bp3.blogger.com/_2MqU1LfBbeM/RjHkrzZlN4I/AAAAAAAAAIM/oIvdIn-3Y8M/s1600-h/04.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5058075297696790402" style="margin: 0px auto 10px; display: block; text-align: center; cursor: pointer; width: 434px; height: 290px;" src="http://lh6.google.com/image/xcchris/RjHkrzZlN4I/AAAAAAAAAIM/MO9Cvp77x10/04.jpg" border="0" alt="" /></a>
  
自己画的Logo我还是挺喜欢的，数字和背后的英语统一用的04号小字体，貌似有点不合适。