---
title: Logo for MARS
author: Chouj
type: post
date: 2007-02-04T13:13:00+00:00
url: /2007/02/04/logo-for-mars/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/logo-for-mars.html
views:
  - 2131
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969846
categories:
  - 我尝试
tags:
  - RSS设计
  - 图片

---
<a href="http://bp3.blogger.com/_2MqU1LfBbeM/RcXc1so2PeI/AAAAAAAAACE/KmwoY7y2YVc/s1600-h/mars-logo.gif" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5027667374102691298" style="cursor: pointer;" src="http://bp3.blogger.com/_2MqU1LfBbeM/RcXc1so2PeI/AAAAAAAAACE/KmwoY7y2YVc/s320/mars-logo.gif" border="0" alt="" align="left" /></a><span style="font-size:180%;"><span style="font-weight: bold;">L</span></span>ogo for <a href="http://marsyan.yculblog.com/" target="_blank">MARS</a>，还是放假前的作业。想不到什么可指代喻示的物件，就拿字母和圆球（来拍我吧，我把这个蓝色球当火星）敷衍了，仿web 2.0 logo的，因为参照了以下两篇东西：<a href="http://www.chinaui.com/news/newsInfo.aspx?ARTICLE_ID=1860" target="_blank">2007年标志设计趋势代码</a>，<a href="http://daodao.org/article.asp?id=119" target="_blank">Web2.0 Logo聚合及相关字体下载</a>。

<span style="font-size:180%;"><span style="font-weight: bold;">二</span></span>元色，反射效果（最好模仿），Balcony Angels字体（郁闷的是，上述第二篇文字介绍的字体要付费下载 &#8211; -||），本想以暖色系寓意火星的，但为配合blog技术流的风格，还是冷色居多了。最后要说，这个gif可能不符合当初的大小要求，要更改的话，Mars同学直接交代就是了。

# ****
  
****  {.ContentTitle}