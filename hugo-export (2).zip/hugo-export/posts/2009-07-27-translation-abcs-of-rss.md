---
title: '[翻译]有关RSS的ABC'
author: Chouj
type: post
date: 2009-07-27T13:34:38+00:00
url: /2009/07/27/translation-abcs-of-rss/
views:
  - 1744
  - 1744
duoshuo_thread_id:
  - 1279764464521970044
categories:
  - 相关
tags:
  - RSS的ABC
  - Translation

---
<img src="http://pic.yupoo.com/xcchris/152046216d4e/07vxiyl1.jpg" alt="[翻译]有关RSS的ABC" align="right" />[原文]<a title="ABCs of RSS feeds" href="http://www.feedforall.com/abcs-of-rss.htm" target="_blank">ABC&#8217;s of RSS Feeds</a>
  
[作者]Sharon Housley
  
[翻译]抽筋儿
  
[译者按]能力有限，欢迎指正。

[全文]

Implementing RSS (Really Simple Syndication) can be aided by an understanding of the terms relating to RSS. Learn the ABCs of RSS&#8230;.
  
来学RSS的ABC吧，了解了这些和RSS有关的东东，你就能搞懂RSS啦。

**A &#8211; AutoDiscovery（自动识别）**

Auto Discovery is code that is inserted into the header of an HTML web page, which then indicates to readers that an RSS feed is available for the content.
  
如果网页HTML源码的头部中有了自动识别编码，那么阅读器就能知道该网页有RSS feed可读取。

**B &#8211; Blogs（博客）**

Blogs are web logs that are updated regularly, usually on a daily basis. Blogs generally contain information related to a specific topic. In some cases, blogs are used as daily diaries about people&#8217;s personal lives, political views, or even as social commentaries. The truth of the matter is that blogs can be shaped into whatever the author wants them to be. While initially thought of as diaries or online journals, blogs have evolved into the latest fresh web content.
  
每日更新或规律更新的网络日志就是博客，它往往有其特定的主题，比方个人日记，政治倾向，甚至是时事探讨。最关键的是，博主能依照他们的意愿决定博客的一切（译者注：请参照贵国基本国情理解），因此本被理解为线上日记的博客变成了网络上的新鲜内容发源地。

**C &#8211; Cache（缓存）**

Cache is a temporary storage area for frequently-accessed or recently-accessed data. Having certain data stored in a cache area speeds up the operation of the computer. Using a cache with RSS feeds will help minimize bandwidth and display an RSS feed&#8217;s content quicker.
  
最近或经常调用的数据就会被堆放在缓存里。电脑就是有益于缓存而使得运行速度提高。在RSS feeds里配备缓存可以减少带宽占用并加快内容展示的速度。

<!--more-->

**D &#8211; Display（显示）**

Many webmasters post the content of an RSS feed on their website. They use either PHP, ASP, or javascript for such purposes. If done properly, the feed&#8217;s content will dynamically update as the content of the feed changes.
  
许多网站管理员将RSS种子的内容发布在他们的网站上。他们使用 PHP、ASP或javascript其中的一种来实现目的。如果正常，那么当种子的内容改变时，它会动态地更新。(by <a href="https://twitter.com/liyang80s/status/2799343843" target="_blank">liuyang80s</a>)

**E &#8211; Elements（元素）**

Within an RSS feed, there are various feed elements. The elements of an RSS feed are defined by tags.
  
在RSS feed的源码中有很多不同的元素，他们由标签来指定。

**F &#8211; Filter（过滤）**

Many RSS feeds contain duplicate or similar content. Publishers can filter RSS feeds so that they only see content that they wish to see, by filtering out duplicate postings.
  
很多RSS feeds的内容重复或类似。过滤掉RSS feeds中重复的信息，使得想得到的信息浮出水面。

**G &#8211; GUID（全局惟一标识符）**

GUID stands for Globally Unique IDentifier. The RSS specification strongly suggests that each RSS feed item have a unique GUID. If you are creating feeds, a GUID is important because GUIDs are often used by feed readers and aggregators to determine if a feed item is new or simply an existing item that has been updated. Each item in the RSS feed should have a unique GUID.
  
GUID是全局惟一标识符的缩写。RSS技术规范建议每个RSS feed条目都有一个GUID码。GUID码帮助阅读器或聚合器程序识别一个feed条目是新发布的还是原有条目内容的变动，所以在你编写RSS feed时，GUID码很重要，feed中的每个条目都应该有惟一的GUID码。

**H &#8211; HTML（超文本标记语言）**

HTML, which is the acronym for HyperText Markup Language, is frequently used to design websites.
  
HTML是超文字标记语言的简称，用以进行网页的编写。

I &#8211; iTunes Namespace（iTunes命名空间）

The iTunes Namespace allows the user to add the information necessary to have a podcast listed on the Apple iTunes Music Store (ITMS).
  
用户需要将一个播客材料放到苹果iTunes音乐商店（译者注：一款线上软件）上时，可以用iTunes命名空间来规划一些必须的信息。（译者注：该编码规范详见<a href="http://www.feedforall.com/itunes.htm" target="_blank">这里</a>）

**J &#8211; JavaScript**

Javascript can be used to display the content of an RSS feed.
  
可以用JavaScript语言调用RSS feed的内容并展示出来。

**K &#8211; Keywords（关键词）**

Keywords should be integrated into the RSS feed to help search engines determine what the RSS feed is about.
  
为了让搜索引擎知道该RSS feed是关于什么的，RSS feed中需要指定一些关键词。

**L &#8211; Links（链接）**

Links are used to direct RSS readers to the original webpage containing information that directly relates to the feed.
  
我们用链接将RSS feed和对应的原始页面关联起来以指引RSS读者。

**M &#8211; Mashup（聚合）**

A mashup is a combination of multiple RSS feeds that have been merged together to create a new, single feed.
  
将多个RSS feeds合并输出到一个新的feed就称为聚合。

**N &#8211; Namespace Extensions（命名空间扩展）**

The RSS specification allows you to create and use your own custom elements (tags) in any RSS feed by declaring your own namespace. Doing this is 100% in line with the RSS specification and the feed will validate. However, you should have a specific and well-planned reason to do so. No RSS readers, or other RSS processing applications, will be able to use your custom info for any purpose. Adding elements (tags) would typically be used only in an in-house situation where both the writing application and the reading application have prior knowledge of the new tags.
  
RSS规范允许程序员通过声明新的命名空间来在feed中添加自定义的元素标签。这么做符合RSS规范，制造的feed也有效。但这是在有特殊目的或是计划周密的情况下才这样，因为没有哪个阅读器或者RSS应用会去采用你的定制。只有在内部环境允许的情况下，比方读写两方都对新的标签能够理解时，才会用到新元素（标签）的添加。

**O &#8211; OPML（大纲处理标记语言）**

OPML, or Outline Processor Markup Language, is a file format standard that can be used to exchange subscription lists between programs. OPML is used as a standard to import or export groups of RSS feed subscriptions. OPML was initially designed by Radio UserLand as a file format for outlines. The purpose of this format is to provide a way to exchange information between outliners and Internet services. OPML has since been adopted for other uses, the most common being to exchange lists of RSS feeds between RSS aggregators. OPML is an open format, allowing other services to extend the format. While OPML was not initially designed as a vehicle to share RSS feeds, it has become the de facto standard. OPML, like RSS, is based on RSS, and because of the similarities, those familiar with RSS have embraced OPML as a way to share RSS feed collections.
  
大纲处理标记语言简称OPML，是一种用于应用间交换订阅列表的文件格式标准，RSS feed订阅列表的导入导出都要用到它。最初，Radio Userland针对纲目列表开发了OPML这种格式，其目的是在摘要生成器和网络服务间提供一种信息交换的路径。现在，OPML被应用到其他方面，最为常见的即在不同的RSS聚合器间交换feeds列表。OPML是开放的格式，允许其他服务进行扩展。它起初并不是开发用来共享RSS feeds，但事实上OPML已经成为了标准。和RSS技术一样，这种基于RSS的OPML以其简洁性成为了RSS拥趸交换订阅feeds的利器。

**P &#8211; Podcasting（播客）**

Podcasting is online audio content that is delivered via an RSS feed. Many people equate podcasting to &#8220;radio on demand&#8221;. However, in reality, podcasting gives the listener far more options than radio does, in terms of content and programming. In addition, podcast listeners can determine their own time and the place for listening, meaning they decide what programming they want to receive, and when they want to listen to it. Listeners can retain audio archives to listen to later, at their leisure. While blogs have turned many bloggers into journalists, podcasting has the potential to turn podcasters into radio personalities.
  
播客在线上借由RSS feed传播声讯内容。很多人将播客视为点播电台。但是事实上，播客在内容和节目上能提供的选择比电台更多。另外，播客受众可以选定听节目的时间和地点，意味着听不听，听什么都是他们说了算。而且，他们还可以保留下音频节目，以后方便的时候再听。当博客把好多博主变身为新闻记者的时候，播客正在把播主变身成个人电台发言人。

**Q &#8211; Query（查询）**

Webmasters can create RSS feeds based on search queries for their websites.
  
网站管理员可以根据他们站点的搜索请求来制定RSS feeds。

**R &#8211; RSS**

RSS is a standard format for syndicating content on the Internet. The content can be anything! Information contained in an RSS feed is often syndicated on other sites, which expands its reach. Website visitors love RSS because they choose which feeds they wish to subscribe to. If at any point they are unhappy with the content contained in the RSS feed, they simply unsubscribe and no longer receive notification of feed updates. RSS is really a win-win for both subscribers and publishers. In order to get a better understanding of how RSS works, download an RSS reader or use a web aggregator and subscribe to an RSS feed (they are usually indicated by a small orange icon).
  
RSS是应用于网络上的一种联合供稿标准格式。其所包含的信息包罗万象，并可实时发布在多家网站上借以扩大影响。浏览者都喜欢RSS，因为他们可以选择他们想看的feed来订阅。什么时候他们不爽一个feed了，那就直接取消订阅，以后就不会收到日志更新的消息了。无论对订阅读者来说，还是对日志发布者来说，RSS让双方都受益。为了更好的理解RSS的机制，赶紧去下载一个阅读器软件或使用基于浏览器的线上服务来订阅feed吧（feed经常由一个橘色小标志来指示）。

**S &#8211; Syndication（联合供稿）**

Syndication is the supply of material for reuse and integration with other material.
  
联合供稿是用于材料的循环使用和整合的。

**T &#8211; Template（模版）**

Many webmasters use templates to layout the contents of their RSS feed and make it match there website.
  
很多网站管理员使用一些模版来排版他们的RSS feed，以使其搭配他们的网站。

**U &#8211; URL（链接）**

URLs can be embedded into the description of the RSS feed items, so that when the feed is syndicated, the content originator gains backlinks.
  
RSS feed条目的描述中可以嵌入URL链接，这样当feed内容被展示出来的时候，原内容贡献者就会得到反向链接。

**V- Validate（通过验证）**

Feed validation is important. If a feed is not properly formed, it will not always be valid for reading.
  
Feed需要通过验证。如果一个feed格式不规范，那么它就不具备读取的有效性。

**W &#8211; Website（网站）**

Updates RSS feeds can be set up to notify visitors when a website changes.
  
当一个网站更新时，RSS feed就会通知他们的访客。

**X &#8211; XML（延伸性标志语言）**

RSS is a subset of XML, or eXtensible Markup Language.
  
RSS从属于XML，延伸性标识语言。

**Y &#8211; Yahoo Answers（雅虎问答）**

Yahoo&#8217;s interactive system of questions and answers can be tracked using RSS feeds. You can create keyword or category feeds for anything in Yahoo Answers.
  
雅虎交互性问答系统可由RSS feed来追踪。用户可以再雅虎问答里订阅关键词feed或分类feed。（译者注：百度知道也可以。）

**Z &#8211; Zero Feeds（没有Feeds）**

Not having RSS feeds for your website puts you at a competitive disadvantage. RSS feeds bring traffic and help the stickiness of your website.
  
不支持RSS feeds的网站已经处于弱势。RSS feeds可以带来流量和访客忠诚度。