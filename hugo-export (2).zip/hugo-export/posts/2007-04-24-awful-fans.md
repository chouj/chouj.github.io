---
title: 可怕的粉丝
author: Chouj
type: post
date: 2007-04-24T15:58:00+00:00
url: /2007/04/24/awful-fans/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/blog-post_24.html
views:
  - 1847
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969878
categories:
  - 我记录
tags:
  - 网络

---
<a href="http://bp3.blogger.com/_2MqU1LfBbeM/Ri4pizScIMI/AAAAAAAAAHI/5l0Tsbg7lHc/s1600-h/qeegi.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5057025109443485890" style="cursor: pointer; width: 458px; height: 472px;" src="http://bp3.blogger.com/_2MqU1LfBbeM/Ri4pizScIMI/AAAAAAAAAHI/5l0Tsbg7lHc/s400/qeegi.jpg" border="0" alt="" /></a>

点击上图，可见原始大小，原帖<a href="http://www.wangtam.com/50226711/ae_blogging_6_rss_89450.php" target="_blank">见此</a>。事件缘由[可参考此][1]。

<span style="font-size:180%;">只</span>是见着了我不乐于看见的言论，留了言，结果被抬高了身价，还被标记上了派别，我心里那个寒，真是可怕的粉丝。

<span style="font-size:180%;">为</span>了澄清一些事情，我主动和<a href="http://blogunion.org/blogs/the-highest-pagerank-chinese-blogs.html" target="_blank">被认为争议性</a>的<a href="http://www.wangtam.com/" target="_blank">网谈</a>作者启羁 (QeeQi)私下交流了一下，事后他在twitter里提到，觉得自己变得好说话了，呵呵，也确实，并没有给我高高在上的感觉。他提到了很多，从文字里我开始尝试理解他，为了blog，为了中文blogsophere的氛围与经营环境，可以看得出他在思考，在努力，关于blog的发展也想的很深。至少，他是值得敬仰的优秀blogger。

 [1]: http://forum.chinabloggernetwork.com/viewthread.php?tid=306&extra=page%3D1