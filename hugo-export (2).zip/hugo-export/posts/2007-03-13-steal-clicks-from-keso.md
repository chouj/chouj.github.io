---
title: 从keso那里盗流量
author: Chouj
type: post
date: 2007-03-13T14:26:00+00:00
url: /2007/03/13/steal-clicks-from-keso/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/keso.html
views:
  - 1759
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969861
categories:
  - 我尝试
tags:
  - blog
  - 网络

---
<span style="font-size:180%;"><span style="font-weight: bold;">最</span></span>近，借由<a href="http://www.mybloglog.com/" target="_blank">MyBlogLog</a>的统计发现，基本每天我的两个blog都有从<a href="http://blog.donews.com/keso" target="_blank">keso</a>那里过来的流量，一时挺惊讶。我没在他那里附链接留言，他也不大可能写个链接指向我的博客。

<span style="font-size:180%;"><span style="font-weight: bold;">一</span></span>番小小调查，还真发现我和<a href="http://blog.donews.com/keso" target="_blank">keso</a>攀上了关系，在他的博客上找到了我的链接，虽然这个链接是由机器生成，<a href="http://blog.donews.com/keso" target="_blank">keso</a>是被动和不知情的。究其原因，一个widget帮了我这个忙，帮<a href="http://blog.donews.com/keso" target="_blank">keso</a>挂上了我的友情链接。

<a href="http://widget.criteo.com/" target="_blank"><img style="border: 0pt none ; width: 265px; height: 96px;" src="http://widget.criteo.com/autoroll/data/logo.png" alt="" /></a>
  
<span style="font-size:180%;"><span style="font-weight: bold;">A</span></span>utoRoll，我和<a href="http://blog.donews.com/keso" target="_blank">keso</a>都在博客上加载了这一widget，而其功能就是自动搭建blog的链接桥梁，跟<a href="http://www.mybloglog.com/" target="_blank">MyBlogLog</a>差不多，机器帮你做互动。条件很简单：都使用此widget，blog内容相关。但我的内容和<a href="http://blog.donews.com/keso" target="_blank">keso</a>的一点都不相似嘛，为什么可以在Autoroll上互链了呢？这是因为目前使用这一widget的中文blog还不够多，只要拿中文写的blog基本都被机器认为是相关的了。我就这么堂而皇之的骗到了<a href="http://blog.donews.com/keso" target="_blank">keso</a>的一点点流量。

<span style="font-size:180%;"><span style="font-weight: bold;">如</span></span>果有朋友跟我一样，被芝麻利益冲昏了头，想攀龙附凤，鸡犬升天的话，不妨尽快一试。时机过了，恐怕只能在AutoRoll上和我互链了，呵呵，可惜我这里日流量才两位数。对于<a href="http://blog.donews.com/keso" target="_blank">keso</a>，不好意思拿你这杆大旗说事啦。