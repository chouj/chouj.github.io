---
title: 到哪里找限免iPhone/iTouch Apps
author: Chouj
type: post
date: 2010-11-22T07:51:41+00:00
url: /2010/11/22/where-find-limited-free-apps/
views:
  - 6000
duoshuo_thread_id:
  - 1279764464521970060
categories:
  - 我表达
tags:
  - App
  - iPhone
  - iPod

---
从香港官网收入8G Touch4 一枚，同学人肉过关顺利。正式变身Apps人肉精选器，初期阶段只来列个找Apps的站点列表，功能就是限免提醒+app推荐：

  1. <a title="AppShopper" href="http://AppShopper.com" target="_blank">AppShopper.com</a>
  
    第一推荐的，还是AppShopper，超全超快速。侧栏有各种类别的推送Feed供订阅。注册用户还可以建立Wish List。且有自己的<a href="http://itunes.apple.com/app/appshopper/id387037496?mt=8" target="_blank">App</a>。
  2. <a title="爱Apps" href="http://iappstoday.com" target="_blank">爱Apps</a>
  
    大家肯定都知道iappstoday，中文站点，推送的App更适合国人。还有App Push
  3. <a title="苹果I派党" href="http://www.ipadown.com/" target="_blank">苹果I派党</a>
  
    域名有点像专做iPad的，其实不然，也是相当好的iOS Apps推荐站，还有各<a title="Apple APP Store应用排行榜" href="http://www.ipadown.com/top/" target="_blank">App Store应用排行榜</a>。
  4. <a title="iapp" href="http://iapp.com.tw/" target="_blank">iapp</a>
  
    这是个台湾的站点。其每日发布的“[限時免費/最新免費] Free app分享”包含当天限免或免费的Apps，只看这个也不错。
  5. <a href="http://www.williamlong.info/archives/2363.html" target="_blank">常用iPhone手机软件应用</a> + <a href="http://www.williamlong.info/archives/2410.html" target="_blank">iPhone应用程序推荐</a>
  
    月光的这两篇很值得一看。
  6. <a title="Leies" href="http://www.maclifes.com/app" target="_blank">Maclifes的Leies在Twitter上的限免推荐</a>
  
    最近好像没怎么发推。
  7. <a title="VastApp" href="http://www.vastapp.com/" target="_blank">VastApp</a>
  
    这是个新上线的各平台App的推荐站。
  8. <a title="Apps Ku" href="http://appsku.com/" target="_blank">Apps Ku beta</a>
  
    这个更是最新上线，内容还不多。不过它有个用Project Babel 2搭建的<a title="AppKu.com社区" href="http://appskucom.appspot.com/" target="_blank">分享和讨论Apps的社区</a>，可以来光顾下。
  9. <a title="V2EX" href="http://v2ex.appspot.com" target="_blank">V2EX</a>
  
    当然也可以来V2EX的Apple Section，这里也有帖子讨论App的。V2EX是个注册人数3000+的侧重分享与发现的社区。

PS.买了个<a title="touch 保护壳" href="http://item.taobao.com/item.htm?id=7733307940" target="_blank">保护壳</a>，还8错。