---
title: 为汶川地震灾区的同胞祈祷
author: Chouj
type: post
date: 2008-05-13T11:56:36+00:00
url: /2008/05/13/pray-for-compatriots-in-wenchuan-earthquake/
views:
  - 4363
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969735
categories:
  - 我表达
tags:
  - 中国
  - 地震
  - 汶川
  - 祈祷

---
![pray][1]

  1. **请为地震中死去的数万同胞默哀，请为灾区幸存的同胞祈祷，请向赶赴灾区救援的同胞们致敬！**
  2. 个人鄙视以地震、撞车等伤亡事件为背景篡改古文、编写段子并传播的人，请问意义何在？没有亲戚好友在灾区就可以冷眼旁观，制造笑料了吗？
  3. 欲向灾区捐款，可去“<a title="淘宝-早一点到达，多一份希望" href="http://www.taobao.com/cn/theme/site/scdz_080512.php" target="_blank">淘宝-早一点到达，多一份希望</a>”紧急救灾页面，参与中国红十字会“李连杰壹基金计划”，以支付宝捐款，最低一元。
  4. 有篇06年发表于《灾害学》的文献——《<a href="http://www.gsdkj.net:90/~kjqk/zhx/zhx2006/0603pdf/060318.pdf" target="_blank">基于可公度方法的川滇地区地震趋势研究</a>》，从地震历史统计分析的角度预测到08年将有较严重震情。也可参看《<a title="研究一篇成功预测了汶川地震的诡异论文——格致" href="http://gezhi.org/node/965" target="_blank">研究一篇成功预测了汶川地震的诡异论文</a>》。

 [1]: http://farm3.static.flickr.com/2400/2485879371_1505132d2e.jpg?v=0