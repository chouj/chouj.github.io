---
title: ForRSS.com：围绕RSS的又一博
author: Chouj
type: post
date: 2009-01-31T13:57:53+00:00
url: /2009/01/31/forrss-com/
views:
  - 1776
  - 1776
duoshuo_thread_id:
  - 1279764464521970037
categories:
  - 相关
  - 资源
tags:
  - blog
  - RSS推广

---
<img src="http://vsfish.bgp2.kaiyele.net/forrss/img/logo.gif" border="0" alt="" align="left" />套用下老套台词：”我很欣慰！“，哈哈！我非常高兴又看到一个全面介绍RSS web应用的中文Blog诞生，她就是<a title="ForRSS" href="http://forrss.com" target="_blank">ForRSS：A Weblog that Covers All Things RSS</a>，由博主**火星人**执笔。纵观ForRSS这几个月的posts，她均以简短精湛的汉字介绍了当下以RSS为基础的网络应用服务。能有更多介绍RSS应用的中文日志甚至是中文blog涌现，让RSS不再是GEEKer的玩物，正是我所乐见的！

<img src="http://pic.yupoo.com/xcchris/832306e7c241/zg5kme6o.jpg" border="0" alt="" />

如果想follow最新最帅的RSS应用，就请跟紧**<a title="ForRSS" href="http://forrss.com" target="_blank">ForRSS</a>**！