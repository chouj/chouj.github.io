---
title: My Experience from BS to MS Student
author: Chouj
type: post
date: 2007-10-28T10:02:42+00:00
url: /2007/10/28/my-experience-from-bs-to-ms-student/
views:
  - 1932
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969716
categories:
  - 我表达
tags:
  - English
  - pagerank
  - pr
  - 广州
  - 生活

---
这是篇英语作文，我今天交上去的，拿来blog里充数。好久没更新，不算上篇的话。因为那是个失误，本想新建个页面的，结果建成了post，WP又说我没有权限删它，就撩在哪里了。就这么草率打扫的blog，居然她的Google PR还到了4，比<a href="http://aboutrss.cn" target="_blank">RSS相关</a>的3都要高。

<iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://ditu.google.com/maps/ms?f=q&hl=zh-CN&geocode=&ie=UTF8&msa=0&msid=102575039203066245657.00043d8a82052ba7efd89&ll=23.139458,113.298305&spn=0.028453,0.040169&om=1&output=embed&s=AARTsJowaxqUGY0HmlVyrdtwhYwaY-F54Q"></iframe>  
<small><a href="http://ditu.google.com/maps/ms?f=q&hl=zh-CN&geocode=&ie=UTF8&msa=0&msid=102575039203066245657.00043d8a82052ba7efd89&ll=23.139458,113.298305&spn=0.028453,0.040169&om=1&source=embed" style="color:#0000FF;text-align:left">查看大图</a></small>

这是我双休两天早上6点多爬起来赶去上课的地方～其实现在上课是件很享受的事情：眼睛不用像实验室里一样盯着显示器，而是看着远远的投影，有利视力；课间一票人踢踢毽子——广东这边巨流行的运动；中午找一圈儿人搞起杀人游戏，虽然新手太多，降低了趣味性，但毕竟很开心。

最近异常忙～继续搁置～

Time flies fast. What an old-fashioned beginning! But really it is.

It’s a whole year since I came to Guangzhou for the interview. I have to say life changes hugely in this year. I haven’t imagined that I would be mentioned with “the ocean” together, however, it happened actually. “What you choose then what you afford” is quite a wonderful belief. So there is no complaint. Fortunately, I’ve found the Physical Oceanography interesting.

During the undergraduate state when I studied in Huazhong University of Science & Technology my major is physics. It’s one of those mystery subjects in natural science and this major of mine is also the dominate reason why I finally come across the field of physical oceanography. But I have to admit that I havn’t spent enough time on learning my major courses. In other words, something else leading a more colorful life cost me a lot of time. At the very start, exactly when I was a sophomore I became a reporter working for my department and wrote news whenever there was an activity. It was a busy life those days especially when the celebrations for the World Physics Year was held. But the experience is quite memorable because of the special particularities of these activities. After I finished performing a journalist role, I dramatically focused my eyes on the internet when I was a junior. Do not just imagine that I was playing internet games day after day. Actually, I found the internet is a tool as useful and important as English. We can access plenty of sites and receive different sounds via the internet. As a result, I became interested in various web applications and I was used to acquiring information from the internet. Furthermore, I almost devoted myself to blog during my spare time and believed that blogging is a kind of life style. It doesn’t look like university life, does it? That’s because the university provides quite free environment which we can lead an independent life in. You need to be responsible to yourself and learn to manage time to balance your study and hobbies. In my opinion everyone will agree that the life in the university is a golden period in your life.

After I compare nowadays to the past, I have said that the life is changing hugely due to the conclusion that I find. The main element in our daily life is academic research now. The entertainment is much less additionally. But in March I chose to make my graduation project in South China Sea Institute of Oceanology where I pursue my MS degree. One reason I considered was that I could force myself to adapt to these changes. Then after I graduated from HUST and got the Bachelor Degree, It’s easy for me to start my MS Life in new environment. The fact proves that my decision is quite correct.

New life starts just like the sun rises in the east. Why not go further ahead?

**严禁剽窃去当composition的作业哦～**