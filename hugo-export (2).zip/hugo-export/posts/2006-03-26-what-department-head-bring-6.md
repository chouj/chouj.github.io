---
title: 部长带来的（六）
author: Chouj
type: post
date: 2006-03-26T02:20:00+00:00
url: /2006/03/26/what-department-head-bring-6/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/03/blog-post_26.html
views:
  - 1636
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969764
categories:
  - 我记录
tags:
  - 部长

---
2004－2005学年度下学期大学生新闻中心优秀通讯员＋《西行漫记》一本
  
2004－2005学年度校优秀学生干部＋800RMB奖学金＋“霸王龙”牌笔记本包一个
  
2005年度校优秀通讯员＋50RMB奖励
  
系团学联通讯部部长一年聘书＋面值68元智慧IC卡一张
  
精美邀请函两封

名誉和物质上的收获貌似就这些，都索那浮云，只是所谓“浮云遮望眼”，何况这云的构成成分还8成是Au&#8230;

&#8230;飘过&#8230;