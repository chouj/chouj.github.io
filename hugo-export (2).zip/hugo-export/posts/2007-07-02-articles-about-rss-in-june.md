---
title: '[草莓版]六月汇集：品完鲜果 再来抓虾'
author: Chouj
type: post
date: 2007-07-01T18:01:08+00:00
url: /2007/07/02/articles-about-rss-in-june/
views:
  - 1718
  - 1718
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969959
categories:
  - 相关
tags:
  - Burn
  - Feedburner
  - Feedmeplz
  - Feedster
  - Feedtwister
  - Google Reader
  - Icon
  - Reader
  - Subscribe
  - Symbol
  - twitter
  - twitterfeed
  - widget
  - xFruits
  - Xianguo
  - Zhuaxia

---
<big><big>这</big></big>几个月以来,**RSS**的消息一直像是沸水里的气泡，喷薄而出，炽炎之热，咄咄逼人。

[**鲜果阅读器**]
  
![][1]

<big><big>既</big></big>[鲜果离线阅读器][2]之后，**[鲜果在线][3]**横空出世，这可引发了RSS阅读器评测比较、阅读器发展模式探讨的浪潮。

大家公认（[1][4]、[2][5]、[3][6]、[4][7]）[鲜果][8]具备[Google Reader][9]和[抓虾][10]的特点，比如支持快捷键，具备社会化元素；[抓虾饱受争议的转型和稳定性、Google Reader的撞墙问题][11]，以及[狗狗的被收购][12]，又使[鲜果][3]拥有了良好的上线时机。但一个阅读器的发展，包括方方面面。作为用户，[守望][13]、[启羁][14]、[WebLeOn][5]都提到，良好的用户体验中重要的是**稳定性**，包括feed抓取速度和访问速度，用户越多，[鲜果][3]的稳定性越值得考验。而阅读器未来发展的模式同样值得大家探讨。曹增辉和吕欣欣都不大看好阅读器市场，因为阅读器市场较低的进入门槛，[前者还是支持阅读体验纯粹的Google Reader][11]，[后者则为“鲜果在这个领域准备坚持努力的决心，和开放合作的态度”，选择支持他们][15]。狂风则认为[鲜果若能先模仿后超越，定可后来居上][6]。WebLeOn在考虑[阅读器的走向到底应该纯工具化还是应该伴随服务推送][5]；长天暮鼓给的答案是，[看好抓虾的内容分类推送，支持RSS应用的多元化][16]，同时也给出了阅读器盈利模式的建议。

[**抓虾风波**]

<big><big>抓</big></big>虾目前事故不少。[27号在饭否上看到和菜头说抓虾访问不能][17]，结果是[因为光纤断掉][18]；就在写这篇的时候，我又看到[Angelived同学在质问：“抓虾怎么不抓了？”][19]。更加严重的貌似是关于抓虾**是否盗用bloggers内容**的讨论，（[1][20]、[2][21]、[3][22]）。我个人认为值得看看的，还是**优比客**的<a href="http://ubikr.com/archives/30" rel="bookmark">用抓虾订阅博客的十大理由。</a>

[**RSS未来之路**]

<big><big>关</big></big>于RSS应用现状和未来发展的探讨、诠释从来就没有停止过，六月中**魏武挥**有两篇非常优秀的文章值得一看：《[RSS的兴旺：当它不再是RSS][23]》、《[RSS阅读：前景何在？][24]》。文章告诉我们目前RSS应用依然十分**小众**，受技术门槛和需求的影响，这一现象可能将长久存在，而RSS又在一定程度上阻碍了交互功能而使得其发展局面陷入困顿之中。

[**RSS使用技巧**]

<big><big>如</big></big>何在[信息爆炸之中][25]摘取有价值信息，而不是被冲击得体无完肤，已经受到较多的关注。旁观者郑钧介绍了[三种信息过滤的方法][26]，可供参考；[Angelived则告诉大家如何给RSS阅读器减肥][27]。

<big><big>8</big></big>4同学定是尝到了RSS阅读的甜头，[不遗余力得推广RSS Feed订阅][28]，我们要感谢他；老前则告诉我们[如何理解Feed订阅数的小波小动][29]；曾英杰是个好同志，收集了[能给你博客带去流量的77个中外RSS目录][30]，想提交Feed地址到收录站点的朋友，看这篇准没错；博客学堂的Rss订阅统计相当帅气，您可以到这一篇[《个性化博客RSS订阅统计状态》][31]中学习学习。

[**RSS新应用**]
  
<big><big><br /> 新</big></big>应用多了去了。**[xFruits][32]**再次发威，发布第11个应用，RSS to My Blog（[1][33]，[2][34]），能够把RSS Feed内容发布到Blog或CMS系统中去；**[Feedster][35]**发布了2.0版本，可以[将blog搜索结果以widget形式挂出来][36]；盗盗这次教我们一个方法，[巧用Yahoo Pipes翻译烧制RSS Feed][37]，对订阅英文文章的朋友会有帮助；Geuro介绍了一款服务**<a href="http://twitterfeed.com/" target="_blank">twitterfeed</a>**，[可将Feed内容自动发布到twitter][38]； [hhalloyy][39]发现了一个简单输出Feed条目标题的服务：**[FeedMeplz][40]**；Adobe air程序渐渐增多，[Riku介绍了一款基于此技术的RSS阅读器，名为Fresh][41]；在[臭豆][42]的指引下(XD),[盗盗发现了提供RSS聚合烧制服务的**Feedtwister**][43]；RSS和煎蛋也有密切关系啊，煎蛋编辑找到了两个好东东，一是[视频网站专用 RSS 阅读器——**Democracy Player**][44]，一是[30 款免费 水晶透明型RSS订阅图标][45]，很实用的哦。

<font color="#ff6666"><small>不知道您是否喜欢这期<strong>草莓版</strong>文章汇集呢？可以留言告诉我。我阅读范围有限，有好文章也可以告诉我哦！</small></font>

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://photo6.yupoo.com/20070626/224426_792388676_jrchrsfq.jpg
 [2]: http://www.myholo.com/tools/berryreader/index.html
 [3]: http://www.xianguo.com/
 [4]: http://www.wappblog.com/50226711/ecieaecrsseec_102247.php
 [5]: http://webleon.org/2007/06/rss.html
 [6]: http://www.kuangfeng.cn/blog/?p=1277
 [7]: http://www.showeb20.com/?p=558
 [8]: http://www.xianguo.com
 [9]: http://www.google.com/reader/view/
 [10]: http://www.zhuaxia.com
 [11]: http://www.caozenghui.cn/?p=192
 [12]: http://www.ilili8.cn/post/68.html
 [13]: http://www.ilili8.cn/post/67.html
 [14]: http://www.wangtam.com/50226711/ec_aecc_rss_ee_102226.php
 [15]: http://www.lvxinxin.com/archives/206
 [16]: http://www.ilmay.cn/post/china-rss-readers.html
 [17]: http://fanfou.com/statuses/B7YaMMeZNpQ
 [18]: http://www.zhuaxia.com/blog/?p=144
 [19]: http://angelived.org/2007/07/01/zhuaxia-is-tired/
 [20]: http://blogsdiy.org/2007-06/full-text-feed/
 [21]: http://blogsdiy.org/2007-07/zhuaxia-issue/
 [22]: http://www.ilmay.cn/post/i-love-zhuaxia.html
 [23]: http://weiwuhui.com/archives/487.html "Permanent Link: RSS的兴旺：当它不再是RSS"
 [24]: http://weiwuhui.com/archives/509.html "Permanent Link to RSS阅读：前景何在？"
 [25]: http://www.xuchi.name/blog/2007/05/23/information-explosion/
 [26]: http://www.cnblogs.com/zhengyun_ustc/archive/2007/06/29/799806.html
 [27]: http://angelived.org/2007/07/01/make-your-feed-thinner/
 [28]: http://since1984.cn/blog/?p=567
 [29]: http://www.qianblogger.com/2007/06/25/feedburner-tongji/
 [30]: http://blogunion.org/blogging-tools/77-rss-directories.html
 [31]: http://blogsdiy.org/2007-06/custom-rss-subscriber-stats/
 [32]: http://xfruits.com/
 [33]: http://www.wappblog.com/50226711/xfruitsc11aeeierss_to_myblog_102819.php
 [34]: http://www.showeb20.com/?p=566
 [35]: http://www.feedster.com/
 [36]: http://www.wappblog.com/50226711/feedster20cieaefeed_widget_102812.php
 [37]: http://www.showeb20.com/?p=546 "Article-Link (Permalink)"
 [38]: http://justin0842.blogspot.com/2007/06/twitterfeed-feedtwitter.html
 [39]: http://e-spacy.com/blog/author/hhalloyy/
 [40]: http://feedmeplz.com/
 [41]: http://www.wappblog.com/50226711/adobe_airccierssee_fresh_99987.php
 [42]: http://www.choudou.com
 [43]: http://www.showeb20.com/?p=515
 [44]: http://jandan.net/2007/06/07/democracy-player-096-released.html "Permanent Link to 视频网站专用 RSS 阅读器——Democracy Player"
 [45]: http://jandan.net/2007/06/15/30-free-vector-rss-icons.html "Permanent Link to 30 款免费 RSS 订阅图标，水晶透明型"