---
title: 中文BSP中寻找RSS地址
author: Chouj
type: post
date: 2007-03-03T11:46:07+00:00
url: /2007/03/03/rss-address/
views:
  - 18694
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969937
categories:
  - 教程
tags:
  - address
  - RSS地址
  - Tutorial
  - url

---
<img title="Feed" src="http://www.feedsky.com/images/icon_f4_feed.gif" alt="Feed" width="99" height="73" align="left" /><span style="font-size: small;"><span style="font-size: large;"><span style="font-weight: bold;">具</span></span>有哪些标志的页面、站点可以被订阅？这是首要问题，也就是要找到RSS源，或者称</span><span style="font-size: small;">为</span><span style="font-size: small;">FEED。左图就是当今最常见的FEED标志，表征此站可通过RSS订阅。</span>

<span style="font-size: small;">常见字样为：<span style="font-weight: bold;">RSS</span><span style="font-weight: bold;"> XML ATOM</span> </span>

<span style="font-size: small;">常见图样为：<img style="width: 16px; height: 16px;" src="http://blog.donews.com/images/blog_donews_com/keso/121/o_rss.gif" border="0" alt="" /></span><img src="http://www.feedsky.com/images/icon_sub_c1s2.gif" alt="feedsky" align="absmiddle" /> <span style="font-size: small;"><img src="http://photocdn.sohu.com/tb/rss.gif" border="0" alt="" /> <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_rss7.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_rss7.jpg" border="0" alt="" /></a></span>

<span style="font-size: small;"><span style="font-size: large;"><span style="font-weight: bold;">另</span></span>外IE7和Firefox都支持RSS自动搜寻功能，只要页面存在RSS源，浏览器上的标签就会高亮。以IE7为例：</span>
  
<span style="font-size: small;"><br /> </span>

<span style="font-size: small;"><a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_rss2.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_rss2.jpg" border="0" alt="" /></a></span>

以FF为例：

[<img src="http://pic.yupoo.com/xcchris/214339b3955a/vozuc9da.jpg" border="0" alt="" />][1]

<span style="font-size: small;"><span style="font-size: large;"><span style="font-weight: bold;">点</span></span>击以上图样、浏览器RSS指示标志，都会得到该RSS地址，即一url。也就是说blog上该标志指向的链接地址，即RSS地址。如果您使用IE7，RSS内容页面上，将会有如下一段显示： </span>

> <span style="font-size: small;"><strong>您正在查看的提要包含频繁更新的内容。</strong>订阅提要后，该提要会添加到“常见提要列表”中。该提要的更新信息会自动下载到计算机，通过 Internet Explorer 及其他程序可以查看这些信息。</span>

<span><br /> <span style="font-size: large;"><span style="font-weight: bold;">下</span></span>面分别指出各国内BSP（Blog Service Providers）初始（未经烧制过）的RSS标志在哪里：</span>

<span style="font-weight: bold;">新浪博客</span>——侧栏上有如下标志： <img src="http://image2.sina.com.cn/blog/tmpl/v3/images/xmlRSS2.gif" border="0" alt="xml" />推荐订阅：订阅到RSS阅读器

<span style="font-weight: bold;">sohu博客</span>——博客名称＋博客地址链接＋<img src="http://js.pp.sohu.com/ppp/blog/styles_ppp/images/ico_rss.gif" border="0" alt="RSS订阅" align="absmiddle" /> <span></span>

<span style="font-weight: bold;">网易博客</span>——博客页最下：有RSS标志<span style="font-weight: bold;">BlogBus</span>——侧栏上有此标志： <img src="http://www.blogbus.com/images/site-v3/rss.gif" border="0" alt="RSS1.0" /><a href="http://help.blogbus.com/logs/2003/12/55530.html" target="_blank">什么是RSS？</a> <span style="font-weight: bold;"><br /> </span></p> 

<span style="font-weight: bold;">歪酷博客</span>——侧栏上有此标志： <img src="http://image2.sina.com.cn/blog/tmpl/v3/images/xmlRSS2.gif" border="0" alt="xml" /><span style="font-weight: bold;"><br /> </span>

<span style="font-weight: bold;">猫扑博客</span>——侧栏上有此标志：<img src="http://image2.sina.com.cn/blog/tmpl/v3/images/xmlRSS2.gif" border="0" alt="xml" />

<span style="font-weight: bold;">My.Donews</span>——侧栏“其他链接：”后有RSS字样链接 <span style="font-weight: bold;"><br /> </span>

<span style="font-weight: bold;">Blog.Donews</span>——侧栏有“日志 RSS” <span style="font-weight: bold;"><br /> </span>

<span style="font-weight: bold;">中文Blogger</span>——页底有“订阅：帖子（Atom）字样链接

 <span></span> <span></span></ul> 

<p style="text-align: center">
  <p style="text-align: left">

 [1]: http://pic.yupoo.com/xcchris/214339b3955a/vozuc9da.jpg