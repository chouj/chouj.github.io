---
title: 留言板
author: Chouj
type: post
date: 2007-02-14T12:06:56+00:00
url: /2007/02/14/messageboard/
views:
  - 22646
  - 22646
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969931
categories:
  - 话语权
tags:
  - 留言

---
<big><big>交</big></big>流对于Bloggers来说是格外重要的，所以一定要开辟一个交流的阵地！有什么想说的、想骂的、想赞的，欢迎留在这里，支持言论自由！