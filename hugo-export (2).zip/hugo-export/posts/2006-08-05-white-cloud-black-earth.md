---
title: 白云 黑土
author: Chouj
type: post
date: 2006-08-05T02:46:00+00:00
url: /2006/08/05/white-cloud-black-earth/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/blog-post.html
views:
  - 1575
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969790
categories:
  - 我表达
tags:
  - 恶搞

---
**创造老百姓自己的YY，以下纯属虚构哦！**

**
  
** 白云：武汉咋就这热乎捏？
  
黑土：可不匝地。胳肢窝都能晒黑喽！
  
白云：瞧这说话没根没据的，青春痘长胳肢窝里都瞅不着，那哪还能晒黑喽？
  
黑土：瞅着咱站的啥地方不？
  
白云：马路崖子啊！
  
黑土：这马路崖子平整不？
  
白云：挺光溜的呀！
  
黑土：那不就完了嘛！反光啊！
  
白云：何着听你着掰活的，白眼球不也得晒黑喽？
  
黑土：不懂科学啦不是！太阳，一道光，chua chua 下来，是不？
  
白云：嗯
  
黑土：这地板，反光，chua chua 上来，是不？
  
白云：嗯
  
黑土：知道两束光，碰一起会产生啥现象不？
  
白云：能产生啥玩意儿啊？
  
黑土：叠加干涉啊！好家伙那一干涉就产生明暗条纹啊！
  
白云：那能匝地？
  
黑土：这条纹往你这眼睛珠子上一chua chua ，那不就有黑有白了嘛，这玩意儿都想不到。
  
白云：瞅着你这文化层次还挺深啊
  
黑土：那可不匝地。