---
title: Anonymouse.org代理显示FB订阅图标失效
author: Chouj
type: post
date: 2008-06-17T08:19:28+00:00
url: /2008/06/17/anonymouse-org-feedcount-display-invalid/
views:
  - 1531
  - 1531
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970008
categories:
  - 工具
  - 新闻
tags:
  - Feedburner
  - Icon
  - Subscribe
  - Symbol

---
因为Anonymouse.org撞墙被屏蔽，所以，之前介绍的<a title="显示FeedBurner订阅数图标的唯一方法" href="http://aboutrss.cn/2008/05/only-way-to-show-feedburner-feedcount-image/" target="_self">Anonymouse.org代理以显示FeedBurner订阅数图标的方法</a>**失效**。

**主机在国外的朋友**，可以参考江东的这篇<a title="Feedburner订阅数图标显示解决办法 江东" href="http://www.storyday.com/html/y2007/1165_feedburner-reader-icon.html" target="_blank">Feedburner订阅数图标显示解决办法</a>，通过上传一php文件来解决问题。

Fuck G.F.W