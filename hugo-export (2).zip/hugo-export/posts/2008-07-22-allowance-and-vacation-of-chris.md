---
title: 抽筋儿之假期补贴
author: Chouj
type: post
date: 2008-07-22T03:11:21+00:00
url: /2008/07/22/allowance-and-vacation-of-chris/
views:
  - 2737
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969903
categories:
  - 我表达
tags:
  - 假期
  - 麦兜

---
[<img class="alignnone size-medium wp-image-297" title="麦兜 点我点我 1024×768" src="http://www.xuchi.name/blog/wp-content/uploads/2008/07/mai-dou.jpg" alt="麦兜" width="500" />][1]

麻烦你，奥运假期

木有假期

是吗。。。来加班补贴吧

木有补贴

是吗。。。要避暑假期吧

木有假期

呃。。。那要降温补贴吧

木有补贴

怎么什么都没有啊？那要假期补贴吧

木有假期

又木有啊？麻烦你来份水果补贴吧

木有补贴

抽筋儿啊，他们的假期跟补贴都木有啦，就是所有跟补贴和假期的配搭都没了哦～～～

没有那些搭配啊！麻烦你，只要补贴吧

咣！！！木有补贴

那假期呢？

木有假期

 [1]: http://www.xuchi.name/blog/wp-content/uploads/2008/07/mai-dou.jpg