---
title: 愚人节
author: Chouj
type: post
date: 2007-04-01T02:03:00+00:00
url: /2007/04/01/april-fool-day/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/blog-post.html
views:
  - 1943
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969871
categories:
  - 我记录
tags:
  - 愚人节

---
<a href="http://www.douban.com/" target="_blank"><span style="font-size:130%;"><span style="font-weight: bold;">豆</span></span>瓣</a>访问不能，别说是愚人节玩笑。update:为什么别人都说可以访问，就我这里打不开。

<span style="font-size:130%;"><span style="font-weight: bold;">这</span></span>节应该是让大家开心的节日，翻两个以前的原创恶搞出来充场面，本想花点心思骗骗人，但一花心思就比较累，作罢。

[创意表白 雪之缘][1]

[宿舍楼下惊现雪地表白 和谐校园初见建设成效][2]

 [1]: http://www.xuchi.name/blog/2007/01/say-love-by-footprint-in-snowfield/
 [2]: http://www.xuchi.name/blog/2007/01/say-love-in-snowfield/