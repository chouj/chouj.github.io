---
title: RSS是拿来干什么的？
author: Chouj
type: post
date: 2008-10-22T19:53:31+00:00
url: /2008/10/23/what-can-rss-do/
views:
  - 11673
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969757
categories:
  - Featured
  - 知识
tags:
  - RSS推广
  - RSS是干什么的
  - RSS订阅
  - 什么是RSS

---
<img style="float: left; margin-left: 0px; margin-right: 10px;" src="http://pic.yupoo.com/xcchris/6394858412e5/medium.jpg" border="0" alt="RSS是拿来干什么的？" width="111" height="114" />_这里的第100篇，不知道有没有资格企及这个艰难的题目。但，既然叫“RSS相关”，没有对RSS的解释，是不行的。下面开始正文，我会尽最大努力描述得浅显易懂。_

<span style="background-color:#99ccff;"><strong>RSS是做什么的?</strong></span>

RSS大叔是哪来的我暂且不谈，看名字就知道丫是走技术路线很专业的老外，我们只要弄明白RSS大叔能提供什么服务就成，它叫RSS还是叫XSS都可以无视。

**<span style="background-color:#99ccff;">基于RSS的订阅 VS 打开网页的浏览</span>**

  *  <span class="entry-content">网站就是报刊亭，网上信息就是报纸。打开网站浏览就是去报刊亭买报纸，最新的报纸还可能没来，白跑一趟。太忙的时候没时间去报刊亭，报纸错过就看不到了。</span>

  * <span class="entry-content">报纸有订阅一说，网上信息能订阅吗？当然能，只要有咱RSS大叔。</span><span class="entry-content">注册RSS阅读器就是在你家门口钉了个信箱</span><span class="entry-content">，邮递员是谁呢？就是RSS大叔</span><span class="entry-content">。邮递员会把你要的报纸塞到你家信箱去，你打开信箱就可以取下报纸看，省了去报刊亭的麻烦过程，和去早了的尴尬；你不开信箱，报纸会存在那里，绝对不会错过或丢失。</span>

<!--more-->

**<span style="background-color:#99ccff;">“邮递员”RSS大叔带来的好处</span>**

OK，你知道啦！RSS大叔是做邮递员的！每天早上你能收到报纸，都是因为RSS大叔在默默无闻的工作。好处是显而易见的：

将**主动**的信息搜求——上网站浏览，转变为了**被动**的信息收取——RSS订阅。

信息自动送上门的感觉肯定是无比畅快的。更细化的好处，请参看另一文《[为什么要用线上RSS阅读器？][1]》。

**<span style="background-color:#99ccff;">怎么雇用RSS大叔，学会RSS订阅？</span>**

aw师兄<a title="RSS入门及订阅指南" href="http://www.awflasher.com/blog/rsshelp" target="_blank">说的好</a>：

> 就我的经验，要想理解RSS，最好先**抛开**那些复杂的英文缩写和学术概念；同时，自己亲自使用RSS周边的产品和服务。经过一段时间的使用、体验之后，再回过头去分析它更多的理论含义和应用价值。

再加上我鼓吹了半天，你也该想尝试一下了吧？不试不知道嘛，是该揭晓RSS三元素的时候了。
  
<img style="float: right; margin-left: 10px; margin-right: 10px;" src="http://pic.yupoo.com/xcchris/6550458422a9/lqm2u5md.jpg" alt="RSS标志" />

  1. **RSS标志**
  
    具备RSS标志的网站，最直观得表明其支持RSS。你可以在本站找到大量[RSS标志的漂亮设计][2]。
  2. **RSS feed**
  
    RSS标志上的链接，一般即为站点的RSS地址，亦称feed。如何寻找RSS feed，[请看这里][3]。
  3. **RSS阅读器**
  
    实现RSS订阅的地方，比如Google Reader、抓虾、鲜果等在线阅读器服务。使用指南参见《[如何利用Google Reader订阅blog][4]》、《[如何利用抓虾订阅blog][5]{#r_l_2}》、《<a title="如何使用鲜果订阅博客" href="../2008/07/xianguo/" target="_self">如何使用鲜果订阅博客</a>》。

看了这些，想必你对RSS订阅已略知一二。其实现在的阅读器更智能，它们基本都会自动分析你提交的页面是否含有RSS feed，所以让RSS大叔为你效劳是很简单的。还有不明白的，可以到《**<a title="RSS普及教程系列" href="http://www.xuchi.name/blog/tutorial/" target="_self">RSS应用普及教程系列</a>**》找找答案。

**<span style="background-color:#99ccff;">RSS大叔的未来</span>**

  * 多元化递送
除了新闻消息的递送工作外，RSS大叔也许会实时递送更多的东西，诸如股市行情、促销信息、供求信息、商品价格、图书借阅状态等等等等，他将全面服务于我们生活的方方面面。

  * 后台式工作
RSS大叔将更加默默无闻。也许未来人们理所当然得获取信息之时，根本不知道在后台，在底层，有这么一位叫RSS的大叔在为他们工作。</ul> 

**<span style="background-color:#99ccff;">RSS大叔的身世</span>**

好吧。既然你都看到这里了，我就偷偷透漏点RSS大叔的身世给你：RSS他很年轻的哦。

  * <a href="http://baike.baidu.com/view/1644.htm" target="_blank">RSS 百度百科</a>
  * <a href="http://zh.wikipedia.org/wiki/RSS" target="_blank">RSS wikipedia-zhCN</a>
  * <a href="http://cyber.law.harvard.edu/rss/rss.html" target="_blank">RSS 2.0 Specification</a>
  * <a href="http://web.resource.org/rss/1.0/spec" target="_blank">RDF Site Summary (RSS) 1.0<br /> </a>

<span style="background-color:#99ccff;"><strong>结语</strong></span>

在国内，RSS依然是小众的玩物，很难发出光亮，特别是在追求娱乐和流量的大环境下。但作为能够有效获取信息，提高效率的工具，RSS应用在被不断的介绍着推广着。希望本文的介绍能增进大家对RSS的了解，不多说了，用过才知道，不看广告看疗效！

 [1]: http://www.xuchi.name/blog/2007/11/why-do-we-need-rss-reader/ "为什么要用线上RSS阅读器？"
 [2]: http://www.xuchi.name/blog/tag/icon/ "RSS标志的漂亮设计"
 [3]: http://www.xuchi.name/blog/2007/03/rss-address/ "如何寻找RSS地址"
 [4]: ../2007/02/21/google-reader/ "如何利用Google Reader订阅blog"
 [5]: ../2007/02/24/zhuaxia/ "如何利用抓虾订阅blog"