---
title: 宿舍楼下惊现雪地表白 和谐校园初见建设成效
author: Chouj
type: post
date: 2007-01-18T01:55:00+00:00
url: /2007/01/18/say-love-in-snowfield/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/01/blog-post_18.html
views:
  - 2750
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969843
categories:
  - 我表达
tags:
  - 图片
  - 恶搞

---
<span style="font-size:180%;"><span style="font-weight: bold;">日</span></span>前，于本不老歌刊发一文《[创意表白 雪之源][1]》吸引诸多学子注目，本报社予以高度关注，特刊发社论如下：

<span style="font-size:180%;"><span style="font-weight: bold;">据</span></span>记者实地采访调查，该照片拍摄于某高校女生宿舍湖滨×舍，留下脚印表白的当事人为该高校××级MM。MM告诉记者，时遇大雪，即在雪地上踩出此番字样，用相机拍下，发给男友，以用此特别的方式寄语情意；脚印在宿舍楼的内部，既不会引起广泛的注意，也不易遭到破坏。

<span style="font-size:180%;"><span style="font-weight: bold;"> 本</span></span>报认为，当事人MM的表白方式，彰显了当代女大学生追求幸福的决心，聪颖别致又不显招摇媚俗，实属上乘之作。party中央认为，大学生是时代的精英，要实现构建和谐社会的构想，必先实现和谐校园。MM正是以其实际行动表明：当代校园内，女性地位得到普遍提高，女性意识逐渐唤醒，女性追求自身权利和幸福的能力普遍增强。众所周知，男女平等是社会团结稳定和谐进步的基石，可见，和谐校园和谐社会的建设已经收到了成效。

<span style="font-size:180%;"><span style="font-weight: bold;">据</span></span>调查表明，当代大学生在情感表达方面的花销日渐高昂，动辄成百上千，恋爱俨然成为消费品、奢侈品。殊不知，玫瑰花会凋谢巧克力会消灭，烛光造势污染大气，更为恶劣。而当事人MM的表白方式，尽显雅致与格调：雪花纵然会融化（注：和玫瑰一样最后死无对证），但以雪之白象征爱之纯，以雪之痕寓意爱之深，一切天意所至，佳偶天成；却又不费一分一离、一笔一墨，与“构建节约型校园”不谋而合，愈发值得向广大院校，尤其北方高校，乃至全社会广泛推广，深入学习。

<span style="font-size:180%;"><span style="font-weight: bold;">本</span></span>报特号召广大在校未婚男女青年，以MM为榜样，将满腔热情投入“和谐校园，和谐社会”的建设中来，共同打造“和谐表白”！

<div style="text-align: center;">
  ＝＝＝＝＝＝＝＝＝＝＝＝广告＝＝＝＝＝＝＝＝＝＝＝＝
</div>

<div style="text-align: center;">
  友情提醒：情网有风险 入网请交钱（中国移不动）
</div>

<div style="text-align: center;">
  ＝＝＝＝＝＝＝＝＝＝＝＝广告＝＝＝＝＝＝＝＝＝＝＝＝
</div>

<div style="text-align: right;">
  新华干报社 评论员 Chris</p> 
  
  <div style="text-align: left;">
    <span style="color: #666666;"><br /> 原创e搞，沙发自己坐，附赠PS图一张：顶贴也和谐</span></p> 
    
    <p>
      <a href="http://bp0.blogger.com/_2MqU1LfBbeM/Ra7WOso2PdI/AAAAAAAAAB4/vuNHyr1ySSc/s1600-h/DSC03839.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5021186182553681362" style="cursor: pointer;" src="http://bp0.blogger.com/_2MqU1LfBbeM/Ra7WOso2PdI/AAAAAAAAAB4/vuNHyr1ySSc/s400/DSC03839.jpg" border="0" alt="" /></a>
    </p>
  </div>
</div>

 [1]: http://xcchris.blogspot.com/2007/01/blog-post_16.html