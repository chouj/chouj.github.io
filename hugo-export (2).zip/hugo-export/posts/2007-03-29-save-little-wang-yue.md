---
title: 救助小王越 Feedsky的力量
author: Chouj
type: post
date: 2007-03-29T03:05:00+00:00
url: /2007/03/29/save-little-wang-yue/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/feedsky.html
views:
  - 2185
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969870
categories:
  - 我表达
tags:
  - feedsky
  - 公益
  - 小王越

---
<span style="font-size:180%;"><span style="FONT-WEIGHT: bold">接</span></span>受<a href="http://beta.feedsky.com/" target="_blank">Feedsky</a>话题广告之后，我就在想，全国同类型服务仅Feedsky一家，如我一般趋利而又要尝鲜的blogger绝对不少，所以，基本上全国Blogosphere统一话题的时刻指日可待(刚看见GG有一篇，名字叫<a href="http://ggpi.blogspot.com/2007/03/blog-post_29.html" target="_blank">广告:满城尽是小王越</a>)。最近在对<a href="http://twitter.com/" target="_blank">Twitter</a>的描述上，我见过一个词“Blog界病毒式传播”，Feedsky指定出的话题，无疑拥有了这个力量。不妨调侃一下，2008年8月8日8时，Feedsky说大家都写篇关于奥运的宣传广告吧，然后举国河山一片“和谐”，与“奥运”相关的页面数激增，全世界Bloggers注视中国Blogosphere，胡core拉着吕帅的手感激涕泠，何其壮观。当然，这样的事不大可能发生，因为feedsky说：“我们更希望你能站在中立的角度上对产品进行评价”。

<span style="font-size:180%;"><span style="FONT-WEIGHT: bold">调</span></span>侃归调侃，拥有力量，就要善用力量，不禁想到<a href="http://www.douban.com/subject/1766546/" target="_blank">Gundam Seed</a>中的Kira和Lacus，这对儿一定能对这一观点滔滔不绝。那么，Feedsky的这股力量呢，在商业上无疑极大的造福了广告商；在公益事业上也必将汇成一股爱心洪流。而力量运用的第一次，Feedsky选择了后者，这次公益事件的关键词是：王越。

<a href="http://www.help1by1.com/attachments/month_0606/9200668133625.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img style="DISPLAY: block; MARGIN: 0px auto 10px; WIDTH: 400px; CURSOR: pointer; TEXT-ALIGN: center" src="http://www.help1by1.com/attachments/month_0606/9200668133625.jpg" border="0" alt="" /></a>
  
<span style="font-size:180%;"><span style="FONT-WEIGHT: bold">她</span></span>是一名7岁的小女孩儿，虽然我不认识她，只通过网络对她有所了解，但我相信，她能为仅有10平米的打工家庭带来了无上的欢乐，她理应和所有天真快乐的儿童一样茁壮成长。但上天并没有对这个可爱的孩子些许眷顾，小王越不幸患上了白血病（急性髓系白血病(M2a)），18个月的治疗给这个经济拮据的家庭带来了巨大的负担，18个月的病痛同样让小王越尝尽健康人从未体验过的苦楚。写到这里我很惭愧，单单那常人未曾经受的折磨，就足够让人头皮发麻，心生怜意，可我，经常以翻零钱麻烦为借口，漠然经过校园中与我更近的爱心捐赠箱。这次，没有理由再次漠视，这次我选择声援。

<a href="http://bp3.blogger.com/_2MqU1LfBbeM/RgtSYoGgNtI/AAAAAAAAAHA/26zl4OI7QRM/s1600-h/msn.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5047218390433806034" style="FLOAT: left; MARGIN: 0pt 10px 10px 0pt; CURSOR: pointer" src="http://bp3.blogger.com/_2MqU1LfBbeM/RgtSYoGgNtI/AAAAAAAAAHA/26zl4OI7QRM/s400/msn.jpg" border="0" alt="" /></a>关于小王越的详细资料，您可以参看<a href="http://helpwy.com/" target="_blank">MSN爱心签名活动官方页面</a>和<a href="http://beta.feedsky.com/wangyue" target="_blank">Feedsky的专题页面</a>。

您可以简单的通过添加MSN爱心签名“<span style="color: blue;">(L)救助小王越&#8211;www.helpwy.com</span>”，即可为王越募集善款， 每完成一次MSN爱心签名，您就为小王越多筹集了5分钱。<a style="FONT-WEIGHT: bold" href="http://www.helpwy.com/joinActivity.do" target="_blank">具体页面见此</a>

您也可以直接捐款：

**银行卡捐款**：

招商银行捐款帐号：6225881006799372 姓名：张俊霞（王越妈妈） （支持网上转帐）

工商银行捐款帐号：6222020200001780820 姓名：王喜海（王越爸爸） （支持网上转帐）

<a style="FONT-WEIGHT: bold" href="http://www.helpwy.com/juankuan.jsp" target="_blank">具体页面见此</a>

<span style="font-size:180%;"><span style="FONT-WEIGHT: bold">在</span></span>全国诸多媒体、单位和个人的支持下，再经过Feedsky广告平台的全网域发布，可以想象，这样一次善举将有多么强大的宣传力度，从这个角度说，小王越是幸运的。我想Feedsky在话题发布时的愿望：

> 我们希望以这种形式，呼唤中国Blogosphere的爱心，让小王越能够在面对病魔的时候更有信心，更有力量。

定能得到实现。这也促使我思考另一个问题，Feedsky是不是在时机成熟之后，即获得广泛的号召力之后，<span style="FONT-WEIGHT: bold">把公益活动从商业广告中剥离出来</span>，即打造两个号召平台，一个全商业广告，一个全爱心活动。现在的情况是，公益广告有点像是隐藏在人们趋利的心理之下，虽然能获得宣传最大化，但好像欠缺力量的纯净。另外，以空前的号召力，搭起一个爱心活动平台，利于爱心活动的统一宣传，也利于其Feedsky的公司形象。我不是Feedsky，我提出这个idea完全没有顾及任何一家公司都要获利这一基本原则，不过剽窃idea等于犯罪，哈哈，声明一下。

**<span style="font-size:180%;">同</span>**样是声援，但多一个无妨。强烈无条件支持非典型愤青Zola对重庆“维权户”的独家探访和报道，虽然他的网志已经不大能正常打开，但还是给出[链接][1]。按龙应台野火集的观点，咱社会就是缺少Zola、吴苹、杨武这样的人。转张照片，Zola著名的左手自拍，吴苹和Zola！
  
<img src="http://photo5.fotolog.net.cn/userimages/87/19/z/zola/74/240_2nx5PvRs.jpg" border="0" alt="" />

<span style="font-size:180%;"><span style="FONT-WEIGHT: bold">最</span></span>后要说：非常抱歉在这篇本应煽情的广告中，太多的以类似商家的眼界讨论问题，附加跑题，比较冷酷和无情。但我只是想诚实的“承载思想的青涩”，顺便测试下Feedsky对文章的评审尺度，而且，谁让Feedsky把公益广告和商业广告杂糅到一个平台去了，请允许我声援王越的同时，开开小差，:)

<a href="http://ad.feedsky.com/ads/feedsky/chrischou/~/txt/18/r.html" target="_blank"><img style="BORDER-RIGHT: 0pt; BORDER-TOP: 0pt; BORDER-LEFT: 0pt; BORDER-BOTTOM: 0pt" src="http://ad.feedsky.com/ads/feedsky/chrischou/%7E/img/18/cw.gif" alt="" /></a>

 [1]: http://www.zuola.com/weblog/?p=750