---
title: Feed助推新贵FeedCat.net图解
author: Chouj
type: post
date: 2008-07-30T17:42:48+00:00
url: /2008/07/31/feedcat-net/
views:
  - 1898
  - 1898
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970014
categories:
  - 教程
  - 新闻
tags:
  - FeedCat

---
_<a href="http://dupola.com/post/235#comment-6189" target="_blank">吕老大的留言</a>让我觉得有种“FeedBurner残废、FeedSky下跪”的意味，国情如此，不好苛求。<a title="FEEDCAT.NET RSS和Atom Feed 助推引擎" href="http://www.feedcat.net/zh-cn/" target="_blank">FeedCat</a>恰巧来了，救市与否尚不可知，但，很珍贵。_

<a title="FEEDCAT.NET RSS和Atom Feed 助推引擎" href="http://www.feedcat.net/zh-cn/" target="_blank"><img src="http://www.feedcat.net/i/logo.gif" alt="FeedCat.NET RSS 和 Atom Feed助推系统" width="340" height="43" /></a>

**<a title="FEEDCAT.NET RSS和Atom Feed 助推引擎" href="http://www.feedcat.net/zh-cn/" target="_blank">FeedCat</a>**是最近上线，提供Rss Feed托管服务的一个站点。一眼看去，<a title="FEEDCAT.NET RSS和Atom Feed 助推引擎" href="http://www.feedcat.net/zh-cn/" target="_blank">FeedCat</a>这只猫有什么特色的地方吗？

  * 像FeedBurner！
  * 站点语言支持中文！
  * 语言特色：Feed助推引擎！Feed Boost！ 不是Burn了。

上首页截图：

<a title="FeedCat首页截图 点击看大图" href="http://pic.yupoo.com/xcchris/293335f2014b/egs4zw7b.jpg" target="_blank"><img src="http://pic.yupoo.com/xcchris/293335f2014b/egs4zw7b.jpg" alt="FeedCat.NET RSS 和 Atom Feed助推系统" width="468" /></a>

<!--more-->

可以看出，<a title="FEEDCAT.NET RSS和Atom Feed 助推引擎" href="http://www.feedcat.net/zh-cn/" target="_blank">FeedCat</a>首页比较类似FeedBurner的首页布局，这对于FeedBurner用户来说是挺亲切的。“Feed助推”这个翻译也很传神，我们来仔细看看猫猫是怎么助推的吧，下面来到“我的Feed”页面：

[<img src="http://pic.yupoo.com/xcchris/343245f40871/l4kfoix1.jpg" alt="我的Feed FeedCat.net" width="468" />][1]

在中间输入框填写要助推（烧制）的原始Feed地址，就可以开始Feed助推之旅啦。为什么要用他们的助推服务呢，这只猫这样说：

> FEEDCAT.NET 主要致力于助推（Boost） Feed。何为”助推“，为何”助推“：
> 
> <ul class="std matov">
>   <li>
>     助推的 Feed 更易读，且用户界面友好
>   </li>
>   <li>
>     助推的 Feed 内容会得到我们搜索引擎的推介
>   </li>
>   <li>
>     助推的 Feed 可以添加标记，更易寻找
>   </li>
>   <li>
>     助推的 Feed 使用合法的 XML 语法
>   </li>
>   <li>
>     我们是助推 Feed 的衡量读者
>   </li>
>   <li>
>     我们节省您服务器资源的负载
>   </li>
>   <li>
>     接管您 Feed 内容的完整控制
>   </li>
> </ul>

挺不错吧，助推一把好了！

[<img src="http://pic.yupoo.com/xcchris/329545f40bd5/ke2mfqan.jpg" alt="助推Feed编辑" width="468" />][2]

这样我们就拥有了一个有猫推的新Feed，来看看这只猫都提供什么服务吧：

<img src="http://pic.yupoo.com/xcchris/117495f41309/fbplfcyx.jpg" alt="FeedCat 侧栏" width="176" height="463" />

很全乎，但是有两个”概要“，估计是翻译疏忽，先看第一个：

[<img src="http://pic.yupoo.com/xcchris/828015f41309/hdfhbo9e.jpg" alt="概要 Feedcat" width="468" />][3]

这里有Feed最基本的一些信息。再看”统计“：

[<img src="http://pic.yupoo.com/xcchris/955285f41309/9pgymlm5.jpg" alt="统计 Feedcat" width="468" />][4]

这里有一些需要注意的问题：从图来看，订阅量是按天统计的，但是下面的注释则是以周为单位统计；”被阅读次数“是个很有意思的统计量，似乎跟阅读行为有关，尚不知是如何统计的；FeedCat并没有提供订阅来源的统计。

[<img src="http://pic.yupoo.com/xcchris/843225f4130b/yzs968t7.jpg" alt="详细资料 FeedCat" width="468" />][5]

”详细资料“页也就是Feed基本资料，来看下一个”概要“：

[<img src="http://pic.yupoo.com/xcchris/092245f4130b/uupqq35u.jpg" alt="概要 二 FeedCat" width="468" />][6]

似乎这里应该是”详细资料“才对，Feed内容获取频率的调整，Adult与否，ping服务，标题or全文，都可以在这里设置。

[<img src="http://pic.yupoo.com/xcchris/451095f417d1/wao1lkiu.jpg" alt="标签 FeedCat" width="468" />][7]

FeedCat为每个Feed都配备了TAG系统。

[<img src="http://pic.yupoo.com/xcchris/202645f417d1/3dpixm3t.jpg" alt="控制 FeedCat" width="468" />][8]

”控制“页是为了Feed重定向和删除准备的。接着是”特别功能“列：

[<img src="http://pic.yupoo.com/xcchris/048935f417d1/93sliliy.jpg" alt="条目点击追踪 FeedCat" width="468" />][9]

”条目点击追踪“就是Item Track”功能，追踪Feed值Site的点击量。

[<img src="http://pic.yupoo.com/xcchris/230195f417d0/zf5xnivt.jpg" alt="外观 FeedCat" width="468" />][10]

在“外观”页，挑选喜欢的Feed页配色。

[<img src="http://pic.yupoo.com/xcchris/841675f417d1/891df5vm.jpg" alt="订阅选项 FeedCat" width="468" />][11]

选择Feed页上的订阅按钮，FeedCat没有提供代码生成功能。

[<img src="http://pic.yupoo.com/xcchris/851825f41b02/m8dwlcyw.jpg" alt="网站图标 FeedCat" width="468" />][12]

”网站图标“这里可以找到订阅量贴图，但FeedCat提供的统计是以周为单位的，是过去一周的订阅量。

介绍完毕。从表面看，我还是非常满意FeedCat这个新的托管服务的，希望其更新速度也能有上佳表现，各位不妨一试：

[ **<a title="FeedCat 中文" href="http://www.feedcat.net/zh-cn/" target="_blank">点此进入 FeedCat.net</a>** ]

欢迎订阅[RSS相关][13]由FeedCat助推的Feed：

[ <a title="RSS相关 FeedCat助推Feed" href="http://feed.feedcat.net/RSS" target="_blank">Feed.FeedCat.net/RSS</a> ]

 [1]: http://pic.yupoo.com/xcchris/343245f40871/l4kfoix1.jpg "我的Feed FeedCat.net 点我看大图"
 [2]: http://pic.yupoo.com/xcchris/329545f40bd5/ke2mfqan.jpg "助推Feed编辑 点我看大图"
 [3]: http://pic.yupoo.com/xcchris/828015f41309/hdfhbo9e.jpg "概要 FeedCat 点我看大图"
 [4]: http://pic.yupoo.com/xcchris/955285f41309/9pgymlm5.jpg "统计 FeedCat 点我看大图"
 [5]: http://pic.yupoo.com/xcchris/843225f4130b/yzs968t7.jpg "详细资料 FeedCat 点我看大图"
 [6]: http://pic.yupoo.com/xcchris/092245f4130b/uupqq35u.jpg "概要 二 FeedCat 点我看大图"
 [7]: http://pic.yupoo.com/xcchris/451095f417d1/wao1lkiu.jpg "标签 FeedCat 点我看大图"
 [8]: http://pic.yupoo.com/xcchris/202645f417d1/3dpixm3t.jpg "控制 FeedCat 点我看大图"
 [9]: http://pic.yupoo.com/xcchris/048935f417d1/93sliliy.jpg "条目点击追踪 FeedCat 点我看大图"
 [10]: http://pic.yupoo.com/xcchris/230195f417d0/zf5xnivt.jpg "Feed外观 FeedCat 点我看大图"
 [11]: http://pic.yupoo.com/xcchris/841675f417d1/891df5vm.jpg "订阅选项 FeedCat 点我看大图"
 [12]: http://pic.yupoo.com/xcchris/851825f41b02/m8dwlcyw.jpg "网站图标 FeedCat 点我看大图"
 [13]: http://aboutrss.cn