---
title: '[ppt下载]如何利用”RSS”定制相关的学术资源'
author: Chouj
type: post
date: 2008-05-08T07:03:16+00:00
url: /2008/05/08/ppt-rss-apply-for-academy/
views:
  - 1826
  - 1826
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970001
categories:
  - 教程
  - 知识
tags:
  - Academic
  - Download
  - PPT
  - Tutorial

---
<img class="alignleft" style="float: left;" src="http://pic.yupoo.com/xcchris/6931659095ff/olk23ml2.jpg" alt="如何利用RSS定制相关的学术资源" width="256" height="256" />早些时候我在以“RSS 图书馆”为关键字搜索时，看到了**南开大学图书馆信息部邓克武老师**的一个讲座，题为“<span class="style17"><span class="style21"><a title="讲座通知" href="http://www.lib.nankai.edu.cn/news/tongzhi20.htm" target="_blank"><strong>如何利用&#8217;RSS&#8217;定制相关的学术资源</strong></a>”，深感惊奇。因为我</span></span><span class="style17"><span class="style21">之前有浅显得讨论<a title="学术领域的RSS应用" href="http://aboutrss.cn/2008/03/05/rss-apply-for-academic/" target="_self">学术领域的RSS应用</a>，且最近</span></span><span class="style17"><span class="style21">也在思考高校在RSS普及上的作用，而高校开展这类性质的宣讲还真是我第一次见到，但愿是我孤陋寡闻或这类信息没有上网。</span></span>

我立即联系上了邓老师，邓老师给了我讲座的课件ppt，并允许我发布出来。在这里我要感谢热心的邓老师，这类ppt材料是少有而可贵的。

该PPT面向RSS的初识者，以文字和图示结合的形式涵盖了RSS的概念、用途、价值和优势、订阅的方法以及学术资源信息的获取渠道。

**下载地址**：<a title="ppt download via Box.net" href="http://www.box.net/shared/8olmym60w4" target="_self">Box下载</a> | <a title="ppt download via Nankai Library online" href="http://www.lib.nankai.edu.cn/nav/main/upload/upfile/RSS.pps" target="_self">南开大学图书馆线上下载</a>

**ppt版权归作者——南开大学图书馆信息部邓克武老师所有！**