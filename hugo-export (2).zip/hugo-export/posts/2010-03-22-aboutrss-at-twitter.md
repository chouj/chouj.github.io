---
title: 转至Twitter发布RSS的相关信息
author: Chouj
type: post
date: 2010-03-22T14:17:33+00:00
excerpt: 本站职能也无外乎把美味书签（delicious.com）里rss/feed tag下的最新东西罗列至此，目前想来，还不如在Twitter写140字畅快。遂经由TwitterFeed自动发布美味书签（delicious.com）里rss/feed tag下条目于@aboutrss。欢迎发喽，本人id @chouj 亦会不时RT @aboutrss的消息并作简短注解。
url: /2010/03/22/aboutrss-at-twitter/
views:
  - 2436
  - 2436
duoshuo_thread_id:
  - 1279764464521970048
categories:
  - 相关
tags:
  - RSS
  - twitter

---
本站职能也无外乎把美味书签（delicious.com）里rss/feed tag下的最新东西罗列至此，目前想来，还不如在<a title="Twitter" href="https://twitter.com" target="_self">Twitter</a>写140字畅快。遂经由TwitterFeed自动发布<a title="RSS tag @ Delicious" href="http://feeds.delicious.com/v2/rss/tag/rss?count=15" target="_self">美味书签（delicious.com）里rss/feed tag下条目</a>于<a title="aboutrss@twitter" href="https://twitter.com/aboutrss" target="_self">@aboutrss</a>。欢迎发喽，本人id @chouj 亦会不时RT @aboutrss的消息并作简短注解。

<img src="http://pic.yupoo.com/xcchris/0364690aeee4/41jq1trx.jpg" border="0" alt="RSS to Twitter" width="500" />