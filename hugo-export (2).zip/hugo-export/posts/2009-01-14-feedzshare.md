---
title: FeedzShare：“中文版”的ReadBurner
author: Chouj
type: post
date: 2009-01-14T15:09:02+00:00
url: /2009/01/14/feedzshare/
views:
  - 2003
  - 2003
duoshuo_thread_id:
  - 1279764464521970033
categories:
  - 工具
tags:
  - FeedzShare
  - Filter
  - Google Reader
  - 国内

---
<img style="float: left; margin-left: 10px; margin-right: 10px;" src="http://pic.yupoo.com/xcchris/214316d1520a/pxsblws4.jpg" alt="FeedzShare：“中文版”的ReadBurner" width="224" height="50" align="left" />水煮鱼[最近有提到][1][ReadBurner][2](一家按Google Reader分享人数进行信息热度排行的服务)，大意是由于[Google Reader][3]不像[鲜果][4]、[抓虾][5]和[九点][6]那样做类似于“热文”的信息Digg，所以才让[ReadBurner][2]有机可乘。可是ReadBurner是针对分享的英文信息条目的，不适合国人，有没有中文内容的shared items热度排行服务呢？有，但不是ReadBurner真对中文用户的产品，而是本文的主人公：<a title="FeedzShare：“中文版”的ReadBurner" href="http://www.feedzshare.com" target="_blank">FeedzShare</a>，由<a href="http://www.cnblogs.com/kuber/" target="_blank">Jeff</a>出品。

<!--more-->

我喜欢FeedzShare的原因在于：

  1. 她不仅像ReadBurner一样，可以见到背后分享该条目的ID；
  2. 而且她根据“最新”、“三天”、“七天”来进行时间尺度上的热分享信息过滤；
  3. 再者，过滤后的条目列表，提供RSS输出，方便人们订阅这种经过热度筛选后的信息；
  4. 最后，有“内容快照”功能，直接浏览全文，虽然这样到达条目真正页面的流量会少不少。

上截图：

<img src="http://pic.yupoo.com/xcchris/534786d1520a/z6c22xd1.jpg" alt="FeedzShare：“中文版”的ReadBurner" width="468" height="806" />

想详细了解FeedzShare的话，不妨去看首页右上角的”关于“；也可以在首页右侧栏直接给开发者留言。

[ **<a title="FeedzShare" href="http://www.feedzshare.com" target="_blank">点此进入FeedzShare</a>** ]

 [1]: http://fairyfish.net/2009/01/09/from-douban-9-to-rss/
 [2]: http://www.readburner.com
 [3]: https://www.google.com/reader
 [4]: http://www.xianguo.com
 [5]: http://www.zhuaxia.com
 [6]: http://9.douban.com