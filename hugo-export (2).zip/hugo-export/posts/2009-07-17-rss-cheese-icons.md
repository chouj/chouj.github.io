---
title: '[下载]RSS奶酪图标'
author: Chouj
type: post
date: 2009-07-17T14:56:42+00:00
excerpt: 新鲜奶酪RSS图标一套
url: /2009/07/17/rss-cheese-icons/
views:
  - 1591
  - 1591
duoshuo_thread_id:
  - 1279764464521970043
categories:
  - 标志
tags:
  - Download
  - Icon
  - RSS设计

---
<img src="http://pic.yupoo.com/xcchris/064227c404f8/hhu9qbtt.jpg" border="0" alt="" width="468" />

新鲜奶酪RSS图标一套

格式：png
  
大小：512&#215;512, 256&#215;256, 128&#215;128 and 64&#215;64
  
使用：free 无限制

预览：

<img src="http://pic.yupoo.com/xcchris/758907c404c0/crank0u8.jpg" border="0" alt="" width="468" />

**来源和下载**：<a title="RSS奶酪图标" href="http://www.jankoatwarpspeed.com/post/2009/06/30/rss-cheese-free-icons.aspx" target="_blank">RSS Cheese &#8211; A free icon set you can taste</a>