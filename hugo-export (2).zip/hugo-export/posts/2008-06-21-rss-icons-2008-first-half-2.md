---
title: 08上半年出炉的RSS图标精选（二）
author: Chouj
type: post
date: 2008-06-20T18:34:43+00:00
url: /2008/06/21/rss-icons-2008-first-half-2/
views:
  - 1409
  - 1409
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970009
categories:
  - 标志
tags:
  - button
  - Download
  - Graph
  - Icon
  - RSS设计
  - Subscribe
  - Symbol

---
_08上半年精选RSS图标系列继续登场，特开辟出投票环节，选出每期你最喜欢的RSS标志设计吧，期待08上半年最受欢迎RSS标志十强的出炉。<a title="08上半年出炉的RSS图标精选（一）" href="http://aboutrss.cn/2008/06/rss-icons-2008-first-half-1/" target="_self">上一期</a>已经添加投票系统啦，赶紧补选哈～光看预览图是不行滴，下载下来看原图才是正道！_
  
[poll id=&#8221;3&#8243;]

  * 2008.05.04 <a title="RSS feed 17 icons-sign v1.0" href="http://coroud.deviantart.com/art/RSS-feed-17-icons-sign-v1-0-84684288" target="_blank"><strong>RSS feed 17 icons-sign v1.0</strong></a>

<img src="http://pic.yupoo.com/xcchris/087045bf55ba/tb9151ia.jpg" alt="RSS feed 17 icons-sign v1.0" width="400" height="800" />
  
<!--more-->

  * 2008.05.18 **<a title="Rss icons by ~jinsona" href="http://jinsona.deviantart.com/art/Rss-icons-85984718" target="_blank">Rss icons by ~jinsona</a>**

<img src="http://pic.yupoo.com/xcchris/531125bf55ba/vtn2eol0.jpg" alt="Rss icons by ~jinsona" width="300" height="240" />

  * 2008.05.31 <a title="RSS图标 SweetOrange" href="http://flashgc.deviantart.com/art/SweetOrange-87281257" target="_blank"><strong>SweetOrange</strong></a>

<img src="http://pic.yupoo.com/xcchris/597135bf55bb/3szrk3el.jpg" alt="SweetOrange" width="300" height="165" />

  * 2008.05.29 <a title="RSS Pack Free PSD Icons by ~Grafon" href="http://grafon.deviantart.com/art/RSS-Pack-Free-PSD-Icons-87093551" target="_blank"><strong>RSS Pack Free PSD Icons by ~Grafon</strong></a>

<img src="http://pic.yupoo.com/xcchris/905405bf55ba/sv2xwo4c.jpg" alt="RSS Pack Free PSD Icons by ~Grafon" width="200" height="500" />

  * 2008.05.03 <a title="JD RSS Icons by ~z-dark" href="http://z-dark.deviantart.com/art/JD-RSS-Icons-84671734" target="_blank"><strong>JD RSS Icons by ~z-dark </strong></a>

<img src="http://pic.yupoo.com/xcchris/940015bf55ba/90o4ej7u.jpg" alt="JD RSS Icons by ~z-dark" width="300" height="320" />

  * 2008.05.02 <a title="RSS Stamps by ~tayzar44" href="http://tayzar44.deviantart.com/art/RSS-Stamps-84498504" target="_blank"><strong>RSS Stamps by ~tayzar44</strong></a>

<img src="http://pic.yupoo.com/xcchris/589775bf6a76/ny68kowv.jpg" alt="RSS Stamps by ~tayzar44" width="429" height="377" />

  * 2008.05.01 [**IconTexto WebDev by ~IconTexto**][1]

![IconTexto WebDev by ~IconTexto][2]

  * 2008.05.01 **[Free Subscribe Me PSD Buttons][3]**

<img src="http://pic.yupoo.com/xcchris/999535bf6a76/yn375ggm.jpg" alt="Free Subscribe Me PSD Buttons" width="468" height="468" />

  * 2008.04.26 **[6 Feed RSS Logos by ~sedazza][4]**

![6 Feed RSS Logos by ~sedazza][5]

  * 2008.04.20 **[Rss 1 by ~flugv1][6]**

![Rss 1 by ~flugv1][7]

 [1]: http://icontexto.deviantart.com/art/IconTexto-WebDev-84413719 "IconTexto WebDev by ~IconTexto"
 [2]: http://pic.yupoo.com/xcchris/876935bf6a76/c09gwjp4.jpg
 [3]: http://grafon.deviantart.com/art/Free-Subscribe-Me-PSD-Buttons-84407927 "Free Subscribe Me PSD Buttons"
 [4]: http://sedazza.deviantart.com/art/6-Feed-RSS-Logos-83937907 "6 Feed RSS Logos by ~sedazza"
 [5]: http://pic.yupoo.com/xcchris/628895bf6a76/2itjotul.jpg
 [6]: http://flugv1.deviantart.com/art/Rss-1-83418067 "Rss 1 by ~flugv1"
 [7]: http://pic.yupoo.com/xcchris/497565bf6a76/9f4bz7by.jpg