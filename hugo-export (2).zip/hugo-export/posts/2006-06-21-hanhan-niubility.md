---
title: “韩寒挺牛逼的”
author: Chouj
type: post
date: 2006-06-21T13:00:24+00:00
url: /2006/06/21/hanhan-niubility/
views:
  - 1525
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969890
categories:
  - 我表达
tags:
  - 生活
  - 韩寒

---
<div class="contant">
  <p>
    <span style="font-size: small;"> 从 <a href="http://www.wangxiaofeng.net/" target="_blank">带三个表</a> 的一篇《<a href="http://www.wangxiaofeng.net/?p=154" target="_blank">韩寒谈粉丝</a>》里，看见了韩寒一首歌《偶像》的歌词，果真如 带三个表 所说，韩寒“蔑视规矩和规则”，“彻底和发自骨子里的叛逆”，还有就是“韩寒挺牛逼的”。</span>
  </p>
  
  <p>
    <span style="font-size: small;">韩寒歌词《偶像》</span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">安静舒缓不见   人类动荡妖艳<br /> 欠揍的出现     开始放电    他怎么不触电</span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">偶像露出嘴脸   英雄开始下贱<br /> 所谓的尊严  不值一钱  你竟以此共勉</span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">上帝派出和平鸽  却被人类做汤喝  别啦  投胎快乐</span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">没有偶像的年代  万物一年被淘汰  人们礼尚往来  内心却很坏   啦啦<br /> 这是最好的年代  充斥最烂的情怀  孩子难免受害  再给下一代<br /> 我最怀念某年  空气自由新鲜<br /> 远山和炊烟  狗和田野  我沉睡一夏天 </span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">突然满眼的工业  麻木代替热血<br /> 永别  把我消灭</span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">我最心底的姑娘  她已模糊不成样 请安息在脑海  让年岁掩埋  啦啦<br /> 没有信仰的年代  我们等着被变卖 我们只会发呆  发成了痴呆  啦啦<br /> 这是最好的年代  充斥最假的情爱 噪音变成天籁  金钱换来爱  拉拉<br /> 这是最好的年代  这是完美的年代 拉拉拉拉拉拉  最后变成了  时代</span>
  </p>
  
  <p>
    <span style="color: #666666; font-size: small;">拉拉……</span>
  </p>
  
  <p>
    <span style="font-size: small;"> 歌词写的挺黑暗的，万劫不复。我们也不能总盯着黑暗不放，免得影响心情或是得了抑郁症。快乐一点，阳光一点对谁都有好处，哪怕是装的。拿一些人的qq签名 说事：“上帝把我们都骗了,其实地狱才是最美丽的地方,佛知道真相,所以佛说:我不入地狱谁入地狱:)”，来自最高信仰的欺骗，俨然黑暗的最高境界。但 “真相下的世界，即使惨烈也值得向往，不要什么所谓的关系，躯壳而已”。嗯，要笑看浮云。</span>
  </p>
  
  <p>
    <span style="font-size: small;"> 愈发觉我是为了blog而blog了，抒写理念陷入了编造理念的陷阱，发现写看法感想没有写日记体裁来的真实和真诚。遂补点近况。</span>
  </p>
  
  <p>
    <span style="font-size: small;"> NBA2006赛季结束，总决赛没怎么看。诺维斯基同学在世界杯德哥揭幕战后，预料总决赛结果4：2，还真是准确，只是胜负颠倒了一下而已。世界杯场次过 半，当豪强在淘汰赛中相遇时，将会碰撞出精彩的火花。人们也找到了追求和寄托，喊无聊的少了，看球嗷嗷叫的多了。这学期很早考完，等待实习中，还有次社会 实践的机会，去苏州常熟考察，不知是去还是不去，还要帮人家设计个团队衫。暑假可能先呆家几天，再过来，初步打算。表妹高考胜利结束，不知道会不会有什么 节目安排。</span>
  </p>
  
  <p>
    <span style="font-size: small;"> 望家里一切安好！</span>
  </p>
</div>