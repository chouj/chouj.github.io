---
title: 学术领域的RSS应用
author: Chouj
type: post
date: 2008-03-05T12:26:41+00:00
url: /2008/03/05/rss-apply-for-academic/
views:
  - 2240
  - 2240
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969997
categories:
  - 教程
  - 相关
tags:
  - Academic
  - RSS应用
  - Tutorial

---
<big><big>搞</big></big>研究的同志们都很关心最新的期刊杂志又发表了哪些文章，似乎和RSS的作用很对路，所以，不妨利用RSS为研究人员的信息获取带来点便利。

<a href="http://www.xuchi.name" title="抽筋儿" target="_blank"><big><big>抽</big></big>筋儿</a>注意到，很多学术性网站都提供了RSS输出功能，何不利用之。下面以<a href="http://www.cnki.net/index.htm" title="中国期刊全文数据库" target="_blank">中国期刊全文数据库</a>为例，纯属抛砖。

<!--more-->

<big><big>用</big></big>户登录进<a href="http://www.cnki.net/index.htm" title="中国期刊全文数据库" target="_blank">中国期刊全文数据库</a>后，即可在左边侧栏看到**数据库导航部分**（如下图），这里有期刊导航，该网收录的每份期刊都支持RSS feed。

<p style="text-align: center">
  <img src="http://pic.yupoo.com/xcchris/7139153205d8/i67ijut4.jpg" alt="cnki homepage" />
</p>

点击“期刊导航”进入，可见到**期刊分类**：

<p style="text-align: center">
  <img src="http://pic.yupoo.com/xcchris/5581953205d9/uf0xuwye.jpg" alt="期刊分类" />
</p>

点击各专业类别即可看到所包含的**期刊**了：

<p style="text-align: center">
  <img src="http://pic.yupoo.com/xcchris/8823853205d9/poe682mv.jpg" alt="期刊封面" />
</p>

每份期刊下面都可见到“RSS订阅”的标志，赶紧找到感兴趣的期刊订阅吧。以Google Reader为例，在阅读器里，你将看到下图（点击放大）：

<p style="text-align: center">
  <a href="http://pic.yupoo.com/xcchris/2973753205d9/dnleba21.jpg"><img src="http://pic.yupoo.com/xcchris/2973753205d9/small.jpg" alt="Reader界面" /></a>
</p>

新paper标题、作者、摘要，一目了然；再配合Google Reader的搜索功能，无论找作者还是找文章，都唾手可得。

<big><big>不</big></big>妨多举个例子，**<a href="http://www.springerlink.com/home/main.mpx" title="Springer" target="_blank">SpringerLink</a>**一样支持RSS输出：

<p style="text-align: center">
  <img src="http://pic.yupoo.com/xcchris/0443453205d8/ldgndnm2.jpg" alt="Springer" />
</p>

<big><big>所</big></big>以，有了RSS，学术关注一样轻而易举。