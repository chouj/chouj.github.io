---
title: '[WP插件]RSSless：实现feed中的内容隐藏'
author: Chouj
type: post
date: 2008-10-14T03:00:21+00:00
url: /2008/10/14/plugin-rssless/
views:
  - 2160
  - 2160
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970025
categories:
  - WordPress
tags:
  - Plugin
  - RSSless
  - WordPress

---
<img title="WordPress Plugin about RSS" src="http://pic.yupoo.com/xcchris/309805b2a084/qye3bzys.jpg" alt="WordPress" style="float: left; margin-left: 10px; margin-right: 10px;" />如果想在RSS feed中隐藏内容，使得页面内容和RSS feed内容不一样的话，那你也许就需要这款WordPress Plugin：RSSless。打个比方，你想在页面上显示“请看以下视频”，在feed内容中显示“请访问本日志方可看到视频”，RSSless就是解决你这方面需求的利器。

**简介**：

<table style="padding: 2px; text-align: left;" border="0" cellspacing="4">
  <tr valign="top">
    <td>
      作者:
    </td>
    
    <td>
      John Kolbert
    </td>
  </tr>
  
  <tr valign="top">
    <td>
      版本:
    </td>
    
    <td>
      1.0
    </td>
  </tr>
  
  <tr valign="top">
    <td>
      最后更新:
    </td>
    
    <td>
      8 9, 2008
    </td>
  </tr>
  
  <tr valign="top">
    <td>
      适用于:
    </td>
    
    <td>
      WordPress 2.5+, 2.6+
    </td>
  </tr>
  
  <tr valign="top">
    <td>
      功能:
    </td>
    
    <td>
      使用简单代码隐藏或更改RSS feed中的内容，特别针对在RSS阅读器中显示异常的视屏或flash嵌入。
    </td>
  </tr>
  
  <tr valign="top">
    <td>
      WP-Extend:
    </td>
    
    <td>
      <a href="http://wordpress.org/extend/plugins/rssless/">http://wordpress.org/extend/plugins/rssless/</a>
    </td>
  </tr>
</table>

<!--more-->


  
**使用方法**：

<img src="http://pic.yupoo.com/xcchris/686306578070/td1v8134.jpg" alt="RSSless Option page" width="468" height="614" />

  1. 在控制台“设置”中的RSSless Option Page中填入默认替换内容，即需要的话，该内容会在feed中显示，并替换掉日志页面上的内容；
  2. 以代码\[rssless\]\[/rssless\]来控制内容的隐藏与更改。

**例如**：

默认替换内容为：请访问本页观看视频

文内代码为：
  
[coolcode]我在简要介绍RSSless这款插件。
  
[rssless] 以下是视频内容：[/rssless]
  
精彩吗？

[rssless text=&#8221;RSS读者看不到视频内容，请访问页面。&#8221;] 以上是视频内容[/rssless]
  
还可以吧？[/coolcode]

> **RSS读者看到的是：**
  
> 我在简要介绍RSSless这款插件。
  
> 请访问本页观看视频
  
> 精彩吗？
> 
> RSS读者看不到视频内容，请访问页面。
  
> 还可以吧？
> 
> **页面读者看到的是：**
  
> 我在简要介绍RSSless这款插件。
  
> 以下是视频内容：
  
> 精彩吗？
> 
> 以上是视频内容
  
> 还可以吧？

如果对这款能随心所欲主宰输出内容的插件感兴趣的话，访问RSSless主页获悉详细说明吧。

[ <a title="RSSless WordPress plugin" href="http://simply-basic.com/rssless-plugin/" target="_blank"><strong>点此进入RSSless插件主页</strong></a> ]