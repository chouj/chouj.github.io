---
title: DoYouFeed:iPhone家的feed裁缝
author: Chouj
type: post
date: 2008-10-10T00:31:37+00:00
url: /2008/10/10/doyoufeed/
views:
  - 1414
  - 1414
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970024
categories:
  - 工具
tags:
  - DoYouFeed
  - iPhone

---
<a title="DoYouFeed.com" href="http://www.doyoufeed.com/" target="_blank"><img src="http://www.doyoufeed.com/i/logo.png" alt="DoYouFeed.com logo" width="261" height="85" /></a>

DoYouFeed.com: Turn any RSS feed into an iPhone friendly site.

theAppleBlog写过一篇<a href="http://theappleblog.com/2008/08/04/tutorial-build-a-simple-rss-reader-for-iphone/" target="_blank">文章</a>，教iPhone用户打造一个简易的iPhone RSS Reader。现在有了DoYouFeed，似乎会更加方便，该站可以将RSS Feed改造成适合在iPhone阅读的页面，所以我叫它iPhone家的Feed裁缝。只是俺买不起iPhone，不知道能提升多少阅读体验；其实对这个站有需求的人估计也挺少，呵呵。

<!--more-->

当然，介绍还是得细致些。在页面生成的步骤中，有些选项可以设置，包括主题、导航、频率等，参考以下页面：

<img src="http://pic.yupoo.com/xcchris/3073365186a7/mvkro5fz.jpg" alt="" width="468" height="556" />

[ <a title="DoYouFeed.com" href="http://www.doyoufeed.com/" target="_blank">有需求的朋友点此进入DoYouFeed.com</a> ]