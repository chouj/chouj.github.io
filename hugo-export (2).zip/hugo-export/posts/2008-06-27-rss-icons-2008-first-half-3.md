---
title: 08上半年出炉的RSS图标精选（三）
author: Chouj
type: post
date: 2008-06-27T05:53:11+00:00
url: /2008/06/27/rss-icons-2008-first-half-3/
views:
  - 1871
  - 1871
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970010
categories:
  - 标志
tags:
  - button
  - Download
  - Graph
  - Icon
  - RSS设计
  - Subscribe
  - Symbol
  - Vote

---
_来选出你最喜欢的RSS标志吧～_

[poll id=&#8221;4&#8243;]

  * 2008.03.29 <a title="RSS earth icon v 2. by ~FreakDr" href="http://freakdr.deviantart.com/art/RSS-earth-icon-v-2-81336211" target="_blank"><strong>RSS earth icon v 2.</strong> by ~FreakDr</a>

![RSS earth icon v 2. by ~FreakDr][1]

  * 2008.03.22 <a title="Hat RSS Icon by ~LoafNinja" href="http://loafninja.deviantart.com/art/Hat-RSS-Icon-80717627" target="_blank"><strong>Hat RSS Icon</strong> by ~LoafNinja</a>

<img src="http://pic.yupoo.com/xcchris/309905c7f1d6/w4jt7v1u.jpg" alt="Hat RSS Icon by ~LoafNinja" width="468" height="327" />

<!--more-->

  * 2008.04.17 <a title="RSS Buttons by *5MILLI" href="http://5milli.deviantart.com/art/RSS-Buttons-83162240" target="_blank"><strong>RSS Buttons</strong> by *5MILLI</a>

![RSS Buttons by *5MILLI][2]

  * 2008.06.05 <a title="345 Free RSS Icons by ~Studiom6" href="http://studiom6.deviantart.com/art/345-Free-RSS-Icons-87760765" target="_blank"><strong>345 Free RSS Icons</strong> by ~Studiom6</a>

![345 Free RSS Icons by ~Studiom6][3]

  * 2008.05.25 <a title="Regular RSS Icon PSD, 5 Sizes by ~macattack2142" href="http://macattack2142.deviantart.com/art/Regular-RSS-Icon-PSD-5-Sizes-86699680" target="_blank"><strong>Regular RSS Icon PSD, 5 Sizes</strong> by ~macattack2142</a>

<img src="http://pic.yupoo.com/xcchris/293575c7e907/zuskbu3k.jpg" alt="Regular RSS Icon PSD, 5 Sizes by ~macattack2142" width="300" height="94" />

  * 2008.04.17 <a title="Free RSS Icons by ~Grafon" href="http://grafon.deviantart.com/art/Free-RSS-Icons-83135885" target="_blank"><strong>Free RSS Icons</strong> by ~Grafon</a>

![Free RSS Icons by ~Grafon][4]

  * 2008.04.08 <a title="RSS icon by ~Magic-Jowol" href="http://magic-jowol.deviantart.com/art/RSS-icon-82269295" target="_blank"><strong>RSS icon</strong> by ~Magic-Jowol</a>

<img src="http://pic.yupoo.com/xcchris/640085c7e907/5e98jvzu.jpg" alt="RSS icon by ~Magic-Jowol" width="300" height="300" />

  * 2008.04.06 <a title="RSS icon by ~aminor1" href="http://aminor1.deviantart.com/art/RSS-icon-82021352" target="_blank"><strong>RSS icon</strong> by ~aminor1</a>

<img src="http://pic.yupoo.com/xcchris/318715c7f1d6/mzqnqalw.jpg" alt="RSS icon by ~aminor1" width="468" height="468" />

  * 2008.03.24 <a title="Wax Seals by *sniffels" href="http://sniffels.deviantart.com/art/Wax-Seals-80878213" target="_blank"><strong>Wax Seals</strong> by *sniffels</a>

![Wax Seals by *sniffels][5]

  * 2008.03.26 <a title="globalsharing RSS by ~deviantdark" href="http://deviantdark.deviantart.com/art/globalsharing-RSS-81074454" target="_blank"><strong>globalsharing RSS</strong> by ~deviantdark</a>

<img src="http://pic.yupoo.com/xcchris/691505c7f1d6/fkhtrxbb.jpg" alt="globalsharing RSS by ~deviantdark" width="469" height="244" />

_什么？没找到好看的？那去<a title="08上半年出炉的RSS图标精选（一）" href="http://aboutrss.cn/2008/06/rss-icons-2008-first-half-1/" target="_self">第一辑</a>和<a title="08上半年出炉的RSS图标精选（二）" href="http://aboutrss.cn/2008/06/rss-icons-2008-first-half-2/" target="_self">第二辑</a>找找吧 🙂_

 [1]: http://pic.yupoo.com/xcchris/201375c7f1d6/x0sb0oh8.jpg
 [2]: http://pic.yupoo.com/xcchris/706065c7e907/rz1a0b0r.jpg
 [3]: http://pic.yupoo.com/xcchris/360925c7ece0/a1nnr4t6.jpg
 [4]: http://pic.yupoo.com/xcchris/922095c7e907/wfmxwrzq.jpg
 [5]: http://pic.yupoo.com/xcchris/210035c7f1d7/sol37wc3.jpg