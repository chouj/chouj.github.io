---
title: 如何利用Google Reader订阅blog
author: Chouj
type: post
date: 2007-02-21T12:35:53+00:00
url: /2007/02/21/google-reader/
views:
  - 27963
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969932
categories:
  - 教程
tags:
  - Google Reader
  - RSS订阅
  - Tutorial

---
IE 7发布，亮点之一就是集成了RSS订阅功能，评论谓之“迎合‘高端’用户的胃口”，“为推广RSS订阅作出了贡献”。既然RSS订阅都高端了，那我也来推 广推广。平日深感众多开博人士尚不知RSS订阅为何物，仍停留在把博客加入收藏夹的“原始”阶段。要知道，订阅RSS即可实现对方更新的及时获知，省去挨 个打开收藏夹里链接的繁琐，故希望看了此教程后，各位也能接触“高端”，体验一把技术浪潮尖儿上的浪花。会用的还是请无视吧。

<span>此教程仅仅告诉丫<span>RSS怎么用</span>，至于RSS是虾米东东，丫在技术上又是怎么实现的，本教程一概不论。</span>

Step <span style="font-size: large;">1 </span>**找RSS**

具有哪些标志的页面、站点可以被订阅？这是首要问题，也就是要找到RSS源，或者称为FEED。
  
常见字样为：<span>RSS XML ATOM</span>
  
常见图样为： <img src="http://blog.donews.com/images/blog_donews_com/keso/121/o_rss.gif" border="0" alt="" />[<img src="http://pic.yupoo.com/xcchris/931989b3a0d0/fun9e1bf.jpg" border="0" alt="" />][1]
  
各大BSP（博客服务提供商）的blog都支持RSS订阅，各blog上肯定有这些图样。
  
另外IE7和Firefox都支持RSS自动搜寻功能，只要页面存在RSS源，浏览器上的标签就会高亮，以IE7为例：
  
[<img src="http://pic.yupoo.com/xcchris/028129b3a0cc/yn1zgfyy.jpg" border="0" alt="" />][2]
  
Step <span style="font-size: large;">2</span> **获取RSS地址**
  
点击以上图样，或者浏览器RSS指示标签，都会得到该RSS地址。如果您使用IE7，将会有如下一段显示：

> **您正在查看的提要包含频繁更新的内容。**订阅提要后，该提要会添加到“常见提要列表”中。该提要的更新信息会自动下载到计算机，通过 Internet
  
> Explorer 及其他程序可以查看这些信息。

有了RSS地址，即可进一步完成订阅的步骤。不过有些站点比较贱，点了以上图标弹出要求安装丫提供的订阅器，比如sohu博客。这时候就要灵活对待，其实sohu博客的rss地址，即在博客地址后加上“/rss”。

Step <span style="font-size: large;">3</span> **使用在线订阅服务**

光有地址还不行，还要有订阅的工具。目前比较常见的在线工具有<a href="http://reader.google.com/" target="_blank">google reader</a>和<a href="http://www.zhuaxia.com/" target="_blank">抓虾</a>，当然都要注册。以下以Google reader为例。

reader左边栏见下图：

<img src="http://pic.yupoo.com/xcchris/578569b3a0cd/0mdua5vg.jpg" border="0" alt="" />

点击“Add subscription”，如下：

[<img src="http://pic.yupoo.com/xcchris/841369b3a0cf/4jqy8rh6.jpg" border="0" alt="" />][3]

将获得的RSS地址复制于上图位置，添加，即可显示在下面了。有可能出现添加失败，多试几次也许就好了，看人品。标题右边括号里的数字即表示未阅览的post数，有没有这个数字即表示是否有新post。点击标题即可看到post，如下，点击看大图：

[<img src="http://pic.yupoo.com/xcchris/658569b3a0ce/qejzw9vs.jpg" border="0" alt="" />][4]

OK，这个步骤完成，即可享用服务了。

之前算入门的话，再扯点提高的，见下图。

[<img src="http://pic.yupoo.com/xcchris/031619b3a0cb/n8y712zj.jpg" border="0" alt="" />][5]

[<img src="http://pic.yupoo.com/xcchris/139029b3a0cd/puqhsesf.jpg" border="0" alt="" />][6]

很多blog都可以见到以上这些按钮，同样是方便订阅的。但这个要先进一些，针对不同的订阅工具，丫用什么工具，就点对应的按钮就行了，不用像以上steps一样麻烦，快捷点。

教程over，希望各位有博人士能用的上。

 [1]: http://pic.yupoo.com/xcchris/931989b3a0d0/fun9e1bf.jpg
 [2]: http://pic.yupoo.com/xcchris/028129b3a0cc/yn1zgfyy.jpg
 [3]: http://pic.yupoo.com/xcchris/841369b3a0cf/4jqy8rh6.jpg
 [4]: http://pic.yupoo.com/xcchris/658569b3a0ce/qejzw9vs.jpg
 [5]: http://pic.yupoo.com/xcchris/031619b3a0cb/n8y712zj.jpg
 [6]: http://pic.yupoo.com/xcchris/139029b3a0cd/puqhsesf.jpg