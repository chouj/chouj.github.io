---
title: 不是出路的出路
author: Chouj
type: post
date: 2007-04-08T15:11:00+00:00
url: /2007/04/08/not-a-good-way/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/04/blog-post_08.html
views:
  - 1887
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969872
categories:
  - 我思考
tags:
  - blog

---
[<span style="font-size:180%;"><span style="font-weight: bold;">望</span></span>月][1]架了个[独立小站][2]，然后赶紧声明[最终解释权归自己所有][3]：不会背叛Google Blogger。我是不是也要效仿下？毕竟已经决心自己做老板，架个独立的blog，同时经营几家分店。如果你订阅了这里的RSS的话，就可窥得端倪，我瞄上了盘古的一代理，虽然有流量限制，但对于非主题的个人blog来说已经足够，况且我财不大气也不够粗。

<span style="font-size:180%;"><span style="font-weight: bold;">为</span></span>什么要如此费时费力费财的折腾？一是看上了dot name域名，不弄一个回来吧，怕自己的被人家注册了；注册了不用的话，又等于浪费，干脆派个用场。二是个人网站是个人的品牌，不管品牌咋样，这网站当然是越早上线越好。三呢，诸多网上人士抱怨自己架站的繁琐，但又有WP架构的新鲜，我欲自己体验一把，偏向虎山行。四是，以现有经济状况尚可维持，真想少花钱，如果弄个cn域名架站，平均下来每月耗费个位数而已。五呢，个人站点不是那么好跟搜索引擎套近乎，估计得在SEO上下点儿功夫，正好研究一下。六，我啃个硬骨头，然后可以见人就告诉他啃硬骨头该怎么下嘴，没准儿可以收点儿学费，哈哈。

<span style="font-size:180%;"><span style="font-weight: bold;">对</span></span>于blogger来说，[Google Blogger][4]已经能给予一切，甚至提供了独立站点所没有的优势，比方与Google搜索友好，比方共同的blogspot平台，和基于此平台上中文blogger间的一见如故。禾草唐楷更是说[Google Blogger是企业级的][5]，叫我怎忍放弃。上一段我并没有说独立架站能摆脱Blogger的间歇性封锁，正是基于我对Google Blogger的乐观。我不信广大中国人用不上如此优质的服务一点抗议的声音都没有，不想看到独立架站能促进消费拉动内需外还要带着逃离Google Blogger的中国特色式隐忍，不认为Google Blogger会一直间断性抽筋儿。

<span style="font-size:180%;"><span style="font-weight: bold;">回</span></span>想当时，随便忽悠了个名字,抽丫的筋儿，现在也塞到[搜索引擎前几页][6]去了。风光在外，这里则将本着“记录”二字，回归赤裸和琐碎。飙句口号式的话，如果我是大清皇上，这里就是后花园；如果我是周曙光，这里就是自留地。想起[麦子][7]那句“[我随性的写，您随性的看][8]”，算是和他并轨了，但我要求不高，您看不看都无所谓。而我想表达的，想交流的，想满足告知欲和认同感的东西基本将放在新的地方，就叫抽筋儿的话语权吧。

<span style="font-size:180%;"><span style="font-weight: bold;">一</span></span>个礼拜没写，因为blogspot尚在封锁期，且为了独立建站，非常有瘾的折腾了好几天。窝棚也见雏形，但除了“Hello World!”，还没内容，就不丢出来了。

 [1]: http://zwblogger.blogspot.com/
 [2]: http://www.ilili8.cn/
 [3]: http://zwblogger.blogspot.com/2007/04/blog-post.html
 [4]: http://www.blogger.com
 [5]: http://dugangs.blogspot.com/2007/02/blogger.html
 [6]: http://www.baidu.com/s?wd=%B3%E9%D1%BE%B5%C4%BD%EE%B6%F9&cl=3
 [7]: http://manonfire.yculblog.com
 [8]: http://manonfire.yculblog.com/post.2665705.html