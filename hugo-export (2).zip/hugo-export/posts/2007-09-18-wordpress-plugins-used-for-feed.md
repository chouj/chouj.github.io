---
title: 我使用的Feed类WordPress插件
author: Chouj
type: post
date: 2007-09-18T03:44:08+00:00
url: /2007/09/18/wordpress-plugins-used-for-feed/
views:
  - 1912
  - 1912
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969984
categories:
  - WordPress
tags:
  - Plugin
  - WordPress

---
<img src="http://photo11.yupoo.com/20070918/101405_1406873759_qmhftysm.jpg" title="WordPress logo" alt="WordPress logo" height="150" width="150" />

响应总统号召，参与<a href="http://jiangzhanyong.com/2007/09/blogging-game-my-favorite-wordpress-plugins-541.html" title="博客串联活动: 我喜欢的 WordPress 插件" target="_blank">博客串联</a>！为和这里的主题相关，特挑几个与Feed有关的WordPress插件说事儿。

<font color="#ff6600"><strong><small>我现在用到的插件：</small></strong></font>

**[©Feed][1]** ★★★★★

暴强的Feed footer内容添加插件，可添加的内容包括**版权声明**、**文章留言**、**相关文章标题**，还可以控制feed**是否全文输出**，可定制性很强，就是不支持php语言来自定义比较郁闷。

<!--more-->

**[Better Feed][2]** ★★★★

和©Feed一样给feed添加内容的，是一个比较简单的插件，需要自己改插件代码中供自定义的部分，不懂php会比较麻烦，当然，优势也在于其支持php自定义，那样生成的内容可以细致很多。

**[FeedBurner FeedSmith][3]** ★★★

FeedBurner出的官方插件，将默认原始feed地址都转为FeedBurner烧制的Feed地址，同时支持发文自动ping FeedBurner，这有利于订阅Feed的统一和订阅量的统计。FeedSky也有类似的插件：<a href="http://my.donews.com/blogbug/2006/09/12/bighenuutlprplhjfpqevisssgauozwwyuwo/" rel="bookmark">Feedsky Feed 插件 for wordpress</a>

**[ST Add Related Posts to Feed][4]** ★★★★★

在Feed里显示**相关文章**的插件，需要Related Posts或UTW支持，只要启用就可以了，表现完美，用的朋友很多。

<font color="#ff6600"><strong><small>我想试试的插件：</small></strong></font>

**<a href="http://www.mapelli.info/feed/feed-count-12" title="Feed Count 1.2 WordPress Plugin" target="_blank">Feed Count 1.2</a>** ★★★★★

用于自定义FeedBurner Feed订阅数样式的，在河蟹横行的日子里凸显出了她的价值。
  
[][5]

**[jRSS][5]** ★★

一款拿来展示RSS items的小插件，试着玩玩。

**<a href="http://www.scratch99.com/wordpress-plugin-dualfeeds/" title="WordPress Plugin - DualFeeds" target="_blank">DualFeeds</a>** ★★★★

一款叫“俩Feeds”的插件，可以提供一个Full Post Feed，一个Summary Feed，争来争去的人们都在这个插件面前闭嘴吧，哇咔咔。

**[WordPress 2.3 Related Posts Plugin 0.2][6]** ★★★

雪山飞猪和Paopao开发的，可以选择是否将相关文章显示在Feed中，没准儿可以一插两得。

<p align="center">
  ———————————————割之————————————————
</p>

还有不少Feed类的WP插件可供大家研究，具体请参看Nicky的[一些有关 Feed 的 WordPress 插件][7]。

 [1]: http://bueltge.de/wp-feed-plugin/204/ "访问插件主页"
 [2]: http://planetozh.com/blog/my-projects/wordpress-plugin-better-feed-rss/ "访问插件主页"
 [3]: http://www.feedburner.com/fb/a/help/wordpress_quickstart "访问插件主页"
 [4]: http://www.solo-technology.com/apps.html "访问插件主页"
 [5]: http://jakobj.dk/blog/archives/35 "jRSS - WordPress plugin"
 [6]: http://fairyfish.net/2007/09/12/wordpress-23-related-posts-plugin-02/
 [7]: http://www.osxcn.com/wordpress/some-of-the-feed-wordpress-plugin.html "一些有关 Feed 的 WordPress 插件"