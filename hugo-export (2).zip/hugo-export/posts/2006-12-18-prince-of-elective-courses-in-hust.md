---
title: 华工选修课王子呀！
author: Chouj
type: post
date: 2006-12-18T10:43:00+00:00
url: /2006/12/18/prince-of-elective-courses-in-hust/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/12/blog-post_18.html
views:
  - 2425
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969836
categories:
  - 我表达
tags:
  - 华中科技大学

---
选修课王子在华工算是家喻户晓了，见过丫真身几次，所以到不在意。倒是想知道咱系03级的那位女同学是 怎么成为 又是 抱着何种心态成为 片中女主角的，嘿嘿。

更详细的到这里看吧：<a href="http://www.awflasher.com/blog/article.asp?id=710" target="_blank">选修课王子 &#8211; 恶搞、炒作还是新闻？(照片+视频)</a> by <a href="http://www.awflasher.com/" target="_blank">aw</a>