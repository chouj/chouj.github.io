---
title: 艾薇儿经典手势三张
author: Chouj
type: post
date: 2008-09-05T07:38:05+00:00
url: /2008/09/05/gesture-of-avril/
views:
  - 7797
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969907
categories:
  - 我表达
tags:
  - 图片
  - 艾薇儿

---
<img class="alignnone size-full wp-image-304" title="艾薇儿经典手势 | 抽筋儿的话语权" src="http://www.xuchi.name/blog/wp-content/uploads/2008/09/avil.jpg" alt="艾薇儿经典手势 | 抽筋儿的话语权" width="500" height="750" />

<img class="alignnone size-full wp-image-305" title="艾薇儿经典手势 | 抽筋儿的话语权" src="http://www.xuchi.name/blog/wp-content/uploads/2008/09/large_2306j93.jpg" alt="艾薇儿经典手势 | 抽筋儿的话语权" width="500" height="750" />

<img class="alignnone size-full wp-image-306" title="艾薇儿经典手势 | 抽筋儿的话语权" src="http://www.xuchi.name/blog/wp-content/uploads/2008/09/large_1727i58.jpg" alt="艾薇儿经典手势 | 抽筋儿的话语权" width="500" height="606" />