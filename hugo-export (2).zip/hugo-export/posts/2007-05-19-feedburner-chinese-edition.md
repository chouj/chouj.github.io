---
title: FeedBurner：中文版现身及被收购传闻
author: Chouj
type: post
date: 2007-05-19T04:06:00+00:00
url: /2007/05/19/feedburner-chinese-edition/
views:
  - 1891
  - 1891
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969955
categories:
  - 新闻
tags:
  - Feedburner
  - Google

---
<img src="http://www.feedburner.com/fb/i/flamocon_190h.gif" title="feedburner-aboutrss" alt="feedburner-aboutrss" height="190" width="179" />

一早上就看到两则令人激动的消息，一是<a href="http://www.feedburner.com/fb/a/languages" target="_blank">FeedBurner多语言版</a>中，出现了**中文版（Beta）**的身影；二是传闻<a href="http://www.google.com" target="_blank">Google</a>将继续花金撒银得进行收购事业，碰巧这次的收购对象有可能是<a href="http://www.feedburner.com" target="_blank">FeedBurner</a>，且收购金额都有所透漏。废话少说，上链接：

<a href="https://www.feedburner.com/fb/a/switchlang;jsessionid=44BE60FDE16438E34110B048284C1A9E.app1?locale=zh_CN" target="_blank"><strong>点此将您的FeedBurner页面转化为<font color="#99cc00">简</font>体中文</strong> </a>

**<a href="https://www.feedburner.com/fb/a/switchlang;jsessionid=44BE60FDE16438E34110B048284C1A9E.app1?locale=zh_TW" target="_blank">点此将您的FeedBurner页面转化为<font color="#99cc00">繁</font>体中文</a>**

相关信息来源于：
  
<a href="http://www.vecosys.com/2007/05/18/rumour-google-to-buy-feedburner/" rel="bookmark" title="Permanent Link to " target="_blank">Rumour: Google to buy Feedburner</a>
  
<a href="http://www.wangtam.com/50226711/feedburner_ccaece_95267.php" title="Feedburner 正式推出简繁中文界面" target="_blank">Feedburner 正式推出简繁中文界面——网谈</a>
  
<a href="http://webleon.org/2007/05/googlefeedburner.html" target="_blank">今日最大传闻：Google收购FeedBurner——歪脖狼</a>
  
<a href="http://webleon.org/2007/05/feedburner.html" target="_blank">FeedBurner中文版——歪脖狼</a>

<font color="#c0c0c0">个人认为Feed这个词还不如不翻译，现在已经很少把Windows叫视窗了，Vista也没翻译，何必要把Feed弄成种子。</font>

<font color="#c0c0c0">还有，如果真的收购成功，那么google更进一步的统一了网络桌面级应用，再如果google作恶的话，比如在RSS上加个GFW之类的墙，您可以继续往下想了吧，这是多么恐怖的事情。</font>

<font color="#c0c0c0">另，FeedBurner中文版<strong>使用教程</strong>撰写将启动，敬请期待。</font>

<font color="#ff0000">Update</font>:

注意到两个**很有意思**的问题：

1、<a href="http://www.feedburner.com/fb/a/myfeeds" target="_blank">我的种子</a>页面里，硕大个My Feed却没有被翻译为“我的种子”，网页的Title也没有翻译为中文。但是My Feed后面的中文却非常有意思，**刷新该页面会随机显示一些句子**：“照单点菜”，“脚踏弹簧，心似春日”，“内容新颖”，“得寸进尺”，“有心栽花，当然要发”，“已经满溢了”，等等等等，非常之多，截图为证：

<img src="http://photo6.yupoo.com/20070519/135135_1497425753_eycrnqon.jpg" title="my feed aboutrss" alt="my feed aboutrss" height="211" width="436" />

**这个就很有意思了**，不知道是不是因为Beta版的缘故，还是FeedBurner有意而为。

2、**种子标题还是不适合使用中文**。英文版下是不能使用中文命名Feed的，中文版能不能用呢？在FF下测试结果为：**还是不可以**。用了中文Feed标题（别切换回英文了，因为换为英文版的话您Feed标题上的中文会变成一串问号，再切换成中文也还是一串问号），表面一直没事，各个界面都很正常，那么把浏览器进程关掉呢？再开FF，登入My Feeds界面，问号们又回来了。要是不止我这里是这样的话，那就说明**汉化非常不彻底**。

继续附上相关信息，还真是多啊！
  
<a href="http://www.ilmay.cn/post/feedburner-chinese.html" target="_blank">FeedBurner推出中文版与被收购传言——晨钟暮鼓</a>
  
<a href="http://blog.istef.info/2007/05/19/google-acquires-feedburner/" target="_blank">Google 即将收购 FeedBurner?——花儿开了</a>
  
<a href="http://www.williamlong.info/archives/896.html" target="_blank">FeedBurner将被Google收购？——月光博客</a>
  
<a href="http://www.mobinode.com/chinese/?p=22" target="_blank">Google收购FeedBurner, Feedsky的天空不再寂寞——动点博客</a>
  
<a href="http://www.hecaitou.com/?p=1830" rel="bookmark" target="_blank">我承认：Feedburner是我翻译的——和菜头</a>
  
<a href="http://www.web2week.com/archives/2007/05/googlefeedburner.html" target="_blank">Google一亿美元收购Feedburner？——WEB2.0周刊</a>
  
<a href="http://www.showeb20.com/?p=470" title="Article-Link (Permalink)" target="_blank">谣言Google即将一亿美元收购Feedburner？——盗盗</a>
  
<a href="http://glif.cn/2007/05/feedburnergoogle.html" target="_blank">FeedBurner中文翻译真相与Google收购——PengBone</a>
  
<a href="http://glif.cn/2007/05/feedburnergoogle.html" target="_blank">写在FeedBurner被Google收购之后——Src</a>
  
<a href="http://jiangzhanyong.com/2007/05/feedburner-chinese-interface-319.html" target="_blank" title="Permanent Link to Feedburner 被粗糙汉化">Feedburner 被粗糙汉化——总统</a>

再度<font color="#ff0000"><strong>Update</strong> ：</font>风波已过，**Feedburner把中文版收回**了，当然，转成中文版后的用户还是中文版，但那个多语言版名单上已经木有中文版了。原因简单，翻译粗糙引来恶评如潮。详见Riku的**<a href="http://www.wappblog.com/50226711/feedburneraecaeie.php" title="FeedBurner中文版消失了？" target="_blank">FeedBurner中文版消失了？</a>**