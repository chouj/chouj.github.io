---
title: RSS应用推广普及专贴
author: Chouj
type: post
date: 2007-02-27T06:41:00+00:00
url: /2007/02/27/about-rss-cn/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/rss.html
views:
  - 2154
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969858
categories:
  - 我表达
tags:
  - blog
  - RSS

---
<img title="知道RSS吗?" src="http://xchchris.googlepages.com/rss.gif" alt="RSS ?" align="right" /><span style="font-size:180%;"><span style="font-weight: bold;">自</span></span>打新浪弄出名人博客，这“全民博客”的口号就响亮了好久，博客门坎也被忽悠的越来越低(相信还有不少群众的观点是：只有新浪才叫博客，别人的都不叫博客吧 &#8211; -b)。但放眼四周，还是有诸多“博友”对自己博客上那个<span style="color: #ff6600;">RSS</span>小标志不理不睬不闻不问。为什么我总纠结在这个小标志上不撒手呢？因为像我这样写博时间不长的人都觉得，要是忽略了<span style="color: #ff6600;">RSS</span>的作用，基本上写在网上和写在纸上没区别，作博客的乐趣也就少了大半。看着大把的快乐您体会不到，我就挺着急，痛心疾首的跟您面前摆着一百块钱您不捡一个感觉。

<span style="font-size:180%;"><span style="font-weight: bold;">于</span></span>是，干脆单开了一个博客:

[<span style="font-size:130%;"><span style="font-weight: bold;"><span style="color: #ff6600;">RSS</span>相关</span></span>][1]
  
[<span style="font-weight: bold;">http://aboutrss.cn/</span>][1]

<span style="font-size:180%;"><span style="font-weight: bold;">从</span></span>域名也看的出，这个博客以<span style="color: #ff6600;">RSS</span>为中心，专门贴一些关于<span style="font-weight: bold;"><span style="color: #ff6600;">RSS</span>的介绍</span>、<span style="font-weight: bold;">教程</span>、<span style="font-weight: bold;">技巧</span>之类。当您弄明白怎么从<span style="color: #ff6600;">RSS</span>获得便捷，怎么在由技术推动的信息流中品尝到快乐，您就可以离开这里了。换言之，对我来说，这个站不求订阅量，只求SEO。同时，我也衷心希望能有同样乐意推广<span style="color: #ff6600;">RSS</span>的朋友支持这个博客。如果您比较空闲，可以<span style="color: #3366ff;">加入进来成为博客作者</span>，共同维护，毕竟我一人的精力和技术水平都有限；如果您不嫌弃，也可以<span style="color: #3366ff;">在您自己的博客上给出链接，或者将其加入您的网摘</span>，以示支持（不是为了骗PR哦，如果这个博客的PR上去了，我就根据反向链接，做互链！）。

<span style="font-size:180%;"><span style="font-weight: bold;">最</span></span>后来个华丽的，高的不着调的官方宣传：为了普及RSS应用，提高众博客们的业务素质，增加博客作业的技术含量，深度挖掘博客长尾价值，特推出博客：<span><span><a href="http://aboutrss.cn/"><span style="font-size:130%;"><span style="font-weight: bold;"><span style="color: #ff6600;">RSS</span>相关</span></span></a></span></span>！大家呱唧呱唧！XD ..

<span style="font-size: 85%; color: #999999;">PS. 马上要去广州搞毕设，这里能否维持更新或能否更新也是我想知道的，留这篇广告作置顶也不错，hoho 😛</span>

 [1]: http://aboutrss.cn/