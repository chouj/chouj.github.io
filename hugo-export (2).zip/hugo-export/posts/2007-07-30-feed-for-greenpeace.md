---
title: RSS资源：绿色和平组织
author: Chouj
type: post
date: 2007-07-30T15:15:08+00:00
url: /2007/07/30/feed-for-greenpeace/
views:
  - 1472
  - 1472
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969967
categories:
  - 资源
tags:
  - Feed

---
[][1]<img border="0" src="http://photo8.yupoo.com/20070730/225624_1895007690_htpgtjmn.jpg" alt="绿色和平组织" title="绿色和平组织" />

[<img border="0" src="http://www.greenpeace.org/international/assets/graphics/xml-gif" /> 绿色和平(中国)的最新消息][2]{.xml} 
  
[<img border="0" src="http://www.greenpeace.org/international/assets/graphics/xml-gif" /> 绿色和平(中国)的新闻发布][3]{.xml} 

<a target="_blank" href="http://www.greenpeace.org/china/zh/" title="绿色和平">绿色和平组织</a>一直致力于环保事业，很多新闻和事项都值得我们大家关注！英语优秀的朋友也可以订阅绿色和平组织的国际新闻<a target="_blank" href="http://feeds.feedburner.com/GreenpeaceNews" title="Greenpeace International">Feed</a>。另，

> 绿色和平网站的任何一页都可以成为RSS 2.0 feed！你只需要把 <span class="red">/rss</span>插到网址 http://www.greenpeace.org 之后即可。 
> 
> 例如，你可以把以下网址
> 
> http://www.greenpeace.org/china/zh/press/releases
> 
> 改为
> 
> http://www.greenpeace.org<span style="color: red">/rss</span>/china/zh/press/releases
> 
> 然后汇入你的RSS阅读软件。

 [1]: http://www.greenpeace.org/china/zh/ "绿色和平组织"
 [2]: http://www.greenpeace.org/rss/china/zh/news
 [3]: http://www.greenpeace.org/rss/china/zh/press/releases