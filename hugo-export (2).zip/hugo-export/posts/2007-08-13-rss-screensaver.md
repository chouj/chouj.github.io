---
title: RSS ScreenSaver：屏保也疯狂
author: Chouj
type: post
date: 2007-08-13T03:34:25+00:00
url: /2007/08/13/rss-screensaver/
views:
  - 1434
  - 1434
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969715
categories:
  - 工具
tags:
  - Screensaver
  - Software

---
<small><font color="#ff0000">编前</font>：不知何故，<a href="http://aboutrss.cn" title="RSS相关">RSS相关</a>的feed和单篇页面一段时间内404报错，现经重装wp已经恢复，祈求上天保佑，别在折腾我了，阿门。</small>

屏保和RSS能牵扯上关系吗？[抽儿][1]负责任的告诉你，可以，而且2005年就可以了，因为要介绍的这款屏保软件在2005年就有了，- -b 希望别太火星。

RSS Screensaver 能够在屏保激活时，在背景图片之上，显示你所设置的feed中的条目，截图如下：

<img src="http://www.nuparadigm.com/products/toys/rssscreensaver/Screenshots/RSS%20Screensaver%201.jpg" title="Rss Screensaver 截屏" alt="Rss Screensaver 截屏" height="374" width="469" />

可以看到，中间半透明的区域是显示feed标题的地方，而每个标题对应的摘要则显示于右侧，并以淡入淡出的方式滚动播出。

软件的自定义程度很高，**支持数个feeds订阅**。在设置中，你可以选择<font color="#333399">显示的标题数目</font>，<font color="#333399">背景图片切换的时间周期</font>，<font color="#333399">feed信息停留的时间</font>，也可以自己更改<font color="#333399">背景图片文件夹</font>，选择自己心怡的图片。屏保激活时，可以使用左右方向键在feeds中切换，使用上下方向键选择感兴趣的条目，或使用空格键，在浏览器中打开当前条目。

不过， [抽儿][1]私以为，屏保的时候都要和feed上的信息打交道，实在是残忍的行为，过载的还不够么？

[ <a href="http://www.nuparadigm.com/products/toys/rssscreensaver/" title="RSS Screensaver 页面" target="_blank">点击进入<strong>RSS Screensaver下载</strong>页面</a>，软件需要<span>.NET Framework支持</span> ]

 [1]: http://www.xuchi.name