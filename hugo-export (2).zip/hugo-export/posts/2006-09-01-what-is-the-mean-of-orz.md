---
title: '[普及贴]orz是什么意思？'
author: Chouj
type: post
date: 2006-09-01T05:50:00+00:00
url: /2006/09/01/what-is-the-mean-of-orz/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/orz.html
views:
  - 1850
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969800
categories:
  - 我记录
tags:
  - Orz
  - 网络

---
**<span style="font-size:180%;">这</span>**个符号叫**失意体前屈**

**<span style="font-size:180%;">失</span>**意体前屈，原本指的是网路上流行的表情符号：＿￣○，源自日本。看起来像是一个人跪倒在地上，低着头，一副「天啊，你为何这样对我」的动作，虽然简单却很传神。

**<span style="font-size:180%;">在</span>**初期的时候，并没有人对这个符号起个名字，失意体前屈也是后来才出现的， 据说是某个餐厅的座垫上绣着这五个字，至於再之前又是谁想到的，就不可考了。 后来，又有人发现，用简单的三个英文字也可以表现这个动作，於是 orz 就开始流行了。到2004年之后，orz的广泛使用，已经从日本，扩展到中文网络了。

**<span style="font-size:180%;">orz</span>**原本带有“愤恨”“无力回天”等含义，后来意义逐渐扩展，目前比较多用的是“拜服”“被你打败了”等，有点象中文BBS上的常用语“I服了U！”、“Faint”等。

**<span style="font-size:180%;">各</span>**种失意体前屈的表示法

全形：

＿￣○ ← 右向

○￣＿ ← 左向

○＿￣ ← 逆天

半形：

STO ← 右向

OTZ ← 左向

OLS ← 左向逆天

ZJO ← 右向逆天

半形小写：

sto ← 右向

orz ← 左向

ots ← 左向逆天

z_/o ← 右向逆天

迷你形：

no ← 右向

on ← 左向

ou ← 左向逆天

uo ← 右向逆天

其他

orz 这是小孩&#8230;

OTZ 这是大人&#8230;

or2 这是屁股特别翘的&#8230;

Or2 这是头大身体小的翘屁股&#8230;

orZ 这是下半身肥大&#8230;

OTz 这是举重选手吧&#8230;

○rz 这是大头&#8230; （=。=）

●rz 这是黑人头先生&#8230;

Xrz 这是刚被爆头完&#8230;

6rz 这是魔人普乌&#8230;

On 这是婴儿&#8230; crz 这是机车骑士&#8230;

ORZ=3这是蹲下的人不小心放了一个屁&#8230;囧

rz 这是念ㄐㄩㄥˇ&#8230;

崮rz 这是囧国国王&#8230;

莔rz 这是囧国皇后&#8230;

商rz 这是戴斗笠的囧&#8230;

st冏 楼上的他老婆吗&#8230;

sto 换一边跪&#8230; 曾rz ←假面超人&#8230;

★rz ←武藤游戏&#8230;.

口rz ← 豆腐先生.

__Drz ← 爆脑浆&#8230;