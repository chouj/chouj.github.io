---
title: 春节快乐！猪事吉祥！
author: Chouj
type: post
date: 2007-02-16T09:21:00+00:00
url: /2007/02/16/happy-spring-festival/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/blog-post_16.html
views:
  - 1986
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969853
categories:
  - 我尝试
tags:
  - 图片
  - 新年
  - 春节

---
<div style="text-align: center;">
  <a href="http://bp2.blogger.com/_2MqU1LfBbeM/RdV4J9r4-DI/AAAAAAAAAC4/ymHOjfo6fiE/s1600-h/hny.gif" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5032060271229204530" style="cursor: pointer;" src="http://bp2.blogger.com/_2MqU1LfBbeM/RdV4J9r4-DI/AAAAAAAAAC4/ymHOjfo6fiE/s320/hny.gif" border="0" alt="" /></a></p> 
  
  <p>
    <span style="font-size:85%;"><span style="color: #ff9900;"><span style="color: #ff6600;">刚刚PS出炉</span></span></span>
  </p>
  
  <p>
    <span style="font-weight: bold; font-size: 180%; color: #ff0000;">Happy Spring Festival !</span>
  </p>
</div>

 <span style="color: #ffffff;"></span>