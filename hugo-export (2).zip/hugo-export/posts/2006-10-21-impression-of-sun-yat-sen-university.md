---
title: 广州印象 中山大学
author: Chouj
type: post
date: 2006-10-21T07:22:00+00:00
url: /2006/10/21/impression-of-sun-yat-sen-university/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/10/blog-post_21.html
views:
  - 1917
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969823
categories:
  - 我表达
  - 我记录
tags:
  - 中山大学
  - 广州

---
<a href="http://culture.163.com/06/1023/10/2U463MQ400281M76.html" target="_blank">推行博客实名制，曹操引发脑中风</a>

<span style="font-size:180%;"><strong>先</strong></span>推荐篇好玩的文章，网易文化频道的，再入正题。

[<img style="FLOAT: left; MARGIN: 0px 10px 10px 0px; CURSOR: hand" src="http://www.sysu.edu.cn/2003/xxgk/img/xiaoxun.gif" border="0" alt="" />][1] <span style="font-size:180%;"><strong>一</strong></span>路之隔，中山大学当然是晃悠的首选之地。

<span style="font-size:180%;"><strong>不</strong></span>得不承认，中山大学比较符合我心目中对“大学”的定义，至少从感观层面上。其实不论是大学前，还是进了华工，我都不曾想过为“大学”下个定义，但走在中大的路上，我仿佛找到了那种大学的感觉，也许是新的环境总让人所向往,而在自己的学校里呆久了，心生厌倦。

<span style="font-size:180%;"><strong>中</strong></span>大校园绿色荫庇，古旧的建筑物传递着历史的气息，走在不算宽的小路上，仿佛沉浸入文化之河。路上学生不多，三三两两，静谧而不拥挤，没有扩招的遗毒。也许这就是我对大学的基本要求，不像华工，放学路上那洪水猛兽般的人海。。冲到食堂就差吞噬一切。。

[<img style="FLOAT: left; MARGIN: 0px 10px 10px 0px; CURSOR: hand" src="http://www.sysu.edu.cn/2003/xxgk/fg.files/image010.jpg" border="0" alt="" />][2]

<span style="font-size:180%;"><strong>还</strong></span>是回到中大。历史始终是中大的主题，无论孙中山铜像还是中国近代十八先贤雕塑，都透露着厚重。我有所注意到，老毛的雕像要么指点江山，要么挥手致意，手都是向上；而孙中山铜像确是伸手向下，有如抚平历史的伤疤一般。近代中国的混沌和希冀压在孙中山一个人的身上，确实不是一个可以像老毛一样意气风发的时代。

[<img style="MARGIN: 0px 10px 10px 0px; WIDTH: 400px; CURSOR: hand" src="http://www.sysu.edu.cn/2003/xxgk/fg.files/image049.png" border="0" alt="" />][3]
  
<span style="font-size:180%;"><strong>顺</strong></span>路往北，穿过“国立中山大学”的牌坊，来到珠江江边享受那份惬意。健身慢跑的男女，放风筝的老人，和中大的氛围一样，闲适而不慵懒。翻飞在高楼背景中的风筝，带来别样的风情……

<span style="font-size:180%;"><strong>我</strong></span>去过的大学并不多，主要也就是武汉的几所。相比而来，武汉的高校还是缺少些韵致的。兴许因为，中大主校区要改成研究生院的缘故，现在都是大三以上的学生，所以多了沉稳，少了浮躁吧。

 [1]: http://www.sysu.edu.cn/2003/xxgk/img/xiaoxun.gif
 [2]: http://www.sysu.edu.cn/2003/xxgk/fg.files/image010.jpg
 [3]: http://www.sysu.edu.cn/2003/xxgk/fg.files/image049.png