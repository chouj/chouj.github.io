---
title: 标记
author: Chouj
type: post
date: 2008-04-29T02:49:09+00:00
url: /2008/04/29/to-remember-linzhao/
views:
  - 2232
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969730
categories:
  - 我记录
tags:
  - 林昭
  - 纪念

---
挂在RSS相关侧栏的doll——萝丽，已经400天了（该萝丽估计无法显示于RSS阅读器），但我要说的到不是这个。今天是<a title="百度百科：林×昭" href="http://baike.baidu.com/view/31342.htm" target="_blank">林*昭</a>遇难四十周年纪念日，<a title="林*昭，一个爱国者的40年" href="http://www.sohoxiaobao.com/chinese/bbs/blog_view.php?id=984068" target="_blank">一个爱国者就这么莫无声息几近忘却得走过了40年</a>。

<p style="text-align: center;">
  <img class="aligncenter" src="http://www.xuchi.name/blog/wp-content/uploads/2008/04/linzhao.jpg" alt="林*昭碑后的诗" width="480" height="640" />
</p>

<p style="text-align: center;">
  <a title="纪念林*昭" href="http://www3.nbnet.nb.ca/stao/memo_linzhao" target="_blank">纪念林*昭</a> | <a title="林*昭年表" href="http://www.taosl.net/dir2/memo_linzhao_moluo.htm" target="_blank">林*昭年表</a>
</p>