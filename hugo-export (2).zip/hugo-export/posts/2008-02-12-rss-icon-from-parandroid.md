---
title: 帕兰整理的RSS Feed图标大集合
author: Chouj
type: post
date: 2008-02-11T16:41:19+00:00
url: /2008/02/12/rss-icon-from-parandroid/
views:
  - 1881
  - 1881
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969994
categories:
  - 标志
tags:
  - button
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
<p align="center">
  <img src="http://pic.yupoo.com/xcchris/2066862170ed/ui9df08s.jpg" alt="免费的RSS Feed订阅图标按钮集合下载" />
</p>

###### <span style="color: #999999;">图片盗自</span><a title="帕兰映像" href="http://parandroid.com" target="_blank"><span style="color: #999999;">parandroid.com</span></a>

<big><big>我</big></big>真懒，真的。每次我该做的事情总有人替我代劳，哈哈。详情请看：

### [ <a title="Parandroid.com的免费RSS Feed订阅图标按钮下载大集合" href="http://parandroid.com/rss-icon-button-set-download/" target="_blank">免费的RSS Feed订阅图标按钮下载大集合</a>——Parandroid.com ]