---
title: 《满城尽带黄金甲》预告片精彩截图
author: Chouj
type: post
date: 2006-09-01T11:52:00+00:00
url: /2006/09/01/the-city-of-golden-armor/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post.html
views:
  - 1762
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969801
categories:
  - 我表达
tags:
  - 图片
  - 满城尽带黄金甲

---
[<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-2.jpg" border="0" alt="" />][1]

[<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-3.jpg" border="0" alt="" />][2]

[<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-6.jpg" border="0" alt="" />][3]

**<span style="font-size:180%;">丫</span>**鬟？

<div>
  <div>
    <div>
      <div>
        <div>
          <div>
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-9.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-9.jpg" border="0" alt="" /></a></p>
            </div>
            
            <div>
              <strong><span style="font-size:180%;">巩</span></strong>俐(Gong li)
            </div>
            
            <div>
              <span style="color: #ff6600;"><strong><span style="font-size:180%;">频</span></strong>出的这些镜头，莫非我找到了卖点？？</span>
            </div>
            
            <div>
            </div>
            
            <div>
              <span style="color: #000000;"><strong><span style="font-size:180%;">还</span></strong>是给点正常的&#8230;</span>
            </div>
            
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-1.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-1.jpg" border="0" alt="" /></a></p> 
              
              <p>
                <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-8.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-8.jpg" border="0" alt="" /></a>
              </p>
            </div>
            
            <div>
              <strong><span style="font-size:180%;">发</span></strong>哥 （Chow Yun-fat）
            </div>
            
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-5.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-5.jpg" border="0" alt="" /></a>
            </div>
            
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-7.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-7.jpg" border="0" alt="" /></a>
            </div>
            
            <div>
              <strong><span style="font-size:180%;">JAY</span></strong>
            </div>
            
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-4.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-4.jpg" border="0" alt="" /></a></p>
            </div>
            
            <div>
              <strong><span style="font-size:180%;">虾</span></strong>兵蟹将
            </div>
            
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_满城尽带黄金甲h480p(000228).jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_满城尽带黄金甲h480p(000228).jpg" border="0" alt="" /></a>
            </div>
            
            <div>
              <a href="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-10.jpg"><img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-10.jpg" border="0" alt="" /></a>
            </div>
            
            <div>
              <strong><span style="font-size:180%;">恢</span></strong>宏场景
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

 [1]: http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-2.jpg
 [2]: http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-3.jpg
 [3]: http://blog.donews.com/images/blog_donews_com/xcchris/107822/r_未标题-6.jpg