---
title: Firefox上的阅读器：Wizz RSS News Reader
author: Chouj
type: post
date: 2007-08-22T12:34:21+00:00
url: /2007/08/22/firefox-extension-wizz-rss-reader/
views:
  - 2200
  - 2200
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969974
categories:
  - 工具
tags:
  - firefox
  - Reader

---
<img src="http://photo6.yupoo.com/20070822/191418_728437375_azhcsavb.jpg" title="Firefox" alt="Firefox" align="left" height="128" width="128" />

火狐浏览器一直是技术人员最为喜欢的浏览器，以极好的网页标准支持和丰富的扩展能力而著称。因此，必定会有RSS Feed阅读器以火狐扩展的形式而存在，<a href="http://www.xuchi.name/blog" title="抽筋儿" target="_blank">抽儿</a>一直都这样以为。Wizz RSS News Reader就是这么一款集成于Firefox之上的extension，虽然<a href="http://www.xuchi.name/blog" title="抽筋儿" target="_blank">抽儿</a>并不喜欢浏览器的上下左右被各种插件攻陷，但<a href="http://www.xuchi.name/blog" title="抽筋儿" target="_blank">抽儿</a>还是要推荐它，因为也许有朋友用的到。

Wizz RSS News Reader可以实现一般在线或离线阅读器的主流功能，作为一款火狐扩展插件来说，还是非常强大的。在安装好之后，我们可以在浏览器中看到它：

<img src="http://photo8.yupoo.com/20070822/194557_785427207_lrkpnmru.jpg" title="Wizz RSS" alt="Wizz RSS" height="351" width="468" />

<!--more-->图中标识出来的区域即为该扩展的界面，包括侧栏和工具栏Wizz RSS Toolbar。Toolbar上包含扩展的显隐按钮、阅读器选项、Feed更新监测、帮助等。

<img src="http://www.wizzrss.com/Images/outbrain3.jpg" height="396" width="297" />

在选项窗口中， 我们可以看出，其功能在细节上的定制还是很丰富的。下面<a href="http://www.xuchi.name/blog" title="抽筋儿" target="_blank">抽儿</a>借助侧栏的放大图，简要介绍下阅读器的用法。

<img src="http://photo8.yupoo.com/20070822/194557_1761804450_alcsgmyk.jpg" title="Wizz RSS Sidebar" alt="Wizz RSS Sidebar" align="left" height="631" width="247" />阅读器能够以侧栏或弹出窗口的形式显示出来，以侧栏为例，总共分为三大区域，从上到下，分别为①Feeds List区——订阅的Feeds都在这里，②单个Feed内容的标题区——显示某Feed内容中各文章的标题，③标题对应的文章内容区。

在①号 Feeds List区，可以对Feeds进行添加删除归类更名等操作，支持右键菜单。点击一个Feed，其标题则显示于②号区。

在 ②号区，Feed里各文章的标题都显示于此，绿点表示未读，红点表示已读（当然，这个颜色可以自行设置）。点击标题，则在Firefox当前窗口打开标题 对应的页面，同时绿色转变为红色。配合最上方的小按钮和鼠标右键，可以很方便的管理信息阅读状态，或进行查找和分享。鼠标悬停于某标题之上时，该标题对应 的内容会在 ③号区给出预览。

③号区，主要用于显示feed中的详细内容，以供预览，方便判断信息是否值得一读。

如果想即拿即用，不过多考虑信息的留存和共享的话，Wizz RSS News Reader确实是一个不错的选择。

[ <a href="http://www.wizzrss.com/" title="Wizz RSS" target="_blank"><strong>Wizz RSS News Reader 主页</strong></a> ]

[ **<a href="https://addons.mozilla.org/en-US/firefox/addon/424" title="扩展安装下载页面" target="_blank">FireFox扩展下载安装页面</a>** ]

[ <a href="http://www.wizzrss.com/help/WizzRssHelp.php" title="Wizz RSS 详细帮助" target="_blank"><strong>扩展详细帮助</strong></a>（英文） ]