---
title: 我在写博客过程中犯过错误吗？
author: Chouj
type: post
date: 2007-08-04T08:53:00+00:00
url: /2007/08/04/do-i-make-mistakes-in-blogging/
views:
  - 3824
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969698
categories:
  - 我表达
tags:
  - blog
  - Google
  - RSS
  - 生活

---
关于<a href="http://aboutrss.cn" title="RSS相关" target="_blank">RSS相关</a>这个blog的事情一直都想说，正巧被曾兄点了名，就写点吧，其实本不打算上火车前再写东西。游戏的名字叫“<a href="http://blogunion.org/marketing/mistakes-i-made-in-blogging.html" title="我在写博客过程中犯过的N个错误——博客联盟" target="_blank">我在写博客过程中犯过的N个错误</a>”，就我个人而言，我没觉得是什么错误，所以把题目改了下；而且那边的主题是关于RSS应用，所以文字发在这里了，都望曾兄不要介意。

写博客会犯错误吗？如果就blogging技巧、经验，blog的长远发展和个人品牌的建立这些<a href="http://blogunion.org" title="博客联盟" target="_blank">博客联盟</a>关注的方面来讲，犯错误是肯定会有的。刚接触blog概念的新人，绝不可能想的这么周全完备，有的甚至不觉的个人品牌和自写自话会有什么关系，他们之所以会犯这些方面的错误，就是没看一些blogging指导上的文字；而我在这些方面犯的错误，都要归咎于当时没有<a href="http://blogunion.org" title="博客联盟" target="_blank">博客联盟</a>，XD~Just a JOKE

具体而言，在blog发展上我犯的错误有：

**1、****换了好些BSP**，像我这阶段的bloggers应该都犯过这“错误”；

从05年开始blogging，换了好些。其实这算错误么？当时连玩的是“blog”我都不知道，BSP也知道的少之又少，随着眼界开阔，换换是难免的。

**2、最后选择了Google Blogger，被GFW所扰**；

Google Blogger依然是非常棒的BSP，如果不被封掉的话；当然，不封掉她，我也不会这么早走上独立blogger的道路，因祸得福？还是该加条“**没想过要独立的**”错误？

**3、曾一直拿Donews作Blogger的镜像，但后来发现说搞重复内容不利SEO**；

这错误还不是因为当时连SEO是什么都不知道。

4、就<a href="http://aboutrss.cn" title="RSS相关" target="_blank">RSS相关</a>来说，**换现在这个模板好像是个错**。

这个模板虽然针对Google Adsense投放进行了优化，但左侧栏还是不适合SEO。与前一个模板时搜索引擎带来的流量差别，即可观察出这个错误比较严重，但我最近没打算管这事，因为这个模板看着舒服。

OK，游戏任务完成，回到我自己的见解，**离开blog经营，就个人所得而言：我觉得blogging的过程中我没犯错**， 即便现在我还在BSP上，我都没有错，因为只要我有写，我就有收获。我都有坚持写blog了，还要扣个错误的帽子在我头上，我多冤呐。其实，写blog本 来就是新事物的体验认知过程，写成什么样子，写给自己，写给朋友，还是要写成名博，写到可以赚钱，都是认知的丰富、个人的成长和学习的过程。

拿 我写blog的经历来说。05年夏天在52blog.net上刨了个坑儿，当时不知道blog是何物，且只是为了学习下html，也不知道CSS+ DIV。那时的自己不在blog上写字，只DIY过两个粗糙的blog界面，记得网易还有免费空间服务的时候，弄过个个人主页。然后有朋友开始写东西，于 是自己跟着写，纯属流水帐日记类。Google Blogger可以访问之后，立马加入，有了<a href="http://xcchris.blogspot.com" title="抽丫的筋儿" target="_blank">抽丫的筋儿</a>（需代理），参考了不少blogspot技巧，学会自己改模板，那里一直写到封掉，160多篇日志，PR为2，顺便缅怀下当时中文Blogger圈的热闹氛围。同时学会了经RSS阅读，苦于诸同学不会这招儿，就有了blogspot上的<a href="http://allofrss.blogspot.com" title="RSS相关" target="_blank">RSS相关</a>（需代理），PR为3。有了些经济基础，加上GFW时不时抽筋儿 &#8211; -#，就于今年4月初独立。在万网注册的.name域名，送一个.cn域名，于是又有了现在的<a href="http://aboutrss.cn" title="RSS相关" target="_blank">RSS相关</a>。

记得<a href="http://www.awflasher.com/blog" target="_blank">aw</a>说 过，几年blogging的所学所得，远远超过课堂。经历了一段时日的blogging，我也这样以为。我写blog不是为了钻营之，而是为了兴趣和快乐，就像我不会因为模板SEO不利而心急火燎；挂Adsense，弄广告，不是单纯为了赚钱，更是为了体验一种网络方式；写<a href="http://aboutrss.cn" title="RSS相关" target="_blank">RSS相关</a>，是为了帮助更多不知道它的人，同时体验主题blog写手，订阅数增长的感觉。相比没有blog的人，我发展的再缓慢也走在了前面；相比喜欢写字喜欢记录生活的bloggers，我体验的更多更丰富，只是他们没准儿以为，花钱弄个空间弄个域名才叫犯错呢。

所以，**抛开blog的发展和技巧，任何bloggers都没有犯错，享受快乐就好**。鉴于我这地界来的大多是同学或非技术性bloggers，我就不点名了，但欢迎大家参与<a href="http://blogunion.org/marketing/mistakes-i-made-in-blogging.html" title="我在写博客过程中犯过的N个错误——博客联盟" target="_blank">曾兄的游戏</a>。