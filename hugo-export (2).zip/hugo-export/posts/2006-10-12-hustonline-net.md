---
title: 怒赞改版后的HUSTonline
author: Chouj
type: post
date: 2006-10-12T05:24:00+00:00
url: /2006/10/12/hustonline-net/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/10/hustonline.html
views:
  - 1564
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969820
categories:
  - 我表达
tags:
  - Hustonline
  - 华中科技大学
  - 图片

---
<div>
  <a href="http://photos1.blogger.com/blogger2/4366/415671023967385/1600/hustonline.jpg"><img style="CURSOR: hand" src="http://photos1.blogger.com/blogger2/4366/415671023967385/400/hustonline.jpg" border="0" alt="" /></a></p> 
  
  <p>
    点击上图看大图 该站点地址：<a href="http://www.hustonline.net/" target="_blank">华中大在线 HUSTonline</a>
  </p>
</div>

**<span style="font-size:180%;">也</span>**许大学的遗憾之一就是没能提早发现<a href="http://www.bingyan.net" target="_blank"><img src="http://www.hustonline.net/images/bingyan_logo.gif" border="0" alt="" />Bingyan Studio</a> ，然后join in &#8230;