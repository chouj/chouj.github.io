---
title: 2006年度“我最喜欢的软件”评选结果
author: Chouj
type: post
date: 2006-12-09T02:20:00+00:00
url: /2006/12/09/my-favorite-softwares-in-2006/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/12/2006.html
views:
  - 2230
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969833
categories:
  - 我尝试
  - 我表达
tags:
  - 网络
  - 软件

---
IT.com.cn发起的2006年度“我最喜欢的软件”评选结果公布.软件方面,分了十类进行投票评选,这其中有老面孔的IM软件、杀毒软件以及浏览器软件等,也有新面孔反流氓软件和在线视频直播软件等.总体来说排名变化不大,老牌软件依旧强势,但其中也不乏有新势力涌现,比如音频播放方面的千千静听、安全软件中的360安全卫士等.

我最喜欢的中文输入法 获奖者：<span style="font-weight: bold;">紫光拼音</span>

我最喜欢的聊天软件 获奖者：<span style="font-weight: bold;">腾讯QQ</span>

我最喜欢的音频播放工具 获奖者：<span style="font-weight: bold;">Winamp</span>

我最喜欢的视频播放工具 获奖者：<span style="font-weight: bold;">暴风影音</span>

我最喜欢的反流氓软件工具 获奖者：<span style="font-weight: bold;">超子兔子</span>

我最喜欢的杀毒软件 获奖者：<span style="font-weight: bold;">卡巴斯基</span>

我最喜欢的网络资源交流工具 获奖者：<span style="font-weight: bold;">BitComet</span>

我最喜欢的网页浏览器 获奖者：<span style="font-weight: bold;">遨游Maxthon</span>

我最喜欢的在线视频直播工具 获奖者：<span style="font-weight: bold;">PPLive</span>

我最喜欢的下载工具 获奖者：<span style="font-weight: bold;">迅雷</span>

详见<a href="http://www.it.com.cn/f/edu/0612/7/359255.htm" target="_blank">此页</a> 各项参选<span style="color: #ff0000;">排行</span>见<a href="http://vote1.it.com.cn/dc_data.php?dc_id=569" target="_blank"><span style="font-weight: bold;">此页</span></a>

<span style="font-size:180%;"><span style="font-weight: bold;">看</span></span>来我足够睿智，也足够草根，基本用的和上面所列的一样了，除了遨游和Winamp。浏览器方面我还是忠于火狐和IE7，可惜排名上遨游几乎不可撼动。音频播放方面，实在想不通Winamp是怎么成为冠军的，这么一个江河日下，都没继续更新的软件了；目前用foobar中；千千静听也曾用过一段时日，为尝鲜才换成foobar，并没有觉得它不好，也确实如日中天。

<span style="font-size:180%;"><span style="font-weight: bold;">至</span></span>于其他：紫光绝对强于智障ABC；教育网内想用MSN而不能，Gtalk尚待普及，故没QQ就没IM，而且先有QQ后有QQ邮箱，而先有Gmail后有Gtalk，所以Gtalk的普及完全受限；暴风影音功能齐全，虽然格式支持多了，挑选、设置都比较麻烦，但我不怕麻烦，其他一概没用过；超级兔子一直是我的优化首选，非常适合初级电脑使用者，简单易懂，功能强大，又不像优化大师那样专业而艰深，至于排行上的那个“其他”着实耐人寻味；卡巴的上榜倒是有点让人意外，居然这么流行了，看来是因为升级比较方便吧，不过最近丫加强了对盗版的封锁，我家里的已经不能正常升级了；BT不用说了，bitcomet应该都知道，电驴也尚待普及，目前我没用过，不过对VeryCD开始感兴趣；拿PPlive看NBA是件很爽的事情，所以丫上榜理所当然，榜上第二的“其他”也值得寻味，个人认为这块领域的争夺将愈演愈烈;迅雷和快车真是统领了下载领域，听说快车准备翻身，但我没打算尝试。

<span style="font-size:180%;"><span style="font-weight: bold;">看</span></span>看你是否也足够睿智和草根呢？