---
title: 由一件小事想到的
author: Chouj
type: post
date: 2007-03-15T13:06:00+00:00
url: /2007/03/15/a-tiny-thing/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/blog-post_15.html
views:
  - 2189
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969863
categories:
  - 我思考
tags:
  - 华中科技大学
  - 广州
  - 生活

---
<span style="font-size:180%;"><span style="font-weight: bold;">广</span></span>州的三月俨然初夏。虽然中大的MM们开始穿的清凉，虽然中大食堂少了份汗臭多了点脂粉的幽香，也虽然能偶遇迷你的裙装，但有件事，更能让我心情舒畅。那就是：遍地迷你？！×_×&#8230;呃，不好意息，把心里话说出来了。其实是，有一些罪名终将得到洗刷。

<span style="font-size:180%;"><span style="font-weight: bold;">事</span></span>出有因。前些时日，接到学校的通知，大致有两点，一是木有注册，二是要办请假，需寄毕设所在单位公文证明。在与本人所知情况不符的困惑不解下，本人本着友好协商、不得内伤的原则，与校方进行了友好的有意义的积极的协调，复述了本人于上学期已经上交相关证明，完成请假手续，并得到校方的许可与叮嘱这一基本情况，承诺了将在返校第一时间补完学籍注册的所有步骤，并表达了对校方牵挂学生的感激之情。

<span style="font-size:180%;"><span style="font-weight: bold;">随</span></span>后，就短暂出现的本人私自离校逾期不返，对毕设单位瞒报手续周全的恶性后果，本人进行了深刻的自我审查，终于发现在行事上存在重大疏忽。由于本人和校方之间是一对一的关系，在事件的交割历史上，相对记忆牢固；而校方负责人面对的是广大学生，是一对多的关系，综合校方负责人不是机器这一因素，难免有所遗忘、乃至错怪的现象，本人对此深表理解，对自己考虑不周深表遗憾。在日后同类事件的处理中，本人定当遵循此次所得经验，做好思想准备的同时多为校方行事提供方便。时至此刻，事态正在向良好的方向发展。

<span style="font-size:180%;"><span style="font-weight: bold;">除</span></span>撰写此文表达本人的忏悔外，也值此文发表之际，以本人为例，传达本人的所悟所得，告知大家为人处事之道：

<span style="font-weight: bold;">第一，出现不应该出现的言论时，要有气度，学会微笑着聆听；</span>
  
<span style="font-weight: bold;">第二，发生不应该发生的事情时，要有自责意识。</span>