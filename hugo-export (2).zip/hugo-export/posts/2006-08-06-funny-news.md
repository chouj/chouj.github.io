---
title: 趣闻一个接一个
author: Chouj
type: post
date: 2006-08-06T02:49:00+00:00
url: /2006/08/06/funny-news/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/blog-post_05.html
views:
  - 2242
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969791
categories:
  - 我表达
  - 我记录
tags:
  - 社会
  - 网络

---
先扯个小范围内的趣闻，互联网业界的。

[www.ie7.com][1] 看到这个地址，稍微了解业界动态的估计都知道应该和微软的Internet Explorer 7发布有关。可是你点开看看，那可绝对是个意外：这个IE7的域名下放了一个大大的Firefox LOGO，并且做了一个导向链接指向了Mozilla的Firefox浏览器下载地址，还附了一句：“<span style="color: #666699;">Neither this site nor Mozilla is connected with Microsoft.”</span>咱都知道火狐和IE那可是竞争冤家，这明摆着挑衅嘛。倒是抢注这个域名的家伙聪明的紧，估计是Firefox的人吧。

相关新闻：[爆笑：FireFox竟然成功抢注ie7.com域名][2]

在扯个最近流行的套套事件。

最早在<span style="color: #808080;">btChina</span>的一个极不显眼的角落里看到一个链接，名为<span style="color: #808000;">“中央一套”被抢注成安全套商标</span>，先一寻思，一频道和安全套有虾米关系？转而YY一下，茅塞顿开啊，这个事情还真是极其好玩捏。这个就比上面那个竞争对手抢注域名厉害多了，注册商标这伙计有胆识有见地，虽然还在审核中。

不过，这火爆的新闻怎么没见哪家blog报料调侃一番呢？刚刚觉得有点惋惜，今早就来了一篇，三表同志的《[不就是一个套儿吗][3]》，下面的评论倒是更精彩了，人民的YY能力还是不可小视啊！丫们自己看去哈，为维护偶blog繁荣昌盛的假相，偶就不贴出来亲自教导你们YY了。

相关新闻：[中央一套被抢注成避孕套商标][4]

顺便提个，在家瞟了电视两眼，听到个新名词儿：“××××<span style="color: #808000;">专用面</span>”。自打什么“××会专用饮用水、××航天员专用牛奶”，这次今麦郎又蹦出来个“大学生运动会专用面”。这还算好，所谓“专用”也只是说××组织者提供的东西仅此一牌子尔。倒是像“中国××队专用××”的比较惨，代言人家品牌，就得用人家的东西，放眼超市琳琅满目的牌子不能选，真是连消费者的最低权益都被剥夺了。人家愿意赚点广告费，我们也无可厚非，只怕到时候什么乱七八糟“专用”都出来了。李愚蠢专用蠢才，哦，是唇彩，不好意思，偶的破专用输入法；何洁专用假睫毛，马家爵专用榔头；黄健翔专用响声丸；××夜总会专用套套——中央一套；中国××女队专用卫生巾——挡中央……想必市场上必是腥风血雨，这粉丝帮派、那利益集团可是打的不可开胶。便宜了那帮商家们，市场份额倒好算无比，数粉丝人头呗。

当下的消费者们，一定要打造自己的专用品牌，你们谁专用的我专不用，看你们丫的怎么办！

 [1]: http://www.ie7.com/
 [2]: http://www.pconline.com.cn/pcedu/softnews/yejie/0607/836867.html
 [3]: http://www.wangxiaofeng.net/?p=291
 [4]: http://news.sina.com.cn/s/2006-07-31/053210581016.shtml