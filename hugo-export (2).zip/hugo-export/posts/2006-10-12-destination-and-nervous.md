---
title: 目的地啊，忐忑
author: Chouj
type: post
date: 2006-10-12T14:30:00+00:00
url: /2006/10/12/destination-and-nervous/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/10/blog-post_12.html
views:
  - 1788
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969821
categories:
  - 我记录
tags:
  - 南海所
  - 图片

---
<div>
  <a href="http://photos1.blogger.com/blogger2/4366/415671023967385/1600/map.jpg" target="_blank"><img style="CURSOR: hand" src="http://photos1.blogger.com/blogger2/4366/415671023967385/400/map.jpg" border="0" alt="" /></a>
</div>

<div>
  <a href="http://photos1.blogger.com/blogger2/4366/415671023967385/1600/map2.jpg" target="_blank"><img style="CURSOR: hand" src="http://photos1.blogger.com/blogger2/4366/415671023967385/400/map2.jpg" border="0" alt="" /></a>
</div>

<div>
</div>

<div>
  点击上图看大图
</div>