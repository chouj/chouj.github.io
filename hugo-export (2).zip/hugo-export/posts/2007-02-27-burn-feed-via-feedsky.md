---
title: Feed烧制教程贴 via Feedsky
author: Chouj
type: post
date: 2007-02-27T12:23:52+00:00
url: /2007/02/27/burn-feed-via-feedsky/
views:
  - 5478
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969935
categories:
  - 教程
tags:
  - Burn
  - feedsky
  - Tutorial

---
<span style="font-size: large;"><span style="font-weight: bold;">为</span></span>什么很多博客上有花里胡哨的订阅按钮呢？那是因为博主为他的博客RSS烧制了一个Feed，提供Feed烧制服务的网站，一般都支持在线生成订阅按钮的服务。除此之外，我们能获得的好处还包括：对订阅数、订阅源进行一定的跟踪；Feed url页面更加美观，等等。

<a href="http://www.feedsky.com/" target="_blank"><span style="font-weight: bold; font-size: large;">F</span>eedsky</a>/<a href="http://www.feedburner.com/" target="_blank">Feedburner</a>是国内外两家最常见的提供烧制服务的网站，既然本博客面向中文用户，就以[Feedsky][1]为例，图解Feed烧制过程。

<span style="font-size: large;"><span style="font-weight: bold;">下</span></span>图为您登录后的<a href="http://www.feedsky.com/" target="_blank">Feedsky</a>首页图：

<p style="text-align: center">
  <figure style="width: 500px" class="wp-caption aligncenter"><a href="http://pic.yupoo.com/xcchris/885359b38e98/n6ah7ndo.jpg"><img title="Feedsky首页" src="http://pic.yupoo.com/xcchris/885359b38e98/n6ah7ndo.jpg" alt="Feedsky首页" width="500" /></a><figcaption class="wp-caption-text">Feedsky首页</figcaption></figure> 
  
  <p>
    <span><br /> <span style="font-size: large;"><span style="font-weight: bold;">圈</span></span>一和圈二，<a href="http://www.feedsky.com/" target="_blank">Feedsky</a>告 诉您为什么要烧一个Feed。圈三处，即是需要您录入的地方。若以为本博客烧Feed为例，填入的地址就可以是http: //www.xuchi.name/bog/或博客的初始RSS，即http: //www.xuchi.name/blog/feed/。博客的初始RSS可以在“订阅”、XML或RSS字样处找 到。录入完毕，点击下一步，见到下图：</span>
  </p>
  
  <p>
    <span> </span>
  </p>
  
  <p style="text-align: center">
    <figure style="width: 500px" class="wp-caption aligncenter"><a href="http://pic.yupoo.com/xcchris/804869b38e98/4egep265.jpg"><img title="Feedsky添加feed" src="http://pic.yupoo.com/xcchris/804869b38e98/4egep265.jpg" alt="Feedsky添加feed" width="500" /></a><figcaption class="wp-caption-text">Feedsky添加feed</figcaption></figure> 
    
    <p>
      <span style="font-size: large;"><span style="font-weight: bold;">机</span></span>器 自动取得了Feed所指向的博客标题，剩下的信息可自行进行补充。新Feed地址即以http://feed.feedsky.com/打头，起名本着与 博客相关，好记的原则。本博客的Feed即烧制为http://feed.feedsky.com/aboutrss。点击下一步：
    </p>
    
    <p style="text-align: center">
      <figure style="width: 500px" class="wp-caption aligncenter"><a href="http://pic.yupoo.com/xcchris/056069b38e98/46nehs6c.jpg"><img title="Feedsky添加feed成功" src="http://pic.yupoo.com/xcchris/056069b38e98/46nehs6c.jpg" alt="Feedsky添加feed成功" width="500" /></a><figcaption class="wp-caption-text">Feedsky添加feed成功</figcaption></figure> 
      
      <p>
        <span style="font-size: large;"><span style="font-weight: bold;">提</span></span>示烧制成功。上图中的小问号，即帮助您更好的享用服务，推荐过目。下面进入Feed管理。在Feed统计中，Feed订阅量以及该量的变化都将直观的呈现在您面前。<br /> <figure style="width: 500px" class="wp-caption aligncenter"><a href="http://pic.yupoo.com/xcchris/780199b3910a/bcb6zmlj.jpg"><img title="Feedsky feed管理" src="http://pic.yupoo.com/xcchris/780199b3910a/bcb6zmlj.jpg" alt="Feedsky feed管理" width="500" /></a><figcaption class="wp-caption-text">Feedsky管理</figcaption></figure>
      </p>
      
      <p>
        <span style="font-size: large;"><span style="font-weight: bold;">订</span></span>户使用什么样的订阅工具，您也能做到心中有数。
      </p>
      
      <p style="text-align: center">
        <a href="http://pic.yupoo.com/xcchris/798519b3910b/gg6iduwv.jpg" ><img src="http://pic.yupoo.com/xcchris/798519b3910b/gg6iduwv.jpg" border="0" alt="Feedsky订阅工具统计" width="500" /></a>
      </p>
      
      <p>
        <span style="font-size: large;"><span style="font-weight: bold;">一</span></span>般普通RSS的页面都是如下显示的，即一堆代码：
      </p>
      
      <p style="text-align: center">
        <a href="http://pic.yupoo.com/xcchris/127129b3910b/oauspcs1.jpg" ><img src="http://pic.yupoo.com/xcchris/127129b3910b/oauspcs1.jpg" border="0" alt="RSS代码" width="500" /></a>
      </p>
      
      <p>
        <span style="font-size: large;"><span style="font-weight: bold;">有</span></span>了<a href="http://www.feedsky.com/" target="_blank">Feedsky</a>的Feed优化，您的Feed页面将变得个性美观，便于订阅和浏览。
      </p>
      
      <p style="text-align: center">
        <a href="http://pic.yupoo.com/xcchris/385099b3910b/355vzcqc.jpg" ><img src="http://pic.yupoo.com/xcchris/385099b3910b/355vzcqc.jpg" border="0" alt="Feedsky Feed模版" width="500" /></a>
      </p>
      
      <p>
        <span style="font-size: large;"><span style="font-weight: bold;">同</span></span>时，您使用网摘或相册服务的话，还可以将这些服务的更新情况加载到Feed中来，方便订户全方位了解您的更新信息。Feed发布即包括订阅图标生成，统计图标生成、email订阅按钮生成等服务。
      </p>
      
      <p style="text-align: center">
        <a href="http://pic.yupoo.com/xcchris/616809b3910b/p5brpvt2.jpg" ><img src="http://pic.yupoo.com/xcchris/616809b3910b/p5brpvt2.jpg" border="0" alt="Feedsky Feed优化显示" width="500" /></a>
      </p>
      
      <p>
        <span style="font-size: large;"><br /> <span style="font-weight: bold;">不</span></span>同的按钮针对不同的阅读工具，自己对订阅按钮进行挑选和DIY，搭配出合适您博客的排列，然后将自动生成的代码粘贴到您博客的合适位置，您的博客就拥有漂亮的订阅图标啦。
      </p>
      
      <p>
        <span><span style="font-size: large;"><span style="font-weight: bold;">一</span></span>次全部操作完成，即可一劳永逸，既把握了自己博客的订阅情况，也方便了欲订阅您博客的博友。第一次知道的朋友，赶紧去试试吧！</span>
      </p>

 [1]: http://www.feedsky.com/