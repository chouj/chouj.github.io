---
title: 统计分析一下你的blog吧
author: Chouj
type: post
date: 2006-08-29T10:47:00+00:00
url: /2006/08/29/stats-analyze-tool-for-blog/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/08/blog.html
views:
  - 2187
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969798
categories:
  - 我表达
tags:
  - blog
  - 网络

---
<span style="font-size:180%;"><strong>blog</strong></span>的流量想必每个blogger都会或多或少关心下的，单一的计数器也许不能满足我们的需要了。这就需要blogger对自己的领地进行统计分析啦，不外乎申请一个统计服务，然后嵌入其所提供的代码到你的blog里。

<span style="font-size:180%;"><strong>常</strong></span>见的免费统计分析工具有:

 <img src="http://www.cnzz.com/stat/images/icon.gif" border="0" alt="" />[站长统计][1]
  
 <img src="http://www.itsun.com/stats.gif" border="0" alt="" />[ITSUN网站流量统计][2]
  
 <img src="http://icon.ajiang.net/icon_0.gif" border="0" alt="" />[我要啦 免费统计 51.LA][3]
  
<img src="http://count1.51yes.com/count1.gif" border="0" alt="" /><a href="http://count.51yes.com" target="_blank">http://count.51yes.com</a>
  
<img src="http://www.statcounter.com/images/statcounter_best_web_tracker_and_counter.gif" border="0" alt="" />
  
<a href="http://my.cnw.cn/show.php" target="_blank"><img src="http://my.cnw.cn/stats/count.php?&style=501&did=1617" border="0" alt="" /></a>
  
[<img id="logo" src="http://www.google.com/analytics/images/logo_ga.gif" border="0" alt="" width="227" height="65" />][4]

**<span style="font-size:180%;">这</span>**些都是相当不错的免费统计工具。大致功能均为访客ip记录，访问量统计分析，访客地域统计，访客浏览器统计，访客系统统计之类。就以上统计服务，据我所知评述如下：

**<span style="font-size:180%;">前</span>**两个我只用过一段时间，但最后放弃了，因为比较中规中矩，缺乏图形分析，形象化元素太少。只不过站长统计[站长统计][5]有个优点就是可以显示当前页面在线的人数。

**<span style="font-size:180%;">中</span>**间两个其实是不错的统计工具，我没选用的原因是在教育网下要开代理才行。就51.LA首页上的介绍，功能还是很强大的，而且很形象。Statcounter是国外的统计服务，没用过，想必不错。
  
**<span style="font-size:180%;">最</span>**后两个是我现在还在用的统计服务。[网界][6]是[donews][7]合作的统计平台，因为[我的备份blog][8]的缘故，接触到了这里。php编写的站点，动态生成flash，操作傻瓜，图形丰富。给几个图例如下：

<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_blog-1.jpg" border="0" alt="" />

8月份访问量柱状图，很不错吧。

<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_blog-2.jpg" border="0" alt="" />

访客明细，逃不过我的眼睛，所以丫们看到这里的就小心了，你们在此的行踪尽在掌握哟。

Google analytics 就属于非常权威、非常细致的统计了，也很形象，先给个图。

<img src="http://blog.donews.com/images/blog_donews_com/xcchris/107822/o_blog-3.jpg" border="0" alt="" />

很细致吧，以上是google提供的最基本的分析，都非常实用非常不错，只是并没有像网界那样提供ip地址分析。

<span style="font-size:180%;"><strong>所</strong></span>以，bloggers各取所需吧，不过写blog就是不能在意这些比较没有意义的东西，否则陷入追逐流量虚荣之中，blogging的动机就不纯了。blog就是要做到有感而发，无感不发，勿被其他所累。

 [1]: www.cnzz.com
 [2]: http://www.itsun.com/
 [3]: http://www.51.la/
 [4]: http://www.google.com/analytics/
 [5]: http://beta.blogger.com/www.cnzz.com
 [6]: http://my.cnw.cn/
 [7]: http://blog.donews.com
 [8]: http://blog.donews.com/xcchris