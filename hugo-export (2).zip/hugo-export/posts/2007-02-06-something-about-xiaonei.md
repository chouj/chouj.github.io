---
title: 挑校内网xiaonei.com的刺儿
author: Chouj
type: post
date: 2007-02-06T06:46:00+00:00
url: /2007/02/06/something-about-xiaonei/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/xiaoneicom.html
views:
  - 1876
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969848
categories:
  - 我思考
tags:
  - blog
  - 校内网
  - 网络

---
<a href="http://bp0.blogger.com/_2MqU1LfBbeM/RcgsJH_upBI/AAAAAAAAACY/ucHIdmAFo4Q/s1600-h/xnw.jpg" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5028317519235949586" style="cursor: pointer;" src="http://bp0.blogger.com/_2MqU1LfBbeM/RcgsJH_upBI/AAAAAAAAACY/ucHIdmAFo4Q/s400/xnw.jpg" border="0" alt="" /></a>

> 将如下链接发给朋友,他们不必登录就可看到你的页面 (<span style="font-weight: bold;">不要放到其他网站上,否则baidu或google会搜到这个页面</span>)

<span style="font-size:180%;"><span style="font-weight: bold;">哈</span></span>哈，非常希望<a href="http://xiaonei.com/" target="_blank">校内网</a>能对上面那个粗体句子给我一个合理的解释，不然我就不能克制的要从负面因素来揣测其不良用心。

<span style="font-size:180%;"><span style="font-weight: bold;">我</span></span>是不喜欢<a href="http://xiaonei.com/" target="_blank">校内网</a>和<a href="http://qzone.qq.com/" target="_blank">Qzone</a>这种社区型服务的，却又眼红其聚集的高昂人气。鉴于我这阴暗的心理，我猜想<a href="http://xiaonei.com/" target="_blank">校内网</a>的这个用意是“不可告人”的。每个做网站的ITer都希望自己的站点能为搜索引擎索引到，而且梦想他们能将自己的站名排在首位；每个终端用户也都希望自己的个人页面能被索引到，并置于显要位置，为何<a href="http://xiaonei.com/" target="_blank">校内网</a>要反其道行之呢？莫非，担心自己的服务器无法承担搜索引擎所带来的更大流量？还是想降低知名度来消减其copy <a href="http://www.facebook.com/" target="_blank">facebook.com</a> 所带来的风险？

<span style="font-size:180%;"><span style="font-weight: bold;">昨</span></span>天还和<a href="http://peacefulfire.blogspot.com/" target="_blank">麦子</a>聊到过<a href="http://xiaonei.com/" target="_blank">校内网</a>，因为周围玩<a href="http://xiaonei.com/" target="_blank">校内</a>和<a href="http://qzone.qq.com/" target="_blank">Qzone</a>的人远多于博客圈的人，而我俩又对博客抱有同样的信仰，似乎有那么点无奈和悲凉。记得有同学跟我说他也有博客了，我问他地址，然后他给了我一个他[校内网][1]的链接，我当时就觉得哭笑不得。在我眼里，这种社区型站点所提供的日志发布服务，纯粹就是玩具，根本配不上博客的理念，最起码，连RSS输出都不具备。而我所抱有的博客的信仰，确是建立在这“侠义”的博客的基础上的（用到“‘侠义’的博客”让我觉的很不幸）。“全民博客”的口号响了很久，效果显著（比如这位<a href="http://blog.sina.com.cn/m/gaoyaojie" target="_blank">老奶奶</a>）。但我泡在网上这么久，所见到的理解博客理念的人仍以ITers和高知识水平的资深网民居多，很多的blogger根本不理解![][2]有什么用，或者压根儿没注意到它。而按长尾理论，千千万万的草根博客才是其价值所在，但在我看来，这价值得以体现的基础之一，就是博客理念的深入人心。

> 诚挚的说，这种浮华和斗秀的地方，不适合放心路历程。

<span style="font-size:180%;"><span style="font-weight: bold;">我</span></span>记得我曾在某<a href="http://qzone.qq.com/" target="_blank">Qzone</a>留下这样的话，“浮华”和“斗秀”即是我对国内SNS社区的基本感觉，而这正式我对这些地方厌恶的原因。不过，存在即合理，昨天还见到了这句话。我所承认的SNS社区，是其社会化网络的交流功能，它的兴盛在于满足了人的群体性，正是这个为网站带来了人气和金钱。但现阶段BLOG≠SNS，BLOG通过RSS和抓虾这类聚合内容服务站，构建了无限空间，但SNS用户间的交流却只能局限于各自的SNS，我自私得不愿看到把<a href="http://xiaonei.com/" target="_blank">校内网</a>当作博客这样的笑话发生。未来是否会发展到将两者聚合到一起，我觉得很有可能，不过还是那句，要让所有人把“![][2]是什么”理解了再说。愿这不是一个长期而曲折的过程。

<span style="font-size:180%;"><span style="font-weight: bold;">再</span></span>扯回到那张<a href="http://xiaonei.com/" target="_blank">校内网</a>的图。我不是搞网站的，可能理解有些偏颇，但愿别让我的言语成为了知名社区光环下的阴影。

<span style="font-size: 180%; color: #666666;"><span style="font-weight: bold;">P</span></span><span style="color: #666666;">S. 想借用RSS在校内网上即时输出Recent Posts，宣告失败，原因如下：</span>

> &#8220;script&#8221;是在涂鸦板里面禁用的字符串

<span style="color: #666666;">只好去手动借人气了。。校内破网。。</span>

update：若干月后再看这文，感觉有些傻逼，明明是保护用户隐私嘛。。

 [1]: http://xiaonei.com/
 [2]: http://image2.sina.com.cn/blog/tmpl/v3/images/xmlRSS2.gif