---
title: 天凉好个秋～
author: Chouj
type: post
date: 2006-09-08T04:02:00+00:00
url: /2006/09/08/is-it-a-poem/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/blog-post_08.html
views:
  - 1798
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969804
categories:
  - 我表达
tags:
  - 诗

---
<div>
  <span style="color: #999999;">当信念被颠覆</span>
</div>

<div>
  <span style="color: #999999;">当光明被遗忘</span>
</div>

<div>
  <span style="color: #999999;">当沉沦拧成狰狞的漩涡</span>
</div>

<div>
</div>

<div>
  <span style="color: #999999;">多么希望</span>
</div>

<div>
  <span style="color: #999999;">世界</span>
</div>

<div>
  <span style="color: #999999;">独我</span>
</div>

<div>
</div>

<div>
  <span style="color: #999999;">我以我血荐轩辕</span>
</div>

<div>
  <span style="color: #999999;">我以我心映明月</span>
</div>

<div>
  <span style="color: #999999;">我何从寻找永恒的突破</span>
</div>

<div>
</div>

<div>
  <span style="color: #999999;">皈依我佛</span>
</div>

<div>
  <span style="color: #999999;">逼我</span>
</div>

<div>
  <span style="color: #999999;">苟活</span>
</div>

<div>
</div>

<div>
</div>

<div>
</div>

<div>
  <strong><span style="font-size:180%;">在</span></strong>自习教室看概率论，看着看着脑袋里莫名的蹦出一句七言：“<span style="color: #666666;">寰宇天下一鸣秋</span>”。哪天再受刺激估计就会蹦出二、三、四句，敬请期待。
</div>

<div>
</div>

<div>
  2006.9.8于西十二S512
</div>