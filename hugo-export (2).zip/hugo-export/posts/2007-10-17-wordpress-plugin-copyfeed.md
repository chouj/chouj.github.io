---
title: '[WP插件]©Feed指南及其汉化版'
author: Chouj
type: post
date: 2007-10-17T12:16:45+00:00
url: /2007/10/17/wordpress-plugin-copyfeed/
views:
  - 2392
  - 2392
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969989
categories:
  - WordPress
  - 教程
tags:
  - Plugin
  - Tutorial
  - WordPress

---
适用于WordPress的**[©Feed][1]**插件功能强大，可在feed footer添加**版权声明**、**数字指纹、文章留言**、**相关文章标题**，还可以控制feed**是否全文输出**，因而很多bloggers都安装并启用了这款插件。现在，为方便国内用户，[Anthony][2]汉化了该插件，请有需要的朋友移步至此下载：

<p align="center">
  [ <a href="http://www.angryouth.com/2007/10/15/copyrightfeed-chinese/" title="CopyRightFeed 汉化版" target="_blank">点此进入<strong>©Feed汉化版</strong>下载页</a> ]
</p>

<p align="center">
  &nbsp;
</p>

<!--more-->


  
虽然中文blog圈儿内已经出现了不少该插件的使用教程，但抽儿还是PS了些图作个指南，会使用该插件的朋友可以跳过。

<img src="http://photo11.yupoo.com/20071017/185404_39287532_dqnzfbiy.jpg" title="RSS相关-plugin-copyfeed-copyright" alt="RSS相关-plugin-copyfeed-copyright" height="419" width="381" />

**添加版权声明的html代码**：由于数字指纹的存在，插件用三个输入框共同完成代码的设定，会html的朋友就可以自行设计啦。数字指纹框下会随机给出一组key，直接copy到输入区即可，或者自行创造一个也一样。这里放出[RSS相关][3]的代码供参考～

<coolcode linenum="off">

* * *

<small></p> 

<p>
  <a target="_blank" rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/cn/"><br /> <img alt="Creative Commons License" style="border-width: 0pt;" src="http://i.creativecommons.org/l/by-nc-nd/2.5/cn/80x15.png" /><br /> </a>本站作品采用<a target="_blank" rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/cn/">知识共享署名-非商业性使用-禁止演绎 2.5 中国大陆许可协议</a>进行许可。<br /> Copyright&copy; 2007 作者及版权归属: <a href="http://www.xuchi.name">抽筋儿</a> at <a href="http://aboutrss.cn">RSS相关</a> (数字指纹:数字指纹:97038184b23d995ffd319294ee2e36d3)</small>
</p>

<p>
  </coolcode>
</p>

<p>
  可以在该页面下方的Preview ©Feed区点击Update预览代码效果：
</p>

<p>
  <img src="http://photo5.yupoo.com/20071017/185406_283658508_bzvollfs.jpg" title="RSS相关-plugin-copyfeed-preview" alt="RSS相关-plugin-copyfeed-preview" height="196" width="381" />
</p>

<p>
  <strong>添加文章评论进Feed</strong>：只需作下图中的勾选，并调整下代码：
</p>

<p>
  <img src="http://photo11.yupoo.com/20071017/185405_500558733_qvtzghuj.jpg" title="RSS相关-plugin-copyfeed-comment" alt="RSS相关-plugin-copyfeed-comment" height="482" width="382" />
</p>

<p>
  可依据提供的参数，自行设定文章评论在feed里的显示样式，给出一个实效如下：
</p>

<p>
  <img src="http://photo5.yupoo.com/20071017/190847_276974187_qrkfunef.jpg" title="RSS相关-plugin-copyfeed-effect" alt="RSS相关-plugin-copyfeed-effect" height="372" width="423" />
</p>

<p>
  <strong>添加相关文章进Feed</strong>： 可如下图设置，但我并没启用此功能，因为发现文章关联性不强。
</p>

<p>
  <img src="http://photo11.yupoo.com/20071017/185406_1574881970_iqhsfkah.jpg" title="RSS相关-plugin-copyfeed-related" alt="RSS相关-plugin-copyfeed-related" height="624" width="384" />
</p>

<p>
  <strong>Feed全文输出的设置</strong>： 支持使用more标签的情形下依然全文输出，只需勾选此项：
</p>

<p>
  <img src="http://photo11.yupoo.com/20071017/185406_2103260915_hvycyjuk.jpg" title="RSS相关-plugin-copyfeed-fullfeed" alt="RSS相关-plugin-copyfeed-fullfeed" height="181" width="381" />
</p>

<p>
  <strong>内容剽窃搜查</strong>：数字指纹段是可以被搜索引擎爬虫follow的，故可搜索该指纹以查知文章是否被剽窃（剽窃者会剽窃个指纹咩？有点奇怪～）：
</p>

<p>
  <img src="http://photo5.yupoo.com/20071017/190847_364677109_hxyoibtd.jpg" title="RSS相关-plugin-copyfeed-search" alt="RSS相关-plugin-copyfeed-search" height="338" width="381" />
</p>

 [1]: http://wordpress.org/extend/plugins/copyfeed/ "©Feed"
 [2]: http://angryouth.com/ "愤青团"
 [3]: http://aboutrss.cn "RSS相关"