---
title: 与RSS有关的网摘
author: Chouj
type: post
date: 2008-10-20T15:22:43+00:00
url: /2008/10/20/articles-about-rss-collected/
views:
  - 1988
  - 1988
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969756
categories:
  - 相关
tags:
  - Bookmark
  - Share
  - widget
  - 搜集

---
<img src="http://pic.yupoo.com/xcchris/46767660067b/medium.jpg" alt="搜罗天下有关RSS的优秀文章" width="275" height="500" align="left" />草莓版RSS相关信息汇集停止于<a title="草莓版07年10月汇集" href="http://aboutrss.cn/2007/11/articles-about-rss-in-october/" target="_self">去年十月</a>(其实没做几期)，这是一项我觉得挺有意义的工作，能实现信息的浓缩和再消化。一年过去了（似乎网络上草莓版的东西活得不大长），估计以后我也不会重新拾它起来，一是因为写它太费精力，负担不起，时间是需要用在刀刃上的；二是目前博客圈都弥漫着倦怠，文章质和量都趋于下乘，以RSS为题材的文与同期相比更是少了许多。

不过，还是需要靠群策群力来为RSS应用广而告之，所以我以网摘的形式，分享中文虚拟世界里不时出现的RSS相关文章，将它们收录于侧栏。正如左图所示，此栏目唤作“[搜罗天下有关RSS的优秀文章][1](<a title="feed for articles collected" href="http://feeds.delicious.com/v2/rss/xcchris/rss" target="_blank">feed</a>)”。围绕RSS应用的新闻、讨论、介绍都包含于其中。欢迎朋友们或关注，或订阅。

说实话，通过搜索引擎过来的点击都有很强的目的性，是为问题而来，不是为浏览而来。所以该栏目收录条目超过100，但点击率依然很差，特独立撰文提携一下，望能有朋友从中受益。

[ **[搜罗天下有关RSS的优秀文章][1]** | <a title="feed for articles collected" href="http://feeds.delicious.com/v2/rss/xcchris/rss" target="_blank">feed</a> ]

 [1]: http://delicious.com/xcchris/rss "搜罗天下有关RSS的优秀文章"