---
title: 一场垃圾比赛
author: Chouj
type: post
date: 2006-06-11T03:31:00+00:00
url: /2006/06/11/awful-game/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/06/blog-post.html
views:
  - 1342
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969781
categories:
  - 我表达
tags:
  - 世界杯

---
英格兰 vs 巴拉圭 1:0
  
球在天上的时间比在地上的时间还多，不如两个门将把球大脚踢过来再大脚踢过去，其他20个人在裁判带领下，围着中圈玩杀人！
  
居然还能把球开到球场上方的显示屏上。。。。佩服。。。
  
丫英格兰就这么凭借乌龙拿了三分，丢人啊丢人。。。白云上都有名为“欧洲就只靠意大利”的帖子了。。。唉。。。