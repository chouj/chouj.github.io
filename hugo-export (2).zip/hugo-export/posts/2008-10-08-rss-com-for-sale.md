---
title: RSS.com即将拍卖
author: Chouj
type: post
date: 2008-10-08T03:26:14+00:00
url: /2008/10/08/rss-com-for-sale/
views:
  - 1344
  - 1344
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970023
categories:
  - 新闻
tags:
  - RSS.com

---
<img src="http://pic.yupoo.com/xcchris/403996216d4e/jgrrv8n1.jpg" alt="RSS.com即将拍卖" width="172" height="129" style="float: left; margin-left: 10px; margin-right: 10px;" />根据<a title="RSS.com for sale" href="http://www.rss-specifications.com/blog.htm#911" target="_blank">RSS blog的消息</a>，<a title="rss.com" href="http://rss.com" target="_blank">RSS.com</a>域名将在10月16日拍卖，且拍卖最低价格为750,000USD，<a href="http://www.greatdomains.com/auction/auction_detail.php?language=us&auction_id=42674&tracked=&partnerid=32392" target="_blank">GreatDomains.com</a>和<a href="http://www.sedo.co.uk/auction/auction_detail.php?language=e&auction_id=42674&tracked=&partnerid=" target="_blank">Sedo</a>上都已有拍卖日程。该域名下没有内容，PR为4，alexa排名63万+。

想必大家都跟我一样想知道该域名花落谁家，会孕育出一个什么样的站，那就让我们拭目以待吧。