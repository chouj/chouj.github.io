---
title: 使用FeedzShare实现信息过滤
author: Chouj
type: post
date: 2009-01-17T11:04:56+00:00
url: /2009/01/17/use-feedzshare-to-filter/
views:
  - 1759
  - 1759
duoshuo_thread_id:
  - 1279764464521970034
categories:
  - 工具
  - 教程
tags:
  - FeedzShare
  - Filter

---
<img style="float: left; margin-left: 10px; margin-right: 10px;" src="http://pic.yupoo.com/xcchris/214316d1520a/pxsblws4.jpg" alt="FeedzShare：“中文版”的ReadBurner" width="224" height="50" align="left" />经<a href="http://aboutrss.cn/2009/01/feedzshare/#comment-790" target="_self">Kuber的回复</a>获知，FeedzShare还有一个<a title="FeedzShare：“中文版”的ReadBurner" href="http://aboutrss.cn/2009/01/feedzshare/" target="_self">尚未提到</a>的有趣功能：我们现在可以利用FeedzShare以推荐数的多寡为门限来进行信息过滤。所以，像cnBeta和译言这类更新较快的站点，我们就可以挑选受众人推荐的信息来进行阅读，从而节省时间，免去信息过载之忧。

方法如下：

FeedzShare首页左侧栏，点击“过滤”，就进入到信息过滤的界面：

<img src="http://pic.yupoo.com/xcchris/272176d51e3c/3xvejjas.jpg" alt="FeedzShare实现信息过滤" width="468" height="183" />

<!--more-->

输入想过滤信息的站点地址，以cnBeta为例，回车如下：

<img src="http://pic.yupoo.com/xcchris/324776d51e3d/mzk89ls3.jpg" alt="FeedzShare实现信息过滤" width="468" height="397" />

如图红线处，可选择推荐人数门限值，比方只筛出推荐人数多于和等于4的cnBeta文章。然后黄线处，即为经过过滤后的信息RSS输出地址。订阅这个地址即实现了信息的过滤。这个方法对于更新过频的站来说，还是十分管用的。

[ <a title="FeedzShare过滤页面" href="http://www.feedzshare.com/b" target="_blank">点此进入FeedzShare过滤页面</a> ]