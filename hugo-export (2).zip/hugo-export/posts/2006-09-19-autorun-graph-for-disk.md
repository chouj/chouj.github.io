---
title: 社会实践光盘Autorun界面
author: Chouj
type: post
date: 2006-09-19T02:35:00+00:00
url: /2006/09/19/autorun-graph-for-disk/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/autorun.html
views:
  - 1972
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969811
categories:
  - 我尝试
tags:
  - Autorun
  - 图片
  - 物理系
  - 社会实践

---
<img src="http://lh6.google.com/xcchris/RQ1rPtNeABI/AAAAAAAAABI/ZoJhNMt2yAE/%E6%9C%AA%E6%A0%87%E9%A2%98-1.jpg" border="0" alt="社会实践光盘Autorun界面" width="450" />

**<span style="font-size:180%;">那</span>**4行斗4俺们活动主题！！最后一句斗4俺想出来滴！！被逼无奈要向第一行押韵呐。。俺们那队伍叫“水乡行”社会实践队…俺们那总结居然有100多pages…最近还要俺给团队评优做一KT版…NND~~做出来鸟就贴出来～～

**<span style="font-size:180%;">PS</span>**.为照顾俺blog布局&#8230;不符合规格的pictures都加了width=&#8221;450&#8243;标签，不是原始大小…可以自行查其网络地址再打开鸟看 ^_^