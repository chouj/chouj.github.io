---
title: 我使用的博客虚拟主机
author: Chouj
type: post
date: 2008-05-27T18:12:35+00:00
url: /2008/05/28/my-blog-host/
views:
  - 3606
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969893
categories:
  - 我尝试
tags:
  - WordPress
  - 博客主机

---
<span style="color: #888888;">写这么一篇文章，我就能从<a title="2号博客主机举办抽奖活动" href="http://jiangzhanyong.com/2008/05/blog-hosting-contest-2rd-hosting-843.html" target="_blank">总统</a>那里收获拾元人民币，这个数在我整个blog月收入里占到99.99%，所以我写的义无反顾义不容辞，心甘情愿被他收买，为其做病毒式传销。嘿嘿。当然，货肯定是好货，包满意。</span>

<a title="完美支持 WordPress 等 php 博客程序" href="http://wpchina.org/hosting/" target="_blank"><img src="http://wpchina.org/images/w-clients-20060-1.gif" alt="WP博客主机" /></a>

侧栏最下的这个标识表征了我目前使用的主机，它也正是本话题广告的主角：总统的WordPress中文站所提供的<a title="WordPress专业主机" href="http://wpchina.org/hosting/" target="_blank">博客主机</a>。

和<a title="总而言之，统而言之" href="http://jiangzhanyong.com" target="_blank">总统</a>认识挺久的了，那还是在他代理盘古主机的时候，我从他手上买入了第一款虚拟空间来架设独立blog。但盘古服务不大稳定，诟病较多，<a title="总而言之，统而言之" href="http://jiangzhanyong.com" target="_blank">总统</a>弃而自谋美国主机HostGator，开始组织主机合租。我在盘古空间到期之后，就立即扑入了总统<a title="WordPress专业主机" href="http://wpchina.org/hosting/" target="_blank">WordPress专业主机</a>的怀抱（麻死人不偿命）。

二号主机上线运行以来，一直表现良好，<a title="总而言之，统而言之" href="http://jiangzhanyong.com" target="_blank">总统</a>的服务也是尽心尽力，热心到位，此次抽奖活动反映出<a title="总而言之，统而言之" href="http://jiangzhanyong.com" target="_blank">总统</a>是一位善良的商人（囧，hoho），得到了二号主机用户的普遍爱戴。

现在总统组织的四号主机合租正在进行中，四号主机和二号主机具备同样的规格，大体是：

  * 磁盘空间：500M；
  * 每月流量：5G；
  * 可绑定顶级域名：3个；
  * 可绑定子域名：10个；
  * 可用数据库：3个；
  * 独立的Cpanel帐户：1个，中英文可切换；

具体参数和细节问题可前去<a title="WordPress专业主机" href="http://wpchina.org/hosting/" target="_blank">博客主机</a>页面查看，欢迎垂询。

<span style="color: #888888;">写完咯，开始惦记钱钱&#8230;</span>