---
title: RSS聚合器 之 Gregarius
author: Chouj
type: post
date: 2007-07-14T14:42:32+00:00
url: /2007/07/14/gregarius/
views:
  - 1576
  - 1576
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969963
categories:
  - 工具
tags:
  - Aggregator
  - Gregarius

---
  * **<font color="#009900">什么是RSS聚合器？</font>**

  **RSS聚合器**是一种以用户被动更新模式更新，可读取RSS Feed / XML并显示新闻项的程序，可以方便地在线获取、阅读和管理RSS/XML格式的信息。

  * **<font color="#009900">Gregarius</font>**

个人认为**Gregarius**已经是一款相当成熟的RSS feed聚合器程序了，具备不错的用户体验，易于操作和管理。[抽儿][1]就是拿这款程序架设的RSS阅读器。特性如下：

  1. 支持 RDF, RSS, ATOM feeds 支持智能识别；
  2. 基于浏览器Web端的前台浏览和后台管理；
  3. 支持目录分类，支持标签系统，并运用了ajax技术；
  4. 支持搜索；
  5. 支持OPML；
  6. 可显示favicon；
  7. 支持已读未读分类和条目数量显示；
  8. 具有多种主题样式，支持插件；

前台样式：

<img src="http://gregarius.net/img/shot.png" height="213" width="414" />

后台含八个管理标签，分别为“控制面板”、“Feed管理”、“条目管理”、“设置”、“插件”、“主题”和“分类目录”，操作简单。

**Demo站点**：

[**OpenRSS**][2]

<strike>[**话语权**][3]</strike>

**Gregarius运行环境**要求：

  * <a href="http://httpd.apache.org/" class="external text" title="http://httpd.apache.org/" rel="nofollow">Apache服务器</a>（推荐）
  * <a href="http://php.net/" class="external text" title="http://php.net" rel="nofollow">PHP</a> (PHP 4.x 或 PHP 5.x, 4.3+ 推荐)
  * 数据库 [MySQL][4] 和 [SQLite][5]

**[Gregarius主页][6]** | **[Gregarius 0.5.4 原版下载页面][7]** | **[Gregarius 0.5.3 的安装说明][8]**

最后提一下[抽儿][1]在使用中的一些感受。首先，空间的访问速度和php的版本会直接影响feed添加以及OPML导入的成败，某些时候可能feed添加成功，但没有成功读取到内容，或抓取后不能实时更新，这在[话语权][3]中表现比较明显。其次，Gregarius有经过汉化的版本，搜索可得（比如[这里][9]），但汉化的不彻底，更新时间显示为乱码，可能涉及编码UTF-8/GB2312的支持和时间日期代码格式的问题。还有就是Gregarius对Feedsky的Feed不友好。

<p class="poweredbyperformancing">
  Powered by <a href="http://scribefire.com/">ScribeFire</a>.
</p>

 [1]: http://www.xuchi.name/blog
 [2]: http://www.openrss.net/
 [3]: http://www.xuchi.name/say/
 [4]: http://wiki.gregarius.net/index.php/MySQL "MySQL"
 [5]: http://wiki.gregarius.net/index.php/SQLite "SQLite"
 [6]: http://gregarius.net/
 [7]: http://sourceforge.net/project/showfiles.php?group_id=98845
 [8]: http://www.linji.cn/1061.htm
 [9]: http://www.cncode.com/downinfo/5169.html