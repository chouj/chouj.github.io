---
title: '[WP插件]RSS includes Pages'
author: Chouj
type: post
date: 2008-11-05T01:47:53+00:00
url: /2008/11/05/rss-includes-pages-wp-plugin/
views:
  - 1602
  - 1602
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970026
categories:
  - WordPress
tags:
  - Plugin
  - WordPress

---
<img style="float: left; margin-left: 10px; margin-right: 10px;" title="WordPress Plugin about RSS" src="http://pic.yupoo.com/xcchris/309805b2a084/qye3bzys.jpg" alt="WordPress" />如果你使用WordPress搭建CMS，那么一定会较多得利用“页面”元素来显示你的内容，但页面内容是不会输出到RSS feed的。怎么解决这个问题，输出页面信息到feed中呢？我们可以使用一个插件：**RSS includes Pages**。

**简介**：

作者：<a title="Author Homepage" href="http://www.mariosalexandrou.com/" target="_blank">marios-alexandrou</a>
  
版本：1.0.2
  
适用：WordPress 2.5+
  
功能：不仅是日志内容，也让页面内容输出到RSS feed
  
最后更新：2008.09.04
  
WP-Extend: <http://wordpress.org/extend/plugins/rss-includes-pages/>

<!--more-->

**使用方法**：

上传插件文件至wp-content\plugins\目录下，在WordPress后台激活插件即可。禁用插件后，RSS Feed将回归原始状态。

<a title="[WP插件]RSS includes Pages" href="http://www.mariosalexandrou.com/blog/?p=423" target="_blank">点此进入插件主页：<strong>RSS includes Pages</strong></a>

🙂