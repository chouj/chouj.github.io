---
title: 招商银行Young卡用卡指南.pdf
author: Chouj
type: post
date: 2008-06-06T09:33:31+00:00
url: /2008/06/06/guide-of-cmb-youngcard-pdf/
views:
  - 6586
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969896
categories:
  - 我表达
tags:
  - pdf
  - 下载
  - 信用卡
  - 招商银行

---
<img src="http://www.xuchi.name/blog/wp-content/uploads/2008/06/cmb-youngcard-pdf.jpg" alt="招商银行Young卡用卡指南pdf" width="429" height="373" />

据搜索结果说，可以找招行申请邮寄用卡指南。可是问了丫们在线客服，说木有，具体参见网站。怒了，我就是想弄份完整的观瞻下加备忘嘛。- -#

自己动手。招行Young卡的指南页也够操蛋的，table+切片，愣是copy不出一个字儿。继续怒，网页截图之，现整理好了发布：

**[pdf]招商银行Young卡用卡指南 整理 by Chris <a title="招商银行 Young卡用卡指南.pdf 整理 by Chris" href="http://www.box.net/shared/652cdlg2s8" target="_blank">Box.net下载</a>** [download id=&#8221;3&#8243;]

不知道我这种非官方的二手打理行为有木有触犯啥条条款款，心怯怯然。不管了，造福于民再说。