---
title: 又有RSS标志设计出炉
author: Chouj
type: post
date: 2007-10-07T16:01:13+00:00
url: /2007/10/08/new-styles-of-rss-icons/
views:
  - 1815
  - 1815
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969987
categories:
  - 新闻
  - 标志
tags:
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
![][1]

伴随<a href="http://del.icio.us/popular/rss" target="_blank">美味书签</a>推送过来的两篇文章，<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽儿</a>又发现了不少新的RSS icons设计，实在太多太精美，都贴过来又太费劲儿，<a href="http://www.xuchi.name/blog/" title="抽筋儿" target="_blank">抽儿</a>在这里只给出原文链接，大家点过去看好了。

**[Over 35 Different Styles of RSS Icons
  
][2]** 
  
**[膨大なRSSアイコン。RSSアイコンをお探しの方はこちら][3]**

另，黄金粥期间，国外bloggers似乎对大陆封禁FeedBurner的Feeds特别感兴趣，给出两篇文章如下：

[China&#8217;s Great Firewall turns its attention to RSS feeds][4]——ars technica，Oct 4

[China Blocking RSS Feeds][5]——TechCrunch，Oct 4

 [1]: http://photo11.yupoo.com/20071007/200442_1778442427_snvgidcj.jpg
 [2]: http://www.designbliss.com/2007/09/27/over-25-different-styles-of-rss-icons/ "Over 35 Different Styles of RSS Icons"
 [3]: http://e0166.blog89.fc2.com/blog-entry-298.html "膨大なRSSアイコン。RSSアイコンをお探しの方はこちら。"
 [4]: http://arstechnica.com/news.ars/post/20071004-chinas-great-firewall-turns-its-attention-to-rss-feeds.html
 [5]: http://www.techcrunch.com/2007/10/04/china-blocking-rss-feeds/ "China Blocking RSS Feeds"