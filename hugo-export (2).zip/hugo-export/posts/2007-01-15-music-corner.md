---
title: 音乐一隅 天空之城
author: Chouj
type: post
date: 2007-01-15T12:17:00+00:00
url: /2007/01/15/music-corner/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/01/blog-post_15.html
views:
  - 2284
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969841
categories:
  - 我表达
tags:
  - 音乐

---
<span style="font-size:180%;"><span style="font-weight: bold;">好</span></span>久没写music方面，因为 12月到1月听的东西不多，时间都耗在掺和别的去了。

<span style="font-size:180%;"><span style="font-weight: bold;">12</span></span>月份，听的最多的是摇滚和少许流行歌，陈述一下，不作推荐。

[<img src="http://www.douban.com/lpic/s1638791.jpg" border="0" alt="" />][1]

<span style="font-size:180%;"><span style="font-weight: bold;">初</span></span>次看到“简迷离”三个字还是在豆瓣的一个小组里，down了整盘CD来听，尝试下别人的推荐。中法组合，“新电摇”的风格，并没有赋予这张碟神圣光环。所有歌曲都是不错的摇滚，像别人评价的一样，是国内的高水平，可惜我没从中找到耐听的。初听之时很有新意，但听不长久。别人评价说，少有他们这样真诚做摇滚的，表示下赞同。

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

[<img src="http://www.douban.com/lpic/s1932602.jpg" border="0" alt="" />][2]

[<img src="http://www.douban.com/lpic/s1399968.jpg" border="0" alt="" />][3]

[<span style="font-size:180%;"><span style="font-weight: bold;">C</span></span>oldplay][4] 和 <span class="pl2"><a href="http://www.douban.com/subject_search?search_text=The%20Cranberries&cat=1003">The Cranberries</a></span>早已是推荐对象了，之前也有间歇的听过一些，这次是认真的听了各自的两张CD。基本可以说这两张代表了两支乐队的风格，也是比较受各fans推崇的。听他们的时候一定要静，不能有外界的干扰，不然声音的魅力就浸润不出来，我是把睡眠时间贡献出来了的。

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

<span style="font-size:180%;"><span style="font-weight: bold;">听</span></span>的流行歌比较零散：许慧欣的《威尼斯迷路》听的最多，其次是《梁山泊与朱丽叶》、周迅的《看海》、蔡旻佑的《我可以》，还有<span class="pl2"><a href="http://www.douban.com/subject_search?search_text=Groove%20Coverage&cat=1003">Groove Coverage</a>的《God Is a</span> Girl》。都是在家的时候偶尔从电视里听到的，然后下下来听。刚听《看海》的时候，不知道是谁唱的，最后愕然的发现是周迅。有两张专辑的封面很诱人，豆瓣上很多人在听，最后发现他们在听的是《God <span class="pl2">Is a</span> Girl》。而我为了那诱人的封面去听《God <span class="pl2">Is a</span> Girl》的时候，楞是发现我听过，学校广播也放过。继续拿图片诱惑各位：

[<img src="http://www.douban.com/lpic/s1504744.jpg" border="0" alt="" width="200" />][5]

[<img src="http://www.douban.com/lpic/s1474533.jpg" border="0" alt="" />][6]

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

<span style="font-size:180%;"><span style="font-weight: bold;">1</span></span>月份，慕名看了宫崎骏的《天空之城》，因为豆瓣上1600多的力荐，也因为那首极好听的主题曲。最推荐小提琴和钢琴的纯器乐版，悠扬凄婉，作背景乐或者铃音都再合适不过（可惜湖北移动没有这款彩铃），百度上有2.4M的可下载。动画的故事情节在当下虽已沦为老套，但比《千与千寻》要好理解的多，而无敌的在于其情感的清澈，算是治愈系的电影了，值得心无杂念的去品评。

＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝

> <span style="font-size:180%;"><span style="font-weight: bold;">朱</span></span>伟在《<a href="http://www.douban.com/subject/1270044/" target="_blank">有关品质</a>》中的《情感与它的美丽容器》中写到：“……于一个乐团在一个优秀指挥率领下，可以制造出这样一种易碎的美丽——那是细腻精细到极点后，好比打磨成了一件极娇嫩脆弱的瓷器。它在灯光下泛出柔和的光泽，每一角度都圆润无比，质地也因此薄到能被灯光照透，不经意就可能破碎。”

<span style="font-size:180%;"><span style="font-weight: bold;">最</span></span>近看到的，形容交响乐的美妙文字。期待自己能有机会听到如此质量的音乐，同时不自量力的希望自己也能写出如此美妙的音乐感受。

 [1]: http://www.douban.com/subject/1767546/
 [2]: http://www.douban.com/subject/1395015/
 [3]: http://www.douban.com/subject/1394709/
 [4]: http://www.douban.com/subject_search?search_text=Coldplay&cat=1003
 [5]: http://www.douban.com/subject/1438261/
 [6]: http://www.douban.com/subject/1452895/