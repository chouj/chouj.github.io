---
title: 文理有别
author: Chouj
type: post
date: 2006-07-31T05:52:43+00:00
url: /2006/07/31/difference-between-arts-and-science/
views:
  - 1498
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969892
categories:
  - 我记录
tags:
  - 生活

---
<div class="contant">
  <p>
    <strong>讲述老百姓自己的故事，说明以下属实哦：</strong>
  </p>
  
  <p>
    某食堂伙食很差。
  </p>
  
  <p>
    某文科生：这饭吃的真“晦涩”～～<img style="cursor: pointer;" onclick="javascript:window.open(this.src);" src="http://xcchris.52blog.net/images/emot/face42.gif" alt="" />
  </p>
  
  <p>
    某理科生：这饭简直不具备“可吃性”！  <img style="cursor: pointer;" onclick="javascript:window.open(this.src);" src="http://xcchris.52blog.net/images/emot/face21.gif" alt="" />
  </p>
</div>