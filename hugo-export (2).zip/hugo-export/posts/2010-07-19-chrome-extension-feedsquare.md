---
title: FeedSquare：打造Feed墙的Chrome扩展
author: Chouj
type: post
date: 2010-07-19T11:48:50+00:00
excerpt: 除了借助油猴脚本来更改Google Reader的界面外观之外，现在在Chrome下，可以通过FeedSquare这个扩展来实现Feed墙的效果，很炫。
url: /2010/07/19/chrome-extension-feedsquare/
views:
  - 4833
duoshuo_thread_id:
  - 1279764464521970054
categories:
  - 工具
tags:
  - Chrome
  - FeedSquare
  - 扩展

---
除了借助油猴脚本来更改<a title="Google Reader" href="https://www.google.com/reader" target="_blank">Google Reader</a>的界面外观之外，现在在<a title="Google Chrome" href="http://www.google.com/chrome" target="_blank">Chrome</a>下，可以通过<a title="FeedSquare" href="https://chrome.google.com/extensions/detail/ddkahgkblobiogkkeedfnjkldecloidi" target="_blank">FeedSquare</a>这个扩展来实现Feed墙的效果，很炫。

特性：
  
&#8211; 将订阅的Feeds以墙的方式展示
  
&#8211; 在线视频支持
  
&#8211; 评论支持
  
&#8211; 输入“？”可获取帮助
  
&#8211; 支持Feed内图片的预览显示
  
&#8211; 与Google Reader同步阅读状态、标签、星标信息
  
&#8211; 易于分享到Google Buzz，Twitter和Facebook
  
&#8211; 最新条目可于后台自动更新
  
&#8211; 有手机版FeedSquare软件

预览如下，点击看大图：

<figure style="width: 500px" class="wp-caption aligncenter">[<img title="FeedSquare Feed Wall 点击看大图" src="http://pic.yupoo.com/xcchris/248969a78b82/medium.jpg" alt="FeedSquare Feed Wall " width="500" height="344" />][1]<figcaption class="wp-caption-text">FeedSquare Feed Wall</figcaption></figure>
  
<!--more-->


  
<figure style="width: 500px" class="wp-caption aligncenter">[<img title="FeedSquare浏览界面 点击看大图" src="http://pic.yupoo.com/xcchris/109099a78b79/medium.jpg" alt="FeedSquare浏览界面" width="500" height="344" />][2]<figcaption class="wp-caption-text">FeedSquare浏览界面</figcaption></figure>

手机版二维码：<figure style="width: 400px" class="wp-caption aligncenter">

<img title="FeedSquare for Android" src="https://chrome.google.com/extensions/img/ddkahgkblobiogkkeedfnjkldecloidi/1278974882.36/screenshot/1002" alt="FeedSquare for Android" width="400" height="300" /><figcaption class="wp-caption-text">FeedSquare for Android</figcaption></figure> 

小试之后觉得：

  * 它似乎是把常更新常阅读的Feed以暖色调展示于墙的中央，其他权重低的Feed则分布于墙的四周。
  * 适合的阅读习惯：按Feed一个一个读。不适合直接读All items和People you follow的。
  * 由于是Feed墙，加上其动态效果，似乎有些影响阅读效率。

更多信息详见该扩展页面：<a title="FeedSquare @ Google Chrome Extension" href="https://chrome.google.com/extensions/detail/ddkahgkblobiogkkeedfnjkldecloidi" target="_blank">https://chrome.google.com/extensions/detail/ddkahgkblobiogkkeedfnjkldecloidi</a>

 [1]: http://pic.yupoo.com/xcchris/248969a78b82/5lwgcfu5.jpg
 [2]: http://pic.yupoo.com/xcchris/109099a78b79/l82j183w.jpg