---
title: 显示FeedBurner订阅数图标的唯一方法
author: Chouj
type: post
date: 2008-05-23T05:46:32+00:00
url: /2008/05/23/only-way-to-show-feedburner-feedcount-image/
views:
  - 1859
  - 1859
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970003
categories:
  - 工具
  - 教程
tags:
  - Feedburner
  - Graph
  - url

---
佳佑的<a title="显示FeedBurner订阅数终极大法" href="http://www.charlespeng.com/feedburner-feedcount-image-final-solution/" target="_blank">显示FeedBurner订阅数终极大法</a>中介绍了很多方法，可是大部分支持订阅数实时更新的方法没有经住时间的考验。

Web2proxy.net方法<span style="color: #ff0000;">失效</span>
  
<a title="FeedM8方法" href="http://kunshou.net/2007/09/feedburner.html" target="_blank">FeedM8方法</a><span style="color: #ff0000;">失效</span>
  
<a title="订阅统计烧录服务" href="http://www.storyday.com/html/y2007/1276_fb-ico-trans.html" target="_blank">江东大哥的订阅统计烧录</a>，申请起来似乎不大灵光。

这里还是推荐一下<a title="anonymouse.org代理显示FeedBurner订阅数" href="http://www.charlespeng.com/feedburner-tips-for-chinese-bloggers/" target="_blank">佳佑补充的新方法</a>，<del datetime="2008-06-17T07:26:15+00:00">目前管用</del>，也是我在用的方法。能够实时显示每天的订阅数。

**<del datetime="2008-06-17T07:26:15+00:00">通过anonymouse.org网页代理显示Feedburner订阅数图标</del>**，编辑网页html代码，在合适位置加入以下代码：

<coolcode linenum="off">[<img src="http://anonymouse.org/cgi-bin/anon-www.cgi/http://feeds.feedburner.com/~fc/aboutrss?bg=99CCFF&fg=444444&anim=0" border="0" alt="订阅我" width="88" height="26" />][1]</coolcode>

请调整其中feed地址中相应部分，共两处；也可更改颜色代码，自行DIY出喜欢的配色。<a title="aboutrss.cn的Feedburner订阅数图标" href="http://anonymouse.org/cgi-bin/anon-www.cgi/http://feeds.feedburner.com/~fc/aboutrss?bg=99CCFF&fg=444444&anim=0" target="_blank">点此检阅能否显示</a>。

强烈希望这个方法能用得越久越好。:)

update:**可惜，这个站也撞墙了，此方法失效。**

 [1]: http://feeds.feedburner.com/aboutrss