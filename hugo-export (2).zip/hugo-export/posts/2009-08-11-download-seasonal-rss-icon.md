---
title: '[下载]四季变换RSS图标'
author: Chouj
type: post
date: 2009-08-11T02:38:43+00:00
url: /2009/08/11/download-seasonal-rss-icon/
views:
  - 5757
  - 5757
duoshuo_thread_id:
  - 1279764464521970045
categories:
  - 标志
tags:
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
<img title="四季变化RSS图标" src="http://pic.yupoo.com/xcchris/209417e44ad2/l8kjcv2p.jpg" border="0" alt="四季变换RSS图标" width="468" />

有了这套图标，就可以一个季节换一个啦！

出品：<a title="HelloIcon" href="http://helloicon.com/" target="_blank">HelloIcon</a>
  
格式：png
  
大小：256×256
  
背景：透明
  
使用：个人和商业网站

大图预览：<!--more-->

<img title="四季变化RSS图标大图预览" src="http://pic.yupoo.com/xcchris/111147e44ad1/cn9k06ha.jpg" border="0" alt="四季变换RSS图标大图预览" width="468" />

[**来源和下载：<a title="Free Icons: Decorative Seasonal RSS Icon Pack" href="http://www.tutorial9.net/resources/free-icons-decorative-seasonal-rss-icon-pack/" target="_blank">Free Icons: Decorative Seasonal RSS Icon Pack</a>|Tutorial9**]