---
title: 我不够humorous？
author: Chouj
type: post
date: 2005-12-11T04:48:00+00:00
url: /2005/12/11/not-humorous-enough/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/09/humorours.html
views:
  - 1646
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969743
categories:
  - 我思考
  - 我表达
tags:
  - 生活

---
在部长的群里 记得电气的部长 一女生 这么说了一句 抽儿啊 挺不错的 就是不够humorous 不然就perfect的了

关于这句 值得回味

我不够humorous么？ 复杂 矛盾 打心里想 自己绝不是个不够幽默的人 不论是和班上的弟兄们 还是在qq群里 我并不沉闷

和兄弟们在一起 我虽然不属于能侃的那种 但至少不寡言 开开玩笑更是少不了

在华工部长群里 纯属活跃分子一个 几乎都晓得我了 年纪大了 被他们喊为“大哥”

思来想去 问题貌似出在和女生在一起的时候 内敛？矜持？ 自己都不想用这些词来形容 不过 确实经常陷入寻找话题的窘境 想找出原因 想寻求改变 莫非只有多锻炼？

发现自己还是适合把思想写出来 不适合说出来 说需要思维敏捷 表达精准 humour更需要这样 而写的东西 可以慢慢思考 慢慢捋思绪 qq上可以想想该怎么说 再打字上去 和班上的人嘻嘻哈哈 刹是无所谓 但和不熟的人见面 在一起的时候呢 和女生呢 难道是顾忌了太多东西吗 别说偶有心理障碍 虽然据说大部分人都有这个障碍……