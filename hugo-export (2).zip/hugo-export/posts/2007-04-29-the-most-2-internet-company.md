---
title: 一个比一个2就是了
author: Chouj
type: post
date: 2007-04-29T00:03:50+00:00
url: /2007/04/29/the-most-2-internet-company/
views:
  - 3121
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969676
categories:
  - 我表达
tags:
  - Live.com
  - Myspace
  - 千橡
  - 新浪
  - 网络
  - 腾讯

---
<img src="http://www.mindmeters.com/upfile/2007423213947723.gif" align="left" /><big><big>有</big></big>幸被<a href="http://www.cactos.cn/index.php/archives/150" target="_blank">Cactos</a>、<a href="http://housne.cn/internet/the-worst-internet-company.html" target="_blank">浩博</a>、<a href="http://www.ilili8.cn/post/33.html" target="_blank">守望</a>联袂点名，众命难违，我也2它一回，参加“[我心中的最2互联网公司][1]”<a href="http://www.mindmeters.com/showlog.asp?log_id=5186" target="_blank">评选</a>。不过这个地址已经失效了，比较莫名。

1.<a href="http://www.sina.com.cn" target="_blank"><strong>新浪</strong></a>

像我这里的，不叫blog；http://blog.sina.com.cn/x/XXXXXXXX的才是blog。之所以有这种观点，就是因为那个很2的畸形门户的存在。最近新浪关闭blog图片外链也让人异常恼火，没见过这么2的。

2.<a href="http://www.oakpacific.com/" target="_blank"><strong>千橡</strong></a>

这 个评选的最高奖应该颁给第二名，嗯，实至名归。我就把第二名搬给千橡吧。这公司旗下的东西没几个成器的：不2不叫mop；5Q也越发颓废，有价值的东西越 来越少；Donews更是垃圾，登录系统经常抽筋儿，教育网内更是无法登录；校内网我倒是在用，不过也是花拳绣腿，还是抄袭facebook.com的， 我纯当个人blog的宣传平台。真是不2不千橡啊。

3.<a href="http://www.myspace.cn" target="_blank"><strong>Myspace.cn麦斯贝</strong></a>

不幸把地址敲成了myspaces.cn，进去一看，中国领先的web1.0网站都算不上，唉，一开始就影响了我的心情。注册的时候又发现myspace.cn用的myspace.com的用户数据，申请自己想要的url不成，郁闷。看到被爆料[myspace.cn对中文支持不好][2]，真是2到极点了。再贴几个让人感觉很2的证据！

<p align="center">
  <img src="http://photo7.yupoo.com/20070427/224057_1699287158_gpenaeyb.jpg" />
</p>

<p align="center">
  <a href="http://photo7.yupoo.com/20070427/224057_1644896862_fsncqtyv.jpg" title="点击放大" target="_blank"><img src="http://photo7.yupoo.com/20070427/224057_1644896862_fsncqtyv.jpg" border="0" height="116" width="500" /></a>
</p>

4.<a href="http://www.qq.com" target="_blank"><strong>腾讯QQ</strong></a>

腾讯到底2不2？答案是太2了，就知道赚钱！虽然中国互联网即便没有腾讯也会有其他公司入主这一领域，但我还是希望少点广告，少点病毒，少点花里胡哨，少点赌徒。

5.<a href="http://www.live.com" target="_blank"><strong>Live.com</strong></a>

某些公司肥了后就想哪里都分一杯羹，这就成就了该公司的2，尤其当它伸出的勺子丑陋无比的时候。

<big><big>5</big></big>月2号截止，时间不多，我就不点了。其实这个评比就很2，嘿嘿。

Technorati Tags: <a href="http://technorati.com/tag/%E6%96%B0%E6%B5%AA" class="performancingtags" rel="tag">新浪</a>, <a href="http://technorati.com/tag/%E5%8D%83%E6%A9%A1" class="performancingtags" rel="tag">千橡</a>, <a href="http://technorati.com/tag/Myspace" class="performancingtags" rel="tag">Myspace</a>, <a href="http://technorati.com/tag/%E8%85%BE%E8%AE%AF" class="performancingtags" rel="tag">腾讯</a>, <a href="http://technorati.com/tag/Live.com" class="performancingtags" rel="tag">Live.com</a>, <a href="http://technorati.com/tag/%E4%BA%92%E8%81%94%E7%BD%91" class="performancingtags" rel="tag">互联网</a>

 [1]: http://2.mindmeters.com/
 [2]: http://cyishere.blogspot.com/2007/04/myspacecn.html