---
title: 汉化了一下WebRankBoard
author: Chouj
type: post
date: 2007-08-09T03:32:37+00:00
url: /2007/08/09/webrankboard-chinese-edition/
views:
  - 8605
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969699
categories:
  - 我表达
tags:
  - SEO
  - site
  - tool
  - WebRankBoard

---
<img src="http://www.webrankboard.com/img/wrb.png" height="109" width="200" />

抽空帮忙翻译了一下WebRankBoard.com，该站已经放出<a href="http://www.webrankboard.com/?lang=cn" title="WebRankBoard中文" target="_blank">中文版</a>。

<a href="http://www.WebRankBoard.com" title="WebRankBoard" target="_blank"><strong>WebRankBoard</strong>.com</a>是7月份才上线的一个工具站点，基于<a href="http://www.viciao2k3.net/services/xinu" title="XINU" target="_blank">XINU</a>，可提供网站详细信息的一次性查询。Check的内容包括，网站信息诊断，域名信息反馈，pr值，反链数，alexa排名，网页代码标准校验，Feed订阅数，搜索引擎收录数，社会性书签收录数以及站点首页截图等等。只要网络上和blog head标签中的相关信息，都可以搜罗出来，是网站信息索引，辅助SEO的好工具。

网站名称里有Board，自然是以面板的形式将查询结果予以呈现，且面板可拖动摆放，面板的显示即查询的项目均可自定义。 就我个人感觉而言，如果查询项中能有网站载入速度的测试更好了；另外，其中一些指标不大适合国内的站点，因为不被国人所用，要想<a href="http://www.webrankboard.com/?lang=cn" title="WebRankBoard中文" target="_blank">中文版WebRankBoard</a>真正受国人欢迎，光解决语言问题怕是不够。

<img src="http://photo4.yupoo.com/20070809/110001_1479823221_mgbieikv.jpg" alt="webrankboard" class="Photo" height="288" width="480" />

之所以有机会帮忙作汉化，是因为我在<a href="http://www.mybloglog.com/buzz/members/xcchris/" target="_blank">MyBlogLog</a>上和该站的文字层面负责人<a href="http://rssmarketing.free.fr/blog/" target="_blank">Julien Griere</a>有过一些交流，翻译的量挺小，于是应邀搞定。目前看来，现在的翻译还比较生硬，用户体验上的优化不够。<font color="#ff6600">欢迎大家使用这款服务，并且比对<a href="http://www.webrankboard.com/?lang=uk" title="WebRankBoard英文" target="_blank"><strong>WebRankBoard英文版</strong></a>，告诉我翻译上的疏漏</font>，因为我自己对一些功能的理解上都可能有出入；或者在<a href="http://www.webrankboard.com/support.php" target="_blank">SUPPORT页面</a>下载站长放出的英文界面代码（2KB），翻译出更好更帅气的版本。