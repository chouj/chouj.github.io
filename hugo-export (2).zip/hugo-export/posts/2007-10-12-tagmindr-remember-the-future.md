---
title: TagMindr：Remember the future
author: Chouj
type: post
date: 2007-10-12T12:54:08+00:00
url: /2007/10/12/tagmindr-remember-the-future/
views:
  - 2896
  - 2896
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969988
categories:
  - 工具
tags:
  - Delicious
  - TagMindr

---
<img width="400" src="http://media.tagmindr.com/2.0/img/ui-logo.jpg" alt="TagMindr" height="144" title="TagMindr" />

[RSS相关][1]较少追一些最新应用的，但最近在<a target="_blank" href="http://del.icio.us/popular/rss" title="美味书签">del.icio.us</a>上出现的**TagMindr**挺有意思，口号是“Remember the future&#8230;”。TagMindr仅利用<a target="_blank" href="http://del.icio.us/" title="美味书签">del.icio.us</a>书签、Tags标记、RSS Feed，却似乎增加了一种面向海量信息的淘金方式，为信息的有效利用建立了一种提醒机制，避免信息价值的快速淹没。其实反过来说，也加强了信息冲击波的杀伤力，- -#

吹完牛，这个TagMindr到底是怎么让你Remember the future的呢？

<!--more-->

  1. 把你的美味书签用户名，告诉TagMindr，自动生成一个RSS Feed，订阅它；
  2. 当你在美味书签里收藏网页条目时，主动添加tag标签：“tagmindr”和“remind:YYYY-MM-DD”，这个条目就会在YYYY-MM-DD通过RSS Feed推送到你的阅读器，让你知道你以前在美味书签收藏了这么一个条目。

<a target="_blank" href="http://www.xuchi.name/blog/" title="抽筋儿">抽儿</a>还没有实用过这个东西，因为测试周期以天为记嘛，所以以上可能有理解出错的地方。至于“Remember the future”，似乎是指通过把今日所见推送到未来细细研究，变相预定未来的阅读内容，而“ Put any bookmark in a time capsule and we&#8217;ll send it to your future self.”中的“Time capsule”正是指“供后世科学家及学者了解之用的存有当代文化的物品和文献的密封容器”。

囧，居然讨论英文去了～～

**Update**：经测试，确实如我所料。

[ <a target="_blank" href="http://tagmindr.com" title="TagMindr"><strong>点此进入TagMindr</strong></a> ]

 [1]: http://aboutrss.cn "RSS相关"