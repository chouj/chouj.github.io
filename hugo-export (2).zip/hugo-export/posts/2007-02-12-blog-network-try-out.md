---
title: 博客圈试用报告
author: Chouj
type: post
date: 2007-02-12T13:21:00+00:00
url: /2007/02/12/blog-network-try-out/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/02/blog-post_12.html
views:
  - 3580
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969851
categories:
  - 我尝试
tags:
  - blog
  - feedsky
  - 博客圈

---
<a href="http://www.blop.cn/" target="_blank" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img style="cursor: pointer; width: 200px;" src="http://www.blop.cn/images/logo.gif" border="0" alt="" /></a>

<span style="font-size:180%;"><span style="font-weight: bold;">心</span></span>里一直认为，以feed合烧为技术支撑搭建博客圈平台，让每个blogger都可以打造自己的博客群落，是一项很2.0很in的服务。所以当<a href="http://beta.feedsky.com/fn_class.html" target="_blank">Feedsky博客圈</a>出现的时候，我再次感受到了技术带来的快乐。当然，我这草民没有<a href="http://beta.feedsky.com/fn_class.html" target="_blank">Feedsky博客圈</a>的划圈儿权，但在网上误打误撞中，发现了这个<a href="http://www.blop.cn/" target="_blank">博客圈</a>，试用报告如下。

<span style="font-weight: bold;">动作</span>

划了个<a href="http://gaozhong.blop.cn/" target="_blank">襄樊四中03届高三六班博客圈儿</a>，这里是<a href="http://gaozhong.blop.cn/rss.xml" target="_blank">合烧feed地址</a>。可以预想，博客圈将成为班级交流的另一崭新阵地。

<span style="font-weight: bold;">特点</span>

每个用户的划圈儿数目不限；支持blog posts、评论、留言审核，即圈主享有posts、评论和留言的生杀大权。所建圈子支持分类，支持tag，支持圈子名称更改和圈子简介，支持圈子头像。莫名的是：有分类有tag，就是没见圈子搜索，没见所有分类页面，没见所有tags页面。

每个圈子有自己的二线域名，比如<a href="http://gaozhong.blop.cn/" target="_blank">高三六班博客圈儿</a>；圈子支持公告，支持圈主随时加入new blogger，支持申请加入（即提交feed，要圈主审核），每篇post支持网友评论（不需注册），支持给圈主留言。

采取添加feed的方式添加圈子博友。

每个加入圈子的feed，支持头像，支持blog名称更改，支持博主名称更改，支持单blog独立页面（比如<a href="http://gaozhong.blop.cn/blogs/421-1-1.html" target="_blank">这里</a>）。

另外，既然feed合烧了，那么就不用将所有博客挨个订阅，仅订此一个feed即可。在当今feed蒲公英满天飞的年代，这个优点还是很实在的。

<span style="font-weight: bold;">BUG报告</span>

1、添加feed后，编辑博客网址的输入框中，可输入字符长度不够，看过源代码，maxlength=&#8221;20&#8243;，20完全不够。直接后果即输入不全，导致<a href="http://gaozhong.blop.cn/blogs/421-1-1.html" target="_blank">此页</a>右侧blog链接为“http://xcchris.blogs”。

2、同一feed，加入不同圈子，则在后加的圈子中，显示不出post。比如我后建的<a href="http://phy0301.blop.cn/" target="_blank">物理0301圈子</a>，加入我自己的feed后，没有posts显示。这个伤很致命，但愿不是试用时我这里出的什么问题。

<span style="font-size:180%;"><span style="font-weight: bold;">看</span></span>的出，这里才诞生不久，<a href="http://www.blop.cn/forum/" target="_blank">博客圈论坛</a>里没有一个帖子。不过，这仍是前途无量的web service，至少我看好。我把我的试用报告mail给对方了，期待完善，期待搭配圈子搜索，继续关注之。

<span style="font-size:180%;"><span style="font-weight: bold;">同</span></span>时YY一下，<a href="http://beta.feedsky.com/fn_class.html" target="_blank">Feedsky的博客圈</a>什么时候下放用户创建的功能呢？

<span style="color: #ff0000;">Update</span>：纠正下BUG 2。同一feed，加入其他圈子，则不能即时显示出post，一定反应时间（时间还挺长）后才能显示出来。这样就还好，不算致命，但还是改之为妙。