---
title: 小试Gregarius
author: Chouj
type: post
date: 2007-05-07T12:55:00+00:00
url: /2007/05/07/try-gregarius/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/05/gregarius.html
views:
  - 2758
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969883
categories:
  - 我尝试
tags:
  - Gregarius
  - RSS聚合

---
<span style="font-size:180%;">眼</span>红于武大的[<span style="font-weight: bold;">博客聚合</span>][1]，在网络上苦搜RSS聚合程序。发现武大的是通过基于ASP的[SXNA][2]构架的，OK，PHP下一定也有一样的程序，果不其然被我搞到手，呵呵。捣腾这些东西貌似有一种蹂躏的快感，嗯，名曰天生BT。

# [<img style="border: 0pt none ;" src="http://lilina.cubegames.net/wordpress/wp-content/lilina1.png" alt="Lilina News Aggregator Logo" />][3]

<span style="font-size:180%;">先</span>入眼的就是这个[<span style="font-weight: bold;">Lilina</span>][4]，辉常好听的名字,需要 php4.3 + mbstring iconv支持，[这里][5]就是拿这玩意儿架的。试装一遍，木成功，估计是支持不够。后来发现其发育不良，主题插件都不完善，技术支持也基本没有。八成是日落西山，门前冷落了。再度寻觅ing。

<span style="font-size:180%;"><span style="font-weight: bold;">Gregarius</span></span>

<span style="font-size:180%;">马</span>上，这玩意儿入眼了。随便介绍一下哈，[Gregarius][6]基本可以当作是自己架的[抓虾][7]，想看例子的到[这里][8]。主要缺陷是对中文的支持不大好，即便是[汉化版][9]，目前我正在四处求教中，拟解决一些中文显示的问题。

<span style="font-size:180%;">最</span>后倒是又听说还有个Feedonfeeds的聚合程序，不知道咋样，貌似[Riku用过][10]。先记这么多。

 [1]: http://www.whublog.com/
 [2]: http://www.sxna.cn/
 [3]: http://lilina.cubegames.net/ "Lilina News Aggregator"
 [4]: http://lilina.cubegames.net/
 [5]: http://www.dbanotes.net/lilina/
 [6]: http://gregarius.net/
 [7]: http://www.zhuaxia.com/
 [8]: http://www.openrss.net/
 [9]: http://www.cncode.com/downinfo/5169.html
 [10]: http://blog.bsdos.cn/archives/392