---
title: 苍井空同学还真不一般
author: Chouj
type: post
date: 2007-06-09T10:35:53+00:00
url: /2007/06/09/cangjingkong-youtube/
views:
  - 3911
btc_comment_summary:
  - 'a:0:{}'
btc_comment_counts:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969684
categories:
  - 我记录
tags:
  - AV
  - youtube
  - 女优
  - 苍井空

---
[via <a href="http://9601.org/lifishake/?p=791" target="_blank">here</a>] 原帖名为 人说女优体力好

ORZ &#8230;