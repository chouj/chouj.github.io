---
title: 一秒芳华
author: Chouj
type: post
date: 2006-12-16T15:18:00+00:00
url: /2006/12/16/in-one-second/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2006/12/blog-post_16.html
views:
  - 1940
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969835
categories:
  - 我思考
  - 我表达
tags:
  - 流星
  - 生活

---
<span style="font-size:180%;"><span style="font-weight: bold;">流</span></span>星划过苍穹，留下一秒芳华。

“<span style="font-size:180%;"><span style="font-weight: bold;">我</span></span>看见啦！那里！噢！噢！”

<span style="font-size:180%;"><span style="font-weight: bold;">手</span></span>指天幕，顺势抓过一人一起欢呼，然后嘲笑下没看到的弟兄。有流星的夜晚，一切都变的兴奋。诚然如bbs上所述，不外乎几坨石头擦出点火光而已，但这种时候岂能如此现实，我们需要的是肆无忌惮的快意，原谅我们的大惊小怪吧。

“<span style="font-size:180%;"><span style="font-weight: bold;">5</span></span>，4，3，2，1，哇，那有一颗！哈哈！”

<span style="font-size:180%;"><span style="font-weight: bold;">美</span></span>妙能否在倒数完的一刹那出现，已经不重要了，编造谎言的同时，我们一起编造快乐。在旁人眼里，我们就是疯子，但通常人们会说，疯子和傻子才是最快乐的。

“<span style="font-size:180%;"><span style="font-weight: bold;">噢</span></span>你妈个头啊！”

<span style="font-size:180%;"><span style="font-weight: bold;">由</span></span>于肆无忌惮的给公德长征抹黑，我们得到了反馈，来自对面的女生楼，吼的人很多，算我们对号入座。不过，无时无刻外加无视氛围环境的豪放，让我们肃然起敬。

<span style="font-size:180%;"><span style="font-weight: bold;">流</span></span>星给了契机，黑夜给了掩映，疯狂得到膨胀。收获了若干颗后，我钻回被窝：回忆，忏悔，外加幻想。

<span style="font-size:180%;"><span style="font-weight: bold;">回</span></span>忆，因为之前看过两次流星雨。高二那年，在男生寝室的阳台，天上的流星和楼下年级主任手电筒的光柱辉映成趣，远处某寝室在齐唱“陪你去看流星雨”。还有一次是凌晨，在家楼下，披着门卫值班用的棉大衣，身边有父亲的陪伴，虽然那晚几乎没有收获，但回忆却依然美好。

<span style="font-size:180%;"><span style="font-weight: bold;">忏</span></span>悔，因为刚刚写下的疯狂。耳边还有善男信女的欢呼，只是随着时间的推移，善男越来越少，充分证明男生向善的功力不够。BBS上有人说，睡觉还能睡好几万次，你能看到好几万颗流星么？所以原谅人们的欢呼吧。但，忏悔仍要继续，为那些骂我们“噢你妈个头”的朋友，不论说出口的还是骂在心里的，毕竟我们的疯狂影响了别人的生活。

<span style="font-size:180%;"><span style="font-weight: bold;">幻</span></span>想，因为传说中的美好。愿下一次看流星雨的时候，能有我喜欢的女孩儿在身边，手牵着手期待那一秒芳华。当最美的流星划过后，能够赠予绵长一吻。耳边的鼾声适时想起，来自同在楼上疯狂过的室友，仿佛提醒我：美梦与流星在时间尺度上具备极端一致性。

<span style="font-size:180%;"><span style="font-weight: bold;">把</span></span>一切交给记忆和这篇东西，和有缘被我见到的流星一起。