---
title: '[照片]专家村'
author: Chouj
type: post
date: 2008-12-15T09:28:38+00:00
url: /2008/12/15/experts-village/
views:
  - 1825
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969913
categories:
  - 我表达
tags:
  - 专家村
  - 从化
  - 照片

---
[<img src="http://pic.yupoo.com/xcchris/536716a997c1/medium.jpg" border="0" alt="IMG_0298" width="500" height="375" />][1]

位于从化

 [1]: http://www.yupoo.com/photos/view?id=ff8080811e399aee011e39f3d89508e3 "来YUPOO看大图"