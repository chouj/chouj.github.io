---
title: 广州之歌
author: Chouj
type: post
date: 2007-03-10T13:56:00+00:00
url: /2007/03/10/song-of-guangzhou/
blogger_blog:
  - xcchris.blogspot.com
blogger_author:
  - 抽筋儿http://www.blogger.com/profile/13101516427419536493noreply@blogger.com
blogger_permalink:
  - /2007/03/blog-post.html
views:
  - 2169
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969859
categories:
  - 我记录
tags:
  - 广州
  - 生活

---
<span style="font-weight: bold;">月亮走我也走……</span>

<span style="font-size:180%;"><span style="font-weight: bold;">元</span></span>宵佳节，南下广州。刚在火车上落定，就看见一人西装革履器宇不凡大有来头。事实验证，果不其然：先掏一证，裱得跟人大代表证似的，上面赫然两杠四星。我心里咯噔一下：这家伙不得了哇，跟我的迅雷等级一个水平的，好歹在线时长得上百小时哇。再发名片，“××投资公司董事长”，说是到襄樊是来作考察的，然后历数襄樊的区县市，可了不得。顺着襄樊侃到广州，此句双关，一指话题，二指行程，可谓事多话多。趁这人去厕所，对面俩姑娘眼巴巴的跟我说，估计你晚上不用睡了；我只好眼巴巴的对着食物发狠：吃掉你丫的！

<span style="font-size:180%;"><span style="font-weight: bold;">B</span></span>TW.元宵佳节的夜车，一可赏月，二可赏一路的烟花焰火，人品好的没准可以赏到秋香，这铁路部门也不加价，真是脑瓜子进水。

<span style="font-weight: bold;">命运交响曲</span>

<span style="font-size:180%;"><span style="font-weight: bold;">没</span></span>在豆瓣的[广州小组][1]里打声招呼，也没跟[武汉小组][2]的ggmm道个别，我就屁颠儿屁颠儿的到了广州，奔向海洋所，追溯历史，已经算是二进宫了，555

<span style="font-size:180%;"><span style="font-weight: bold;">中</span></span>科院系统的就是有钱，人手一电脑，我先使唤一奔三的本儿，说改明儿会换个新台机。再者拿到了700米——400补助＋300路费报销，可惜这里米饭都3毛一两，打三两还吃不饱，郁闷。捞着一研究生宿舍住，现在就我一人，貌似代价是第一年去不了北京了，因为老板说9月份就过来了所以直接安排了吧。别了，我的奥运，别了，我喜欢的颜色分明的四季，别了，北京那些盼我来的亲友，这心里头啊，是临屋涕泠不知所云呐；这表情上啊，是春意盎然大言不惭：自创的，扎根南中国，树挪我不挪；改编的，我是boss的一块砖，哪里需要往哪搬！

<span style="font-size:180%;"><span style="font-weight: bold;">中</span></span>科院系统的兄弟姐妹也确实牛叉。宿舍就是个睡觉的地儿，一天十个小时以上泡实验室。吃喝拉撒睡，掐头去尾，中间的都在实验楼里搞定，要搞定两头的，也就走个50米。这里和大学不一样，不是一小组一项目、一堆人供一台机器，而是一人一项目，好硬件好待遇大施展空间，真正搞研究出文章的地儿，人人都刻苦能干哇。只要能有成绩，作息上不管你啥时来啥时走，换句话说，给你自愿枪毙双休的权力，也就等于在实验室基本没啥娱乐了。我敢赌这里的一些人还不知道blog是何物，像我这样blogging的估计可以贴上“异类”的标签了。坏处就是，在实验室写东西，总有点小偷小摸的不良感觉，可怜哇。看来我得启动一天写一点儿，每周攒一篇儿的地下blog战略。顺道可怜下我的google reader，没准儿我哪天发篇题为“热烈祝贺G Reader未读篇数突破N位数大关”的贴，诸位可别惊讶。别了，那网上纷至沓来的能让思维舞动的资讯，别了，那挨揍的M Scofield和找到姥姥的Claire bear。这心里头哭的是，稀里哗啦巴扎嘿，表面上看起来又是，扎西德勒亚克西……

<span style="font-weight: bold;">摇篮曲</span>

<span style="font-size:180%;"><span style="font-weight: bold;">我</span></span>的毕设课题是“瑞利-布纳德湍流热对流中大尺度相干结构对传热的影响研究”，流体领域中的。

<span style="font-size:180%;"><span style="font-weight: bold;">瑞</span></span>利-布纳德湍流热对流是指实验中的一种现象，即一个装满液体的对流箱内，底板加热保持均匀恒温，顶板制冷保持均匀恒温，板间温差恒定。下部流体受热膨胀，密度变小而上浮；上部流体遇冷收缩，密度变大而下沉。在此机制下，可形成一种环流。若流体是以湍流形式流动，即固定位置处流速呈现随机性，而流动由热能不均驱动，这即叫做湍流热对流。

<a href="http://bp0.blogger.com/_2MqU1LfBbeM/RfK58K18bTI/AAAAAAAAAGs/ovLItnfgKxg/s1600-h/exp.JPG" onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}"><img id="BLOGGER_PHOTO_ID_5040295376334908722" style="margin: 0pt 10px 10px 0pt; float: left; cursor: pointer;" src="http://bp0.blogger.com/_2MqU1LfBbeM/RfK58K18bTI/AAAAAAAAAGs/ovLItnfgKxg/s400/exp.JPG" border="0" alt="" /></a><span style="font-size:180%;"><span style="font-weight: bold;">但</span></span>由于流体的粘性，受热的流体元能量聚集到一定程度，由外界触发后，才会显著的上升，而在上述实验中，其触发主要是由冷水团的下降；冷水团亦和热水团一样，受热水团上升而触发后，显著下沉，道理跟水滴要积攒到一定程度才会滴下一样。但实验测量到，由于板距、流速和水团运动并非持续而是脉冲式的原因，某段时间水团运动会出现真空期，即测量点流速减慢，甚至流速反转，此即瑞利-布纳德湍流热对流现象。这一现象的意义在于，可在地质学中解释古地磁翻转现象。因为地磁由地幔中流动的四氧化三铁形成，同样是流体，地心处高温，接近地表则低温，与实验条件基本吻合，而其流速若也呈现周期性减缓或反转——当然这周期长达上万年——即可解释南北磁极翻转现象。

<span style="font-size:180%;"><span style="font-weight: bold;">我</span></span>现在做的就是利用现有实验数据，尝试找寻实验中流体流速反转周期和一些物理量是否相关，其间是否存在规律。若有规律则可以进一步用其他物理量推算反转周期，实现理论预测。

<span style="font-weight: bold;">尾声</span>
  
括弧，话外音。

<span style="font-size:180%;"><span style="font-weight: bold;">整</span></span>篇科普装点门面，被吓着了快去医院。横批：曲终人散。括弧，备用横批：俺太有才了……

 [1]: http://www.douban.com/group/gz/
 [2]: http://www.douban.com/group/wuhan/