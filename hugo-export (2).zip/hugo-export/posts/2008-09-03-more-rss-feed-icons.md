---
title: RSS标志设计新货上架！
author: Chouj
type: post
date: 2008-09-03T03:06:23+00:00
url: /2008/09/03/more-rss-feed-icons/
views:
  - 2115
  - 2115
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521970019
categories:
  - 标志
tags:
  - Download
  - Graph
  - Icon
  - RSS设计
  - Symbol

---
**漂亮的RSS Feed标志设计新鲜上架啦！**

#### [BrokerScience Real Estate RSS Icons][1]

[<img src="http://pic.yupoo.com/xcchris/584936216d4e/gpef7kav.jpg" alt="" width="400" height="389" />][1]

<!--more-->

#### [DrinkRSS][2]

[<img src="http://pic.yupoo.com/xcchris/270336216d4e/5hkeog8n.jpg" alt="" width="400" height="312" />][2]

#### [Photoshopstar Simple Subscribe Badge (包括PS教程)][3]

[<img src="http://pic.yupoo.com/xcchris/545356216d4e/himxmjd9.jpg" alt="" width="400" height="200" />][3]

#### [Design Freak][4]

[<img src="http://pic.yupoo.com/xcchris/152046216d4e/07vxiyl1.jpg" alt="" width="250" height="134" />][4]

[<img src="http://pic.yupoo.com/xcchris/403996216d4e/jgrrv8n1.jpg" alt="" width="400" height="300" />][5]

#### <a rel="nofollow" href="http://www.toptut.com/2007/12/30/free-download-rss-feed-badges-icons/" target="_blank">RSS Feed Badge</a>

[<img class="desc" src="http://pic.yupoo.com/xcchris/0024062171fd/42oqk4dz.jpg" alt="" width="400" height="350" />][6]

#### <a rel="nofollow" href="http://www.cooljeba.com/downloads/png/rss-heart-png-icons.html" target="_blank">Heart Shape RSS Icons</a>

<a rel="nofollow" href="http://www.cooljeba.com/downloads/png/rss-heart-png-icons.html" target="_blank"><img class="desc" src="http://pic.yupoo.com/xcchris/2276762171fd/pzuihpdh.jpg" alt="" width="308" height="295" /></a>

<small>via <a title="Free RSS Feed Icons, The Ultimate List" href="http://www.hongkiat.com/blog/free-rss-feed-icons-the-ultimate-list/" target="_blank">here </a>and <a title="40+ Really Cool RSS Feed Icons" href="http://www.hongkiat.com/blog/really-cool-rss-feed-icons/" target="_blank">here</a> 感谢<a title="麦可" href="http://menghao.net/" target="_blank">麦可</a>的投递</small>

 [1]: http://brokerscience.com/uncategorized/free-rss-real-estate-icons/
 [2]: http://www.l2design.be/drinkrss/
 [3]: http://www.photoshopstar.com/web-graphics/nice-simple-subscribe-badges/
 [4]: http://www.design-freak.com/design/
 [5]: http://www.design-freak.com/action/rss-ikonka-dlya-foreks-bloga/
 [6]: http://www.toptut.com/2007/12/30/free-download-rss-feed-badges-icons/