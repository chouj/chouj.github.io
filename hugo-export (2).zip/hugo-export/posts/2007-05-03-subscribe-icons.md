---
title: Angelived的18套博客订阅图标汇总
author: Chouj
type: post
date: 2007-05-03T11:21:54+00:00
url: /2007/05/03/subscribe-icons/
views:
  - 1758
  - 1758
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969948
categories:
  - 教程
  - 标志
tags:
  - Graph
  - Icon
  - RSS设计
  - Subscribe
  - Symbol

---
<big><big>强</big></big>烈推荐Angelived同学的

<big><big><a href="http://angelived.org/2007/05/02/dingyue-icon/" target="_blank"><strong>18套博客订阅图标汇总</strong> | Angelived</a></big></big>

<big><big>18</big></big>套之多，收集起来真是不容易啊，Chou本来想做的事情都让<a href="http://Angelived.org" target="_blank">Angelived</a>给做完了，呵呵，可以少奋斗几个时辰。这里给个示意截屏，想查看更多订阅图标，就直接点链接过去看吧。

![][1]

<big><big>这</big></big>么些完美的订阅图标，想自己拥有一套该怎么办，请参考如下代码：

<coolcode linenum="off">

## Subscribe

  * [<img src="http://google订阅图标地址" style="border: 0pt none " alt="Add to Google Reader or Homepage" />][2]
  * <a href="http://www.bloglines.com/sub/http://您的feed地址" title="Angelived" type="application/rss+xml"><img src="http://Bloglines订阅图标地址" alt="Subscribe in Bloglines" style="border: 0pt none " /></a>
  * [
  
    <img src="http://抓虾订阅图标地址" alt="使用抓虾订阅" style="border: 0pt none " />][3]
  * [<img src="http://雅虎订阅图标地址" style="border: 0pt none " />][4]
  * [<img src="http://飞鸽订阅图标地址" alt="Add to Pageflakes" border="0" />][5]
  * [<img src="http://Newsgator订阅图标地址" alt="Subscribe in NewsGator Online" style="border: 0pt none " />][6]
  * [<img src="http://Live订阅图标地址" alt="live" style="border: 0pt none " />][7]

</coolcode>
  
<big><big>只</big></big>要将如上代码中的feed地址，和各图片地址补充完整，然后贴到侧栏sidebar的相应位置，就可以显示出来啦，赶紧动手吧！再次感谢<a href="http://Angelived.org" target="_blank">Angelived</a>同学！

Technorati Tags: <a href="http://technorati.com/tag/subscribe" class="performancingtags" rel="tag">subscribe</a>, <a href="http://technorati.com/tag/Icon" class="performancingtags" rel="tag">Icon</a>, <a href="http://technorati.com/tag/Graphic" class="performancingtags" rel="tag">Graphic</a>

 [1]: http://photo8.yupoo.com/20070503/184816_910493667_nvffsiup.jpg
 [2]: http://fusion.google.com/add?feedurl=http://您的feed地址
 [3]: http://www.zhuaxia.com/add_channel.php?url=http://您的feed地址
 [4]: http://add.my.yahoo.com/rss?url=http://您的feed地址 "Angelived"
 [5]: http://www.pageflakes.com/subscribe.aspx?url=http://您的feed地址 "Add to Pageflakes"
 [6]: http://www.newsgator.com/ngs/subscriber/subext.aspx?url=http://您的feed地址 "Angelived"
 [7]: http://www.live.com/?add=http://您的feed地址