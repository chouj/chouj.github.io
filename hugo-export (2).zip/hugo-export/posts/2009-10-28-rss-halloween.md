---
title: RSS万圣节设计
author: Chouj
type: post
date: 2009-10-27T16:45:35+00:00
url: /2009/10/28/rss-halloween/
views:
  - 2095
  - 2095
duoshuo_thread_id:
  - 1279764464521970047
categories:
  - 标志
tags:
  - Graph
  - Icon
  - RSS设计
  - 万圣节

---
![RSS万圣节南瓜][1]![万圣节RSS南瓜][2]

我不过这个节，还是有些Designers过的，比如设计出以下Halloween RSS Symbols的设计师：

<!--more-->

  * <a href="http://www.designbliss.com/2007/10/24/free-halloween-graphic-design-resources-day-eighteen-vector-rss-icons-a-db-download/" target="_blank">Halloween RSS icons</a>

![Halloween RSS icons][3]

  * <a href="http://www.dapino-colada.nl/3-halloween-rss-icons" target="_blank">3 Halloween RSS Icons by DaPino</a>

![3 Halloween RSS icons][4]

 [1]: http://pic.yupoo.com/xcchris/5905384a819a/efa4wdm7.jpg
 [2]: http://pic.yupoo.com/xcchris/2124484a819a/6rre27w3.jpg
 [3]: http://pic.yupoo.com/xcchris/2460084a8209/ftzbyw1h.jpg
 [4]: http://pic.yupoo.com/xcchris/3909584a820b/j6i90vrx.jpg