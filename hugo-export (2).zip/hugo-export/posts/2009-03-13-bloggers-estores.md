---
title: '[汇总]bloggers开店'
author: Chouj
type: post
date: 2009-03-12T18:23:06+00:00
url: /2009/03/13/bloggers-estores/
views:
  - 2450
duoshuo_thread_id:
  - 1279764464521969919
categories:
  - 我表达
tags:
  - 开店
  - 淘宝
  - 网友

---
  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_red_4.gif" border="0" alt="" align="absmiddle" /><a title="时尚80区" href="http://fad80.com/" target="_blank">时尚80区－FAD80.COM</a> http://shop33649370.taobao.com/ ——裴庆新

点评：这个牛，店掌柜是ex-blogger，曾经打理peiqingxin.cn，现在做了全职淘宝卖家，**主营潮流服饰**。

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_blue_4.gif" border="0" alt="" align="absmiddle" /><a title="Since 1984" href="http://taobao.since1984.cn/" target="_blank">Since1984 Fun your life !</a> http://shop35421234.taobao.com/ ——<a title="设计 | 生活 | 发现新鲜" href="http://since1984.cn/blog/" target="_blank">Since1984</a>

点评：84的店，**主打创意生活杂货**，说实话我觉得挺贵。84的blog更不用说了，新奇创意类blog首屈一指的，可到<a href="http://since1984.cn/store/" target="_blank">这里</a>看商品更新记录。

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_blue_2.gif" border="0" alt="" align="absmiddle" /><a title="时光莓店" href="http://shop35446724.taobao.com/" target="_blank">时光莓店</a> http://shop35446724.taobao.com/ ——<a title="黑莓时光" href="http://berrytimes.cn/" target="_blank">BerryTimes</a>

点评：<a title="黑莓时光" href="http://berrytimes.cn/" target="_blank">黑莓时光</a>博主的**专业黑莓售卖店**，口碑不错，收藏人气上千，我看着上面的机口水哗哗的。

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_red_2.gif" border="0" alt="" align="absmiddle" /><a title="胡戈戈的网店" href="http://shop.hugege.com/" target="_blank">胡戈戈的网店</a> http://shop37107784.taobao.com/ ——<a title="胡戈戈" href="http://hugege.com" target="_blank">胡戈戈</a>

点评：先要恭喜胡戈戈被卓卓网相中哦～！**主营WordPress主机空间、页面设计制作、链接买卖等**。

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_red_1.gif" border="0" alt="" align="absmiddle" /><a title="创意e店" href="http://shop57144235.taobao.com/" target="_blank">创意e店</a> http://shop57144235.taobao.com/ ——<a title="掘图志" href="http://juetuzhi.cn" target="_blank">geuro</a>

点评：掘图志博主geuro也不甘寂寞开了家**时尚家饰/工艺品/十字绣**的店～欢迎捧场！

  * <img class="rank" src="http://pics.taobaocdn.com/newrank/s_red_2.gif" border="0" alt="" align="absmiddle" /><a title="GeekCook" href="http://geekcook.blogspot.com/" target="_blank">GeekCook</a> http://shop57492985.taobao.com/ ——<a title="digitalboy@twitter" href="http://twitter.com/digitalboy" target="_blank">digitalboy</a>

点评：这个也挺牛，直接依托blog平台开网店，没见识过的一定要过去看看，以**Geek衣饰为主打**，店铺右上有twitter可以发楼。<span style="text-decoration: line-through;">淘宝店还没开起来，等开好了我再来update。</span>开起来了已经，有幸能成为该店的第一个友链店铺！

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_red_5.gif" border="0" alt="" align="absmiddle" /><a title="Wopus淘宝" href="http://shop.wopus.org" target="_blank">Wopus淘宝店铺</a> http://shop36739814.taobao.com/ ——<a title="Wopus" href="http://www.wopus.org/" target="_blank">酋长@Wopus</a>

点评：沃普斯的淘宝店，由酋长打理，**主营域名和WordPress空间**。

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_blue_1.gif" border="0" alt="" align="absmiddle" /><a title="WordPress主机专卖" href="http://taobao.wpchina.org" target="_blank">WordPress 主机专卖</a> http://shop37023240.taobao.com/ ——<a title="WordPress非官方中文站" href="http://wpchina.org/" target="_blank">总统</a>

点评：WordPress这玩意儿商机无限啊，总统的主机都卖到17号了，难怪总统那么有米，可以买淘宝旺铺，XD~

  *  <img class="rank" src="http://pics.taobaocdn.com/newrank/s_red_1.gif" border="0" alt="" align="absmiddle" /><a title="南海所资源共享同盟 实拍大图" href="http://shop.xuchi.name" target="_blank">[实拍大图]南海所资源共享同盟</a> http://shop36934860.taobao.com/ ——<a title="抽筋儿" href="http://www.xuchi.name" target="_self">抽筋儿</a>，就是我啦~

点评：俺的店，卖闲置杂货滴，以书刊为主，欢迎惠顾啦~！

仅以此文诚征以上各淘宝店店铺友链，XD~

欢迎补充！