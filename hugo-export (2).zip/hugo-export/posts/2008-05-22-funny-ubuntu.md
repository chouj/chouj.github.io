---
title: 乌班兔好好玩
author: Chouj
type: post
date: 2008-05-22T06:19:29+00:00
url: /2008/05/22/funny-ubuntu/
views:
  - 2604
btc_comment_counts:
  - 'a:0:{}'
btc_comment_summary:
  - 'a:0:{}'
duoshuo_thread_id:
  - 1279764464521969736
categories:
  - 我尝试
tags:
  - Linux
  - Ubuntu
  - 图片

---
<img title="乌班图Ubuntu" src="http://www.ubuntu.org.cn/themes/ubuntu07/images/ubuntulogo.png" alt="Ubuntu" width="202" height="55" />

乌班兔果然比其他兔子好玩多啦，因为这只任人打扮的兔子会杂技和魔术。

3D Desktop
  
[<img class="alignnone size-medium wp-image-90" title="screenshot 3D Desktop Ubuntu" src="http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-300x225.png" alt="screenshot 3D Desktop Ubuntu" width="300" height="225" />][1]

Windows Switcher
  
[<img class="alignnone size-medium wp-image-91" title="screenshot Windows Switcher Ubuntu" src="http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-5-300x225.png" alt="screenshot Windows Switcher Ubuntu" width="300" height="225" />][2]

Flame
  
[<img class="alignnone size-medium wp-image-92" title="screenshot Desktop Flame" src="http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-6-300x225.jpg" alt="screenshot Desktop Flame" width="300" height="225" />][3]

Google Earth & Real Player
  
[<img class="alignnone size-medium wp-image-93" title="screenshot Google Earth & Real Player" src="http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-3-300x225.png" alt="screenshot Google Earth & Real Player" width="300" height="225" />][4]

LumaQQ & Smplayer
  
[<img class="alignnone size-medium wp-image-94" title="screenshot LumaQQ & Smplayer" src="http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-1-300x225.jpg" alt="screenshot LumaQQ & Smplayer" width="300" height="225" />][5]

Desktop & Conky
  
[<img class="alignnone size-medium wp-image-95" title="screenshot Desktop & Conky" src="http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-2-300x225.png" alt="screenshot Desktop & Conky" width="300" height="225" />][6]

系统：Ubuntu 7.10 (gutsy)
  
特效：Compiz Fusion
  
壁纸：<a title="Sleep by Dabid Lanham" href="http://dlanham.com/art/sleep/" target="_blank">Sleep by David Lanham</a>
  
主题：Metacity
  
图标：<a title="Ubuntoon" href="http://www.gnome-look.org/content/show.php/GNUtoon%2BUbuntoon?content=70206" target="_blank">Ubuntoon</a>
  
配置：[Conky][7]

Compiz Fusion更牛逼效果完整展示(7分10秒)：

 [1]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot.png
 [2]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-5.png
 [3]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-6.jpg
 [4]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-3.png
 [5]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-1.jpg
 [6]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/screenshot-2.png
 [7]: http://www.xuchi.name/blog/wp-content/uploads/2008/05/.conkyrc~